/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/operators/common.hpp>

#include <cstring>
#include <limits>
#include <memory>
#include <vector>

namespace cugraph::ops::update_efeat_csc {

template <typename DataT, typename IdxT>
void naive_cpu_fwd_kernel(DataT* out,
                          const DataT* edge_feat,
                          const DataT* src_feat,
                          const DataT* dst_feat,
                          size_t dim_edge,
                          size_t dim_src,
                          size_t dim_dst,
                          const IdxT* offsets,
                          const IdxT* indices,
                          const IdxT* edge_idx,
                          const IdxT* graph_offsets,
                          const IdxT* batch_offsets,
                          const IdxT* nf_offsets,
                          const IdxT* ef_offsets,
                          size_t n_out_nodes,
                          size_t batch_size,
                          bool add_features)
{
  // for add, we implicitly assume dim_edge + dim_src + dim_dst
  auto out_stride = add_features ? dim_edge : (dim_edge + dim_src + dim_dst);
  auto acc        = std::make_unique<DataT[]>(out_stride);

  if (batch_offsets == nullptr) batch_size = 1;

  for (size_t batch = 0; batch < batch_size; ++batch) {
    auto batch_start = batch_offsets == nullptr ? IdxT{0} : graph_offsets[batch_offsets[batch]];
    auto batch_end =
      batch_offsets == nullptr ? n_out_nodes : graph_offsets[batch_offsets[batch] + 1];
    auto nf_offset = nf_offsets == nullptr ? IdxT{0} : nf_offsets[batch];
    auto ef_offset = ef_offsets == nullptr ? IdxT{0} : ef_offsets[batch];

    for (auto out_id = batch_start; out_id < batch_end; ++out_id) {
      auto off_start = offsets[out_id], off_end = offsets[out_id + 1];
      auto out_nf_id = out_id + nf_offset;

      // loop over neighbors
      for (auto neigh_off = off_start; neigh_off < off_end; ++neigh_off) {
        auto neigh    = indices[neigh_off];
        auto neigh_nf = neigh + nf_offset;
        auto eid = edge_idx == nullptr ? neigh_off + ef_offset : edge_idx[neigh_off] + ef_offset;

        // reset accumulators
        if (add_features) {
          for (size_t d = 0; d < out_stride; ++d) {
            acc[d] = DataT{0};

            if (edge_feat != nullptr) { acc[d] += edge_feat[eid * dim_edge + d]; }
            if (src_feat != nullptr) { acc[d] += src_feat[neigh_nf * dim_edge + d]; }
            if (dst_feat != nullptr) { acc[d] += dst_feat[out_nf_id * dim_edge + d]; }
          }
        } else {
          if (edge_feat != nullptr) {
            for (size_t d = 0; d < dim_edge; ++d) {
              acc[d] = edge_feat[eid * dim_edge + d];
            }
          }

          if (src_feat != nullptr) {
            for (size_t d = 0; d < dim_src; ++d) {
              acc[dim_edge + d] = src_feat[neigh_nf * dim_src + d];
            }
          }

          if (dst_feat != nullptr) {
            for (size_t d = 0; d < dim_dst; ++d) {
              acc[dim_edge + dim_src + d] = dst_feat[out_nf_id * dim_dst + d];
            }
          }
        }

        // output aggregated or concatenated values
        for (size_t d = 0; d < out_stride; ++d) {
          out[eid * out_stride + d] += acc[d];
        }
      }
    }
  }
}

template <typename DataT, typename IdxT>
void naive_cpu_bwd_kernel(DataT* grad_edge_feat,
                          DataT* grad_src_feat,
                          DataT* grad_dst_feat,
                          const DataT* grad_out,
                          size_t dim_edge,
                          size_t dim_src,
                          size_t dim_dst,
                          const IdxT* offsets,
                          const IdxT* indices,
                          const IdxT* edge_idx,
                          const IdxT* graph_offsets,
                          const IdxT* batch_offsets,
                          const IdxT* nf_offsets,
                          const IdxT* ef_offsets,
                          size_t n_in_nodes,
                          size_t n_out_nodes,
                          size_t n_edges,
                          size_t batch_size,
                          bool add_features)
{
  if (grad_edge_feat != nullptr) std::memset(grad_edge_feat, 0, n_edges * dim_edge * sizeof(DataT));
  if (grad_src_feat != nullptr) std::memset(grad_src_feat, 0, n_in_nodes * dim_src * sizeof(DataT));
  if (grad_dst_feat != nullptr && grad_src_feat != grad_dst_feat)
    std::memset(grad_dst_feat, 0, n_out_nodes * dim_dst * sizeof(DataT));

  auto dim_out    = dim_edge != 0 ? dim_edge : (dim_src != 0 ? dim_src : dim_dst);
  auto out_stride = add_features ? dim_out : (dim_edge + dim_src + dim_dst);

  if (batch_offsets == nullptr) batch_size = 1;

  for (size_t batch = 0; batch < batch_size; ++batch) {
    auto batch_start = batch_offsets == nullptr ? IdxT{0} : graph_offsets[batch_offsets[batch]];
    auto batch_end =
      batch_offsets == nullptr ? n_out_nodes : graph_offsets[batch_offsets[batch] + 1];
    auto nf_offset = nf_offsets == nullptr ? IdxT{0} : nf_offsets[batch];
    auto ef_offset = ef_offsets == nullptr ? IdxT{0} : ef_offsets[batch];

    for (auto out_id = batch_start; out_id < batch_end; ++out_id) {
      auto off_start = offsets[out_id], off_end = offsets[out_id + 1];
      auto out_nf_id = out_id + nf_offset;

      // loop over neighbors
      for (auto neigh_off = off_start; neigh_off < off_end; ++neigh_off) {
        auto neigh    = indices[neigh_off];
        auto neigh_nf = neigh + nf_offset;
        auto eid = edge_idx == nullptr ? neigh_off + ef_offset : edge_idx[neigh_off] + ef_offset;

        DataT grad;

        if (add_features) {
          for (size_t d = 0; d < dim_edge; ++d) {
            grad = grad_out[eid * dim_edge + d];
            if (grad_edge_feat != nullptr) { grad_edge_feat[eid * dim_edge + d] += grad; }
            if (grad_src_feat != nullptr) { grad_src_feat[neigh_nf * dim_edge + d] += grad; }
            if (grad_dst_feat != nullptr) { grad_dst_feat[out_nf_id * dim_edge + d] += grad; }
          }
        } else {
          // get gradient for edge_feat
          if (grad_edge_feat != nullptr) {
            for (size_t d = 0; d < dim_edge; ++d) {
              grad = grad_out[eid * out_stride + d];
              grad_edge_feat[eid * dim_edge + d] += grad;
            }
          }

          // get gradient for src_feat
          if (grad_src_feat != nullptr) {
            for (size_t d = 0; d < dim_src; ++d) {
              grad = grad_out[eid * out_stride + dim_edge + d];
              grad_src_feat[neigh_nf * dim_src + d] += grad;
            }
          }

          // get gradient for dst_feat
          if (grad_dst_feat != nullptr) {
            for (size_t d = 0; d < dim_dst; ++d) {
              grad = grad_out[eid * out_stride + dim_edge + dim_src + d];
              grad_dst_feat[out_nf_id * dim_dst + d] += grad;
            }
          }
        }
      }
    }
  }
}

}  // namespace cugraph::ops::update_efeat_csc
