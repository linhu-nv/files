/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/graph.hpp>

#include <cugraph-ops-test/activation_cpu.hpp>

#include <cugraph-ops/activation.hpp>
#include <cugraph-ops/operators/common.hpp>

#include <catch2/catch.hpp>

#include <cmath>
#include <cstring>
#include <memory>

namespace cugraph::ops::mha_gat_csc {

template <typename DataT, typename IdxT>
void naive_cpu_fwd_kernel(DataT* output,
                          DataT* sm_scores,
                          const DataT* src_feat,
                          const DataT* dst_feat,
                          const DataT* edge_feat,
                          const DataT* attn_weights,
                          const IdxT* offsets,
                          const IdxT* indices,
                          const IdxT* edge_idx,
                          const IdxT* graph_offsets,
                          const IdxT* batch_offsets,
                          const IdxT* nf_offsets,
                          const IdxT* ef_offsets,
                          IdxT n_dst_nodes,
                          IdxT n_indices,
                          int dim_node,
                          int dim_edge,
                          int batch_size,
                          const mha_params& params)
{
  // if we add own node, sm scores come after the edge sm sores of all edges
  auto n_edges      = n_indices;
  int dim_head      = dim_node / params.num_heads;
  int dim_head_edge = dim_edge / params.num_heads;
  DataT norm        = DataT{1} / static_cast<DataT>(params.num_heads);

  if (params.concat_heads) {
    std::memset(output, 0, n_dst_nodes * dim_node * sizeof(DataT));
  } else {
    std::memset(output, 0, n_dst_nodes * dim_head * sizeof(DataT));
  }
  static constexpr DataT ZERO = DataT{0};
  if (batch_offsets == nullptr) batch_size = 1;

  for (int batch = 0; batch < batch_size; ++batch) {
    auto batch_start = batch_offsets == nullptr ? IdxT{0} : graph_offsets[batch_offsets[batch]];
    auto batch_end =
      batch_offsets == nullptr ? n_dst_nodes : graph_offsets[batch_offsets[batch] + 1];
    auto nf_offset = nf_offsets == nullptr ? IdxT{0} : nf_offsets[batch];
    auto ef_offset = ef_offsets == nullptr ? IdxT{0} : ef_offsets[batch];

    for (auto out_id = batch_start; out_id < batch_end; ++out_id) {
      auto out_nf_id = out_id + nf_offset;
      auto off_start = offsets[out_id], off_end = offsets[out_id + 1];
      auto n_neighbors = off_end - off_start;
      auto scores      = std::make_unique<DataT[]>(n_neighbors);

      for (int h = 0; h < params.num_heads; ++h) {
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          scores[edge] = ZERO;
        }
        auto sm_off_pre  = h * n_edges;
        auto sm_off_post = (params.num_heads + h) * n_edges;
        // we calculate softmax manually here. first get all the scores
        for (int i = 0; i < dim_head; ++i) {
          auto h_i = h * dim_head + i;
          for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
            auto neigh     = off_start + edge;
            auto neigh_off = indices[neigh] + nf_offset;
            auto d         = attn_weights[h_i] * src_feat[neigh_off * dim_node + h_i];
            d += attn_weights[dim_node + h_i] * dst_feat[out_nf_id * dim_node + h_i];
            scores[edge] += d;
          }
        }
        if (edge_feat != nullptr) {
          for (int i = 0; i < dim_head_edge; ++i) {
            auto h_i = h * dim_head_edge + i;
            for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
              auto neigh = off_start + edge;
              auto eid   = edge_idx == nullptr ? neigh : edge_idx[neigh];
              auto d =
                attn_weights[2 * dim_node + h_i] * edge_feat[(eid + ef_offset) * dim_edge + h_i];
              scores[edge] += d;
            }
          }
        }
        // apply activation
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          scores[edge] = activation_fwd_cpu(params.activation, scores[edge]);
          // write back pre-sm (i.e. scores after activation)
          sm_scores[sm_off_pre + off_start + edge + ef_offset] = scores[edge];
        }
        // calculate the softmax (find max first, then subtract etc.)
        auto max_score = std::numeric_limits<DataT>::lowest();
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          if (scores[edge] > max_score) max_score = scores[edge];
        }
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          scores[edge] = std::exp(scores[edge] - max_score);
        }
        DataT sum_score = ZERO;
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          sum_score += scores[edge];
        }
        sum_score = DataT{1} / sum_score;
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          scores[edge] *= sum_score;
          sm_scores[sm_off_post + off_start + edge + ef_offset] = scores[edge];
        }
        // at this point we have the softmax scores
        // now we simply want to weight the source features using these
        for (int i = 0; i < dim_head; ++i) {
          auto h_i  = h * dim_head + i;
          DataT acc = ZERO;
          for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
            auto neigh_off = indices[off_start + edge] + nf_offset;
            acc += scores[edge] * src_feat[neigh_off * dim_node + h_i];
          }
          if (params.concat_heads) {
            output[out_nf_id * dim_node + h_i] += acc;
          } else {
            output[out_nf_id * dim_head + i] += acc * norm;
          }
        }
      }
    }
  }
}

template <typename DataT, typename IdxT>
void naive_cpu_bwd_kernel(DataT* d_src_feat,
                          DataT* d_dst_feat,
                          DataT* d_edge_feat,
                          DataT* d_attn_weights,
                          DataT* d_sm_scores,
                          const DataT* d_out,
                          const DataT* src_feat,
                          const DataT* dst_feat,
                          const DataT* edge_feat,
                          const DataT* attn_weights,
                          const DataT* sm_scores,
                          const IdxT* offsets,
                          const IdxT* indices,
                          const IdxT* edge_idx,
                          const IdxT* graph_offsets,
                          const IdxT* batch_offsets,
                          const IdxT* nf_offsets,
                          const IdxT* ef_offsets,
                          IdxT n_src_nodes,
                          IdxT n_dst_nodes,
                          IdxT n_indices,
                          int dim_node,
                          int dim_edge,
                          int batch_size,
                          const mha_params& params)
{
  auto n_edges                = n_indices;
  static constexpr DataT ZERO = DataT{0};
  int dim_head                = dim_node / params.num_heads;
  int dim_head_edge           = dim_edge / params.num_heads;
  DataT norm                  = DataT{1} / static_cast<DataT>(params.num_heads);

  if (batch_offsets == nullptr) batch_size = 1;
  auto dim_node_s = static_cast<size_t>(dim_node);
  std::memset(d_src_feat, 0, static_cast<size_t>(n_src_nodes) * dim_node_s * sizeof(DataT));
  std::memset(d_dst_feat, 0, static_cast<size_t>(n_dst_nodes) * dim_node_s * sizeof(DataT));
  std::memset(d_attn_weights, 0, 2 * dim_node_s * sizeof(DataT));
  if (edge_feat != nullptr) { std::memset(d_edge_feat, 0, n_indices * dim_edge * sizeof(DataT)); }

  for (int batch = 0; batch < batch_size; ++batch) {
    auto batch_start = batch_offsets == nullptr ? IdxT{0} : graph_offsets[batch_offsets[batch]];
    auto batch_end =
      batch_offsets == nullptr ? n_dst_nodes : graph_offsets[batch_offsets[batch] + 1];
    auto nf_offset = nf_offsets == nullptr ? IdxT{0} : nf_offsets[batch];
    auto ef_offset = ef_offsets == nullptr ? IdxT{0} : ef_offsets[batch];

    for (auto out_id = batch_start; out_id < batch_end; ++out_id) {
      auto out_nf_id = out_id + nf_offset;
      auto off_start = offsets[out_id], off_end = offsets[out_id + 1];
      auto n_neighbors = off_end - off_start;
      auto d_post      = std::make_unique<DataT[]>(n_neighbors);

      for (int h = 0; h < params.num_heads; ++h) {
        auto sm_off_pre  = h * n_edges;
        auto sm_off_post = (params.num_heads + h) * n_edges;
        // first get all the post SM gradients
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          d_post[edge]   = ZERO;
          auto neigh_off = indices[off_start + edge];
          neigh_off += nf_offset;
          for (int i = 0; i < dim_head; ++i) {
            auto h_i = h * dim_head + i;
            if (params.concat_heads) {
              d_post[edge] +=
                d_out[out_nf_id * dim_node + h_i] * src_feat[neigh_off * dim_node + h_i];
            } else {
              d_post[edge] +=
                (d_out[out_nf_id * dim_head + i] * norm) * src_feat[neigh_off * dim_node + h_i];
            }
          }
          d_sm_scores[sm_off_post + off_start + edge + ef_offset] = d_post[edge];
        }
        // calculate gradients before softmax (given out/attn node and head)
        for (IdxT edge = IdxT{0}; edge < n_neighbors; ++edge) {
          auto neigh_off = indices[off_start + edge];
          neigh_off += nf_offset;
          auto d_pre    = ZERO;
          auto sm_score = sm_scores[sm_off_post + off_start + edge + ef_offset];
          for (IdxT edge_j = IdxT{0}; edge_j < n_neighbors; ++edge_j) {
            auto sm_score_j = sm_scores[sm_off_post + off_start + edge_j + ef_offset];
            auto d          = edge == edge_j ? DataT{1} : ZERO;
            auto d_sm_local = sm_score * (d - sm_score_j);
            d_pre += d_sm_local * d_post[edge_j];
          }
          d_sm_scores[sm_off_pre + off_start + edge + ef_offset] = d_pre;

          // backward of activation
          auto sm_score_j = sm_scores[sm_off_pre + off_start + edge + ef_offset];
          d_pre *= activation_bwd_cpu(params.activation, sm_score_j);
          // accumulate gradients based on gradients before softmax
          for (int i = 0; i < dim_head; ++i) {
            auto h_i = h * dim_head + i;
            if (params.concat_heads) {
              d_src_feat[neigh_off * dim_node + h_i] +=
                d_out[out_nf_id * dim_node + h_i] * sm_score;
            } else {
              d_src_feat[neigh_off * dim_node + h_i] +=
                (d_out[out_nf_id * dim_head + i] * norm) * sm_score;
            }
            d_src_feat[neigh_off * dim_node + h_i] += d_pre * attn_weights[h_i];
            d_dst_feat[out_nf_id * dim_node + h_i] += d_pre * attn_weights[dim_node + h_i];
            d_attn_weights[h_i] += d_pre * src_feat[neigh_off * dim_node + h_i];
            d_attn_weights[dim_node + h_i] += d_pre * dst_feat[out_nf_id * dim_node + h_i];
          }
          if (edge_feat != nullptr) {
            for (int i = 0; i < dim_head_edge; ++i) {
              auto h_i   = h * dim_head_edge + i;
              auto neigh = off_start + edge;
              auto eid   = edge_idx == nullptr ? neigh : edge_idx[neigh];
              d_edge_feat[(eid + ef_offset) * dim_edge + h_i] +=
                d_pre * attn_weights[2 * dim_node + h_i];
              d_attn_weights[2 * dim_node + h_i] +=
                d_pre * edge_feat[(eid + ef_offset) * dim_edge + h_i];
            }
          }
        }
      }
    }
  }
}

}  // namespace cugraph::ops::mha_gat_csc
