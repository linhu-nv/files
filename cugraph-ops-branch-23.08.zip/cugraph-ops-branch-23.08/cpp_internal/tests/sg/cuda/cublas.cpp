/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cublas_wrappers.hpp>

#include <cugraph-ops/cuda/cublas.hpp>
#include <cugraph-ops/utils/error.hpp>

#include <catch2/catch.hpp>

namespace cugraph::ops::cuda {

TEST_CASE("cublashandle")
{
  cublashandle ch;

  cublasHandle_t h;
  RAFT_CUBLAS_TRY(cublasCreate(&h));
  cublashandle ch1(h);
  RAFT_CUBLAS_TRY(cublasDestroy(h));
}

}  // namespace cugraph::ops::cuda
