/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cudart.hpp>

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/utils/error.hpp>

#include <catch2/catch.hpp>

namespace cugraph::ops::cuda {

TEST_CASE("stream")
{
  stream st;
  REQUIRE_NOTHROW(st.sync());
  REQUIRE_NOTHROW(utils::sync(st()));
  stream st1(st);
  REQUIRE_NOTHROW(st1.sync());
  REQUIRE_NOTHROW(utils::sync(st1()));

  cudaStream_t custr;
  RAFT_CUDA_TRY(cudaStreamCreate(&custr));
  stream st2(custr);
  REQUIRE_NOTHROW(st2.sync());
  REQUIRE_NOTHROW(utils::sync(st2()));
  RAFT_CUDA_TRY(cudaStreamDestroy(custr));
}

}  // namespace cugraph::ops::cuda
