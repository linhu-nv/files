/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/io/ogbg_reader.hpp>

#include <catch2/catch.hpp>

#include <cstdlib>
#include <memory>

namespace cugraph::ops::io {

std::shared_ptr<ogbg_cpu> load_dataset(const char* raw_dir_env, bool is_undirected)
{
  std::shared_ptr<ogbg_cpu> ogbg_ptr;
  auto* path = std::getenv(raw_dir_env);
  if (path != nullptr) {
    const std::string raw_dir{path};
    return std::make_shared<ogbg_cpu>(raw_dir, is_undirected);
  }
  return {};
}

void verify_dataset_memory(const char* raw_dir_env,
                           bool is_undirected,
                           cudaMemoryType feats_mem_type,
                           cudaMemoryType graph_mem_type)
{
  auto* path = std::getenv(raw_dir_env);
  if (path != nullptr) {
    const std::string raw_dir{path};
    std::shared_ptr<ogbg_cuda> ogbg_ptr =
      std::make_shared<ogbg_cuda>(raw_dir, is_undirected, feats_mem_type, graph_mem_type);

    cudaPointerAttributes attributes;

    cudaPointerGetAttributes(&attributes, ogbg_ptr->node_features);
    REQUIRE(attributes.type == feats_mem_type);
    cudaPointerGetAttributes(&attributes, ogbg_ptr->edge_features);
    REQUIRE(attributes.type == feats_mem_type);
    cudaPointerGetAttributes(&attributes, ogbg_ptr->labels);
    REQUIRE(attributes.type == feats_mem_type);

    cudaPointerGetAttributes(&attributes, ogbg_ptr->graph->offsets);
    REQUIRE(attributes.type == graph_mem_type);
    cudaPointerGetAttributes(&attributes, ogbg_ptr->graph->indices);
    REQUIRE(attributes.type == graph_mem_type);
    cudaPointerGetAttributes(&attributes, ogbg_ptr->graph->graph_offsets);
    REQUIRE(attributes.type == graph_mem_type);
    cudaPointerGetAttributes(&attributes, ogbg_ptr->graph->ef_indices);
    REQUIRE(attributes.type == graph_mem_type);
    cudaPointerGetAttributes(&attributes, ogbg_ptr->graph->rev_edge_ids);
    REQUIRE(attributes.type == graph_mem_type);
  }
}

TEST_CASE("ogbg_hiv") { REQUIRE_NOTHROW(load_dataset("OGBG_HIV_RAW_DIR", true)); }

TEST_CASE("ogbg_hiv_host_host")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeHost,
                        cudaMemoryType::cudaMemoryTypeHost);
}

TEST_CASE("ogbg_hiv_host_device")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeHost,
                        cudaMemoryType::cudaMemoryTypeDevice);
}

TEST_CASE("ogbg_hiv_host_managed")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeHost,
                        cudaMemoryType::cudaMemoryTypeManaged);
}

TEST_CASE("ogbg_hiv_device_host")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeDevice,
                        cudaMemoryType::cudaMemoryTypeHost);
}

TEST_CASE("ogbg_hiv_device_device")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeDevice,
                        cudaMemoryType::cudaMemoryTypeDevice);
}

TEST_CASE("ogbg_hiv_device_managed")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeDevice,
                        cudaMemoryType::cudaMemoryTypeManaged);
}

TEST_CASE("ogbg_hiv_managed_host")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeManaged,
                        cudaMemoryType::cudaMemoryTypeHost);
}

TEST_CASE("ogbg_hiv_managed_device")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeManaged,
                        cudaMemoryType::cudaMemoryTypeDevice);
}

TEST_CASE("ogbg_hiv_managed_managed")
{
  verify_dataset_memory("OGBG_HIV_RAW_DIR",
                        true,
                        cudaMemoryType::cudaMemoryTypeManaged,
                        cudaMemoryType::cudaMemoryTypeManaged);
}

}  // namespace cugraph::ops::io
