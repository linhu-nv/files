/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cstdlib>
#include <cugraph-ops/io/ogbn_reader.hpp>
#include <memory>

#include <catch2/catch.hpp>

namespace cugraph::ops::io {

std::shared_ptr<ogbn_cpu> load_dataset(const char* raw_dir_env,
                                       int n_nodes,
                                       int n_cols,
                                       bool is_undirected)
{
  std::shared_ptr<ogbn_cpu> ogbn_ptr;
  auto* path = std::getenv(raw_dir_env);
  if (path != nullptr) {
    const std::string raw_dir{path};
    return std::make_shared<ogbn_cpu>(raw_dir, n_nodes, n_cols, is_undirected);
  }
  return {};
}

void verify_dataset_memory(const char* raw_dir_env,
                           int n_nodes,
                           int n_cols,
                           bool is_undirected,
                           cudaMemoryType feats_mem_type,
                           cudaMemoryType graph_mem_type)
{
  auto* path = std::getenv(raw_dir_env);
  if (path != nullptr) {
    const std::string raw_dir{path};
    std::shared_ptr<ogbn_cuda> ogbn_ptr = std::make_shared<ogbn_cuda>(
      raw_dir, n_nodes, n_cols, is_undirected, feats_mem_type, graph_mem_type);

    cudaPointerAttributes attributes;

    cudaPointerGetAttributes(&attributes, ogbn_ptr->features);
    REQUIRE(attributes.type == feats_mem_type);

    cudaPointerGetAttributes(&attributes, ogbn_ptr->labels);
    REQUIRE(attributes.type == feats_mem_type);

    cudaPointerGetAttributes(&attributes, ogbn_ptr->graph->offsets);
    REQUIRE(attributes.type == graph_mem_type);

    cudaPointerGetAttributes(&attributes, ogbn_ptr->graph->indices);
    REQUIRE(attributes.type == graph_mem_type);

    if (ogbn_ptr->is_hg) {
      auto* graph_hg = dynamic_cast<fg_csr_hg_s64_t*>(ogbn_ptr->graph.get());
      ASSERT(graph_hg != nullptr,
             "Fatal: expected hetero-graph in ogbn::cuda "
             "destructor but got nullptr.");
      cudaPointerGetAttributes(&attributes, graph_hg->edge_types);
      REQUIRE(attributes.type == graph_mem_type);

      cudaPointerGetAttributes(&attributes, graph_hg->node_types);
      REQUIRE(attributes.type == graph_mem_type);
    }
  }
}

struct products {
  static constexpr int NODES = 2449029;
  static constexpr int COLS  = 100;
};

TEST_CASE("ogbn_products")
{
  REQUIRE_NOTHROW(load_dataset("OGBN_PRODUCTS_RAW_DIR", products::NODES, products::COLS, true));
}

struct arxiv {
  static constexpr int NODES = 169343;
  static constexpr int COLS  = 128;
};

TEST_CASE("ogbn_arxiv")
{
  REQUIRE_NOTHROW(load_dataset("OGBN_ARXIV_RAW_DIR", arxiv::NODES, arxiv::COLS, false));
}

TEST_CASE("ogbn_arxiv_host_host")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeHost,
                        cudaMemoryType::cudaMemoryTypeHost);
}

TEST_CASE("ogbn_arxiv_host_device")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeHost,
                        cudaMemoryType::cudaMemoryTypeDevice);
}

TEST_CASE("ogbn_arxiv_host_managed")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeHost,
                        cudaMemoryType::cudaMemoryTypeManaged);
}

TEST_CASE("ogbn_arxiv_device_host")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeDevice,
                        cudaMemoryType::cudaMemoryTypeHost);
}

TEST_CASE("ogbn_arxiv_device_device")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeDevice,
                        cudaMemoryType::cudaMemoryTypeDevice);
}

TEST_CASE("ogbn_arxiv_device_managed")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeDevice,
                        cudaMemoryType::cudaMemoryTypeManaged);
}

TEST_CASE("ogbn_arxiv_managed_host")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeManaged,
                        cudaMemoryType::cudaMemoryTypeHost);
}

TEST_CASE("ogbn_arxiv_managed_device")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeManaged,
                        cudaMemoryType::cudaMemoryTypeDevice);
}

TEST_CASE("ogbn_arxiv_managed_managed")
{
  verify_dataset_memory("OGBN_ARXIV_RAW_DIR",
                        arxiv::NODES,
                        arxiv::COLS,
                        false,
                        cudaMemoryType::cudaMemoryTypeManaged,
                        cudaMemoryType::cudaMemoryTypeManaged);
}

}  // namespace cugraph::ops::io
