/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/graph/format.hpp>

#include <cuda_runtime.h>

#include <cstdint>

namespace cugraph::ops::graph {

/**
 * @brief Renumber the id's in the MFG such that the values of output nodes
 *        and neighbors refer to the indices of input nodes.
 *
 * This allows dense computations on messages after flowing through the MFG.
 *
 * @param[out]   mfg        the (ELLPACK/CSR) MFG to renumber.
 *                          In particular, we use the `in_nodes` array below as
 *                          reference and output the renumbered values to the
 *                          `out_nodes` and `neighbors` / `indices` fields.
 * @param[out]   counts     occurence count of every ID in the `neighbors`
 *                          matrix, indexed as per the `in_nodes` array.
 *                          [on device] [len = `mfg.n_in_nodes`]
 *                          Ignored if set to `nullptr`.
 * @param[in]    in_nodes   The `in_nodes` array used as a reference [on device]
 *                          [len = `mfg.n_in_nodes`]
 *                          [on device] [len = `mfg.n_out_nodes`]
 * @param[in]    init_nodes initial nodes used to renumber `out_nodes`
 *                          [on device] [len = `mfg.n_out_nodes`]
 * @param[in]    stream     cuda stream where to schedule work
 *
 * @{
 */
void renumber(mfg_ellpack_s32_t& mfg,
              int32_t* counts,
              const int32_t* in_nodes,
              const int32_t* init_nodes,
              cudaStream_t stream);
void renumber(mfg_ellpack_s64_t& mfg,
              int64_t* counts,
              const int64_t* in_nodes,
              const int64_t* init_nodes,
              cudaStream_t stream);
void renumber(mfg_csr_s32_t& mfg,
              int32_t* counts,
              const int32_t* in_nodes,
              const int32_t* init_nodes,
              cudaStream_t stream);
void renumber(mfg_csr_s64_t& mfg,
              int64_t* counts,
              const int64_t* in_nodes,
              const int64_t* init_nodes,
              cudaStream_t stream);
/** @} */

}  // namespace cugraph::ops::graph
