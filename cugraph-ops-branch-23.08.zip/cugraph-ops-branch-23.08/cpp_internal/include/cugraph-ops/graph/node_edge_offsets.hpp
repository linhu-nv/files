/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/graph/format.hpp>

#include <cuda_runtime.h>

#include <cstdint>

namespace cugraph::ops::graph {

/**
 * @brief Generates the node and edge offsets required during graph batching operation
 *
 * @param[out]   node_offsets    start offsets for the nodes in each graph. [on device]
 *                               [len = `batch_size`]
 * @param[out]   edge_offsets    start offsets for the edges in each graph. [on device]
 *                               [len = `batch_size`]
 * @param[out]   n_nodes         total number of nodes in batch. If this is `nullptr`,
 *                               it is not calculated [on device/pinned] [len = `1`]
 * @param[out]   n_edges         total number of edges in batch. If this is `nullptr`,
 *                               it is not calculated [on device/pinned] [len = `1`]
 * @param[in]    batch_size      number of graphs in the current batch
 * @param[in]    batch_offsets   ids of the graphs in the current batch. [on device]
 *                               [len = `batch_size`]
 * @param[in]    graph_offsets   offsets of all graphs within CSR `offsets`. [on device]
 *                               [len = `n_all_graphs`]
 * @param[in]    offsets         CSR offsets of all graphs. [on device]
 *                               [len = `n_all_nodes`]
 * @param[in]    workspace       workspace for computation. [on device]
 *                               [len = `workspace_size`]. Pass a `nullptr` and
 *                               get the workspace size to be allocated.
 * @param[inout] workspace_size  workspace size (in B)
 * @param[in]    stream          cuda stream
 * @{
 */
void node_edge_offsets(int32_t* node_offsets,
                       int32_t* edge_offsets,
                       int32_t* n_nodes,
                       int32_t* n_edges,
                       int32_t batch_size,
                       const int32_t* batch_offsets,
                       const int32_t* graph_offsets,
                       const int32_t* offsets,
                       void* workspace,
                       size_t& workspace_size,
                       cudaStream_t stream);
void node_edge_offsets(int64_t* node_offsets,
                       int64_t* edge_offsets,
                       int64_t* n_nodes,
                       int64_t* n_edges,
                       int64_t batch_size,
                       const int64_t* batch_offsets,
                       const int64_t* graph_offsets,
                       const int64_t* offsets,
                       void* workspace,
                       size_t& workspace_size,
                       cudaStream_t stream);
/** @} */

}  // namespace cugraph::ops::graph
