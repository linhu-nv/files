/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cublas_v2.h>

namespace cugraph::ops::cuda {

/**
 * @brief A simple wrapper class for `cublasHandle_t`
 */
class cublashandle {
 public:
  /** Creates a new cublas handle and owns it's lifetime */
  cublashandle();

  /**
   * @brief This will just compose the cublas handle but not own it
   *
   * @note we don't mark this as explicit since we want to allow implicitly
   *       converting `nullptr` or any handle to a non-owned handle
   *
   * @param[in] h cublas handle
   */
  cublashandle(cublasHandle_t h);  // NOLINT(google-explicit-constructor)

  /**
   * @brief This will just compose the cublas handle but not own it
   *
   * @param[in] other cublas handle
   */
  cublashandle(const cublashandle& other);

  /** this destroys our handle if owned and composes other, but not own it */
  cublashandle& operator=(const cublashandle& other);

  /** destroy the cublas handle if it is owned by this class */
  ~cublashandle();

  /** returns the underlying raw handle */
  cublasHandle_t operator()() const { return h_; }

 private:
  /** whether the underlying cublas handle's lifetime is owned by this class */
  bool is_owned_{false};
  /** the cublas handle */
  cublasHandle_t h_{nullptr};
};  // class stream

}  // namespace cugraph::ops::cuda
