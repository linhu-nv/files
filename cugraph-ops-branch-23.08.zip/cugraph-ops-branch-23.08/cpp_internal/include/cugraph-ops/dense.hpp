/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cuda_runtime.h>

#include <cugraph-ops/activation.hpp>
#include <cugraph-ops/cuda/cublas.hpp>
#include <cugraph-ops/cuda/stream.hpp>

#include <raft/random/rng_state.hpp>

namespace cugraph::ops {

/**
 * @brief gemm operation needed for the forward pass of dense layer of GNNs
 *
 * @param[out]   out      final output. [dim = `m x ldc`] [on device] [row major]
 *                        If this is `nullptr`, then the output `c` is considered
 *                        to be the final output. This also means no bias and
 *                        activations are applied in this layer.
 * @param[out]   c        intermediate output of gemm. [dim = `m x ldc`]
 *                        [on device] [row major]
 * @param[in]    ldc      leading dimension for this matrix
 * @param[in]    a        first matrix. [dim = `m x lda`] [on device] [row major]
 * @param[in]    lda      leading dimension for this matrix
 * @param[in]    b        second matrix. [dim = `m x ldb`] [on device] [row major]
 * @param[in]    ldb      leading dimension for this matrix
 * @param[in]    bias     bias vector. [len = `n`] [on device] [row major].
 *                        If it is not required, pass a `nullptr`.
 * @param[in]    m        gemm m
 * @param[in]    n        gemm n
 * @param[in]    k        gemm k
 * @param[in]    aparams  activation parameters
 * @param[out]   drop_v   dropout cache. [len = 2] [on host]
 *                        If `nullptr`, no dropout is applied.
 * @param[in]    p_drop   dropout probability. Ignored if `drop_v := nullptr`
 * @param[inout] r        RAFT RngState object. Ignored if `drop_v := nullptr`
 * @param[in]    handle   cublas handle
 * @param[in]    stream   cuda stream
 *
 * @{
 */
void dense_fwd(float* out,
               float* c,
               int ldc,
               const float* a,
               int lda,
               const float* b,
               int ldb,
               const float* bias,
               int m,
               int n,
               int k,
               const activation_params& aparams,
               uint64_t* drop_v,
               float p_drop,
               raft::random::RngState* r,
               const cuda::cublashandle& handle,
               const cuda::stream& stream);
/** @} */

/**
 * @brief gemm operation needed for the backward pass of dense layer of GNNs
 *
 * @param[out] da       data gradient for the input during fwd pass.
 *                      [on device] [dim = `m x lda`] [row major].
 * @param[out] db       aka weight gradient. [on device] [dim = `m x ldb`]
 *                      [row major].
 * @param[out] dbias    bias gradient [on device] [len = `n`]. If `bias` is a
 *                      `nullptr`, then this is also expected to be nullptr.
 * @param[out] dgrad    output data gradient for the bias activation layer
 *                      [on device] [dim = `m x ldc`] [row major]. It will be
 *                      unused, if `out` were to be `nullptr`.
 * @param[in]  dout     input gradient [on device] [dim = `m x ldc`] [row major]
 * @param[in]  out      output during fwd pass. [on device] [dim = `m x ldc`]
 *                      [row major]. If this was passed as `nullptr` during the
 *                      fwd call, then during backward, no gradients will be
 *                      computed for bias and activation.
 * @param[in]  c        output of gemm during fwd pass. [on device]
 *                      [dim = `m x ldc`] [row major]
 * @param[in]  ldc      leading dimension for this matrix
 * @param[in]  a        first matrix. [on device] [dim = `m x k`] [row major].
 * @param[in]  lda      leading dimension for this matrix
 * @param[in]  b        second matrix. [on device] [dim = `n x k`] [row major].
 * @param[in]  ldb      leading dimension for this matrix
 * @param[in]  bias     optional bias vector. [on device] [len = `n`].
 *                      If bias is not required, pass a `nullptr`.
 * @param[in]  m        gemm m
 * @param[in]  n        gemm n
 * @param[in]  k        gemm k
 * @param[in]  aparams  activation parameters
 * @param[in]  drop_v   dropout cache from forward pass. [on host] [len = 2].
 *                      If dropout not required, pass `nullptr`
 * @param[in]  p_drop   dropout probability. Ignored if `drop_v := nullptr`
 * @param[in]  handle   cublas handle
 * @param[in]  stream   cuda stream
 *
 * @{
 */
void dense_bwd(float* da,
               float* db,
               float* dbias,
               float* dgrad,
               const float* dout,
               const float* out,
               const float* c,
               int ldc,
               const float* a,
               int lda,
               const float* b,
               int ldb,
               const float* bias,
               int m,
               int n,
               int k,
               const activation_params& aparams,
               const uint64_t* drop_v,
               float p_drop,
               const cuda::cublashandle& handle,
               const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops
