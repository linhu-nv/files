/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cuda_runtime.h>

#include <cugraph-ops/activation.hpp>
#include <cugraph-ops/cuda/stream.hpp>

#include <raft/random/rng_state.hpp>

namespace cugraph::ops {

/**
 * @brief Fused bias + activation layer forward pass
 *
 * @param[out]   out     output matrix [on device] [dim = `m x ld`] [row major]
 * @param[in]    in      input matrix [on device] [dim = `m x ld`] [row major]
 * @param[in]    bias    optional bias vector. [on device] [len = `n`].
 *                       If bias is not required, pass a `nullptr`.
 * @param[in]    m       number of rows of the matrices
 * @param[in]    n       number of columns of the matrices
 * @param[in]    ld      leading dimension of the matrices
 * @param[out]   drop_v  dropout values for backward [on host] [len = 2].
 *                       If `nullptr`, dropout is ignored.
 * @param[in]    p_drop  dropout probability. Ignored if `drop_v := nullptr`
 * @param[inout] r       RAFT RngState object for dropout.
 *                       Ignored if `drop_v := nullptr`
 * @param[in]    aparams activation parameters
 * @param[in]    stream  cuda stream
 *
 * @{
 */
void bias_activation_fwd(float* out,
                         const float* in,
                         const float* bias,
                         int m,
                         int n,
                         int ld,
                         const activation_params& aparams,
                         uint64_t* drop_v,
                         float p_drop,
                         raft::random::RngState* r,
                         const cuda::stream& stream);
/** @} */

/**
 * @brief Fused bias + activation layer backward pass
 *
 * @param[out] din     data gradient for the input during forward pass
 *                     [on device] [dim = `m x ld`] [row major].
 * @param[out] dbias   bias gradient [on device] [len = `n`]
 * @param[in]  dout    input gradient [on device] [dim = `m x ld`] [row major]
 * @param[in]  out     output matrix during the fwd pass [on device]
 *                     [dim = `m x ld`] [row major]
 * @param[in]  in      input matrix [on device] [dim = `m x ld`] [row major]
 * @param[in]  bias    optional bias vector. [on device] [len = `n`]. If bias is
 *                     not required, pass a `nullptr`.
 * @param[in]  m       number of rows of the matrices
 * @param[in]  n       number of columns of the matrices
 * @param[in]  ld      leading dimension of the matrices
 * @param[in]  aparams activation parameters
 * @param[in]  drop_v  dropout values from forward pass.
 *                     If dropout is not required, pass a `nullptr`
 * @param[in]  p_drop  dropout probability. Ignored if `drop_v := nullptr`
 * @param[in]  stream  cuda stream
 *
 * @{
 */
void bias_activation_bwd(float* din,
                         float* dbias,
                         const float* dout,
                         const float* out,
                         const float* in,
                         const float* bias,
                         int m,
                         int n,
                         int ld,
                         const activation_params& aparams,
                         const uint64_t* drop_v,
                         float p_drop,
                         const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops
