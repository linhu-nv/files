/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/utils/allocator.hpp>

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace cugraph::ops::io {

/**
 * @brief A container to hold OGB graph property prediction datasets.
 *        (for CPU-use only)
 */
struct ogbg_cpu {
  /**
   * edge indices (as in CSR format). The edges across the graphs are just
   * stored contiguously, one after the other
   */
  std::vector<int64_t> indices;
  /** See `fg_csr::ef_indices` */
  std::vector<int64_t> ef_indices;
  /** See `fg_csr::rev_edge_ids` */
  std::vector<int64_t> rev_edge_ids;
  /**
   * row offsets (as in CSR format). Like `indices`, these will also have the
   * adjacent graph's row offsets stored contiguously. Each element in this
   * array points to the start of the corresponding adjacency list in the above
   * `indices` array
   */
  std::vector<int64_t> row_offsets;
  /**
   * graph offsets. Each element in this array points to the start of the
   * corresponding row offset for that graph
   */
  std::vector<int64_t> graph_offsets;
  /** all node features */
  std::vector<float> node_features;
  /** all edge feature */
  std::vector<float> edge_features;
  /** graph labels */
  std::vector<int32_t> labels;

  /** total number of graphs */
  int64_t n_graphs;
  /** node feature dimension */
  int64_t n_cols_nodes;
  /** edge feature dimension */
  int64_t n_cols_edges;
  /** total number of unique edges as seen in the input dataset */
  int64_t n_uniq_edges;
  /** whether the input graph is supposed to be undirected */
  bool is_undirected;

  /**
   * @brief Read the graphs and their contents from the raw directory
   *
   * @param[in] raw_dir        the 'raw' directory after downloading and
   *                           extracting the dataset.
   * @param[in] _is_undirected whether the input graphs are supposed to be
   *                           undirected, if yes, then the reverse edges will
   *                           be added to simplify the later pipelines
   */
  explicit ogbg_cpu(const std::string& raw_dir, bool _is_undirected);

  /**
   * @brief Dumps the contents of this graph dataset into a binary file for a
   *        faster loading later.
   *
   * @param[in] file output (gzipped) file containing the dataset
   */
  void dump(const std::string& file) const;

 private:
  void read(const std::string& raw_dir);

};  // struct ogbg_cpu

/** input dataset as accessible from CUDA devices */
struct ogbg_cuda {
  /** graph */
  std::unique_ptr<fg_csr_seq_s64_t> graph;
  /** input node feature dimension */
  int64_t n_cols_nodes;
  /** input edge feature dimension */
  int64_t n_cols_edges;
  /**
   * number of labels (may be smaller than number of graphs)
   * we always assume that the first `n_labels` nodes are labeled
   */
  int64_t n_labels;
  /** total number of graphs */
  int64_t n_graphs;
  /** total number of nodes */
  int64_t n_nodes;
  /** total number of unique edges as seen in the input dataset */
  int64_t n_uniq_edges;

  /** node features */
  float* node_features;
  /** edge features */
  float* edge_features;
  /** graph labels */
  int32_t* labels;

  /** memory type of features and graphs **/
  cudaMemoryType feats_mem_type;
  cudaMemoryType graph_mem_type;

  /**
   * @brief Read the graphs and their contents from the raw directory
   *
   * @param[in] raw_dir        the 'raw' directory after downloading and
   *                           extracting the dataset.
   * @param[in] _is_undirected whether the input graphs are supposed to be
   *                           undirected, if yes, then the reverse edges will
   *                           be added to simplify the later pipelines
   * @param[in] _feats_mem_type  memory type of feature-related buffers (in GPU context)
   * @param[in] _graph_mem_type  memory type of feature-related buffers (in GPU context)
   */
  explicit ogbg_cuda(const std::string& raw_dir,
                     bool _is_undirected,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type);

  ~ogbg_cuda();

  /** don't allow copying */
  ogbg_cuda(const ogbg_cuda&)            = delete;
  ogbg_cuda& operator=(const ogbg_cuda&) = delete;

 private:
  void read(const std::string& raw_dir);
};  // struct ogbg_cuda

}  // namespace cugraph::ops::io
