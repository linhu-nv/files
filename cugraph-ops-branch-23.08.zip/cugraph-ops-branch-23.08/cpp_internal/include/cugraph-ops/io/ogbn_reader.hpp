/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/utils/allocator.hpp>

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace cugraph::ops::io {

/**
 * @brief A container to hold OGB node property prediction datasets (for CPU-use only)
 */
struct ogbn_cpu {
  /** edge indices (as in CSR format) */
  std::vector<int64_t> indices;
  /** row offsets (as in CSR format) */
  std::vector<int64_t> offsets;
  /** all features (aka i/p embeddings) */
  std::vector<float> features;
  /** node labels */
  std::vector<int32_t> labels;
  /** edge types (only for heterogeneous graphs, same length as indices) */
  std::vector<int32_t> edge_types;
  /** node types (only for heterogeneous graphs, same length as offsets) */
  std::vector<int32_t> node_types;

  /** total number of nodes in the graph */
  int64_t n_nodes;
  /** feature dimension */
  int64_t n_cols;
  /** whether the input graph is supposed to be undirected */
  bool is_undirected;
  /** whether the input graph is a heterogeneous graph */
  bool is_hg;
  /** number of node types (only relevant if `is_hg`) */
  int32_t n_node_types;
  /** number of edge types (only relevant if `is_hg`) */
  int32_t n_edge_types;

  /**
   * @brief Read the graph contents from the raw directory
   *
   * @param[in] raw_dir        the 'raw' directory after downloading and
   *                           extracting the dataset.
   * @param[in] _n_nodes         total number of nodes in the dataset
   * @param[in] _n_cols        dimension of input embeddinga
   * @param[in] _is_undirected whether the input graph is supposed to be
   *                           undirected, if yes, then the reverse edges will
   *                           be added to simplify the later pipelines
   */
  explicit ogbn_cpu(const std::string& raw_dir,
                    int64_t _n_nodes,
                    int64_t _n_cols,
                    bool _is_undirected);

  /**
   * @brief Read the heterogeneous graph contents from the raw directory
   *
   * @param[in] raw_dir        the 'raw' directory after downloading and
   *                           extracting the dataset.
   * @param[in] _n_nodes         total number of nodes in the dataset
   * @param[in] _n_cols      dimension of input embeddinga
   * @param[in] _is_undirected whether the input graph is supposed to be
   *                           undirected, if yes, then the reverse edges will
   *                           be added to simplify the later pipelines
   * @param[in] _n_node_types  number of node types in the input graph
   * @param[in] _n_edge_types  number of edge types in the input graph
   */
  explicit ogbn_cpu(const std::string& raw_dir,
                    int64_t _n_nodes,
                    int64_t _n_cols,
                    bool _is_undirected,
                    int32_t _n_node_types,
                    int32_t _n_edge_types);

  /**
   * @brief Dumps the contents of this graph dataset into a binary file for a
   *        faster loading later.
   *
   * @param[in] file output (gzipped) file containing the dataset
   */
  void dump(const std::string& file);

 private:
  void read(const std::string& raw_dir);
};  // struct ogbn_cpu

/**
 * @brief A container to hold OGB nodes datasets accessible from CUDA devices.
 *        (But currently has only been used for `ogbn-products` dataset)
 */
struct ogbn_cuda {
  /** total number of nodes in the graph */
  int64_t n_nodes;
  /** feature dimension */
  int64_t n_cols;
  /**
   * number of labels (may be smaller than number of nodes)
   * we always assume that the first `n_labels` nodes are labeled
   */
  int64_t n_labels;
  /** graph */
  std::unique_ptr<fg_csr_s64_t> graph;
  /** node features */
  float* features;
  /** node labels */
  int32_t* labels;
  /** whether the input graph is a heterogeneous graph */
  bool is_hg;

  /** memory type of features and graphs **/
  cudaMemoryType feats_mem_type;
  cudaMemoryType graph_mem_type;

  /**
   * @brief Read the graph contents from the raw directory and make the graph structure accessible
   *        to CUDA devices as specified.
   *
   * @param[in] raw_dir         the 'raw' directory after downloading and
   *                            extracting the dataset.
   * @param[in] _n_nodes        total number of nodes
   * @param[in] _n_cols         feature dimension
   * @param[in] _is_undirected  whether the input graph is supposed to be
   *                            undirected, if yes, then the reverse edges will
   *                            be added to simplify the later pipelines
   * @param[in] _resize_factor  only relevant when graph is desired that is artifically
   *                            increased through redundant connected components
   *                            resize_factor then specifies the number of connected components
   * @param[in] _feats_mem_type memory type of feature-related buffers (in GPU context)
   * @param[in] _graph_mem_type memory type of feature-related buffers (in GPU context)
   */
  explicit ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     uint16_t _resize_factor,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type);

  /**
   * @brief Read the graph contents from the raw directory and make the graph structure accessible
   *        to CUDA devices as specified.
   *
   * @param[in] raw_dir         the 'raw' directory after downloading and
   *                            extracting the dataset.
   * @param[in] _n_nodes        total number of nodes
   * @param[in] _n_cols         feature dimension
   * @param[in] _is_undirected  whether the input graph is supposed to be
   *                            undirected, if yes, then the reverse edges will
   *                            be added to simplify the later pipelines
   * @param[in] _feats_mem_type memory type of feature-related buffers (in GPU context)
   * @param[in] _graph_mem_type memory type of feature-related buffers (in GPU context)
   */
  explicit ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type);

  /**
   * @brief Read the heterogenous graph from the raw directory and make the graph structure
   * accessible to CUDA devices as specified.
   *
   * @param[in] raw_dir         the 'raw' directory after downloading and
   *                            extracting the dataset.
   * @param[in] _n_nodes        total number of nodes
   * @param[in] _n_cols         feature dimension
   * @param[in] _is_undirected  whether the input graph is supposed to be
   *                            undirected, if yes, then the reverse edges will
   *                            be added to simplify the later pipelines
   * @param[in] _n_node_types   number of node types in the input graph
   * @param[in] _n_edge_types   number of edge types in the input graph
   * @param[in] _resize_factor  only relevant when graph is desired that is artifically
   *                            increased through redundant connected components
   *                            resize_factor then specifies the number of connected components
   * @param[in] _feats_mem_type memory type of feature-related buffers (in GPU context)
   * @param[in] _graph_mem_type memory type of feature-related buffers (in GPU context)
   */
  explicit ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     int32_t _n_node_types,
                     int32_t _n_edge_types,
                     uint16_t _resize_factor,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type);

  /**
   * @brief Read the heterogenous graph from the raw directory and make the graph structure
   * accessible to CUDA devices as specified.
   *
   * @param[in] raw_dir         the 'raw' directory after downloading and
   *                            extracting the dataset.
   * @param[in] _n_nodes        total number of nodes
   * @param[in] _n_cols         feature dimension
   * @param[in] _is_undirected  whether the input graph is supposed to be
   *                            undirected, if yes, then the reverse edges will
   *                            be added to simplify the later pipelines
   * @param[in] _n_node_types   number of node types in the input graph
   * @param[in] _n_edge_types   number of edge types in the input graph
   * @param[in] _feats_mem_type memory type of feature-related buffers (in GPU context)
   * @param[in] _graph_mem_type memory type of feature-related buffers (in GPU context)
   */
  explicit ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     int32_t _n_node_types,
                     int32_t _n_edge_types,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type);

  ~ogbn_cuda();

  /** don't allow copying */
  ogbn_cuda(const ogbn_cuda&)            = delete;
  ogbn_cuda& operator=(const ogbn_cuda&) = delete;

 private:
  void read(const std::string& raw_dir, uint16_t resize_factor);
};  // struct ogbn_cuda

}  // namespace cugraph::ops::io
