/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>

#include <raft/random/rng_state.hpp>

namespace cugraph::ops {

/**
 * @brief Default initialization of bias for linear-type layers.
 *
 * Values come from the uniform distrubtion over
 * [-gain * sqrt(3 / n_fan), gain * sqrt(3 / n_fan)]
 * or the normal distribution with standard deviation gain / sqrt(n_fan)
 *
 * @param[out]   w          values to initialize. [on device] [dim = `n`]
 * @param[in]    n          number of values to initialize.
 * @param[in]    n_fan      fan used for initialization (usually # input
 *                          features or sum of # input and # output features)
 * @param[in]    gain       gain used for initialization (usually sqrt(2) for
 *                          weights and 1 for bias in a linear layer using
 *                          'relu' activation)
 * @param[in]    is_normal  whether to use a normal distribution.
 *                          uniform otherwise.
 * @param[inout] r          RAFT RngState object used for initialization.
 * @param[in]    stream     cuda stream to schedule work on
 *
 * @{
 */
void init_weights(float* w,
                  size_t n,
                  size_t n_fan,
                  double gain,
                  bool is_normal,
                  raft::random::RngState& r,
                  const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops
