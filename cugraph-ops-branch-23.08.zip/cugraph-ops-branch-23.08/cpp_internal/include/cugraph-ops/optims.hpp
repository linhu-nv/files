/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>

namespace cugraph::ops::optims {

/**
 * @brief ADAM optimizer method
 *
 * @param[inout] params     parameters to be updated [on device]
 *                          [len = `n_params`]
 * @param[inout] m          first moment of gradients [on device]
 *                          [len = `n_params`]
 * @param[inout] v          second moment of gradients [on device]
 *                          [len = `n_params`]
 * @param[in]    pgrads     gradients of the parameters [on device]
 *                          [len = `n_params`]
 * @param[in]    beta1      first moment decay rate
 * @param[in]    beta2      second moment decay rate
 * @param[in]    eta        learning rate
 * @param[in]    epsilon    smoothing parameter
 * @param[in]    n_params   number of parameters
 * @param[in]    step       the step id. first step must be 0, second 1, etc.
 * @param[in]    stream     cuda stream to schedule work on
 *
 * @{
 */
void adam_update(float* params,
                 float* m,
                 float* v,
                 const float* pgrads,
                 float beta1,
                 float beta2,
                 float eta,
                 float epsilon,
                 uint64_t n_params,
                 int step,
                 const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops::optims
