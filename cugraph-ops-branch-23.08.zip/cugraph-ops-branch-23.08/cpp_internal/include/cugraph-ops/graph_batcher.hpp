/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/graph/node_edge_offsets.hpp>
#include <cugraph-ops/graph/output_batching.hpp>
#include <cugraph-ops/graph/sampling.hpp>
#include <cugraph-ops/utils/allocator.hpp>
#include <cugraph-ops/utils/error.hpp>
#include <cugraph-ops/utils/nvtx.hpp>

#include <raft/random/rng_state.hpp>

#include <cuda_runtime.h>

#include <algorithm>
#include <cstdint>
#include <random>
#include <tuple>

namespace cugraph::ops {

/**
 * @brief Generates the batch of graphs for the current minibatch.
 *
 * @tparam IdxT indexing type
 *
 * @code{.cpp}
 * graph_batcher<IdxT> gb(graph, batch_size, rng, stream);
 * for (int i = 0; i < gb.num_batches(); ++i) {
 *   auto batch = gb.next_batch();
 *   auto edge_offsets = batch->ef_offsets;
 *   auto batch_graph_offsets = batch->batch_offsets;
 * }
 * @endcode
 */
template <typename IdxT>
struct graph_batcher {
  using fg_t          = graph::fg_csr_seq<IdxT>;
  using graph_batch_t = graph::fg_csr_batch<IdxT>;

  /**
   * @param[in]    _graph       the full set of graphs to be batched
   * @param[in]    _batch_size  batch size
   * @param[in]    _calc_totals whether to compute total node/edge counts.
   *                            Host must be synced with device after sampling
   *                            each batch if this is `true`.
   * @param[inout] _rng         RAFT RngState object
   * @param[in]    _stream      cuda stream
   */
  graph_batcher(fg_t& _graph,
                IdxT _batch_size,
                bool _calc_totals,
                raft::random::RngState& _rng,
                const cuda::stream& _stream)
    : graph_(_graph),
      batch_size_(_batch_size),
      calc_totals_(_calc_totals),
      rng_(_rng),
      gen_(_rng.seed),
      stream_(_stream),
      graph_batch_(std::make_unique<graph_batch_t>(_graph)),
      num_batches_((graph_.n_graphs + batch_size_ - 1) / batch_size_)
  {
    assign_workspace();
    reset();
  }

  /** Resets the batch generator (eg: for the next epoch) */
  void reset()
  {
    next_start_[0]           = 0;
    xor_key_                 = gen_();
    count_                   = 0;
    graph_batch_->batch_size = 0;
  }

  ~graph_batcher()
  {
    auto& h_alloc = utils::host_allocator();
    auto& d_alloc = utils::device_allocator();
    h_alloc.dealloc(next_start_, 0, stream_);
    d_alloc.dealloc(graph_batch_->batch_offsets, 0, stream_);
    d_alloc.dealloc(graph_batch_->nf_offsets, 0, stream_);
    d_alloc.dealloc(graph_batch_->ef_offsets, 0, stream_);
    if (calc_totals_) h_alloc.dealloc(n_batch_nodes_edges_, 0, stream_);
    d_alloc.dealloc(workspace_, 0, stream_);
  }

  /** default copy constructor and copy assignment operator */
  graph_batcher(const graph_batcher&)            = default;
  graph_batcher& operator=(const graph_batcher&) = default;

  /**
   * @brief computes the next batch of graphs
   *
   * @return Reference to a batch of graphs (see `graph::fg_csr_batch<IdxT>`)
   *
   * @note the output batch pointer should NOT be `cudaFree`d by the caller
   */
  const graph_batch_t& next_batch()
  {
    utils::push_range("graph_batcher::next_batch");
    size_t workspace_size = 0;  // to keep compiler happy
    // generate next output batch of nodes
    graph_batch_->batch_size =
      std::max(static_cast<IdxT>(0), std::min(graph_.n_graphs - count_ * batch_size_, batch_size_));
    graph::get_next_output_batch(graph_batch_->batch_offsets,
                                 next_start_,
                                 graph_batch_->batch_size,
                                 graph_.n_graphs,
                                 xor_key_,
                                 workspace_,
                                 workspace_size,
                                 stream_());
    ++count_;
    graph::node_edge_offsets(graph_batch_->nf_offsets,
                             graph_batch_->ef_offsets,
                             calc_totals_ ? n_batch_nodes_edges_ : nullptr,
                             calc_totals_ ? n_batch_nodes_edges_ + 1 : nullptr,
                             graph_batch_->batch_size,
                             graph_batch_->batch_offsets,
                             graph_.graph_offsets,
                             graph_.offsets,
                             workspace_,
                             workspace_size,
                             stream_());
    // update total number of batch nodes/edges
    if (calc_totals_) {
      stream_.sync();
      graph_batch_->n_nodes = n_batch_nodes_edges_[0];
      graph_batch_->n_edges = n_batch_nodes_edges_[1];
    }
    utils::pop_range();
    return curr_batch();
  }

  /** returns the current batch information */
  [[nodiscard]] const graph_batch_t& curr_batch() { return *graph_batch_; }

  /** total number of batches to be generated */
  [[nodiscard]] IdxT num_batches() const { return num_batches_; }

  /** stream used for allocations */
  [[nodiscard]] const cuda::stream& get_stream() const { return stream_; }

  /** max batch size (parameter given to constructor) */
  [[nodiscard]] IdxT max_batch_size() const { return batch_size_; }

 private:
  void assign_workspace()
  {
    auto& h_alloc = utils::host_allocator();
    auto& d_alloc = utils::device_allocator();
    // for computing the output batch at each iteration
    next_start_ = reinterpret_cast<IdxT*>(h_alloc.alloc(sizeof(IdxT) * 2, stream_));
    size_t wsize1, wsize2;
    IdxT* idx_null = nullptr;
    graph::get_next_output_batch(idx_null,
                                 idx_null,
                                 batch_size_,
                                 graph_.n_graphs,
                                 static_cast<uint64_t>(0),
                                 nullptr,
                                 wsize1,
                                 nullptr);
    graph::node_edge_offsets(idx_null,
                             idx_null,
                             idx_null,
                             idx_null,
                             batch_size_,
                             idx_null,
                             idx_null,
                             idx_null,
                             nullptr,
                             wsize2,
                             stream_());
    auto wsize = std::max(wsize1, wsize2);  // reuse workspace
    // output batch
    graph_batch_->batch_offsets =
      reinterpret_cast<IdxT*>(d_alloc.alloc(sizeof(IdxT) * batch_size_, stream_));
    graph_batch_->nf_offsets =
      reinterpret_cast<IdxT*>(d_alloc.alloc(sizeof(IdxT) * batch_size_, stream_));
    graph_batch_->ef_offsets =
      reinterpret_cast<IdxT*>(d_alloc.alloc(sizeof(IdxT) * batch_size_, stream_));
    if (calc_totals_)
      n_batch_nodes_edges_ = reinterpret_cast<IdxT*>(h_alloc.alloc(sizeof(IdxT) * 2, stream_));
    workspace_ = reinterpret_cast<char*>(d_alloc.alloc(sizeof(char) * wsize, stream_));
  }

  /** Host side random number generator (for xor_key) / we want it to be predictable */
  std::mt19937_64 gen_;

  /** current batch graph representation */
  std::unique_ptr<graph_batch_t> graph_batch_;
  /** graphs to be batched */
  fg_t& graph_;
  /** RAFT RngState object */
  raft::random::RngState& rng_;
  /** a 64b number for XOR operation */
  uint64_t xor_key_;
  /** cuda stream to schedule work on */
  cuda::stream stream_;

  /* workspace for total number of nodes/edges per batch */
  IdxT* n_batch_nodes_edges_{nullptr};
  /**
   * list of numbers read so far for from the bijection. [pinned].
   * [len = 1].
   */
  IdxT* next_start_;
  /** workspace for `get_next_output_batch()` */
  char* workspace_;

  /** maximum minibatch size */
  IdxT batch_size_;
  /** total number of batches (or iterations) */
  IdxT num_batches_;
  /** current batch count (eg: in an epoch) */
  IdxT count_;

  /* whether or not to create a reverse graph. */
  bool calc_totals_{false};
};  // struct graph_batcher

}  // namespace cugraph::ops
