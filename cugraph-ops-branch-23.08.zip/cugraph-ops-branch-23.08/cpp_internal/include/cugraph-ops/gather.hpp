/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/graph/format.hpp>

#include <cuda_runtime_api.h>

#include <cstdint>

namespace cugraph::ops {

/**
 * @brief gathers input embeddings based on the sampled input `indices` array
 *
 * This means that the resulting node indices in the sampled graph based on this
 * `indices` array are assumed to be numbered contiguously from 0 to
 * `n_indices -1`.
 *
 * @param[out] out       output dense array. [on device]
 *                       [dim = `n_indices x n`] [row major]
 * @param[in]  in        input larger array from where to gather vectors.
 *                       [on device] [dim = `M x n`] [row major]
 * @param[in]  indices   input indices array which is used to gather the vectors
 *                       [on device] [len = `n_indices`] [row major]
 * @param[in]  n         vector dimension
 * @param[in]  n_indices length of the `indices` array
 * @param[in]  stream    cuda stream to schedule work on
 *
 * @{
 */
void gather(float* out,
            const float* in,
            const int32_t* indices,
            int32_t n,
            int32_t n_indices,
            const cuda::stream& stream);
void gather(float* out,
            const float* in,
            const int64_t* indices,
            int64_t n,
            int64_t n_indices,
            const cuda::stream& stream);
void gather(int32_t* out,
            const int32_t* in,
            const int32_t* indices,
            int32_t n,
            int32_t n_indices,
            const cuda::stream& stream);
void gather(int32_t* out,
            const int32_t* in,
            const int64_t* indices,
            int64_t n,
            int64_t n_indices,
            const cuda::stream& stream);
/** @} */

/**
 * @brief gathers node/edge embeddings based on batch and `ef_indices` array
 *
 * @note Currently, there is no corresponding backward operation.
 * @note After this operation, aggregation operations should not be called
 *       with the `ef_indices`. Either you should call specializations of the
 *       ops without that feature or create a new graph structure with
 *       `ef_indices := nullptr`.
 * @note For a single graph with edge features, simply call
 *       `gather(out_edge_features, in_edge_features, fg.ef_indices, dim_edge,
 *               fg.n_indices, stream)`
 *
 * @param[out] out_node_feat output node features. Can be `nullptr` if only
 *                           gathering edge features. [on device]
 *                           [dim = `fg_batch.n_nodes x dim_node`] [row major]
 * @param[out] out_edge_feat output edge features. Can be `nullptr` if only
 *                           gathering node features. [on device]
 *                           [dim = `fg_batch.n_indices x dim_edge`] [row major]
 * @param[in]  in_node_feat  input node features. Can be `nullptr` if only
 *                           gathering edge features. [on device]
 *                           [dim = `fg_batch.csr_seq.n_nodes x dim_node`]
 *                           [row major]
 * @param[in]  in_edge_feat  input edge features. Can be `nullptr` if only
 *                           gathering node features. [on device]
 *                           [dim = `fg_batch.csr_seq.n_indices x dim_edge`]
 *                           [row major]
 * @param[in]  fg_batch      Input batch of graphs.
 * @param[in]  dim_node      Input node feature size, ignored if
 *                           `in_node_feat == nullptr`
 * @param[in]  dim_edge      Input edge feature size, ignored if
 *                           `in_edge_feat == nullptr`
 * @param[in]  stream        cuda stream to schedule work on
 *
 * @{
 */
void gather_batch(float* out_node_feat,
                  float* out_edge_feat,
                  const float* in_node_feat,
                  const float* in_edge_feat,
                  const fg_csr_batch_s32_t& fg_batch,
                  size_t dim_node,
                  size_t dim_edge,
                  const cuda::stream& stream);
void gather_batch(float* out_node_feat,
                  float* out_edge_feat,
                  const float* in_node_feat,
                  const float* in_edge_feat,
                  const fg_csr_batch_s64_t& fg_batch,
                  size_t dim_node,
                  size_t dim_edge,
                  const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops
