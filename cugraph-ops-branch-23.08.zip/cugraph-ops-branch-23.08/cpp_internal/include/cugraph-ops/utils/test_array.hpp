/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>

#include <cstdint>
#include <string>

namespace cugraph::ops::utils {

/**
 * @brief Verify whether the input array contains NaNs, Infs or
 *        out-of-range values
 *
 * @param[in]  in         input array to be verified [len = `n`]
 * @param[in]  n          number of elements in input array
 * @param[in]  check_v    integer used to perform checks [pinned] [len = `1`]
 * @param[in]  name       name of the array to be verified
 * @param[in]  stream     stream on which to perform computation
 * @param[in]  r1         optional start of range to be checked. If `r1 > r2`,
 *                        this is ignored
 * @param[in]  r2         optional end of range to be checked. If `r1 > r2`,
 *                        this is ignored
 *
 * @return True, if the array contains NaNs, Infs or out-of-range values.
 *         False otherwise.
 *
 * @{
 */
bool verify_nan_inf_range(float* in,
                          size_t n,
                          int32_t* check_v,
                          const std::string& name,
                          const cuda::stream& stream,
                          float r1 = 1.F,
                          float r2 = 0.F);
bool verify_nan_inf_range(double* in,
                          size_t n,
                          int32_t* check_v,
                          const std::string& name,
                          const cuda::stream& stream,
                          double r1 = 1.,
                          double r2 = 0.);
/** @} */

}  // namespace cugraph::ops::utils
