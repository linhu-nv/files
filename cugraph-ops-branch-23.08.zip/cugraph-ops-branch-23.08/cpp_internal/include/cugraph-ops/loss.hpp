/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/cudnn.hpp>
#include <cugraph-ops/cuda/stream.hpp>

namespace cugraph::ops {

/**
 * @brief Computes the softmax crossentropy loss by row
 *
 * Optionally, the gradients w.r.t. input are computed at the same time
 * Optionally, the number of correct predictions w.r.t. labels are computed
 *
 * @param[out] out       output final loss. [pinned] [dim = `1`]
 *                       If `nullptr`, the final loss is not calculated
 * @param[out] acc       output correct count. [pinned] [dim = `1`]
 *                       If `nullptr`, this count is not calculated
 * @param[out] sm_out    output softmax (if `with_grad` is false)
 *                       or gradient otherwise. [on device] [dim = `m x n`]
 *                       [row major]
 * @param[in]  in        input matrix [on device] [dim = `m x n`] [row major]
 * @param[in]  labels    labels. [on device] [dim = `m`]
 * @param[in]  m         number of rows
 * @param[in]  n         number of columns
 * @param[in]  epsilon   smoothing parameter for numerical stability
 * @param[in]  with_grad if `true`, set `sm_out` to the gradient. otherwise,
 *                       `sm_out` holds the softmax activation
 * @param[in]  handle    cudnn handle used in calculation
 * @param[in]  stream    cuda stream to schedule work on
 *
 * @{
 */
void softmax_ce_by_row(float* out,
                       int32_t* acc,
                       float* sm_out,
                       const float* in,
                       const int32_t* labels,
                       int32_t m,
                       int32_t n,
                       float epsilon,
                       bool with_grad,
                       const cuda::cudnnhandle& handle,
                       const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops
