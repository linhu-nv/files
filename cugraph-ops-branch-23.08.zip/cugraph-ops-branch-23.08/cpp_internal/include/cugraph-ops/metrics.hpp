/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>

#include <cstdint>

namespace cugraph::ops {

/**
 * @brief Computes the mean accuracy by row
 *
 * Input can be logits or softmax activated, in any case the max index counts
 *
 * @param[out] acc       correct prediction count. [pinned] [dim = `1`]
 * @param[in]  in        input matrix [on device] [dim = `m x n`] [row major]
 * @param[in]  labels    labels. [on device] [dim = `m`]
 * @param[in]  m         number of rows
 * @param[in]  n         number of columns
 * @param[in]  stream    cuda stream to schedule work on
 *
 * @{
 */
float accuracy_by_row(std::int32_t* acc,
                      const float* in,
                      const std::int32_t* labels,
                      std::int32_t m,
                      std::int32_t n,
                      const cuda::stream& stream);
/** @} */

}  // namespace cugraph::ops
