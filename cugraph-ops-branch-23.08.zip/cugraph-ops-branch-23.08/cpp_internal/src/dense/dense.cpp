/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cublas_wrappers.hpp>
#include <utils/cudart.hpp>

#include <cugraph-ops/bias_activation.hpp>
#include <cugraph-ops/dense.hpp>
#include <cugraph-ops/utils/nvtx.hpp>

#include <raft/random/rng_state.hpp>

#include <cuda_runtime_api.h>

namespace cugraph::ops {

void dense_fwd(float* out,
               float* c,
               int ldc,
               const float* a,
               int lda,
               const float* b,
               int ldb,
               const float* bias,
               int m,
               int n,
               int k,
               const activation_params& aparams,
               uint64_t* drop_v,
               float p_drop,
               raft::random::RngState* r,
               const cuda::cublashandle& handle,
               const cuda::stream& stream)
{
  utils::push_range("cugraph::ops::dense_fwd");
  const float alpha = 1.F, beta = 0.F;
  // since we consider all inputs row-major, we have to invert A and B here
  // in order to get the "correct" output (again in row-major)
  // NOLINTNEXTLINE(readability-suspicious-call-argument)
  RAFT_CUBLAS_TRY(utils::cublasgemm(
    handle(), CUBLAS_OP_T, CUBLAS_OP_N, n, m, k, &alpha, b, ldb, a, lda, &beta, c, ldc, stream()));
  if (out != nullptr) {
    bias_activation_fwd(out, c, bias, m, n, ldc, aparams, drop_v, p_drop, r, stream);
  }
  utils::pop_range();
}

void dense_bwd(float* da,
               float* db,
               float* dbias,
               float* dgrad,
               const float* dout,
               const float* out,
               const float* c,
               int ldc,
               const float* a,
               int lda,
               const float* b,
               int ldb,
               const float* bias,
               int m,
               int n,
               int k,
               const activation_params& aparams,
               const uint64_t* drop_v,
               float p_drop,
               const cuda::cublashandle& handle,
               const cuda::stream& stream)
{
  utils::push_range("cugraph::ops::dense_bwd");
  const float* dense_dc;  // data input gradient to the dense layer
  if (out != nullptr) {
    bias_activation_bwd(
      dgrad, dbias, dout, out, c, bias, m, n, ldc, aparams, drop_v, p_drop, stream);
    dense_dc = dgrad;
  } else {
    dense_dc = dout;
  }
  const float alpha = 1.F, beta = 0.F;
  // aka wgrad before dgrad s.t. a and da can use the same memory
  // we multiply A from forward (inputs) with the gradient on C from forward.
  // NOLINTNEXTLINE(readability-suspicious-call-argument)
  RAFT_CUBLAS_TRY(utils::cublasgemm(handle(),
                                    CUBLAS_OP_N,
                                    CUBLAS_OP_T,
                                    k,
                                    n,
                                    m,
                                    &alpha,
                                    a,
                                    lda,
                                    dense_dc,
                                    ldc,
                                    &beta,
                                    db,
                                    ldb,
                                    stream()));
  if (da != nullptr) {
    // aka dgrad
    // we multiply B from forward (weights) with the gradient on C from forward.
    // NOLINTNEXTLINE(readability-suspicious-call-argument)
    RAFT_CUBLAS_TRY(utils::cublasgemm(handle(),
                                      CUBLAS_OP_N,
                                      CUBLAS_OP_N,
                                      k,
                                      m,
                                      n,
                                      &alpha,
                                      b,
                                      ldb,
                                      dense_dc,
                                      ldc,
                                      &beta,
                                      da,
                                      lda,
                                      stream()));
  }
  utils::pop_range();
}

}  // namespace cugraph::ops
