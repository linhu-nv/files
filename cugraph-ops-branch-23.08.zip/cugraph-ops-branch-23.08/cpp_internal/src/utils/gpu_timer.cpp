/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/error.hpp>
#include <cugraph-ops/utils/gpu_timer.hpp>
#include <cugraph-ops/utils/logger.hpp>

namespace cugraph::ops::utils::gpu {

using timers_t = std::unordered_map<std::string, timer_t>;

timer_t::timer_t(cudaStream_t s)
{
  stream_ = s;
  RAFT_CUDA_TRY(cudaEventCreate(&start_));
  RAFT_CUDA_TRY(cudaEventCreate(&stop_));
}

timer_t::~timer_t()
{
  try {
    RAFT_CUDA_TRY(cudaEventDestroy(start_));
    RAFT_CUDA_TRY(cudaEventDestroy(stop_));
  } catch (...) {
    CUGRAPH_OPS_ERROR("gpu::timer_t: Failed to destroy cuda event resources!");
  }
}

void timer_t::tic()
{
  ASSERT(!running_, "gpu::timer_t::tic: Timer already running!");
  RAFT_CUDA_TRY(cudaEventRecord(start_, stream_));
  running_ = true;
}

void timer_t::toc()
{
  ASSERT(running_, "gpu::timer_t::toc: Timer is not running!");
  RAFT_CUDA_TRY(cudaEventRecord(stop_, stream_));
  RAFT_CUDA_TRY(cudaEventSynchronize(stop_));
  float tmp;
  RAFT_CUDA_TRY(cudaEventElapsedTime(&tmp, start_, stop_));
  static constexpr double MS_TO_S = 1e-3;
  elapsed_ += double{tmp} * MS_TO_S;
  ++count_;
  running_ = false;
}

timers_t& get_timers()
{
  static timers_t t;
  return t;
}

timer_t& get_timer(const std::string& name)
{
  auto& t  = get_timers();
  auto itr = t.find(name);
  ASSERT(itr != t.end(), "gpu::get_timer: Unable to find timer: '%s'!", name.c_str());
  return itr->second;
}

void tic(const std::string& name)
{
  auto& t  = get_timers();
  auto itr = t.find(name);
  if (itr == t.end()) {
    t[name] = timer_t();
    itr     = t.find(name);
  }
  itr->second.tic();
}

void toc(const std::string& name)
{
  auto& t = get_timer(name);
  t.toc();
}

void reset_timers() { get_timers().clear(); }

void tic_for_log(int lev, const std::string& name)
{
  if (will_log_for(lev)) { tic(name); }
}

void toc_and_log(int lev, const std::string& name)
{
  if (will_log_for(lev)) {
    toc(name);
    auto& t = get_timer(name);
    CUGRAPH_OPS_LOG(lev,
                    "[Timer] name=%s total-time %lf(s) count=%d avg-time=%lf(s)\n",
                    name.c_str(),
                    t.elapsed(),
                    t.count(),
                    t.avg_elapsed());
  }
}

}  // namespace cugraph::ops::utils::gpu
