//
// Shamelessly copied from:
// https://gist.githubusercontent.com/piti118/1508048/raw/1a509301db533e9661342b7d4225a32c9240eae6/gzstream.h
//

// ============================================================================
// gzstream, C++ iostream classes wrapping the zlib compression library.
// Copyright (C) 2001  Deepak Bandyopadhyay, Lutz Kettner
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// ============================================================================
//
// File          : gzstream.h
// Revision      : $Revision: 1.5 $
// Revision_date : $Date: 2002/04/26 23:30:15 $
// Author(s)     : Deepak Bandyopadhyay, Lutz Kettner
//
// Standard streambuf implementation following Nicolai Josuttis, "The
// Standard C++ Library".
// ============================================================================

#pragma once

#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <zlib.h>

namespace cugraph::ops::io {

// ----------------------------------------------------------------------------
// Internal classes to implement gzstream. See below for user classes.
// ----------------------------------------------------------------------------

class gzstreambuf : public std::streambuf {
 private:
  static constexpr int BUFFER_SIZE = 47 + 256;  // size of data buff
  // totals 512 bytes under g++ for igzstream at the end.

  gzFile file_{nullptr};            // file handle for compressed file
  char buffer_[BUFFER_SIZE]{'\0'};  // data buffer
  char opened_{0};                  // open/close state of stream
  int mode_{0};                     // I/O mode

  int flush_buffer()
  {
    // Separate the writing of the buffer from overflow() and
    // sync() operation.
    int w = pptr() - pbase();
    if (gzwrite(file_, pbase(), w) != w) return EOF;
    pbump(-w);
    return w;
  }

 public:
  gzstreambuf()
  {
    setp(buffer_, buffer_ + (BUFFER_SIZE - 1));
    setg(buffer_ + 4,   // beginning of putback area
         buffer_ + 4,   // read position
         buffer_ + 4);  // end position
    // ASSERT: both input & output capabilities will not be used together
  }

  [[nodiscard]] bool is_open() const { return static_cast<bool>(opened_); }

  ~gzstreambuf() override { close(); }

  /** delete copy/copy assignment */
  gzstreambuf(const gzstreambuf& other)            = delete;
  gzstreambuf& operator=(const gzstreambuf& other) = delete;

  gzstreambuf* open(const char* name, int open_mode)
  {
    if (is_open()) { return nullptr; }
    mode_ = open_mode;
    // no append nor read/write mode
    if (static_cast<bool>(mode_ & std::ios::ate) || static_cast<bool>(mode_ & std::ios::app) ||
        (static_cast<bool>(mode_ & std::ios::in) && static_cast<bool>(mode_ & std::ios::out))) {
      return nullptr;
    }
    char fmode[10];
    char* fmodeptr = fmode;
    if (static_cast<bool>(mode_ & std::ios::in)) {
      *fmodeptr++ = 'r';
    } else if (static_cast<bool>(mode_ & std::ios::out)) {
      *fmodeptr++ = 'w';
    }
    *fmodeptr++ = 'b';
    *fmodeptr   = '\0';
    file_       = gzopen(name, fmode);
    if (file_ == nullptr) { return nullptr; }
    opened_ = 1;
    return this;
  }

  gzstreambuf* close()
  {
    if (is_open()) {
      sync();
      opened_ = 0;
      if (gzclose(file_) == Z_OK) { return this; }
    }
    return nullptr;
  }

  int underflow() override
  {  // used for input buffer only
    if (gptr() != nullptr && (gptr() < egptr())) {
      return *reinterpret_cast<unsigned char*>(gptr());
    }
    if (!static_cast<bool>(mode_ & std::ios::in) || !is_open()) { return EOF; }
    // Josuttis' implementation of inbuf
    int n_putback = gptr() - eback();
    if (n_putback > 4) { n_putback = 4; }
    memcpy(buffer_ + (4 - n_putback), gptr() - n_putback, n_putback);
    int num = gzread(file_, buffer_ + 4, BUFFER_SIZE - 4);
    if (num <= 0) {  // ERROR or EOF
      return EOF;
    }
    // reset buffer pointers
    setg(buffer_ + (4 - n_putback),  // beginning of putback area
         buffer_ + 4,                // read position
         buffer_ + 4 + num);         // end of buffer
    // return next character
    return *reinterpret_cast<unsigned char*>(gptr());
  }

  int overflow(int c /*= EOF*/) override
  {  // used for output buffer only
    if (!static_cast<bool>(mode_ & std::ios::out) || !is_open()) { return EOF; }
    if (c != EOF) {
      *pptr() = c;
      pbump(1);
    }
    if (flush_buffer() == EOF) { return EOF; }
    return c;
  }

  int sync() override
  {
    // Changed to use flush_buffer() instead of overflow( EOF)
    // which caused improper behavior with std::endl and flush(),
    // bug reported by Vincent Ricard.
    if (pptr() != nullptr && pptr() > pbase()) {
      if (flush_buffer() == EOF) { return -1; }
    }
    return 0;
  }
};

class gzstreambase : virtual public std::ios {
 protected:
  gzstreambuf buf_;

 public:
  gzstreambase() { init(&buf_); }
  gzstreambase(const char* name, int mode)
  {
    init(&buf_);
    open(name, mode);
  }
  ~gzstreambase() override { buf_.close(); }
  void open(const char* name, int open_mode)
  {
    if (buf_.open(name, open_mode) == nullptr) { clear(rdstate() | std::ios::badbit); }
  }

  /** delete copy/copy assignment */
  gzstreambase(const gzstreambase& other)            = delete;
  gzstreambase& operator=(const gzstreambase& other) = delete;

  bool is_open() { return buf_.is_open(); }

  void close()
  {
    if (buf_.is_open()) {
      if (buf_.close() == nullptr) { clear(rdstate() | std::ios::badbit); }
    }
  }
  gzstreambuf* rdbuf() { return &buf_; }
};

// ----------------------------------------------------------------------------
// User classes. Use igzstream and ogzstream analogously to ifstream and
// ofstream respectively. They read and write files based on the gz*
// function interface of the zlib. Files are compatible with gzip compression.
// ----------------------------------------------------------------------------

class igzstream : public gzstreambase, public std::istream {
 public:
  igzstream() : std::istream(&buf_) {}
  explicit igzstream(const char* name, int open_mode = std::ios::in)
    : gzstreambase(name, open_mode), std::istream(&buf_)
  {
  }
  gzstreambuf* rdbuf() { return gzstreambase::rdbuf(); }
  void open(const char* name, int open_mode = std::ios::in) { gzstreambase::open(name, open_mode); }
};

class ogzstream : public gzstreambase, public std::ostream {
 public:
  ogzstream() : std::ostream(&buf_) {}
  explicit ogzstream(const char* name, int mode = std::ios::out)
    : gzstreambase(name, mode), std::ostream(&buf_)
  {
  }
  gzstreambuf* rdbuf() { return gzstreambase::rdbuf(); }
  void open(const char* name, int open_mode = std::ios::out)
  {
    gzstreambase::open(name, open_mode);
  }
};

}  // namespace cugraph::ops::io
