/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include "gzstream.hpp"

#include <utils/cudart.hpp>

#include <cugraph-ops/utils/allocator.hpp>
#include <cugraph-ops/utils/logger.hpp>
#include <cugraph-ops/utils/string_utils.hpp>

#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

namespace cugraph::ops::io {

struct ogzstream;
struct igzstream;

struct __attribute__((aligned(32))) edge_info {
  int64_t id1, id2, e_idx;
  int32_t e_type;
};  // struct edge_info

bool compare_edge(const edge_info& a, const edge_info& b);
bool compare_edge_rev(const edge_info& a, const edge_info& b);

template <typename LambdaT>
void read_gz_file(const std::string& file, LambdaT func)
{
  CUGRAPH_OPS_DEBUG("Reading file='%s'...\n", file.c_str());
  igzstream igz;
  igz.open(file.c_str());
  ASSERT(igz.is_open(), "read_gz_file: failed to open '%s'", file.c_str());
  std::string line;
  int64_t line_num = 0;
  while (std::getline(igz, line)) {
    func(line, line_num);
    ++line_num;
  }
  CUGRAPH_OPS_DEBUG("Done reading file='%s'\n", file.c_str());
}

template <typename DataT>
void read_single_col_from_gz(std::vector<DataT>& vec, const std::string& file)
{
  read_gz_file(file, [&vec](const std::string& line, int64_t /*line_num*/) {
    vec.push_back(utils::str2int(line));
  });
}

template <typename DataT>
void read_embeddings_from_gz(std::vector<DataT>& feats, const std::string& file)
{
  read_gz_file(file, [&feats](const std::string& line, int64_t /*line_num*/) {
    std::stringstream ss(line);
    std::string item;
    while (std::getline(ss, item, ',')) {
      feats.push_back(utils::str2float(item));
    }
  });
}

template <typename DataT>
void read_vec(std::vector<DataT>& vec, igzstream& igz)
{
  size_t len;
  igz.read(reinterpret_cast<char*>(&len), sizeof(len));
  vec.resize(len);
  igz.read(reinterpret_cast<char*>(vec.data()), sizeof(DataT) * len);
}

template <typename DataT, typename LambdaT>
void alloc_and_read_vec(DataT*& ptr,
                        const utils::allocator& alloc,
                        igzstream& igz,
                        size_t& len,
                        uint16_t resize_factor,
                        const cuda::stream& stream,
                        LambdaT copy_func)
{
  igz.read(reinterpret_cast<char*>(&len), sizeof(len));
  ptr = reinterpret_cast<DataT*>(alloc.alloc(sizeof(DataT) * len * resize_factor, stream));
  cudaPointerAttributes attributes;
  cudaPointerGetAttributes(&attributes, ptr);
  if (attributes.type == cudaMemoryType::cudaMemoryTypeDevice) {
    auto host_array = std::make_unique<DataT[]>(len * resize_factor);
    auto* host_ptr  = host_array.get();
    igz.read(reinterpret_cast<char*>(host_ptr), sizeof(DataT) * len);
    if (resize_factor > 1) {
      for (int fac = 1; fac < resize_factor; ++fac) {
        copy_func(host_ptr, fac, len);
      }
    }
    utils::copy(ptr, host_ptr, len * resize_factor, cudaMemcpyHostToDevice);
  } else {
    igz.read(reinterpret_cast<char*>(ptr), sizeof(DataT) * len);
    if (resize_factor > 1) {
      for (int fac = 1; fac < resize_factor; ++fac) {
        copy_func(ptr, fac, len);
      }
    }
  }
  len = len * resize_factor;
}

template <typename DataT>
void alloc_and_read_vec(DataT*& ptr,
                        const utils::allocator& alloc,
                        igzstream& igz,
                        size_t& len,
                        const cuda::stream& stream)
{
  alloc_and_read_vec(
    ptr, alloc, igz, len, 1, stream, [](DataT* /*ptr*/, uint16_t /*fac*/, size_t /*len*/) {});
}

template <typename DataT>
void read_scalar(DataT& val, igzstream& igz)
{
  igz.read(reinterpret_cast<char*>(&val), sizeof(DataT));
}

template <typename DataT>
void dump_vec(const std::vector<DataT>& vec, ogzstream& ogz)
{
  auto len = vec.size();
  ogz.write(reinterpret_cast<char*>(&len), sizeof(len));
  ogz.write(reinterpret_cast<const char*>(vec.data()), sizeof(DataT) * len);
}

template <typename DataT>
void dump_scalar(const DataT& val, ogzstream& ogz)
{
  ogz.write(reinterpret_cast<const char*>(&val), sizeof(DataT));
}

/**
 * @brief wrapper around alloc and copy operation that allows registering
 *        an existing buffer as (pinned) host buffer or copying host data
 *        directly to the newly allocated buffer
 *
 * @tparam DataT  data type
 * @param devPtr  output array (accessible by a CUDA device or on the device)
 * @param hostPtr input array (on host)
 * @param len     lenght of array
 * @param type    memory type of output array (pinned/mapped/device)
 * @param s       cuda stream
 */
template <typename DataT>
void generic_alloc_and_copy(
  DataT*& devPtr, DataT* hostPtr, size_t len, cudaMemoryType type, const cuda::stream& stream)
{
  if (type == cudaMemoryType::cudaMemoryTypeHost) {
    RAFT_CUDA_TRY(cudaHostRegister(hostPtr, len * sizeof(DataT), cudaHostRegisterDefault));
    RAFT_CUDA_TRY(cudaHostGetDevicePointer((void**)&devPtr, (void*)hostPtr, 0));
  } else {
    auto alloc = utils::generic_allocator(type);
    devPtr     = reinterpret_cast<DataT*>(alloc.alloc(sizeof(DataT) * len, stream));
    utils::copy(devPtr, hostPtr, len, cudaMemcpyDefault);
  }
}

}  // namespace cugraph::ops::io
