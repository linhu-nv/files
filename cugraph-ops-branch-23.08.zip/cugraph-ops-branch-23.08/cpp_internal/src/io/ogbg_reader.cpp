/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "gzstream.hpp"
#include "ogb_common.hpp"

#include <utils/cudart.hpp>

#include <cugraph-ops/io/ogbg_reader.hpp>
#include <cugraph-ops/utils/allocator.hpp>
#include <cugraph-ops/utils/cpu_timer.hpp>
#include <cugraph-ops/utils/logger.hpp>
#include <cugraph-ops/utils/nvtx.hpp>
#include <cugraph-ops/utils/string_utils.hpp>

#include <algorithm>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>

namespace cugraph::ops::io {

ogbg_cpu::ogbg_cpu(const std::string& raw_dir, bool _is_undirected)
{
  is_undirected = _is_undirected;
  read(raw_dir);

  n_cols_nodes = static_cast<int64_t>(node_features.size() / (row_offsets.size() - 1));
  n_cols_edges = static_cast<int64_t>(edge_features.size() / n_uniq_edges);
  n_graphs     = static_cast<int64_t>(graph_offsets.size() - 1);
  CUGRAPH_OPS_INFO(
    "Graph information:\n"
    "  #total-edges:  %" PRId64
    "\n"
    "  #total-nodes:  %" PRId64
    "\n"
    "  #graphs:  %" PRId64
    "\n"
    "  #cols-edges:   %" PRId64
    "\n"
    "  #cols-nodes:   %" PRId64 "\n",
    static_cast<int64_t>(indices.size()),
    static_cast<int64_t>(row_offsets.size()),
    n_graphs,
    n_cols_edges,
    n_cols_nodes);
}

void ogbg_cpu::dump(const std::string& file) const
{
  CUGRAPH_OPS_DEBUG("ogbg::dump: dumping dataset to '%s'...\n", file.c_str());
  utils::cpu::tic_for_log(utils::LEVEL_TIMER, "ogbg::dump");
  ogzstream ogz;
  ogz.open(file.c_str());
  ASSERT(ogz.is_open(), "ogbg::dump: failed to open file '%s' for writing", file.c_str());
  dump_vec(indices, ogz);
  dump_vec(ef_indices, ogz);
  dump_vec(rev_edge_ids, ogz);
  dump_vec(row_offsets, ogz);
  dump_vec(graph_offsets, ogz);
  dump_vec(node_features, ogz);
  dump_vec(edge_features, ogz);
  dump_vec(labels, ogz);
  dump_scalar(n_uniq_edges, ogz);
  ogz.close();
  utils::cpu::toc_and_log(utils::LEVEL_TIMER, "ogbg::dump");
}

void ogbg_cpu::read(const std::string& raw_dir)
{
  CUGRAPH_OPS_DEBUG("ogbg::read_raw: reading raw dataset from '%s'...\n", raw_dir.c_str());
  utils::cpu::tic_for_log(utils::LEVEL_TIMER, "ogbg::read_raw");
  // node list
  {
    std::vector<int64_t> g_off;
    read_single_col_from_gz(g_off, raw_dir + "/num-node-list.csv.gz");
    graph_offsets.resize(g_off.size() + 1);
    graph_offsets[0] = 0;
    for (size_t i = 1; i < graph_offsets.size(); ++i) {
      graph_offsets[i] = graph_offsets[i - 1] + g_off[i - 1];
    }
  }
  // edge list
  std::vector<int64_t> edge_list;
  read_single_col_from_gz(edge_list, raw_dir + "/num-edge-list.csv.gz");
  n_uniq_edges = 0;
  for (const auto& itr : edge_list) {
    n_uniq_edges += itr;
  }
  // edges
  size_t graph_idx     = 0;
  int64_t edges_so_far = 0, num_edges = 0;
  row_offsets.resize(graph_offsets.back() + 1, 0);
  indices.reserve(n_uniq_edges);
  ef_indices.reserve(n_uniq_edges);
  rev_edge_ids.reserve(n_uniq_edges);
  std::vector<edge_info> coo;
  // capture by reference by default (all expressions captured by ref)
  read_gz_file(raw_dir + "/edge.csv.gz", [&](const std::string& line, int64_t /*line_num*/) {
    // handle graphs without edges
    while (edge_list[graph_idx] <= 0)
      ++graph_idx;
    std::stringstream ss(line);
    std::string item1, item2, item3;
    std::getline(ss, item1, ',');
    std::getline(ss, item2, ',');
    // the global node id's
    auto local2global = graph_offsets[graph_idx];
    auto src          = int64_t{utils::str2int(item1)} + local2global;
    auto dst          = int64_t{utils::str2int(item2)} + local2global;
    // all ogb datasets are given in the source-destination order
    // since we want an in-graph, we swap the order here
    edge_info ei{.id1 = dst, .id2 = src, .e_idx = edges_so_far, .e_type = 0};
    coo.push_back(ei);
    // it is an undirected graph
    if (this->is_undirected && ei.id1 != ei.id2) {
      edge_info ei_rev{ei.id2, ei.id1, edges_so_far, 0};
      coo.push_back(ei_rev);
    }
    ++num_edges;
    ++edges_so_far;
    // once we have read the edges for the current graph, sort it here itself
    // and then also construct the csr for the current graph
    if (num_edges == edge_list[graph_idx]) {
      auto n_indices_so_far = static_cast<int64_t>(this->indices.size());
      std::sort(coo.begin(), coo.end(), compare_edge);
      for (const auto& edge : coo) {
        this->indices.push_back(edge.id2);
        this->ef_indices.push_back(edge.e_idx);
        ++(this->row_offsets[edge.id1]);
      }
      // to compute the reverse edge ids, reuse the `e_idx` field and then
      // sort according to the src node, whatever the `e_idx` values found
      // will the reverse edge indices. Obviously, this logic works only
      // for undirected graphs. Hence the check!
      if (this->is_undirected) {
        // need the array index for ops inside the loop, hence not using
        // range-based loop
        // NOLINTNEXTLINE(modernize-loop-convert)
        for (size_t i = 0; i < coo.size(); ++i) {
          // need to convert local edge index to global one
          coo[i].e_idx = static_cast<int64_t>(i) + n_indices_so_far;
        }
        std::sort(coo.begin(), coo.end(), compare_edge_rev);
        for (const auto& edge : coo) {
          this->rev_edge_ids.push_back(edge.e_idx);
        }
      }
      num_edges = 0;
      ++graph_idx;
      coo.clear();
    }
  });
  // exclusive prefix sum for the final offsets
  auto prev      = row_offsets[0];
  row_offsets[0] = 0;
  for (size_t i = 1; i < row_offsets.size(); ++i) {
    auto curr      = row_offsets[i];
    row_offsets[i] = prev + row_offsets[i - 1];
    prev           = curr;
  }
  // labels
  read_single_col_from_gz(labels, raw_dir + "/graph-label.csv.gz");
  // embeddings
  read_embeddings_from_gz(node_features, raw_dir + "/node-feat.csv.gz");
  read_embeddings_from_gz(edge_features, raw_dir + "/edge-feat.csv.gz");
  utils::cpu::toc_and_log(utils::LEVEL_TIMER, "ogbg::read_raw");
}

ogbg_cuda::ogbg_cuda(const std::string& raw_dir,
                     bool _is_undirected,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type)
{
  feats_mem_type = _feats_mem_type;
  graph_mem_type = _graph_mem_type;

  // if binary does not exists: create it by reading raw data first
  auto binary_file = raw_dir + "/graph.bin.gz";
  FILE* file       = fopen(binary_file.c_str(), "r");
  if (file == nullptr) {
    auto data = ogbg_cpu(raw_dir, _is_undirected);
    data.dump(binary_file);
  } else {
    ASSERT(fclose(file) == 0, "ogbg: failed to close file '%s'", binary_file.c_str());
  }

  graph = std::make_unique<fg_csr_seq_s64_t>();
  read(raw_dir);
}

void ogbg_cuda::read(const std::string& raw_dir)
{
  auto file = raw_dir + "/graph.bin.gz";
  CUGRAPH_OPS_DEBUG("ogbg::read_binary: load preprocessed dataset from '%s'...\n", file.c_str());
  utils::cpu::tic_for_log(utils::LEVEL_TIMER, "ogbg::read_binary");
  igzstream igz;
  igz.open(file.c_str());
  ASSERT(igz.is_open(), "ogbg: failed to open file '%s' for reading", file.c_str());

  auto feats_alloc = utils::generic_allocator(feats_mem_type);
  auto graph_alloc = utils::generic_allocator(graph_mem_type);
  size_t tmp;

  alloc_and_read_vec(graph->indices, graph_alloc, igz, tmp, nullptr);
  graph->n_indices = static_cast<int64_t>(tmp);
  alloc_and_read_vec(graph->ef_indices, graph_alloc, igz, tmp, nullptr);
  alloc_and_read_vec(graph->rev_edge_ids, graph_alloc, igz, tmp, nullptr);
  alloc_and_read_vec(graph->offsets, graph_alloc, igz, tmp, nullptr);
  graph->n_nodes = static_cast<int64_t>(tmp) - 1;  // row_offsets = n_nodes + 1
  alloc_and_read_vec(graph->graph_offsets, graph_alloc, igz, tmp, nullptr);
  n_graphs        = static_cast<int64_t>(tmp) - 1;  // graph_offsets = n_graphs + 1
  graph->n_graphs = n_graphs;
  alloc_and_read_vec(node_features, feats_alloc, igz, tmp, nullptr);
  n_cols_nodes = static_cast<int64_t>(tmp) / graph->n_nodes;
  alloc_and_read_vec(edge_features, feats_alloc, igz, tmp, nullptr);
  n_cols_edges = static_cast<int64_t>(tmp);
  alloc_and_read_vec(labels, feats_alloc, igz, tmp, nullptr);
  n_labels = static_cast<int64_t>(tmp);
  read_scalar(n_uniq_edges, igz);
  n_cols_edges = n_cols_edges / n_uniq_edges;

  igz.close();
  utils::cpu::toc_and_log(utils::LEVEL_TIMER, "ogbg::read_binary");
}

ogbg_cuda::~ogbg_cuda()
{
  auto feats_alloc = utils::generic_allocator(feats_mem_type);
  feats_alloc.dealloc(node_features, 0, nullptr);
  feats_alloc.dealloc(edge_features, 0, nullptr);
  feats_alloc.dealloc(labels, 0, nullptr);

  auto graph_alloc = utils::generic_allocator(graph_mem_type);
  graph_alloc.dealloc(graph->offsets, 0, nullptr);
  graph_alloc.dealloc(graph->indices, 0, nullptr);
  graph_alloc.dealloc(graph->graph_offsets, 0, nullptr);
  graph_alloc.dealloc(graph->ef_indices, 0, nullptr);
  graph_alloc.dealloc(graph->rev_edge_ids, 0, nullptr);
}

}  // namespace cugraph::ops::io
