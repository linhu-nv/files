/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "gzstream.hpp"
#include "ogb_common.hpp"

#include <utils/cudart.hpp>

#include <cugraph-ops/io/ogbn_reader.hpp>
#include <cugraph-ops/utils/allocator.hpp>
#include <cugraph-ops/utils/cpu_timer.hpp>
#include <cugraph-ops/utils/logger.hpp>
#include <cugraph-ops/utils/nvtx.hpp>
#include <cugraph-ops/utils/string_utils.hpp>

#include <algorithm>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>

namespace cugraph::ops::io {

ogbn_cpu::ogbn_cpu(const std::string& raw_dir,
                   int64_t _n_nodes,
                   int64_t _n_cols,
                   bool _is_undirected)
  : ogbn_cpu::ogbn_cpu(raw_dir, _n_nodes, _n_cols, _is_undirected, 0, 0)
{
}

ogbn_cpu::ogbn_cpu(const std::string& raw_dir,
                   int64_t _n_nodes,
                   int64_t _n_cols,
                   bool _is_undirected,
                   int32_t _n_node_types,
                   int32_t _n_edge_types)
{
  n_nodes       = _n_nodes;
  n_cols        = _n_cols;
  is_undirected = _is_undirected;
  n_node_types  = _n_node_types;
  n_edge_types  = _n_edge_types;
  is_hg         = _n_node_types > 1 || _n_edge_types > 1;

  read(raw_dir);

  CUGRAPH_OPS_INFO("Graph information:\n  #edges:  %" PRId64 "\n  #nodes:  %" PRId64
                   "\n  #cols:   %" PRId64 "\n  #labels: %" PRId64 "\n",
                   static_cast<int64_t>(indices.size()),
                   n_nodes,
                   n_cols,
                   static_cast<int64_t>(labels.size()));
  if (is_hg) {
    CUGRAPH_OPS_INFO(
      "  #edge types: %d\n  #node types: %d\n", this->n_edge_types, this->n_node_types);
  }
  // validation
  auto flen = n_cols * n_nodes;
  ASSERT(features.size() == static_cast<size_t>(flen),
         "ogb: Expected %" PRId64 " features, but found %" PRId64 "!",
         flen,
         static_cast<int64_t>(features.size()));
  ASSERT(offsets.size() == static_cast<size_t>(n_nodes + 1),
         "ogb: Expected %" PRId64 " offsets, but got %" PRId64 "!",
         n_nodes + 1,
         static_cast<int64_t>(offsets.size()));
  ASSERT(
    offsets.front() == 0, "ogb: Expected 0-offset at front but got %" PRId64 "!", offsets.front());
  ASSERT(static_cast<size_t>(offsets.back()) == indices.size(),
         "ogb: Expected %" PRId64 " edges, but fond %" PRId64 "!",
         offsets.back(),
         static_cast<int64_t>(indices.size()));
  if (is_hg) {
    ASSERT(edge_types.size() == indices.size(),
           "ogb: Expected %" PRId64 " edge types, but fond %" PRId64 "!",
           static_cast<int64_t>(indices.size()),
           static_cast<int64_t>(edge_types.size()));
    ASSERT(node_types.size() == static_cast<size_t>(n_nodes),
           "ogb: Expected %" PRId64 " node types, but fond %" PRId64 "!",
           n_nodes,
           static_cast<int64_t>(node_types.size()));
  }
}

void ogbn_cpu::dump(const std::string& file)
{
  CUGRAPH_OPS_DEBUG("ogbn_cpu::dump: dumping dataset to '%s'...\n", file.c_str());
  utils::cpu::tic_for_log(utils::LEVEL_TIMER, "ogbn_cpu::dump");
  ogzstream ogz;
  ogz.open(file.c_str());
  ASSERT(ogz.is_open(), "ogbn_cpu::dump: failed to open file '%s' for writing", file.c_str());
  dump_vec(indices, ogz);
  dump_vec(offsets, ogz);
  dump_vec(features, ogz);
  dump_vec(labels, ogz);
  if (is_hg) {
    std::vector<int32_t> n_types({n_edge_types, n_node_types});
    dump_vec(n_types, ogz);
    dump_vec(edge_types, ogz);
    dump_vec(node_types, ogz);
  }
  ogz.close();
  utils::cpu::toc_and_log(utils::LEVEL_TIMER, "ogbn_cpu::dump");
}

void ogbn_cpu::read(const std::string& raw_dir)
{
  CUGRAPH_OPS_DEBUG("ogbn_cpu::read: reading raw dataset from '%s'...\n", raw_dir.c_str());
  utils::cpu::tic_for_log(utils::LEVEL_TIMER, "ogbn_cpu::read");
  auto is_undirected = this->is_undirected;
  auto is_hg         = this->is_hg;
  auto n_edge_types  = this->n_edge_types;
  // all edge types appear twice in undirected case (see todo below)
  if (is_undirected && is_hg) this->n_edge_types = n_edge_types * 2;
  // edges
  std::vector<edge_info> coo;
  std::vector<int32_t> e_types;
  int64_t edges_so_far = 0;
  read_gz_file(raw_dir + "/edge.csv.gz",
               [&coo, &edges_so_far, is_undirected, is_hg, n_edge_types](const std::string& line,
                                                                         int64_t /*line_num*/) {
                 std::stringstream ss(line);
                 std::string item1, item2, item3;
                 std::getline(ss, item1, ',');
                 std::getline(ss, item2, ',');
                 int32_t e_type = 0;
                 if (is_hg) {
                   std::getline(ss, item3, ',');
                   e_type = utils::str2int(item3);
                   ASSERT(e_type >= 0 && e_type < n_edge_types,
                          "Expected edge type in [0, %d[ but got %d",
                          n_edge_types,
                          e_type);
                 }
                 // all ogb datasets are given in the source-destination order
                 // since we want an in-graph, we swap the order here
                 edge_info ei{.id1    = int64_t{utils::str2int(item2)},
                              .id2    = int64_t{utils::str2int(item1)},
                              .e_idx  = edges_so_far,
                              .e_type = e_type};
                 coo.push_back(ei);
                 // it is an undirected graph
                 if (is_undirected && ei.id1 != ei.id2) {
                   // TODO(mjoux) option for using same edge type of inverse edge
                   // (undirected relations)
                   edge_info ei_rev{ei.id2, ei.id1, edges_so_far, n_edge_types + ei.e_type};
                   coo.push_back(ei_rev);
                 }
                 ++edges_so_far;
               });
  std::sort(coo.begin(), coo.end(), compare_edge);
  offsets.resize(n_nodes + 1, 0);
  indices.resize(coo.size());
  if (is_hg) edge_types.resize(coo.size());
  for (size_t i = 0; i < coo.size(); ++i) {
    indices[i] = coo[i].id2;
    ++offsets[coo[i].id1];
    if (is_hg) edge_types[i] = coo[i].e_type;
  }
  // compute exclusive prefix sum
  auto prev  = offsets[0];
  offsets[0] = 0;
  for (int64_t i = 1; i <= n_nodes; ++i) {
    auto curr  = offsets[i];
    offsets[i] = prev + offsets[i - 1];
    prev       = curr;
  }
  // labels
  read_gz_file(raw_dir + "/node-label.csv.gz",
               [this](const std::string& line, int64_t /*line_num*/) {
                 this->labels.push_back(utils::str2int(line));
               });
  // embeddings
  read_gz_file(raw_dir + "/node-feat.csv.gz",
               [this](const std::string& line, int64_t /*line_num*/) {
                 std::stringstream ss(line);
                 std::string item;
                 while (std::getline(ss, item, ',')) {
                   this->features.push_back(utils::str2float(item));
                 }
               });
  if (is_hg) {
    // node types
    read_gz_file(raw_dir + "/node-types.csv.gz",
                 [this](const std::string& line, int64_t /*line_num*/) {
                   auto n_type = utils::str2int(line);
                   ASSERT(n_type >= 0 && n_type < this->n_node_types,
                          "Expected node type in [0, %d[ but got %d",
                          this->n_node_types,
                          n_type);
                   this->node_types.push_back(n_type);
                 });
  }
  utils::cpu::toc_and_log(utils::LEVEL_TIMER, "ogbn_cpu::read");
}

ogbn_cuda::ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type)
  : ogbn_cuda::ogbn_cuda(
      raw_dir, _n_nodes, _n_cols, _is_undirected, 0, 0, 1, _feats_mem_type, _graph_mem_type)
{
}

ogbn_cuda::ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     uint16_t _resize_factor,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type)
  : ogbn_cuda::ogbn_cuda(raw_dir,
                         _n_nodes,
                         _n_cols,
                         _is_undirected,
                         0,
                         0,
                         _resize_factor,
                         _feats_mem_type,
                         _graph_mem_type)
{
}

ogbn_cuda::ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     int32_t _n_node_types,
                     int32_t _n_edge_types,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type)
  : ogbn_cuda::ogbn_cuda(raw_dir,
                         _n_nodes,
                         _n_cols,
                         _is_undirected,
                         _n_node_types,
                         _n_edge_types,
                         1,
                         _feats_mem_type,
                         _graph_mem_type)
{
}

ogbn_cuda::ogbn_cuda(const std::string& raw_dir,
                     int64_t _n_nodes,
                     int64_t _n_cols,
                     bool _is_undirected,
                     int32_t _n_node_types,
                     int32_t _n_edge_types,
                     uint16_t _resize_factor,
                     cudaMemoryType _feats_mem_type,
                     cudaMemoryType _graph_mem_type)
{
  n_nodes        = _n_nodes;
  n_cols         = _n_cols;
  is_hg          = _n_node_types > 1 || _n_edge_types > 1;
  feats_mem_type = _feats_mem_type;
  graph_mem_type = _graph_mem_type;

  // if binary does not exists: create it by reading raw data first
  auto binary_file = raw_dir + "/graph.bin.gz";
  FILE* file       = fopen(binary_file.c_str(), "r");
  if (file == nullptr) {
    auto data = ogbn_cpu(raw_dir, n_nodes, n_cols, _is_undirected, _n_node_types, _n_edge_types);
    data.dump(binary_file);
  } else {
    ASSERT(fclose(file) == 0, "ogbg: failed to close file '%s'", binary_file.c_str());
  }

  graph = is_hg ? std::make_unique<fg_csr_hg_s64_t>() : std::make_unique<fg_csr_s64_t>();
  n_nodes *= _resize_factor;
  graph->n_nodes   = n_nodes;
  auto feats_alloc = utils::generic_allocator(_feats_mem_type);
  auto graph_alloc = utils::generic_allocator(_graph_mem_type);

  read(raw_dir, _resize_factor);
}

void ogbn_cuda::read(const std::string& raw_dir, uint16_t resize_factor)
{
  auto file = raw_dir + "/graph.bin.gz";
  CUGRAPH_OPS_DEBUG("ogbn_cuda::read: load preprocessed dataset from '%s'...\n", file.c_str());
  utils::cpu::tic_for_log(utils::LEVEL_TIMER, "ogbn_cuda::read");
  igzstream igz;
  igz.open(file.c_str());
  ASSERT(igz.is_open(), "ogbn_cuda::read: failed to open file '%s' for reading", file.c_str());

  auto feats_alloc = utils::generic_allocator(feats_mem_type);
  auto graph_alloc = utils::generic_allocator(graph_mem_type);

  size_t tmp;
  size_t n_nodes_orig = n_nodes / resize_factor;
  alloc_and_read_vec(graph->indices,
                     graph_alloc,
                     igz,
                     tmp,
                     resize_factor,
                     nullptr,
                     [n_nodes_orig](int64_t* ptr, uint16_t fac, size_t len_orig) {
                       std::memcpy(&ptr[len_orig * fac], &ptr[0], sizeof(int64_t) * len_orig);
                       for (size_t idx = 0; idx < len_orig; ++idx) {
                         ptr[len_orig * fac + idx] += n_nodes_orig * fac;
                       }
                     });
  graph->n_indices      = static_cast<int64_t>(tmp);
  size_t n_indices_orig = graph->n_indices / resize_factor;
  // Note that with resize_factor > 1, graph->offsets technically is allocated with (resize_factor -
  // 1) too many elements. However, this small overhead is kept for the sake of simplicity
  alloc_and_read_vec(
    graph->offsets,
    graph_alloc,
    igz,
    tmp,
    resize_factor,
    nullptr,
    [n_nodes_orig, n_indices_orig](int64_t* ptr, uint16_t fac, size_t /*len_orig*/) {
      std::memcpy(&ptr[1 + n_nodes_orig * fac], &ptr[1], sizeof(int64_t) * n_nodes_orig);
      for (size_t idx = 0; idx < n_nodes_orig; ++idx) {
        ptr[1 + n_nodes_orig * fac + idx] += n_indices_orig * fac;
      }
    });
  alloc_and_read_vec(features,
                     feats_alloc,
                     igz,
                     tmp,
                     resize_factor,
                     nullptr,
                     [](float* ptr, uint16_t fac, size_t len_orig) {
                       std::memcpy(&ptr[len_orig * fac], &ptr[0], sizeof(float) * len_orig);
                     });
  alloc_and_read_vec(labels,
                     feats_alloc,
                     igz,
                     tmp,
                     resize_factor,
                     nullptr,
                     [](int32_t* ptr, uint16_t fac, size_t len_orig) {
                       std::memcpy(&ptr[len_orig * fac], &ptr[0], sizeof(int32_t) * len_orig);
                     });
  n_labels = static_cast<int64_t>(tmp);

  if (is_hg) {
    auto* graph_hg = dynamic_cast<fg_csr_hg_s64_t*>(graph.get());
    std::vector<int32_t> n_types;
    read_vec(n_types, igz);
    graph_hg->n_edge_types = n_types[0] * resize_factor;
    graph_hg->n_node_types = n_types[1] * resize_factor;
    alloc_and_read_vec(graph_hg->edge_types,
                       graph_alloc,
                       igz,
                       tmp,
                       resize_factor,
                       nullptr,
                       [](int32_t* ptr, uint16_t fac, size_t len_orig) {
                         std::memcpy(&ptr[len_orig * fac], &ptr[0], sizeof(int32_t) * len_orig);
                       });
    alloc_and_read_vec(graph_hg->node_types,
                       graph_alloc,
                       igz,
                       tmp,
                       resize_factor,
                       nullptr,
                       [](int32_t* ptr, uint16_t fac, size_t len_orig) {
                         std::memcpy(&ptr[len_orig * fac], &ptr[0], sizeof(int32_t) * len_orig);
                       });
  }
  igz.close();

  CUGRAPH_OPS_INFO("Graph information:\n  #edges:  %" PRId64 "\n  #nodes:  %" PRId64
                   "\n  #cols:   %" PRId64 "\n  #labels: %" PRId64 "\n",
                   int64_t{graph->n_indices},
                   n_nodes,
                   n_cols,
                   n_labels);
  utils::cpu::toc_and_log(utils::LEVEL_TIMER, "ogbn_cuda::read");
}

ogbn_cuda::~ogbn_cuda()
{
  // deallocate or unregister feature-related buffers
  auto feats_alloc = utils::generic_allocator(feats_mem_type);
  feats_alloc.dealloc(features, 0, nullptr);
  feats_alloc.dealloc(labels, 0, nullptr);
  // deallocate or unregister graph-related buffers
  auto graph_alloc = utils::generic_allocator(graph_mem_type);
  graph_alloc.dealloc(graph->offsets, 0, nullptr);
  graph_alloc.dealloc(graph->indices, 0, nullptr);
  if (is_hg) {
    auto* graph_hg = dynamic_cast<fg_csr_hg_s64_t*>(graph.get());
    graph_alloc.dealloc(graph_hg->node_types, 0, nullptr);
    graph_alloc.dealloc(graph_hg->edge_types, 0, nullptr);
  }
}

}  // namespace cugraph::ops::io
