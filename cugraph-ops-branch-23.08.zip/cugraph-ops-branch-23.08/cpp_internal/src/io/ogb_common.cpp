/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION . All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "ogb_common.hpp"

namespace cugraph::ops::io {

bool compare_edge(const edge_info& a, const edge_info& b)
{
  if (a.id1 < b.id1) return true;
  if (a.id1 > b.id1) return false;
  return a.id2 < b.id2;
}

bool compare_edge_rev(const edge_info& a, const edge_info& b)
{
  if (a.id2 < b.id2) return true;
  if (a.id2 > b.id2) return false;
  return a.id1 < b.id1;
}

}  // namespace cugraph::ops::io
