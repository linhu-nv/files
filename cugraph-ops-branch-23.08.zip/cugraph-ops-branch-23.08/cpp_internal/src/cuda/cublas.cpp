/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cublas_wrappers.hpp>

#include <cugraph-ops/cuda/cublas.hpp>
#include <cugraph-ops/utils/logger.hpp>

namespace cugraph::ops::cuda {

cublashandle::cublashandle()
{
  is_owned_ = true;
  RAFT_CUBLAS_TRY(cublasCreate(&h_));
}

cublashandle::cublashandle(cublasHandle_t h)
{
  is_owned_ = false;
  h_        = h;
}

cublashandle::cublashandle(const cublashandle& other)
{
  is_owned_ = false;
  h_        = other.h_;
}

cublashandle& cublashandle::operator=(const cublashandle& other)
{
  if (this == &other) return *this;
  if (is_owned_) RAFT_CUBLAS_TRY(cublasDestroy(h_));
  is_owned_ = false;
  h_        = other.h_;
  return *this;
}

cublashandle::~cublashandle()
{
  if (is_owned_) { RAFT_CUBLAS_TRY_NO_THROW(cublasDestroy(h_)); }
}

}  // namespace cugraph::ops::cuda
