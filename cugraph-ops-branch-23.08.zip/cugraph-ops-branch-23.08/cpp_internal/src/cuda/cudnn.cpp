/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cudnn_wrappers.hpp>

#include <cugraph-ops/cuda/cudnn.hpp>
#include <cugraph-ops/utils/logger.hpp>

namespace cugraph::ops::cuda {

cudnnhandle::cudnnhandle()
{
  is_owned_ = true;
  CUGRAPH_OPS_CUDNN_TRY(cudnnCreate(&h_));
}

cudnnhandle::cudnnhandle(cudnnHandle_t h)
{
  is_owned_ = false;
  h_        = h;
}

cudnnhandle::cudnnhandle(const cudnnhandle& other)
{
  is_owned_ = false;
  h_        = other.h_;
}

cudnnhandle& cudnnhandle::operator=(const cudnnhandle& other)
{
  if (this == &other) return *this;
  if (is_owned_) CUGRAPH_OPS_CUDNN_TRY(cudnnDestroy(h_));
  is_owned_ = false;
  h_        = other.h_;
  return *this;
}

cudnnhandle::~cudnnhandle()
{
  if (is_owned_) { CUGRAPH_OPS_CUDNN_TRY_NO_THROW(cudnnDestroy(h_)); }
}

}  // namespace cugraph::ops::cuda
