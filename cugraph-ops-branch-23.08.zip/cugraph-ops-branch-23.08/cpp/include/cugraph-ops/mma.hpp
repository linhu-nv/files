/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/utils/error.hpp>
#include <cugraph-ops/utils/logger.hpp>

#include <cstdint>

namespace cugraph::ops {

/**
 * @brief Type of MMA OPeration
 *
 */
enum class MMAOpT : uint8_t {
  /** use high precision tensor core MMA operation
      for fp32, this means using the 3x TF32 "trick"
  */
  kHighPrecision = 0,
  /** use low precision tensor core MMA operation
      for fp32, this means using a single TF32 MMA
      for fp64, this is equivalent to kHighPrecision
  */
  kLowPrecision,
  /** use a simple kSimt MM implementation */
  kSimt
};  // enum class MMAOptT

}  // namespace cugraph::ops
