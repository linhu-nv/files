/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/graph/format.hpp>

#include <cstdint>

namespace cugraph::ops::graph {

/**
 * @brief Computes the max vertex degree of the input graph
 *
 * @param[out] out    will contain the max vertex degree [on device] [len = `1`]
 * @param[in]  graph  input graph whose max vertex degree needs to be computed
 * @param[in]  stream cuda stream where to schedule work
 *
 * @{
 */
void max_vertex_degree(int32_t* out, const fg_csr_s32_t& graph, cudaStream_t stream);
void max_vertex_degree(int64_t* out, const fg_csr_s64_t& graph, cudaStream_t stream);
/** @} */

}  // namespace cugraph::ops::graph
