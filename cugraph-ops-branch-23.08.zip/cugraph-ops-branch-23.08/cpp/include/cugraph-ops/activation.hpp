/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cstdint>

namespace cugraph::ops {

/** Types of activations supported */
enum class ActivationOpT : uint8_t {
  /** y = x */
  kLinear = 0,
  /** y = relu(x) */
  kRelu,
  /** y = 1 / (e^-x + 1) */
  kSigmoid,
  /** y = tanh(x) */
  kTanh,
  /** y = e^x - 1 if x < 0 else x */
  kELU,
  /** y = alpha * x */
  kScalar,
  /** y = x * alpha if x < 0 else x */
  kLeakyRelu,
};  // enum ActivationOpT

/**
 * @brief a god(!) struct to store all activation params
 */
struct __attribute__((aligned(8))) activation_params {
  /** negative slope for the leaky-relu */
  float alpha{0.F};
  /** activation type */
  ActivationOpT type{ActivationOpT::kLinear};
};  // struct activation_params

}  // namespace cugraph::ops
