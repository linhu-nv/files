/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <string>

namespace cugraph::ops::utils {

/** Returns the library version as a string */
std::string version_str();

}  // namespace cugraph::ops::utils
