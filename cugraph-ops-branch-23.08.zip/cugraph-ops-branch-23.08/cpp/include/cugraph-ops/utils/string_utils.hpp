/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cstdint>
#include <cstdio>
#include <memory>
#include <string>
#include <vector>

namespace cugraph::ops::utils {

/**
 * @brief Splits the input string into a vector as per the delimiter
 *
 * @param[in] str   input string to be split
 * @param[in] delim the delimiter char
 */
std::vector<std::string> split(const std::string& str, char delim);

/**
 * @brief Converts the input string into an integer
 *
 * @param[in] str input string. If it is not an integer, an exception will be
 *                raised
 *
 * @{
 */
int str2int(const std::string& str);
uint64_t str2uint64_t(const std::string& str);
/** @} */

float str2float(const std::string& str);

/**
 * @brief Format a "format" literal according to the arguments.
 *
 * @note We don't use variadic templates here as this is called for every
 *       logging call, thus variadic templates may increase compilation time
 *       and binary size.
 *
 * @param[in] fmt  the format string literal
 * @param[in] ...  the arguments to be formatted
 */
std::string format(const char* fmt, ...) noexcept;

/**
 * @brief Checks for the input value to belong to the list of allowed options
 *
 * @param[in] val  input value to be checked for
 * @param[in] vals list of values to be compared against.
 */
bool is_any_of(const std::string& val, const std::vector<std::string>& vals);

/**
 * @brief Checks for the input value to belong to the list of allowed options
 *
 * @param[in] val     input value to be checked for
 * @param[in] options values to be compared against. They must be passed as a
 *                    string of comma-separated values.
 */
bool is_any_of(const std::string& val, const std::string& options);

}  // namespace cugraph::ops::utils
