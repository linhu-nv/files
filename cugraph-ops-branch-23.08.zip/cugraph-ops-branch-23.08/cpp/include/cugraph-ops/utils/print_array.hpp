/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <string>

namespace cugraph::ops::utils {

/**
 * @brief Print the values contained in an array to stdout (host or device)
 *
 * @param[in]  in         input array to be printed [len = `len`]
 * @param[in]  n          number of elements in input array
 * @param[in]  name       name of the array to be printed
 * @param[in]  prec       optional precision. If >0, number of decimal points
 *
 * @{
 */
void print_a(char const* in, size_t n, const std::string& name, int prec = 0);
void print_a(int8_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(uint8_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(int16_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(uint16_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(int32_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(uint32_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(int64_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(uint64_t const* in, size_t n, const std::string& name, int prec = 0);
void print_a(float const* in, size_t n, const std::string& name, int prec = 0);
void print_a(double const* in, size_t n, const std::string& name, int prec = 0);
/** @} */

}  // namespace cugraph::ops::utils
