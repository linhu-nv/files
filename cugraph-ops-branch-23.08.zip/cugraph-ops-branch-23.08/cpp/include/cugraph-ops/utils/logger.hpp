/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/utils/string_utils.hpp>

#include <iostream>

namespace cugraph::ops::utils {

static constexpr int LEVEL_FATAL = 0;
static constexpr int LEVEL_ERROR = 10;
static constexpr int LEVEL_WARN  = 100;
static constexpr int LEVEL_INFO  = 1000;
static constexpr int LEVEL_TIMER = 10000;
static constexpr int LEVEL_DEBUG = 100000;
static constexpr int LEVEL_TRACE = 1000000;

int& get_log_level() noexcept;

void set_log_level(int lev) noexcept;

bool will_log_for(int lev) noexcept;

#define CUGRAPH_OPS_LOG(lev, fmt, ...)                                            \
  do {                                                                            \
    if (cugraph::ops::utils::will_log_for(lev))                                   \
      std::cout << cugraph::ops::utils::format(fmt, ##__VA_ARGS__) << std::flush; \
  } while (0)

#define CUGRAPH_OPS_FATAL(fmt, ...) \
  CUGRAPH_OPS_LOG(cugraph::ops::utils::LEVEL_FATAL, fmt, ##__VA_ARGS__)
#define CUGRAPH_OPS_ERROR(fmt, ...) \
  CUGRAPH_OPS_LOG(cugraph::ops::utils::LEVEL_ERROR, fmt, ##__VA_ARGS__)
#define CUGRAPH_OPS_WARN(fmt, ...) \
  CUGRAPH_OPS_LOG(cugraph::ops::utils::LEVEL_WARN, fmt, ##__VA_ARGS__)
#define CUGRAPH_OPS_INFO(fmt, ...) \
  CUGRAPH_OPS_LOG(cugraph::ops::utils::LEVEL_INFO, fmt, ##__VA_ARGS__)
#define CUGRAPH_OPS_DEBUG(fmt, ...) \
  CUGRAPH_OPS_LOG(cugraph::ops::utils::LEVEL_DEBUG, fmt, ##__VA_ARGS__)
#define CUGRAPH_OPS_TRACE(fmt, ...) \
  CUGRAPH_OPS_LOG(cugraph::ops::utils::LEVEL_TRACE, fmt, ##__VA_ARGS__)

}  // namespace cugraph::ops::utils
