/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/activation.hpp>
#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/graph/format.hpp>

#include <cstdint>

namespace cugraph::ops {

/**
 * @brief Type of aggregation operation
 */
enum class AggOpT : uint8_t {
  /** mean across the neighbor embeddings */
  kMean = 0,
  /** sum across the neighbor embeddings */
  kSum,
  /** max across the neighbor embeddings */
  kMax,
  /** min across the neighbor embeddings */
  kMin
};  // enum class AggOpT

/*
 * @brief Type of implementation of agg_hg_basis kernels
 */
enum class AggHgImplementationT : uint8_t {
  /* default csc */
  kDefaultT,
  /* big vertex */
  kBigVertexImplementationT,
  /* memory efficient big vertex */
  kBigVertexLessMemoryImplementationT
};  // enum class AggHgImplementationT

struct __attribute__((aligned(16))) mha_params {
  activation_params activation;
  int num_heads{1};
  bool concat_heads{true};
};

}  // namespace cugraph::ops
