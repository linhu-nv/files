/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#define CUGRAPH_OPS_UNPACK(...) __VA_ARGS__

// for a function template foo<AggOpT AGG_OP, int I1, int I2>(arg1, arg2) call:
// CUGRAPH_OPS_AGG_OPT(agg_op, (I1, I2), foo, arg1, arg2)
// note that you need to specify at least one additional template parameter
// (may be a dummy in case you don't actually need it), and those additional
// template parameters must always be placed in parentheses
// i.e. the following will not work:
// CUGRAPH_OPS_AGG_OPT(agg_op, (), foo, arg1, arg2)
// CUGRAPH_OPS_AGG_OPT(agg_op, , foo, arg1, arg2)
// CUGRAPH_OPS_AGG_OPT(agg_op, I1, I2, foo, arg1, arg2)
#define CUGRAPH_OPS_AGG_OPT(op, templ, func, ...)                                          \
  switch (op) {                                                                            \
    case AggOpT::kMean: func<AggOpT::kMean, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__); break; \
    case AggOpT::kSum: func<AggOpT::kSum, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__); break;   \
    case AggOpT::kMin: func<AggOpT::kMin, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__); break;   \
    case AggOpT::kMax: func<AggOpT::kMax, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__); break;   \
    default: ASSERT(false, "Invalid aggregation op pased '%d'!", static_cast<int>(op));    \
  }

// for usage, see `CUGRAPH_OPS_AGG_OPT`
#define CUGRAPH_OPS_AGG_OPT_FLAG(op, flag, templ, func, ...)                            \
  switch (op) {                                                                         \
    case AggOpT::kMean:                                                                 \
      if (flag)                                                                         \
        func<AggOpT::kMean, true, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);               \
      else                                                                              \
        func<AggOpT::kMean, false, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);              \
      break;                                                                            \
    case AggOpT::kSum:                                                                  \
      if (flag)                                                                         \
        func<AggOpT::kSum, true, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);                \
      else                                                                              \
        func<AggOpT::kSum, false, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);               \
      break;                                                                            \
    case AggOpT::kMin:                                                                  \
      if (flag)                                                                         \
        func<AggOpT::kMin, true, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);                \
      else                                                                              \
        func<AggOpT::kMin, false, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);               \
      break;                                                                            \
    case AggOpT::kMax:                                                                  \
      if (flag)                                                                         \
        func<AggOpT::kMax, true, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);                \
      else                                                                              \
        func<AggOpT::kMax, false, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);               \
      break;                                                                            \
    default: ASSERT(false, "Invalid aggregation op pased '%d'!", static_cast<int>(op)); \
  }

// for usage, see `CUGRAPH_OPS_AGG_OPT`
#define CUGRAPH_OPS_AGG_HG_OPT(has_weights, do_norm, templ, func, ...) \
  if ((has_weights) && (do_norm))                                      \
    func<true, true, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);           \
  else if (has_weights)                                                \
    func<true, false, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);          \
  else if (do_norm)                                                    \
    func<false, true, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);          \
  else                                                                 \
    func<false, false, CUGRAPH_OPS_UNPACK templ>(__VA_ARGS__);
