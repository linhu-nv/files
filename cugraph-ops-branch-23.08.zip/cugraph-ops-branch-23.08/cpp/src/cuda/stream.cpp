/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cudart.hpp>

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/utils/error.hpp>
#include <cugraph-ops/utils/logger.hpp>

namespace cugraph::ops::cuda {

stream::stream()
{
  is_owned_ = true;
  RAFT_CUDA_TRY(cudaStreamCreate(&st_));
}

stream::stream(cudaStream_t st)
{
  is_owned_ = false;
  st_       = st;
}

stream::stream(const stream& other)
{
  is_owned_ = false;
  st_       = other.st_;
}

stream& stream::operator=(const stream& other)
{
  if (this == &other) return *this;
  if (is_owned_) RAFT_CUDA_TRY(cudaStreamDestroy(st_));
  is_owned_ = false;
  st_       = other.st_;
  return *this;
}

stream::~stream()
{
  if (is_owned_) { RAFT_CUDA_TRY_NO_THROW(cudaStreamDestroy(st_)); }
}

void stream::sync() { utils::sync(st_); }

}  // namespace cugraph::ops::cuda
