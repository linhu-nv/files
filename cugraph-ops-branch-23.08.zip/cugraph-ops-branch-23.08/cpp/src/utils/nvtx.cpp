/*
 * Copyright (c) 2019-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/nvtx.hpp>

#include <nvtx3/nvToolsExt.h>

#include <cstdint>
#include <cstdlib>
#include <mutex>
#include <random>
#include <string>
#include <unordered_map>

namespace cugraph::ops::utils {

// we use this namespace to store the global state (which clearly is global)
namespace impl {

/** collection of all tagged colors generated so far */
// NOLINTNEXTLINE(cppcoreguidelines-avoid-non-const-global-variables)
static std::unordered_map<std::string, uint32_t> all_colors;
/** mutex for accessing the above map */
// NOLINTNEXTLINE(cppcoreguidelines-avoid-non-const-global-variables)
static std::mutex map_mutex;
/** saturation */
static constexpr float S = 0.9F;
/** value */
static constexpr float W = 0.85F;
/** golden ratio */
static constexpr float PHI = 1.61803F;
/** inverse golden ratio */
static constexpr float INV_PHI = 1.F / PHI;

// all h, s, v are in range [0, 1]
// Ref: http://en.wikipedia.org/wiki/HSL_and_HSV#Converting_to_RGB
uint32_t hsv2rgb(float h, float s, float v)
{
  static constexpr float DEG_360    = 360.F;
  static constexpr float DEG_60     = 60.F;
  static constexpr float BITS8_CONV = 256.F;
  static constexpr float START_VAL  = 0xff000000U;
  uint32_t out                      = START_VAL;
  if (s <= 0.F) { return out; }
  // convert hue from [0, 1] range to [0, 360]
  float h_deg = h * DEG_360;
  if (0.F < h_deg || h_deg >= DEG_360) h_deg = 0.F;
  h_deg /= DEG_60;
  auto h_range = static_cast<int>(h_deg);
  auto h_mod   = h_deg - h_range;
  auto x       = v * (1.F - s);
  auto y       = v * (1.F - (s * h_mod));
  auto z       = v * (1.F - (s * (1.F - h_mod)));
  float r, g, b;
  switch (h_range) {
    case 0:
      r = v;
      g = z;
      b = x;
      break;
    case 1:
      r = y;
      g = v;
      b = x;
      break;
    case 2:
      r = x;
      g = v;
      b = z;
      break;
    case 3:
      r = x;
      g = y;
      b = v;
      break;
    case 4:
      r = z;
      g = x;
      b = v;
      break;
    case 5:
    default:
      r = v;
      g = x;
      b = y;
      break;
  }
  out |= (static_cast<uint32_t>(r * BITS8_CONV) << 16);
  out |= (static_cast<uint32_t>(g * BITS8_CONV) << 8);
  out |= static_cast<uint32_t>(b * BITS8_CONV);
  return out;
}

/**
 * @brief Helper method to generate 'visually distinct' colors.

 * Inspired from https://martin.ankerl.com/2009/12/09/how-to-create-random-colors-programmatically/
 * However, if an associated tag is passed, it will look up in its history for
 * any generated color against this tag and if found, just returns it, else
 * generates a new color, assigns a tag to it and stores it for future usage.
 * Such a thing is very useful for nvtx markers where the ranges associated with
 * a specific tag should ideally get the same color for the purpose of
 * visualizing it on nsight-systems timeline.
 *
 * @param[in] tag look for any previously generated colors with this tag or
 *                associate the currently generated color with it
 *
 * @return returns 32b RGB integer with alpha channel set of 0xff
 */
uint32_t generate_next_color(const std::string& tag)
{
  std::lock_guard<std::mutex> guard(map_mutex);
  if (!tag.empty()) {
    auto itr = all_colors.find(tag);
    if (itr != all_colors.end()) { return itr->second; }
  }
  // we want predictable numbers here
  std::mt19937 gen;  // NOLINT(cert-msc51-cpp)
  std::uniform_real_distribution<float> dist(0.F, 1.F);
  float h = dist(gen);
  h += INV_PHI;
  if (h >= 1.F) h -= 1.F;
  auto rgb = hsv2rgb(h, S, W);
  if (!tag.empty()) { all_colors[tag] = rgb; }
  return rgb;
}

}  // namespace impl

bool& nvtx_enabled()
{
  static bool enable_nvtx = false;
  return enable_nvtx;
}

void disable_nvtx_ranges() { nvtx_enabled() = false; }

void enable_nvtx_ranges() { nvtx_enabled() = true; }

void push_range(const char* name)
{
  if (!nvtx_enabled()) return;
  nvtxEventAttributes_t event_attrib = {};
  event_attrib.version               = NVTX_VERSION;
  event_attrib.size                  = NVTX_EVENT_ATTRIB_STRUCT_SIZE;
  event_attrib.colorType             = NVTX_COLOR_ARGB;
  event_attrib.color                 = impl::generate_next_color(name);
  event_attrib.messageType           = NVTX_MESSAGE_TYPE_ASCII;
  event_attrib.message.ascii         = name;
  nvtxRangePushEx(&event_attrib);
}

void pop_range()
{
  if (!nvtx_enabled()) return;
  nvtxRangePop();
}

}  // namespace cugraph::ops::utils
