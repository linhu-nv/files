/*
 * Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#define CUGRAPH_OPS_STRINGIFY_DETAIL(x) #x
#define CUGRAPH_OPS_STRINGIFY(x)        CUGRAPH_OPS_STRINGIFY_DETAIL(x)

#define CUGRAPH_OPS_UNROLL _Pragma("unroll")
#if defined(__clang__) && defined(__CUDA__)
// clang wants pragma unroll without parentheses
#define CUGRAPH_OPS_UNROLL_N(n) _Pragma(CUGRAPH_OPS_STRINGIFY(unroll n))
#else
// nvcc / nvrtc want pragma unroll with parentheses
#define CUGRAPH_OPS_UNROLL_N(n) _Pragma(CUGRAPH_OPS_STRINGIFY(unroll(n)))
#endif

#if defined(__clang__)
#define CUGRAPH_OPS_CONSTEXPR_D constexpr
#else
#define CUGRAPH_OPS_CONSTEXPR_D constexpr __device__
#endif
