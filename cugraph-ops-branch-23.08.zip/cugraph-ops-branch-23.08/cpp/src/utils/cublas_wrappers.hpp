/*
 * Copyright (c) 2018-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include "cudart.hpp"

#include <raft/linalg/detail/cublas_wrappers.hpp>

#include <cublas_v2.h>

#include <cstdint>

namespace cugraph::ops::utils {

/**
 * @defgroup gemm cublas gemm calls
 * @{
 */
template <typename DataT>
cublasStatus_t cublasgemm(cublasHandle_t handle,
                          cublasOperation_t transA,
                          cublasOperation_t transB,
                          int m,
                          int n,
                          int k,
                          const DataT* alpha,
                          const DataT* A,
                          int lda,
                          const DataT* B,
                          int ldb,
                          const DataT* beta,
                          DataT* C,
                          int ldc,
                          cudaStream_t stream);
template <>
inline cublasStatus_t cublasgemm(cublasHandle_t handle,
                                 cublasOperation_t transA,
                                 cublasOperation_t transB,
                                 int m,
                                 int n,
                                 int k,
                                 const float* alpha,
                                 const float* A,
                                 int lda,
                                 const float* B,
                                 int ldb,
                                 const float* beta,
                                 float* C,
                                 int ldc,
                                 cudaStream_t stream)
{
  RAFT_CUBLAS_TRY(cublasSetStream(handle, stream));
  return cublasSgemm(handle, transA, transB, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc);
}
template <>
inline cublasStatus_t cublasgemm(cublasHandle_t handle,
                                 cublasOperation_t transA,
                                 cublasOperation_t transB,
                                 int m,
                                 int n,
                                 int k,
                                 const double* alpha,
                                 const double* A,
                                 int lda,
                                 const double* B,
                                 int ldb,
                                 const double* beta,
                                 double* C,
                                 int ldc,
                                 cudaStream_t stream)
{
  RAFT_CUBLAS_TRY(cublasSetStream(handle, stream));
  return cublasDgemm(handle, transA, transB, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc);
}
/** @} */

}  // namespace cugraph::ops::utils
