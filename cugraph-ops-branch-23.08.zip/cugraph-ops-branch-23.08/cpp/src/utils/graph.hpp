/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/graph/format.hpp>

namespace cugraph::ops::utils {
template <typename IdxT>
struct get_graph {
  /**
   * @brief Get number of out-nodes of the graph.
   * @{
   */
  __host__ __device__ static inline IdxT n_out_nodes(graph::fg_csr<IdxT> graph)
  {
    return graph.n_nodes;
  }
  __host__ __device__ static inline IdxT n_out_nodes(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.n_nodes;
  }
  __host__ __device__ static inline IdxT n_out_nodes(graph::bipartite_csc<IdxT> graph)
  {
    return graph.n_out_nodes;
  }
  __host__ __device__ static inline IdxT n_out_nodes(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.n_out_nodes;
  }
  __host__ __device__ static inline IdxT n_out_nodes(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.n_nodes;
  }
  /** @} */

  /**
   * @brief Get number of in-nodes of the graph.
   * @{
   */
  __host__ __device__ static inline IdxT n_in_nodes(graph::fg_csr<IdxT> graph)
  {
    return graph.n_nodes;
  }
  __host__ __device__ static inline IdxT n_in_nodes(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.n_nodes;
  }
  __host__ __device__ static inline IdxT n_in_nodes(graph::bipartite_csc<IdxT> graph)
  {
    return graph.n_in_nodes;
  }
  __host__ __device__ static inline IdxT n_in_nodes(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.n_in_nodes;
  }
  __host__ __device__ static inline IdxT n_in_nodes(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.n_nodes;
  }
  /** @} */

  /**
   * @brief Get total number of edges of the graph.
   * @{
   */
  __host__ __device__ static inline IdxT n_edges(graph::fg_csr<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_edges(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_edges(graph::bipartite_csc<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_edges(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_edges(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.n_edges;
  }
  /** @} */

  /**
   * @brief Get total number of indices of the graph (out of convenience duplicate to n_edges)
   * @{
   */
  __host__ __device__ static inline IdxT n_indices(graph::fg_csr<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_indices(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_indices(graph::bipartite_csc<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_indices(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.n_indices;
  }
  __host__ __device__ static inline IdxT n_indices(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.n_edges;
  }
  /** @} */

  /**
   * @brief Get batch size of (potential) batch of graphs.
   * @{
   */
  __host__ __device__ static inline IdxT batch_size(graph::fg_csr<IdxT> /*graph*/)
  {
    return IdxT{1};
  }
  __host__ __device__ static inline IdxT batch_size(graph::fg_csr_rev<IdxT> /*graph*/)
  {
    return IdxT(1);
  }
  __host__ __device__ static inline IdxT batch_size(graph::bipartite_csc<IdxT> /*graph*/)
  {
    return IdxT{1};
  }
  __host__ __device__ static inline IdxT batch_size(graph::bipartite_csc_csr<IdxT> /*graph*/)
  {
    return IdxT(1);
  }
  __host__ __device__ static inline IdxT batch_size(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.batch_size;
  }
  /** @} */

  /**
   * @brief Get pointer of the offsets of the csr graph structure
   * @{
   */
  __host__ __device__ static inline IdxT* offsets(graph::fg_csr<IdxT> graph)
  {
    return graph.offsets;
  }
  __host__ __device__ static inline IdxT* offsets(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.offsets;
  }
  __host__ __device__ static inline IdxT* offsets(graph::bipartite_csc<IdxT> graph)
  {
    return graph.offsets;
  }
  __host__ __device__ static inline IdxT* offsets(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.offsets;
  }
  __host__ __device__ static inline IdxT* offsets(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.csr_seq.offsets;
  }
  __host__ __device__ static inline IdxT* offsets(graph::fg_csr_seq<IdxT> graph_seq)
  {
    return graph_seq.offsets;
  }
  /** @} */

  /**
   * @brief Get pointer of the indices of the csr graph structure
   * @{
   */
  __host__ __device__ static inline IdxT* indices(graph::fg_csr<IdxT> graph)
  {
    return graph.indices;
  }
  __host__ __device__ static inline IdxT* indices(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.indices;
  }
  __host__ __device__ static inline IdxT* indices(graph::bipartite_csc<IdxT> graph)
  {
    return graph.indices;
  }
  __host__ __device__ static inline IdxT* indices(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.indices;
  }
  __host__ __device__ static inline IdxT* indices(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.csr_seq.indices;
  }
  __host__ __device__ static inline IdxT* indices(graph::fg_csr_seq<IdxT> graph_seq)
  {
    return graph_seq.indices;
  }
  /** @} */

  /**
   * @brief Get edge indices of (potential) batch of graphs.
   * @{
   */
  __host__ __device__ static inline IdxT* ef_indices(graph::fg_csr<IdxT> graph)
  {
    return graph.ef_indices;
  }
  __host__ __device__ static inline IdxT* ef_indices(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.ef_indices;
  }
  __host__ __device__ static inline IdxT* ef_indices(graph::bipartite_csc<IdxT> graph)
  {
    return graph.ef_indices;
  }
  __host__ __device__ static inline IdxT* ef_indices(graph::bipartite_csc_csr<IdxT> graph)
  {
    return graph.ef_indices;
  }
  __host__ __device__ static inline IdxT* ef_indices(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.csr_seq.ef_indices;
  }
  __host__ __device__ static inline IdxT* ef_indices(graph::fg_csr_seq<IdxT> graph_seq)
  {
    return graph_seq.ef_indices;
  }
  /** @} */

  /**
   * @brief Get pointer of the reverse edge indices of the csr graph structure
   * @{
   */
  __host__ __device__ static inline IdxT* rev_edge_ids(graph::fg_csr<IdxT> graph)
  {
    return graph.rev_edge_ids;
  }
  __host__ __device__ static inline IdxT* rev_edge_ids(graph::fg_csr_rev<IdxT> graph)
  {
    return graph.rev_edge_ids;
  }
  __host__ __device__ static inline IdxT* rev_edge_ids(graph::bipartite_csc<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* rev_edge_ids(graph::bipartite_csc_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* rev_edge_ids(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.csr_seq.rev_edge_ids;
  }
  __host__ __device__ static inline IdxT* rev_edge_ids(graph::fg_csr_seq<IdxT> graph_seq)
  {
    return graph_seq.rev_edge_ids;
  }
  /** @} */

  /**
   * @brief Get pointer of the graph offsets of the csr graph structure (if existing)
   * @{
   */
  __host__ __device__ static inline IdxT* graph_offsets(graph::fg_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* graph_offsets(graph::fg_csr_rev<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* graph_offsets(graph::bipartite_csc<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* graph_offsets(graph::bipartite_csc_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* graph_offsets(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.csr_seq.graph_offsets;
  }
  __host__ __device__ static inline IdxT* graph_offsets(graph::fg_csr_seq<IdxT> graph_seq)
  {
    return graph_seq.graph_offsets;
  }
  /** @} */

  /**
   * @brief Get the pointer of the batch offsets of the csr graph structure (if existing)
   * @{
   */
  __host__ __device__ static inline IdxT* batch_offsets(graph::fg_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* batch_offsets(graph::fg_csr_rev<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* batch_offsets(graph::bipartite_csc<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* batch_offsets(graph::bipartite_csc_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* batch_offsets(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.batch_offsets;
  }
  /** @} */

  /**
   * @brief Get the pointer of the node feature offsets of the csr graph structure (if existing)
   * @{
   */
  __host__ __device__ static inline IdxT* nf_offsets(graph::fg_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* nf_offsets(graph::fg_csr_rev<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* nf_offsets(graph::bipartite_csc<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* nf_offsets(graph::bipartite_csc_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* nf_offsets(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.nf_offsets;
  }
  /** @} */

  /**
   * @brief Get the pointer of the edge feature offsets of the csr graph structure (if existing)
   * @{
   */
  __host__ __device__ static inline IdxT* ef_offsets(graph::fg_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* ef_offsets(graph::fg_csr_rev<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* ef_offsets(graph::bipartite_csc<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* ef_offsets(graph::bipartite_csc_csr<IdxT> /* graph */)
  {
    return nullptr;
  }
  __host__ __device__ static inline IdxT* ef_offsets(graph::fg_csr_batch<IdxT> graph_batch)
  {
    return graph_batch.ef_offsets;
  }
  /** @} */
};

/**
 * @brief Structure containing adjacency list pointers for ellpack
 * @{
 */
template <typename IdxT>
struct ellpack_info {
  IdxT* neighbors;
  IdxT* neighbor_counts;
};
/** @} */

/**
 * @brief Structure containing adjacency list pointers for csr
 * @{
 */
template <typename IdxT>
struct csr_info {
  IdxT* offsets;
  IdxT* indices;
};
/** @} */

}  // namespace cugraph::ops::utils
