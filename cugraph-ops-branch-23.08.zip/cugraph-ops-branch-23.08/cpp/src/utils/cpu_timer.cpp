/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/cpu_timer.hpp>
#include <cugraph-ops/utils/error.hpp>
#include <cugraph-ops/utils/logger.hpp>

namespace cugraph::ops::utils::cpu {

using timers_t = std::unordered_map<std::string, timer_t>;

void timer_t::tic()
{
  ASSERT(!running_, "cpu::timer_t::tic: Timer already running!");
  start_   = std::chrono::steady_clock::now();
  running_ = true;
}

void timer_t::toc()
{
  ASSERT(running_, "cpu::timer_t::toc: Timer is not running!");
  auto stop = std::chrono::steady_clock::now();
  elapsed_ += std::chrono::duration<double>(stop - start_).count();
  ++count_;
  running_ = false;
}

void timer_t::reset()
{
  elapsed_ = 0.0;
  count_   = 0;
  running_ = false;
}

timers_t& get_timers()
{
  static timers_t t;
  return t;
}

timer_t& get_timer(const std::string& name)
{
  auto& t  = get_timers();
  auto itr = t.find(name);
  ASSERT(itr != t.end(), "cpu::get_timer: Unable to find timer: '%s'!", name.c_str());
  return itr->second;
}

void tic(const std::string& name)
{
  auto& t  = get_timers();
  auto itr = t.find(name);
  if (itr == t.end()) {
    t[name] = timer_t();
    itr     = t.find(name);
  }
  itr->second.tic();
}

void toc(const std::string& name)
{
  auto& t = get_timer(name);
  t.toc();
}

void reset(const std::string& name)
{
  auto& t = get_timer(name);
  t.reset();
}

void reset_timers() { get_timers().clear(); }

void tic_for_log(int lev, const std::string& name)
{
  if (will_log_for(lev)) { tic(name); }
}

void toc_and_log(int lev, const std::string& name)
{
  if (will_log_for(lev)) {
    toc(name);
    auto& t = get_timer(name);
    CUGRAPH_OPS_LOG(lev,
                    "[Timer] name=%s total-time %lf(s) count=%d avg-time=%lf(s)\n",
                    name.c_str(),
                    t.elapsed(),
                    t.count(),
                    t.avg_elapsed());
  }
}

}  // namespace cugraph::ops::utils::cpu
