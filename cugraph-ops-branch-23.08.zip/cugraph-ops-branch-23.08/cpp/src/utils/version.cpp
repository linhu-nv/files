/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "macros.hpp"

#include <cugraph-ops/utils/version.hpp>

namespace cugraph::ops::utils {

// note: this macro is setup in the top-level cmake file
std::string version_str() { return CUGRAPH_OPS_STRINGIFY(CUGRAPH_OPS_VERSION); }

}  // namespace cugraph::ops::utils
