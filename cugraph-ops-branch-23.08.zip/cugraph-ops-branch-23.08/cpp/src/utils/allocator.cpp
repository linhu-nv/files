/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "cudart.hpp"

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/utils/allocator.hpp>

namespace cugraph::ops::utils {

void* cuda_malloc(size_t len, const cuda::stream& /*stream*/)
{
  void* ptr;
  RAFT_CUDA_TRY(cudaMalloc(&ptr, len));
  return ptr;
}

void cuda_free(void* ptr, size_t /*len*/, const cuda::stream& /*stream*/)
{
  RAFT_CUDA_TRY(cudaFree(ptr));
}

allocator& device_allocator()
{
  static allocator obj{cuda_malloc, cuda_free};
  return obj;
}

allocator set_device_allocator(const allocator& obj)
{
  auto& def = device_allocator();
  auto old  = def;
  def       = obj;
  return old;
}

void* cuda_host_malloc(size_t len, const cuda::stream& /*stream*/)
{
  void* ptr;
  RAFT_CUDA_TRY(cudaMallocHost(&ptr, len));
  return ptr;
}

void cuda_host_free(void* ptr, size_t /*len*/, const cuda::stream& /*stream*/)
{
  RAFT_CUDA_TRY(cudaFreeHost(ptr));
}

allocator& host_allocator()
{
  static allocator obj{cuda_host_malloc, cuda_host_free};
  return obj;
}

allocator set_host_allocator(const allocator& obj)
{
  auto& def = host_allocator();
  auto old  = def;
  def       = obj;
  return old;
}

void* cuda_managed_malloc(size_t len, const cuda::stream& /*stream*/)
{
  void* ptr;
  RAFT_CUDA_TRY(cudaMallocManaged(&ptr, len));
  return ptr;
}

void cuda_managed_free(void* ptr, size_t /*len*/, const cuda::stream& /*stream*/)
{
  RAFT_CUDA_TRY(cudaFree(ptr));
}

allocator& managed_allocator()
{
  static allocator obj{cuda_managed_malloc, cuda_managed_free};
  return obj;
}

allocator set_managed_allocator(const allocator& obj)
{
  auto& def = managed_allocator();
  auto old  = def;
  def       = obj;
  return old;
}

allocator generic_allocator(cudaMemoryType type)
{
  allocator alloc = utils::device_allocator();
  switch (type) {
    case cudaMemoryType::cudaMemoryTypeHost: alloc = utils::host_allocator(); break;
    case cudaMemoryType::cudaMemoryTypeDevice: alloc = utils::device_allocator(); break;
    case cudaMemoryType::cudaMemoryTypeManaged: alloc = utils::managed_allocator(); break;
    default: break;  // TODO(stadlmax), raise exception or something
  }
  return alloc;
}

}  // namespace cugraph::ops::utils
