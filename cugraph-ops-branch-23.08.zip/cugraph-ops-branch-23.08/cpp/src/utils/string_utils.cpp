/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/error.hpp>
#include <cugraph-ops/utils/string_utils.hpp>

#include <algorithm>
#include <cctype>
#include <cstdarg>
#include <cstdlib>
#include <sstream>

namespace cugraph::ops::utils {

std::vector<std::string> split(const std::string& str, char delim)
{
  std::stringstream ss(str);
  std::string item;
  std::vector<std::string> ret;
  while (std::getline(ss, item, delim)) {
    ret.push_back(item);
  }
  return ret;
}

template <typename DataT>
DataT str2integer(const std::string& s)
{
  DataT ret = 0, pos = 0;
  bool minus = false;
  for (const auto& c : s) {
    if (pos == 0) {
      ASSERT(isdigit(c) || c == '-' || c == '+',
             "str2int: input string is not an integer! Found='%s'",
             s.c_str());
      if (c == '-') {
        minus = true;
        continue;
      }
      if (c == '+') { continue; }
    } else {
      ASSERT(isdigit(c), "str2int: input string is not an integer! Found='%s'", s.c_str());
    }
    ret = ret * DataT{10} + static_cast<DataT>(c - '0');
  }
  if (minus) { ret = -ret; }
  return ret;
}

int str2int(const std::string& s) { return str2integer<int>(s); }

uint64_t str2uint64_t(const std::string& s) { return str2integer<uint64_t>(s); }

float str2float(const std::string& s) { return std::strtof(s.c_str(), nullptr); }

std::string format(const char* fmt, va_list& vl, va_list& vl_copy) noexcept
{
  // based on https://stackoverflow.com/a/26221725
  // https://stackoverflow.com/questions/2342162/stdstring-formatting-like-sprintf
  // +1 extra space for '\0'
  int size_s = std::vsnprintf(nullptr, 0, fmt, vl) + 1;
  // we silently ignore this, as the function may be used in contexts
  // which do not allow exceptions
  if (size_s <= 0) return {};
  auto size = static_cast<size_t>(size_s);
  auto buf  = std::make_unique<char[]>(size);
  if (std::vsnprintf(buf.get(), size, fmt, vl_copy) < 0)
    return std::string("Error while formatting ") + std::string(fmt);
  // remove the '\0' (last character)
  return {buf.get(), buf.get() + size - 1};
}

// we use C-style variadic function here to reduce compilation time/binary size
// this is only used for logging
// NOLINTNEXTLINE(cert-dcl50-cpp)
std::string format(const char* fmt, ...) noexcept
{
  va_list vl, vl_copy;
  va_start(vl, fmt);
  va_copy(vl_copy, vl);
  auto result = format(fmt, vl, vl_copy);
  va_end(vl_copy);
  va_end(vl);
  return result;
}

bool is_any_of(const std::string& val, const std::vector<std::string>& vals)
{
  return std::any_of(vals.begin(), vals.end(), [val](const std::string& v) { return val == v; });
}

bool is_any_of(const std::string& val, const std::string& options)
{
  auto vals = split(options, ',');
  return is_any_of(val, vals);
}

}  // namespace cugraph::ops::utils
