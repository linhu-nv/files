/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "cudart.hpp"

#include <cugraph-ops/utils/print_array.hpp>

namespace cugraph::ops::utils {

template <typename DataT>
void do_print(DataT const* in, size_t n, const std::string& name, int p)
{
  cudaPointerAttributes attr{};
  RAFT_CUDA_TRY(cudaPointerGetAttributes(&attr, in));
  if (attr.hostPointer == nullptr) {
    print_array(in, n, name, false, p);
  } else {
    print_array(reinterpret_cast<DataT const*>(attr.hostPointer), n, name, true, p);
  }
}

void print_a(char const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(int8_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(uint8_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(int16_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(uint16_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(int32_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(uint32_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(int64_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(uint64_t const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(float const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

void print_a(double const* in, size_t n, const std::string& name, int prec)
{
  do_print(in, n, name, prec);
}

}  // namespace cugraph::ops::utils
