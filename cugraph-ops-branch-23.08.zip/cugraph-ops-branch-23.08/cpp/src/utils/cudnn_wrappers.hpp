/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/utils/error.hpp>

#include <cudnn.h>

namespace cugraph::ops::utils {

inline const char* cudnn_error_to_string(cudnnStatus_t err)
{
  switch (err) {
    case CUDNN_STATUS_SUCCESS: return "CUDNN_STATUS_SUCCESS";
    case CUDNN_STATUS_NOT_INITIALIZED: return "CUDNN_STATUS_NOT_INITIALIZED";
    case CUDNN_STATUS_ALLOC_FAILED: return "CUDNN_STATUS_ALLOC_FAILED";
    case CUDNN_STATUS_BAD_PARAM: return "CUDNN_STATUS_BAD_PARAM";
    case CUDNN_STATUS_ARCH_MISMATCH: return "CUDNN_STATUS_ARCH_MISMATCH";
    case CUDNN_STATUS_MAPPING_ERROR: return "CUDNN_STATUS_MAPPING_ERROR";
    case CUDNN_STATUS_EXECUTION_FAILED: return "CUDNN_STATUS_EXECUTION_FAILED";
    case CUDNN_STATUS_INTERNAL_ERROR: return "CUDNN_STATUS_INTERNAL_ERROR";
    case CUDNN_STATUS_NOT_SUPPORTED: return "CUDNN_STATUS_NOT_SUPPORTED";
    case CUDNN_STATUS_LICENSE_ERROR: return "CUDNN_STATUS_LICENSE_ERROR";
    case CUDNN_STATUS_RUNTIME_PREREQUISITE_MISSING:
      return "CUDNN_STATUS_RUNTIME_PREREQUISITE_MISSING";
    case CUDNN_STATUS_RUNTIME_IN_PROGRESS: return "CUDNN_STATUS_RUNTIME_IN_PROGRESS";
    case CUDNN_STATUS_RUNTIME_FP_OVERFLOW: return "CUDNN_STATUS_RUNTIME_FP_OVERFLOW";
    default: return "CUDNN_STATUS_UNKNOWN";
  };
}

/**
 * @brief Error checking macro for cuDNN runtime API functions.
 *
 * Invokes a cuDNN runtime API function call, if the call does not return
 * CUDNN_STATUS_SUCCESS, throws an exception detailing the cuDNN error that
 * occurred
 */
#define CUGRAPH_OPS_CUDNN_TRY(call)                        \
  do {                                                     \
    cudnnStatus_t const status = (call);                   \
    if (CUDNN_STATUS_SUCCESS != status) {                  \
      std::string msg{};                                   \
      SET_ERROR_MSG(msg,                                   \
                    "cuDNN error encountered at: ",        \
                    "call='%s', Reason=%d:%s",             \
                    #call,                                 \
                    status,                                \
                    utils::cudnn_error_to_string(status)); \
      throw std::runtime_error(msg);                       \
    }                                                      \
  } while (0)

/**
 * @brief Error checking macro for cuDNN runtime API functions. But without
 *        throwing exception
 */
#define CUGRAPH_OPS_CUDNN_TRY_NO_THROW(call)                                                   \
  do {                                                                                         \
    cudnnStatus_t const status = (call);                                                       \
    if (CUDNN_STATUS_SUCCESS != status) {                                                      \
      CUGRAPH_OPS_ERROR("cuDNN error encountered at file=%s line=%d: call='%s', Reason=%d:%s", \
                        __FILE__,                                                              \
                        __LINE__,                                                              \
                        #call,                                                                 \
                        status,                                                                \
                        utils::cudnn_error_to_string(status));                                 \
    }                                                                                          \
  } while (0)

}  // namespace cugraph::ops::utils
