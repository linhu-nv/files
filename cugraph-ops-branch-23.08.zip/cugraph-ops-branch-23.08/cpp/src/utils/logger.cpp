/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/logger.hpp>

namespace cugraph::ops::utils {

int& get_log_level() noexcept
{
  static int log_level = LEVEL_INFO;
  return log_level;
}

void set_log_level(int lev) noexcept { get_log_level() = lev; }

bool will_log_for(int lev) noexcept { return lev <= get_log_level(); }

}  // namespace cugraph::ops::utils
