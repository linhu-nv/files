/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops-test/random/init.hpp>
#include <cugraph-ops-test/test_utils.hpp>

#include <nvbench/nvbench.cuh>

#include <thrust/execution_policy.h>
#include <thrust/sequence.h>

#include <cugraph-ops/operators/common.hpp>
#include <cugraph-ops/utils/allocator.hpp>

#include <cassert>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <random>
#include <stdexcept>
#include <string>

/**
 * @file common.hpp
 * @brief Contains utility functions that facilitate benchmarking cugraph-ops kernels using nvbench.
 *
 */

namespace cugraph::ops {

template <typename IdxT>
void read_graph(std::string filename,
                std::vector<IdxT>& offsets,
                std::vector<IdxT>& indices,
                size_t* n_in_nodes,
                size_t* n_out_nodes,
                size_t* n_samples)
{
  const char* path = std::getenv("CUGRAPH_OPS_DATA_DIR");
  if (path == nullptr) {
    CUGRAPH_OPS_ERROR("The environment variable CUGRAPH_OPS_DATA_DIR is not set.");
  }
  std::filesystem::path full_path = std::string(path);
  full_path /= filename;
  std::ifstream file(full_path, std::ifstream::binary);
  size_t offsets_len, indices_len;

  if (file.is_open()) {
    file.read(reinterpret_cast<char*>(&offsets_len), sizeof(size_t));
    file.read(reinterpret_cast<char*>(&indices_len), sizeof(size_t));

    file.read(reinterpret_cast<char*>(n_in_nodes), sizeof(size_t));
    file.read(reinterpret_cast<char*>(n_out_nodes), sizeof(size_t));
    if (n_samples != nullptr)
      file.read(reinterpret_cast<char*>(n_samples), sizeof(size_t));
    else
      file.ignore(sizeof(size_t));

    offsets.resize(offsets_len);
    file.read(reinterpret_cast<char*>(offsets.data()), offsets_len * sizeof(IdxT));
    indices.resize(indices_len);
    file.read(reinterpret_cast<char*>(indices.data()), indices_len * sizeof(IdxT));

    file.close();
  } else {
    throw std::runtime_error("Unable to open file: " + filename);
  }
}

/**
 * @brief Convert a string to the corresponding aggregation operator.
 *
 */
AggOpT string_to_AggOpT(const std::string& enum_string)
{
  AggOpT op{};
  if (enum_string == "kMean") {
    op = AggOpT::kMean;
  } else if (enum_string == "kMax") {
    op = AggOpT::kMax;
  } else {
    throw std::invalid_argument(
      "Invalid aggregation operator, expected 'kMean' or 'kMax' in benchmarks.");
  }

  return op;
}

template <typename DataT>
inline DataT generate_power_law(DataT l, DataT r, DataT y, DataT alpha = -1.5)
{
  return std::pow((std::pow(r, alpha) - std::pow(l, alpha)) * y + std::pow(l, alpha), 1 / alpha);
}

/**
 * @brief Generate offsets of graphs with different types of distribution.
 *
 */
void host_init_offsets(int* offsets,
                       int offsets_len,
                       int n_in_nodes,
                       int avg_degree,
                       int& n_indices,
                       const std::string& dist = "uniform",
                       bool is_mfg             = false)
{
  // use avg_degree as sample_size when is_mfg is true
  static constexpr uint64_t SEED = 123456ULL;
  std::mt19937 gen{SEED};
  if (dist == "uniform") {
    for (int i = 0; i < offsets_len; ++i) {
      offsets[i] = avg_degree * i;
    }
  } else if (dist == "normal") {
    float mu    = (is_mfg ? 0.5 : 1) * avg_degree;
    float sigma = 0.5 * mu;
    std::normal_distribution dis(mu, sigma);
    int offset = 0;
    for (int i = 0; i < offsets_len; ++i) {
      offsets[i] = offset;
      int deg    = std::max(1, static_cast<int>(dis(gen)));
      if (is_mfg) {
        offset += std::min(avg_degree, deg);
      } else {
        offset += deg;
      }
    }
  } else if (dist == "power") {
    float r = std::min(3 * avg_degree, n_in_nodes);
    float l = 1;
    std::uniform_real_distribution<float> dis(0., 1.);
    int offset = 0;
    for (int i = 0; i < offsets_len; ++i) {
      offsets[i] = offset;
      int deg    = std::max(1, static_cast<int>(generate_power_law(l, r, dis(gen))));
      if (is_mfg) {
        offset += std::min(avg_degree, deg);
      } else {
        offset += deg;
      }
    }
  } else {
    throw std::invalid_argument(
      "Invalid node degree distribution, expected 'uniform', 'normal' or 'power'.");
  }
  n_indices = offsets[offsets_len - 1];  // update n_indices (# of edges)
}

template <typename IdxT>
void init_mfg_csr(graph::mfg_csr<IdxT>& mfg,
                  IdxT n_in_nodes,
                  IdxT n_out_nodes,
                  IdxT sample_size,
                  raft::random::RngState& r,
                  const std::string& dist = "uniform")
{
  int offsets_len = n_out_nodes + 1;
  int *h_offsets, *offsets, *indices;
  int n_indices;
  utils::host_alloc(h_offsets, offsets_len, nullptr, false);
  utils::device_alloc(offsets, offsets_len, nullptr, false);
  host_init_offsets(h_offsets, offsets_len, n_in_nodes, sample_size, n_indices, dist, true);
  utils::copy<int>(offsets, h_offsets, offsets_len, cudaMemcpyHostToDevice);
  utils::host_free(h_offsets, nullptr);

  int start = 0;
  int end   = n_in_nodes - 1;
  utils::device_alloc(indices, n_indices, nullptr, false);
  random::uniform_int(indices, n_indices, r, start, end, nullptr);

  mfg.n_out_nodes = n_out_nodes;
  mfg.sample_size = sample_size;
  mfg.n_in_nodes  = n_in_nodes;
  mfg.n_indices   = n_indices;
  mfg.offsets     = offsets;
  mfg.indices     = indices;
}

template <typename IdxT>
void init_fg_csr(graph::fg_csr<IdxT>& fg,
                 IdxT n_nodes,
                 IdxT avg_degree,
                 raft::random::RngState& r,
                 const std::string& dist = "uniform")
{
  int offsets_len = n_nodes + 1;
  int *h_offsets, *offsets, *indices;
  int n_indices;
  utils::host_alloc(h_offsets, offsets_len, nullptr, false);
  utils::device_alloc(offsets, offsets_len, nullptr, false);
  host_init_offsets(h_offsets, offsets_len, n_nodes, avg_degree, n_indices, dist, false);
  utils::copy<int>(offsets, h_offsets, offsets_len, cudaMemcpyHostToDevice);
  utils::host_free(h_offsets, nullptr);

  int start = 0;
  int end   = n_nodes - 1;
  utils::device_alloc(indices, n_indices, nullptr, false);
  random::uniform_int(indices, n_indices, r, start, end, nullptr);

  fg.n_nodes   = n_nodes;
  fg.n_indices = n_indices;
  fg.offsets   = offsets;
  fg.indices   = indices;
}

template <typename IdxT>
void init_fg_csr(graph::fg_csr<IdxT>& fg, const std::string& filename)
{
  std::vector<IdxT> h_offsets, h_indices;
  size_t n_in_nodes, n_out_nodes;
  read_graph(filename, h_offsets, h_indices, &n_in_nodes, &n_out_nodes, nullptr);
  IdxT *offsets, *indices;
  utils::device_alloc(offsets, h_offsets.size(), nullptr, false);
  utils::device_alloc(indices, h_indices.size(), nullptr, false);
  utils::copy(offsets, h_offsets.data(), h_offsets.size(), cudaMemcpyHostToDevice);
  utils::copy(indices, h_indices.data(), h_indices.size(), cudaMemcpyHostToDevice);

  fg.n_nodes   = n_in_nodes;
  fg.n_indices = h_offsets.back();
  fg.offsets   = offsets;
  fg.indices   = indices;
}

template <typename IdxT>
void init_mfg_csr(graph::mfg_csr<IdxT>& mfg, const std::string& filename)
{
  std::vector<IdxT> h_offsets, h_indices;
  size_t n_in_nodes, n_out_nodes, n_samples;
  read_graph(filename, h_offsets, h_indices, &n_in_nodes, &n_out_nodes, &n_samples);
  IdxT *offsets, *indices;
  utils::device_alloc(offsets, h_offsets.size(), nullptr, false);
  utils::device_alloc(indices, h_indices.size(), nullptr, false);
  utils::copy(offsets, h_offsets.data(), h_offsets.size(), cudaMemcpyHostToDevice);
  utils::copy(indices, h_indices.data(), h_indices.size(), cudaMemcpyHostToDevice);

  mfg.n_in_nodes  = n_in_nodes;
  mfg.n_out_nodes = n_out_nodes;
  mfg.sample_size = n_samples;
  mfg.n_indices   = h_offsets.back();
  mfg.offsets     = offsets;
  mfg.indices     = indices;
}

template <typename IdxT>
void free_mfg_csr(graph::mfg_csr<IdxT>& mfg)
{
  utils::device_free(mfg.offsets, nullptr);
  utils::device_free(mfg.indices, nullptr);
}

template <typename IdxT>
void free_fg_csr(graph::fg_csr<IdxT>& fg)
{
  utils::device_free(fg.offsets, nullptr);
  utils::device_free(fg.indices, nullptr);
}

}  // namespace cugraph::ops
