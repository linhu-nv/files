/*
 * Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <raft/random/rng_state.hpp>

#include <cstdint>

namespace cugraph::ops::random {

/**
 * @brief initialize a device array with random numbers from a normal distribution
 *
 * This function is mainly useful for its default parameters.
 *
 * @tparam DataT data type
 *
 * @param[out]   ptr    output array
 * @param[in]    len    length of the array
 * @param[inout] r      RAFT RngState object
 * @param[in]    mean   mean value of the distribution
 * @param[in]    stddev standard deviation of the distribution
 * @param[in]    stream cuda stream
 */
template <typename DataT>
void normal(DataT* ptr,
            size_t len,
            raft::random::RngState& r,
            DataT mean          = DataT{0},
            DataT stddev        = DataT{1},
            cudaStream_t stream = nullptr);

/**
 * @brief initialize a device array with uniform random integers
 *
 * This function is mainly useful for its default parameters.
 *
 * @tparam DataT integral data type
 *
 * @param[out]   ptr    output array
 * @param[in]    len    length of the array
 * @param[inout] r      RAFT RngState object
 * @param[in]    start  range start
 * @param[in]    end    range end
 */
template <typename DataT>
void uniform_int(DataT* ptr,
                 size_t len,
                 raft::random::RngState& r,
                 DataT start         = DataT{0},
                 DataT end           = DataT{1},
                 cudaStream_t stream = nullptr);

}  // namespace cugraph::ops::random
