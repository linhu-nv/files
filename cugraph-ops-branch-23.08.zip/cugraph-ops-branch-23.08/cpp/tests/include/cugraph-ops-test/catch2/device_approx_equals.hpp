/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include "approx.hpp"

#include <utils/cudart.hpp>

#include <catch2/catch.hpp>

#include <cmath>
#include <string>
#include <vector>

namespace cugraph::ops::catch2 {

/**
 * @brief Custom matcher class for comparing device arrays
 *
 * @tparam DataT data type of the arrays
 */
template <typename DataT>
class device_approx_equals_t : public Catch::MatcherBase<DataT*> {
  compare_approx<DataT> matcher_;
  std::vector<DataT> h_ref_;

 public:
  device_approx_equals_t(DataT* d_ref, size_t len, DataT tol) : matcher_(tol)
  {
    h_ref_.resize(len);
    utils::copy(h_ref_.data(), d_ref, len, cudaMemcpyDeviceToHost);
  }

  bool match(DataT* const& d_computed) const override
  {
    std::vector<DataT> h_computed(h_ref_.size());
    utils::copy(h_computed.data(), d_computed, h_ref_.size(), cudaMemcpyDeviceToHost);
    for (size_t i = 0; i < h_ref_.size(); ++i) {
      if (!matcher_(h_computed[i], h_ref_[i])) {
        UNSCOPED_INFO("@i=" << i << " val=" << h_computed[i] << " ref=" << h_ref_[i]
                            << " tolerance=" << matcher_.tolerance());
        return false;
      }
    }
    return true;
  }

  [[nodiscard]] std::string describe() const override { return "device array approx matcher"; }
};  // class device_approx_equals_t

/**
 * @brief Builder function for the custom device array matcher
 *
 * @tparam DataT data type of the arrays
 *
 * @param[in] d_ref reference device array
 * @param[in] len   length of the array
 * @param[in] tol   tolerance for approximate comparison
 *
 * @return the matcher object
 */
template <typename DataT>
device_approx_equals_t<DataT> device_approx_equals(DataT* d_ref, size_t len, DataT tol)
{
  return device_approx_equals_t<DataT>(d_ref, len, tol);
}

}  // namespace cugraph::ops::catch2
