/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <utils/cudart.hpp>

#include <catch2/catch.hpp>

#include <string>
#include <vector>

namespace cugraph::ops::catch2 {

/**
 * @brief Custom matcher class for comparing device arrays
 *
 * @tparam data_t data type of the arrays
 */
template <typename DataT, typename LambdaT>
class device_lambda_equals_t : public Catch::MatcherBase<DataT*> {
  const LambdaT lambda_;
  const size_t len_;

 public:
  explicit device_lambda_equals_t(LambdaT _lambda, size_t _len) : lambda_(_lambda), len_(_len) {}

  bool match(DataT* const& d_computed) const override
  {
    std::vector<DataT> h_computed(len_);
    utils::copy(h_computed.data(), d_computed, len_, cudaMemcpyDeviceToHost);
    for (size_t i = 0; i < len_; ++i) {
      if (lambda_(i) != h_computed[i]) { return false; }
    }
    return true;
  }

  [[nodiscard]] std::string describe() const override { return "device array lambda matcher"; }
};  // class device_lambda_equals_t

/**
 * @brief Builder function for the custom device array matcher
 *
 * @tparam DataT data type of the arrays
 *
 * @param[in] d_ref reference device array
 * @param[in] len   length of the array
 *
 * @return the matcher object
 */
template <typename DataT, typename LambdaT>
device_lambda_equals_t<DataT, LambdaT> device_lambda_equals(LambdaT lambda, size_t len)
{
  return device_lambda_equals_t<DataT, LambdaT>(lambda, len);
}

}  // namespace cugraph::ops::catch2
