/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <catch2/catch.hpp>

#include <vector>

namespace cugraph::ops::catch2 {

/**
 * @brief Custom matcher class for comparing host arrays
 *
 * @tparam DataT data type of the arrays
 */
template <typename DataT>
class host_equals_t : public Catch::MatcherBase<DataT*> {
  std::vector<DataT> h_ref_;

 public:
  host_equals_t(const DataT* ref, size_t len) { h_ref_ = std::vector<DataT>(ref, ref + len); }

  bool match(DataT* const& computed) const override
  {
    std::vector<DataT> h_computed(computed, computed + h_ref_.size());
    for (size_t i = 0; i < h_ref_.size(); ++i) {
      if (h_computed[i] != h_ref_[i]) {
        UNSCOPED_INFO("@i=" << i << " val=" << h_computed[i] << " ref=" << h_ref_[i]);
        return false;
      }
    }
    return true;
  }

  [[nodiscard]] std::string describe() const override { return "host array matcher"; }
};  // class host_equals_t

/**
 * @brief Builder function for the custom host array matcher
 *
 * @tparam DataT data type of the arrays
 *
 * @param[in] d_ref reference host array
 * @param[in] len   length of the array
 *
 * @return the matcher object
 */
template <typename DataT>
host_equals_t<DataT> host_equals(const DataT* d_ref, size_t len)
{
  return host_equals_t<DataT>(d_ref, len);
}

}  // namespace cugraph::ops::catch2
