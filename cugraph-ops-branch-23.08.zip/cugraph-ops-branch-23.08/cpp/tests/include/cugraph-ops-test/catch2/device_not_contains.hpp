/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <utils/cudart.hpp>

#include <catch2/catch.hpp>

#include <sstream>
#include <string>
#include <vector>

namespace cugraph::ops::catch2 {

/**
 * @brief Custom matcher class for checking an element's non-existence in the
 *        input device array
 *
 * @tparam DataT data type of the array
 */
template <typename DataT>
class device_not_contains_t : public Catch::MatcherBase<DataT*> {
  const DataT value_;
  const size_t len_;

 public:
  explicit device_not_contains_t(DataT val, size_t _len) : value_(val), len_(_len) {}

  bool match(DataT* const& d_computed) const override
  {
    std::vector<DataT> h_computed(len_);
    utils::copy(h_computed.data(), d_computed, len_, cudaMemcpyDeviceToHost);
    for (size_t i = 1; i < len_; ++i) {
      if (value_ == h_computed[i]) {
        UNSCOPED_INFO("@i=" << i << ": " << h_computed[i] << " == " << value_
                            << " (h_computed[i] == value_)");
        return false;
      }
    }
    return true;
  }

  [[nodiscard]] std::string describe() const override
  {
    std::stringstream ss;
    ss << "device array does contain [" << value_ << "]";
    return ss.str();
  }
};  // class device_not_contains_t

/**
 * @brief Builder function for the custom device array element non-existence
 *        checker
 *
 * @tparam DataT data type of the array
 *
 * @param[in] val this value should not be present in the input array
 * @param[in] len length of the array
 *
 * @return the matcher object
 */
template <typename DataT>
device_not_contains_t<DataT> device_not_contains(DataT val, size_t len)
{
  return device_not_contains_t<DataT>(val, len);
}

}  // namespace cugraph::ops::catch2
