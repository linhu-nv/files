/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <utils/cudart.hpp>

#include <catch2/catch.hpp>

#include <sstream>
#include <string>
#include <vector>

namespace cugraph::ops::catch2 {

/**
 * @brief Custom matcher class for checking monotonicity in device array
 *
 * @tparam DataT data type of the array
 */
template <typename DataT>
class device_monotonic_t : public Catch::MatcherBase<DataT*> {
  const bool increasing_;
  const size_t len_;

 public:
  explicit device_monotonic_t(bool increase, size_t _len) : increasing_(increase), len_(_len) {}

  bool match(DataT* const& d_computed) const override
  {
    std::vector<DataT> h_computed(len_);
    utils::copy(h_computed.data(), d_computed, len_, cudaMemcpyDeviceToHost);
    for (size_t i = 1; i < len_; ++i) {
      if (increasing_) {
        if (h_computed[i - 1] > h_computed[i]) return false;
      } else {
        if (h_computed[i - 1] < h_computed[i]) return false;
      }
    }
    return true;
  }

  [[nodiscard]] std::string describe() const override
  {
    std::stringstream ss;
    ss << "device monotonic checker (" << (increasing_ ? "increasing" : "decreasing") << ")";
    return ss.str();
  }
};  // class device_monotonic_t

/**
 * @brief Builder function for the custom device array monotonicity checker
 *
 * @tparam DataT data type of the array
 *
 * @param[in] increasing whether to check for increasing-ness or decreasing-ness
 * @param[in] len   length of the array
 *
 * @return the matcher object
 */
template <typename DataT>
device_monotonic_t<DataT> device_monotonic(bool increasing, size_t len)
{
  return device_monotonic_t<DataT>(increasing, len);
}

}  // namespace cugraph::ops::catch2
