/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#define CATCH_CONFIG_EXTERNAL_INTERFACES
#define CATCH_CONFIG_RUNNER

// our listener that displays test cases and time taken
#include <cugraph-ops-test/catch2/listener.hpp>

#include <cugraph-ops/utils/nvtx.hpp>

// this will generate the main function
#include <catch2/catch.hpp>

int main(int argc, char** argv)
{
  cugraph::ops::utils::enable_nvtx_ranges();
  return Catch::Session().run(argc, argv);
}
