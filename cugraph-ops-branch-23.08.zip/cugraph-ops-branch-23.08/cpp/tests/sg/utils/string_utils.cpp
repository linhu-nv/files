/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/string_utils.hpp>

#include <catch2/catch.hpp>

namespace cugraph::ops::utils {

TEST_CASE("split")
{
  auto vec = split("a,b,c,,", ',');
  REQUIRE(vec.size() == 4U);
  REQUIRE(vec[0] == "a");
  REQUIRE(vec[1] == "b");
  REQUIRE(vec[2] == "c");
  REQUIRE(vec[3] == "");  // NOLINT(readability-container-size-empty)
}

TEST_CASE("str2int")
{
  REQUIRE(str2int("1") == 1);
  REQUIRE(str2int("-1") == -1);
  REQUIRE(str2int("+1") == 1);
  REQUIRE_THROWS(str2int("abc10"));
  REQUIRE_THROWS(str2int("abc"));
  REQUIRE_THROWS(str2int("-abc"));
  REQUIRE_THROWS(str2int("-10abc"));
  REQUIRE_THROWS(str2int("+abc"));
  REQUIRE_THROWS(str2int("+10abc"));
}

TEST_CASE("str2float")
{
  // NOLINTNEXTLINE(readability-magic-numbers) test constant
  REQUIRE(str2float("1.6") == 1.6F);
  REQUIRE(str2float("abc") == 0.0);
}

TEST_CASE("is_any_of")
{
  REQUIRE(is_any_of("a", "a,b,c,1"));
  REQUIRE_FALSE(is_any_of("z", "a,b,c,1"));
}

}  // namespace cugraph::ops::utils
