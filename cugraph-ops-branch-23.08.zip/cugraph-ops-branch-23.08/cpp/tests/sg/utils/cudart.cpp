/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <utils/cudart.hpp>

#include <catch2/catch.hpp>

namespace cugraph::ops::utils {

TEST_CASE("THROW")
{
  auto func = []() { THROW("This will throw an exception"); };
  REQUIRE_THROWS_AS(func(), raft::exception);
}

TEST_CASE("ASSERT")
{
  auto func = [](bool pass) { ASSERT(pass, "This will try to assert"); };
  REQUIRE_THROWS_AS(func(false), raft::exception);
  REQUIRE_NOTHROW(func(true));
}

TEST_CASE("sync") { REQUIRE_NOTHROW(sync(nullptr)); }

}  // namespace cugraph::ops::utils
