/*
 * Copyright (c) 2020-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/version.hpp>

#include <catch2/catch.hpp>

namespace cugraph::ops::utils {

#define STRINGIFY_DETAIL(x) #x
#define STRINGIFY(x)        STRINGIFY_DETAIL(x)

TEST_CASE("version_str") { REQUIRE(version_str() == STRINGIFY(CUGRAPH_OPS_VERSION)); }

#undef STRINGIFY_DETAIL
#undef STRINGIFY

}  // namespace cugraph::ops::utils
