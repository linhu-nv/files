#!/bin/bash
# Copyright (c) 2022-2023, NVIDIA CORPORATION.

set -euo pipefail

source rapids-env-update

export CMAKE_GENERATOR=Ninja

rapids-print-env

rapids-logger "Begin cpp build"

rapids-mamba-retry mambabuild conda/recipes/libcugraphops

# build internal packages for PRs and branch merges
if [[ "${RAPIDS_BUILD_TYPE}" == "pull-request" || "${RAPIDS_BUILD_TYPE}" == "branch" ]]; then
    rapids-mamba-retry mambabuild \
      --channel "${RAPIDS_CONDA_BLD_OUTPUT_DIR}" \
      conda/recipes/libcugraphops_internal
fi

rapids-upload-conda-to-s3 cpp
