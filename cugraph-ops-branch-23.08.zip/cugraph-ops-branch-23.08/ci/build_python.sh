#!/bin/bash
# Copyright (c) 2022-2023, NVIDIA CORPORATION.

set -euo pipefail

source rapids-env-update

export CMAKE_GENERATOR=Ninja

rapids-print-env

rapids-logger "Begin py build"

CPP_CHANNEL=$(rapids-download-conda-from-s3 cpp)

# TODO: Remove `--no-test` flags once importing on a CPU
# node works correctly
rapids-logger "Begin pylibcugraphops build"
rapids-mamba-retry mambabuild \
  --no-test \
  --channel "${CPP_CHANNEL}" \
  conda/recipes/pylibcugraphops

# build internal packages for PRs and branch merges
if [[ "${RAPIDS_BUILD_TYPE}" == "pull-request" || "${RAPIDS_BUILD_TYPE}" == "branch" ]]; then
    rapids-mamba-retry mambabuild \
      --no-test \
      --channel "${CPP_CHANNEL}" \
      conda/recipes/pylibcugraphops_internal
fi

rapids-upload-conda-to-s3 python
