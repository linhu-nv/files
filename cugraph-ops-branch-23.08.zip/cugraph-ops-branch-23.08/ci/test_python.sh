#!/bin/bash
# Copyright (c) 2022-2023, NVIDIA CORPORATION.

set -e          # abort the script on error
set -o pipefail # piped commands propagate their error
set -E          # ERR traps are inherited by subcommands
trap "EXITCODE=1" ERR
EXITCODE=0
. /opt/conda/etc/profile.d/conda.sh

ARCH=$(arch)
rapids-logger "Generate Python testing dependencies"
rapids-dependency-file-generator \
  --output conda \
  --file_key test_python \
  --matrix "cuda=${RAPIDS_CUDA_VERSION%.*};arch=${ARCH};py=${RAPIDS_PY_VERSION}" | tee env.yaml

rapids-mamba-retry env create --force -f env.yaml -n test

# Temporarily allow unbound variables for conda activation.
set +u
conda activate test
set -u

rapids-logger "Downloading artifacts from previous jobs"
CPP_CHANNEL=$(rapids-download-conda-from-s3 cpp)
PYTHON_CHANNEL=$(rapids-download-conda-from-s3 python)

RAPIDS_TESTS_DIR=${RAPIDS_TESTS_DIR:-"${PWD}/test-results"}
RAPIDS_COVERAGE_DIR=${RAPIDS_COVERAGE_DIR:-"${PWD}/coverage-results"}
mkdir -p "${RAPIDS_TESTS_DIR}" "${RAPIDS_COVERAGE_DIR}"

rapids-print-env

PACKAGES="pylibcugraphops"
# for PRs, run internal tests, too
# If tests for branch merges get enabled, should enable this for "branch", too.
if [[ "${RAPIDS_BUILD_TYPE}" == "pull-request" ]]; then
  PACKAGES+=" pylibcugraphops-internal"
fi

rapids-mamba-retry install \
  --channel "${CPP_CHANNEL}" \
  --channel "${PYTHON_CHANNEL}" \
  "${PACKAGES}"

rapids-logger "Check GPU usage"
nvidia-smi

set +e

# always run generic tests of external/public package
rapids-logger "pytest pylibcugraphops-generic"
pushd pylibcugraphops/tests/
pytest \
  --cache-clear \
  --numprocesses=8 \
  --dist=loadscope \
  --ignore=pytorch \
  .
popd

# for supported archs/CUDA, run pytorch tests, too
if [[ "${ARCH}" == "x86_64" ]]; then
  rapids-logger "pytest pylibcugraphops-pytorch"
  pushd pylibcugraphops/tests/pytorch
  pytest \
    --cache-clear \
    --junitxml="${RAPIDS_TESTS_DIR}/junit-pylibcugraphops.xml" \
    --numprocesses=8 \
    --dist=loadscope \
    --cov-config=.coveragerc \
    --cov=pylibcugraphops \
    --cov-report=xml:"${RAPIDS_COVERAGE_DIR}/pylibcugraphops-coverage.xml" \
    --cov-report=term \
    .
  popd
fi

# for PRs, run internal tests, too
# If tests for branch merges get enabled, should enable this for "branch", too.
if [[ "${RAPIDS_BUILD_TYPE}" == "pull-request" ]]; then
  rapids-logger "pytest pylibcugraphops-internal"
  pushd pylibcugraphops_internal/tests/pylibcugraphops_internal
  pytest \
    --cache-clear \
    --junitxml="${RAPIDS_TESTS_DIR}/junit-pylibcugraphops-internal.xml" \
    --numprocesses=8 \
    --dist=loadscope \
    --cov-config=.coveragerc \
    --cov=pylibcugraphops_internal \
    --cov-report=xml:"${RAPIDS_COVERAGE_DIR}/pylibcugraphops-internal-coverage.xml" \
    --cov-report=term \
    .
  popd

  rapids-logger "Run python end-to-end tests..."
  python scripts/test_examples_full.py --use_s3
fi

echo "test_python is exiting with value: ${EXITCODE}"
exit ${EXITCODE}
