/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/bias_activation.hpp>

#include <raft/random/rng_state.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT>
void bias_act_fwd_wrapped(array_wrapper<FeatT>& out,
                          const array_wrapper<FeatT>& in,
                          const array_wrapper<FeatT>& bias,
                          int m,
                          int n,
                          int ld,
                          const cugraph::ops::activation_params& aparams,
                          array_wrapper<uint64_t>& drop_v,
                          FeatT p_drop,
                          raft::random::RngState* r,
                          const cuda::stream& stream)
{
  cugraph::ops::bias_activation_fwd(
    out.ptr(), in.ptr(), bias.ptr(), m, n, ld, aparams, drop_v.ptr(), p_drop, r, stream);
}

template <typename FeatT>
void bias_act_bwd_wrapped(array_wrapper<FeatT>& din,
                          array_wrapper<FeatT>& dbias,
                          const array_wrapper<FeatT>& dout,
                          const array_wrapper<FeatT>& out,
                          const array_wrapper<FeatT>& in,
                          const array_wrapper<FeatT>& bias,
                          int m,
                          int n,
                          int ld,
                          const cugraph::ops::activation_params& aparams,
                          const array_wrapper<uint64_t>& drop_v,
                          FeatT p_drop,
                          const cuda::stream& stream)
{
  cugraph::ops::bias_activation_bwd(din.ptr(),
                                    dbias.ptr(),
                                    dout.ptr(),
                                    out.ptr(),
                                    in.ptr(),
                                    bias.ptr(),
                                    m,
                                    n,
                                    ld,
                                    aparams,
                                    drop_v.ptr(),
                                    p_drop,
                                    stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT>
void init_bias_act_fwd_bwd(nb::module_& m, const std::string& type_str)
{
  std::string name_fwd = "bias_activation_fwd_" + type_str;
  m.def(name_fwd.c_str(), &cugraph::ops::binding::bias_act_fwd_wrapped<FeatT>);
  std::string name_bwd = "bias_activation_bwd_" + type_str;
  m.def(name_bwd.c_str(), &cugraph::ops::binding::bias_act_bwd_wrapped<FeatT>);
}

void init_layers_bias_activation(nb::module_& m) { init_bias_act_fwd_bwd<float>(m, "float32"); }
