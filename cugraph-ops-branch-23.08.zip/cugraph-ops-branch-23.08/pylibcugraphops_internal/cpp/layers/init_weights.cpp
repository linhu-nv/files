/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/init_weights.hpp>

#include <nanobind/nanobind.h>

#include <cmath>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT>
void init_weights_wrapped(array_wrapper<FeatT>& w,
                          size_t n,
                          size_t n_fan,
                          double gain,
                          bool is_normal,
                          raft::random::RngState& r,
                          const cuda::stream& stream)
{
  cugraph::ops::init_weights(w.ptr(), n, n_fan, gain, is_normal, r, stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT>
void init_weight_init(nb::module_& m, const std::string& type_str)
{
  std::string name = "init_weights_" + type_str;
  m.def(name.c_str(),
        &cugraph::ops::binding::init_weights_wrapped<FeatT>,
        nb::arg("w"),
        nb::arg("n"),
        nb::arg("n_fan"),
        nb::arg("gain")      = std::sqrt(2.),
        nb::arg("is_normal") = false,
        nb::arg("rng"),
        nb::arg("stream"));
}

void init_layers_weight_init(nb::module_& m) { init_weight_init<float>(m, "float32"); }
