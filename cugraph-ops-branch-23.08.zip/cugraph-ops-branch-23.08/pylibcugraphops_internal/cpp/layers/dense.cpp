/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/dense.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT>
void dense_fwd_wrapped(array_wrapper<FeatT>& out,
                       array_wrapper<FeatT>& c,
                       int ldc,
                       const array_wrapper<FeatT>& a,
                       int lda,
                       const array_wrapper<FeatT>& b,
                       int ldb,
                       const array_wrapper<FeatT>& bias,
                       int m,
                       int n,
                       int k,
                       const cugraph::ops::activation_params& aparams,
                       array_wrapper<uint64_t>& drop_v,
                       FeatT p_drop,
                       raft::random::RngState* r,
                       const cuda::cublashandle& cublas,
                       const cuda::stream& stream)
{
  cugraph::ops::dense_fwd(out.ptr(),
                          c.ptr(),
                          ldc,
                          a.ptr(),
                          lda,
                          b.ptr(),
                          ldb,
                          bias.ptr(),
                          m,
                          n,
                          k,
                          aparams,
                          drop_v.ptr(),
                          p_drop,
                          r,
                          cublas,
                          stream);
}

template <typename FeatT>
void dense_bwd_wrapped(array_wrapper<FeatT>& da,
                       array_wrapper<FeatT>& db,
                       array_wrapper<FeatT>& dbias,
                       array_wrapper<FeatT>& dgrad,
                       const array_wrapper<FeatT>& dout,
                       const array_wrapper<FeatT>& out,
                       const array_wrapper<FeatT>& c,
                       int ldc,
                       const array_wrapper<FeatT>& a,
                       int lda,
                       const array_wrapper<FeatT>& b,
                       int ldb,
                       const array_wrapper<FeatT>& bias,
                       int m,
                       int n,
                       int k,
                       const cugraph::ops::activation_params& aparams,
                       const array_wrapper<uint64_t>& drop_v,
                       FeatT p_drop,
                       const cuda::cublashandle& cublas,
                       const cuda::stream& stream)
{
  cugraph::ops::dense_bwd(da.ptr(),
                          db.ptr(),
                          dbias.ptr(),
                          dgrad.ptr(),
                          dout.ptr(),
                          out.ptr(),
                          c.ptr(),
                          ldc,
                          a.ptr(),
                          lda,
                          b.ptr(),
                          ldb,
                          bias.ptr(),
                          m,
                          n,
                          k,
                          aparams,
                          drop_v.ptr(),
                          p_drop,
                          cublas,
                          stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT>
void init_dense_fwd_bwd(nb::module_& m, const std::string& type_str)
{
  std::string name_fwd = "dense_fwd_" + type_str;
  m.def(name_fwd.c_str(), &cugraph::ops::binding::dense_fwd_wrapped<FeatT>);
  std::string name_bwd = "dense_bwd_" + type_str;
  m.def(name_bwd.c_str(), &cugraph::ops::binding::dense_bwd_wrapped<FeatT>);
}

void init_layers_dense(nb::module_& m) { init_dense_fwd_bwd<float>(m, "float32"); }
