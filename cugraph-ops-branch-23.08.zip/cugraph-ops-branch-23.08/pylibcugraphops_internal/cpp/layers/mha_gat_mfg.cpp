/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/operators/common.hpp>
#include <cugraph-ops/operators/mha_gat_mfg.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT, typename IdxT>
void mha_gat_mfg_fwd_wrapped(array_wrapper<FeatT>& attn_feat,
                             array_wrapper<FeatT>& sm_scores,
                             const array_wrapper<FeatT>& in_feat,
                             const array_wrapper<FeatT>& weights,
                             const graph::mfg_ellpack<IdxT>& mfg,
                             const mha_params& params,
                             size_t dim,
                             const cuda::stream& stream)
{
  cugraph::ops::mha_gat_mfg_n2n_fwd(
    attn_feat.ptr(), sm_scores.ptr(), in_feat.ptr(), weights.ptr(), mfg, params, dim, stream);
}

template <typename FeatT, typename IdxT>
void mha_gat_mfg_bwd_wrapped(array_wrapper<FeatT>& d_in_feat,
                             array_wrapper<FeatT>& d_weights,
                             const array_wrapper<FeatT>& d_attn_feat,
                             const array_wrapper<FeatT>& in_feat,
                             const array_wrapper<FeatT>& weights,
                             const array_wrapper<FeatT>& sm_scores,
                             const graph::mfg_ellpack<IdxT>& mfg,
                             const mha_params& params,
                             size_t dim,
                             const cuda::stream& stream)
{
  cugraph::ops::mha_gat_mfg_n2n_bwd(d_in_feat.ptr(),
                                    d_weights.ptr(),
                                    d_attn_feat.ptr(),
                                    in_feat.ptr(),
                                    weights.ptr(),
                                    sm_scores.ptr(),
                                    mfg,
                                    params,
                                    dim,
                                    stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT, typename IdxT>
void init_mha_gat_mfg_fwd_bwd(nb::module_& m,
                              const std::string& feat_str,
                              const std::string& idx_str)
{
  std::string name_fwd = "mha_gat_mfg_fwd_" + feat_str + "_" + idx_str;
  m.def(name_fwd.c_str(), &cugraph::ops::binding::mha_gat_mfg_fwd_wrapped<FeatT, IdxT>);
  std::string name_bwd = "mha_gat_mfg_bwd_" + feat_str + "_" + idx_str;
  m.def(name_bwd.c_str(), &cugraph::ops::binding::mha_gat_mfg_bwd_wrapped<FeatT, IdxT>);
}

void init_layers_mha_gat_mfg(nb::module_& m)
{
  auto m_mha = m.def_submodule("mha_gat_mfg", "cugraph_ops mha_gat_mfg layers");

  init_mha_gat_mfg_fwd_bwd<float, int32_t>(m_mha, "float32", "int32");
  init_mha_gat_mfg_fwd_bwd<float, int64_t>(m_mha, "float32", "int64");
}
