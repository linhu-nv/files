/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/operators/agg_hg_basis_mfg.hpp>
#include <cugraph-ops/operators/common.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT, typename IdxT>
void agg_hg_basis_post_fwd_wrapped(array_wrapper<FeatT>& out,
                                   const array_wrapper<FeatT>& in,
                                   const array_wrapper<FeatT>& weights_comb,
                                   size_t dim,
                                   int n_bases,
                                   const graph::mfg_ellpack_hg<IdxT>& mfg,
                                   bool concat_own,
                                   bool norm_by_out_degree,
                                   const cuda::stream& stream)
{
  cugraph::ops::agg_hg_basis_mfg_n2n_post_fwd(out.ptr(),
                                              in.ptr(),
                                              weights_comb.ptr(),
                                              dim,
                                              n_bases,
                                              mfg,
                                              concat_own,
                                              norm_by_out_degree,
                                              stream);
}

template <typename FeatT, typename IdxT>
void agg_hg_basis_post_bwd_wrapped(array_wrapper<FeatT>& din,
                                   array_wrapper<FeatT>& dw,
                                   const array_wrapper<FeatT> dout,
                                   const array_wrapper<FeatT>& in,
                                   const array_wrapper<FeatT>& weights_comb,
                                   size_t dim,
                                   int n_bases,
                                   const graph::mfg_ellpack_hg<IdxT>& mfg,
                                   bool concat_own,
                                   bool norm_by_out_degree,
                                   const cuda::stream& stream)
{
  cugraph::ops::agg_hg_basis_mfg_n2n_post_bwd(din.ptr(),
                                              dw.ptr(),
                                              dout.ptr(),
                                              in.ptr(),
                                              weights_comb.ptr(),
                                              dim,
                                              n_bases,
                                              mfg,
                                              concat_own,
                                              norm_by_out_degree,
                                              stream);
}

template <typename FeatT, typename IdxT>
void agg_hg_basis_pre_fwd_wrapped(array_wrapper<FeatT>& out,
                                  const array_wrapper<FeatT>& in,
                                  const array_wrapper<FeatT>& weights_comb,
                                  size_t dim,
                                  int n_bases,
                                  const graph::mfg_ellpack_hg<IdxT>& mfg,
                                  bool concat_own,
                                  bool norm_by_out_degree,
                                  const cuda::stream& stream)
{
  cugraph::ops::agg_hg_basis_mfg_n2n_pre_fwd(out.ptr(),
                                             in.ptr(),
                                             weights_comb.ptr(),
                                             dim,
                                             n_bases,
                                             mfg,
                                             concat_own,
                                             norm_by_out_degree,
                                             stream);
}

template <typename FeatT, typename IdxT>
void agg_hg_basis_pre_bwd_wrapped(array_wrapper<FeatT>& din,
                                  array_wrapper<FeatT>& dw,
                                  const array_wrapper<FeatT> dout,
                                  const array_wrapper<FeatT>& in,
                                  const array_wrapper<FeatT>& weights_comb,
                                  size_t dim,
                                  int n_bases,
                                  const graph::mfg_ellpack_hg<IdxT>& mfg,
                                  bool concat_own,
                                  bool norm_by_out_degree,
                                  const cuda::stream& stream)
{
  cugraph::ops::agg_hg_basis_mfg_n2n_pre_bwd(din.ptr(),
                                             dw.ptr(),
                                             dout.ptr(),
                                             in.ptr(),
                                             weights_comb.ptr(),
                                             dim,
                                             n_bases,
                                             mfg,
                                             concat_own,
                                             norm_by_out_degree,
                                             stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT, typename IdxT>
void init_agg_hg_basis_fwd_bwd(nb::module_& m,
                               const std::string& feat_str,
                               const std::string& idx_str)
{
  std::string name_post_fwd = "agg_hg_basis_post_fwd_" + feat_str + "_" + idx_str;
  m.def(name_post_fwd.c_str(), &cugraph::ops::binding::agg_hg_basis_post_fwd_wrapped<FeatT, IdxT>);
  std::string name_post_bwd = "agg_hg_basis_post_bwd_" + feat_str + "_" + idx_str;
  m.def(name_post_bwd.c_str(), &cugraph::ops::binding::agg_hg_basis_post_bwd_wrapped<FeatT, IdxT>);

  std::string name_pre_fwd = "agg_hg_basis_pre_fwd_" + feat_str + "_" + idx_str;
  m.def(name_pre_fwd.c_str(), &cugraph::ops::binding::agg_hg_basis_pre_fwd_wrapped<FeatT, IdxT>);
  std::string name_pre_bwd = "agg_hg_basis_pre_bwd_" + feat_str + "_" + idx_str;
  m.def(name_pre_bwd.c_str(), &cugraph::ops::binding::agg_hg_basis_pre_bwd_wrapped<FeatT, IdxT>);
}

void init_layers_agg_hg_basis_mfg(nb::module_& m)
{
  init_agg_hg_basis_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_agg_hg_basis_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
