/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/metrics.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT>
void acc_by_row_wrapped(array_wrapper<int32_t>& acc,
                        const array_wrapper<FeatT>& in,
                        const array_wrapper<int32_t>& labels,
                        int m,
                        int n,
                        const cuda::stream& stream)
{
  cugraph::ops::accuracy_by_row(acc.ptr(), in.ptr(), labels.ptr(), m, n, stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT>
void init_acc_by_row(nb::module_& m, const std::string& type_str)
{
  std::string name = "accuracy_by_row_" + type_str;
  m.def(name.c_str(), &cugraph::ops::binding::acc_by_row_wrapped<FeatT>);
}

void init_layers_metrics(nb::module_& m) { init_acc_by_row<float>(m, "float32"); }
