/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION.. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/operators/agg_dmpnn.hpp>
#include <cugraph-ops/operators/common.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT, typename IdxT>
void agg_dmpnn_fg_e2e_fwd_wrapped(array_wrapper<FeatT>& out_edge_feat,
                                  const array_wrapper<FeatT>& in_edge_feat,
                                  size_t dim_edge,
                                  const graph::fg_csr_batch<IdxT>& fg_batch,
                                  bool concat_own,
                                  const cuda::stream& stream)
{
  cugraph::ops::agg_dmpnn_fg_e2e_fwd(
    out_edge_feat.ptr(), in_edge_feat.ptr(), dim_edge, fg_batch, concat_own, stream);
}

template <typename FeatT, typename IdxT>
void agg_dmpnn_fg_e2e_bwd_wrapped(array_wrapper<FeatT>& d_in_edge_feat,
                                  const array_wrapper<FeatT>& d_out_edge_feat,
                                  size_t dim_edge,
                                  const graph::fg_csr_batch<IdxT>& fg_batch,
                                  bool concat_own,
                                  const cuda::stream& stream)
{
  cugraph::ops::agg_dmpnn_fg_e2e_bwd(
    d_in_edge_feat.ptr(), d_out_edge_feat.ptr(), dim_edge, fg_batch, concat_own, stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT, typename IdxT>
void init_agg_dmpnn_fwd_bwd(nb::module_& m, const std::string& feat_str, const std::string& idx_str)
{
  std::string name_fwd = "agg_dmpnn_fg_e2e_fwd_" + feat_str + "_" + idx_str;
  m.def(name_fwd.c_str(), &cugraph::ops::binding::agg_dmpnn_fg_e2e_fwd_wrapped<FeatT, IdxT>);
  std::string name_bwd = "agg_dmpnn_fg_e2e_bwd_" + feat_str + "_" + idx_str;
  m.def(name_bwd.c_str(), &cugraph::ops::binding::agg_dmpnn_fg_e2e_bwd_wrapped<FeatT, IdxT>);
}

void init_layers_agg_dmpnn_fg(nb::module_& m)
{
  init_agg_dmpnn_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_agg_dmpnn_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
