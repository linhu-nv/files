/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/loss.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT>
void softmax_ce_by_row_wrapped(array_wrapper<FeatT>& out,
                               array_wrapper<int32_t>& acc,
                               array_wrapper<FeatT>& sm_out,
                               const array_wrapper<FeatT>& in,
                               const array_wrapper<int32_t>& labels,
                               int m,
                               int n,
                               float epsilon,
                               bool with_grad,
                               const cuda::cudnnhandle& cudnn,
                               const cuda::stream& stream)
{
  cugraph::ops::softmax_ce_by_row(out.ptr(),
                                  acc.ptr(),
                                  sm_out.ptr(),
                                  in.ptr(),
                                  labels.ptr(),
                                  m,
                                  n,
                                  epsilon,
                                  with_grad,
                                  cudnn,
                                  stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT>
void init_softmax_ce_by_row(nb::module_& m, const std::string& type_str)
{
  std::string name = "softmax_ce_by_row_" + type_str;
  m.def(name.c_str(), &cugraph::ops::binding::softmax_ce_by_row_wrapped<FeatT>);
}

void init_layers_loss(nb::module_& m) { init_softmax_ce_by_row<float>(m, "float32"); }
