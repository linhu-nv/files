/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/operators/agg_concat_mfg.hpp>
#include <cugraph-ops/operators/common.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT, typename IdxT>
void agg_concat_mfg_n2n_fwd_wrapped(array_wrapper<FeatT>& out,
                                    array_wrapper<IdxT>& out_pos,
                                    const array_wrapper<FeatT>& in,
                                    size_t dim,
                                    const graph::mfg_ellpack<IdxT>& mfg,
                                    AggOpT op,
                                    const cuda::stream& stream)
{
  cugraph::ops::agg_concat_mfg_n2n_fwd(
    out.ptr(), out_pos.ptr(), in.ptr(), in.ptr(), dim, dim, mfg, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_concat_mfg_n2n_bwd_wrapped(array_wrapper<FeatT>& din,
                                    const array_wrapper<FeatT>& dout,
                                    const array_wrapper<IdxT>& out_pos,
                                    size_t dim,
                                    const graph::mfg_ellpack<IdxT>& mfg,
                                    AggOpT op,
                                    const cuda::stream& stream)
{
  cugraph::ops::agg_concat_mfg_n2n_bwd(
    din.ptr(), din.ptr(), dout.ptr(), out_pos.ptr(), dim, dim, mfg, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_concat_mfg_n2n_bwd_rev_wrapped(array_wrapper<FeatT>& din,
                                        const array_wrapper<FeatT>& dout,
                                        const array_wrapper<IdxT>& out_pos,
                                        size_t dim,
                                        const graph::mfg_ellpack<IdxT>& mfg,
                                        const graph::mfg_csr_rev<IdxT>& mfg_rev,
                                        AggOpT op,
                                        const cuda::stream& stream)
{
  cugraph::ops::agg_concat_mfg_n2n_bwd_rev(
    din.ptr(), din.ptr(), dout.ptr(), out_pos.ptr(), dim, dim, mfg, mfg_rev, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_concat_mfg_n2n_fwd_csr_wrapped(array_wrapper<FeatT>& out,
                                        array_wrapper<IdxT>& out_pos,
                                        const array_wrapper<FeatT>& in,
                                        size_t dim,
                                        const graph::mfg_csr<IdxT>& mfg,
                                        AggOpT op,
                                        const cuda::stream& stream)
{
  cugraph::ops::agg_concat_mfg_n2n_fwd(
    out.ptr(), out_pos.ptr(), in.ptr(), in.ptr(), dim, dim, mfg, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_concat_mfg_n2n_bwd_csr_wrapped(array_wrapper<FeatT>& din,
                                        const array_wrapper<FeatT>& dout,
                                        const array_wrapper<IdxT>& out_pos,
                                        size_t dim,
                                        const graph::mfg_csr<IdxT>& mfg,
                                        AggOpT op,
                                        const cuda::stream& stream)
{
  cugraph::ops::agg_concat_mfg_n2n_bwd(
    din.ptr(), din.ptr(), dout.ptr(), out_pos.ptr(), dim, dim, mfg, op, stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT, typename IdxT>
void init_agg_concat_fwd_bwd(nb::module_& m,
                             const std::string& feat_str,
                             const std::string& idx_str)
{
  std::string name_fwd = "agg_concat_mfg_n2n_fwd_" + feat_str + "_" + idx_str;
  m.def(name_fwd.c_str(), &cugraph::ops::binding::agg_concat_mfg_n2n_fwd_wrapped<FeatT, IdxT>);
  m.def(name_fwd.c_str(), &cugraph::ops::binding::agg_concat_mfg_n2n_fwd_csr_wrapped<FeatT, IdxT>);
  std::string name_bwd = "agg_concat_mfg_n2n_bwd_" + feat_str + "_" + idx_str;
  m.def(name_bwd.c_str(), &cugraph::ops::binding::agg_concat_mfg_n2n_bwd_wrapped<FeatT, IdxT>);
  m.def(name_bwd.c_str(), &cugraph::ops::binding::agg_concat_mfg_n2n_bwd_csr_wrapped<FeatT, IdxT>);
  std::string name_concat_bwd_rev = "agg_concat_mfg_n2n_bwd_rev_" + feat_str + "_" + idx_str;
  m.def(name_concat_bwd_rev.c_str(),
        &cugraph::ops::binding::agg_concat_mfg_n2n_bwd_rev_wrapped<FeatT, IdxT>);
}

void init_layers_agg_concat_mfg(nb::module_& m)
{
  init_agg_concat_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_agg_concat_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
