/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/gather.hpp>
#include <cugraph-ops/scatter.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT, typename IdxT>
void gather_wrapped(array_wrapper<FeatT>& out,
                    const array_wrapper<FeatT>& in,
                    const array_wrapper<IdxT>& indices,
                    int32_t n,
                    int32_t n_indices,
                    const cuda::stream& stream)
{
  cugraph::ops::gather(out.ptr(), in.ptr(), indices.ptr(), n, n_indices, stream);
}

template <typename FeatT, typename IdxT>
void scatter_wrapped(array_wrapper<FeatT>& out,
                     const array_wrapper<FeatT>& in,
                     const array_wrapper<IdxT>& indices,
                     int32_t n,
                     int32_t n_indices,
                     const cuda::stream& stream)
{
  cugraph::ops::scatter(out.ptr(), in.ptr(), indices.ptr(), n, n_indices, stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT, typename IdxT>
void init_gather_scatter(nb::module_& m, const std::string& feat_str, const std::string& idx_str)
{
  std::string name_gather = "gather_" + feat_str + "_" + idx_str;
  m.def(name_gather.c_str(), &cugraph::ops::binding::gather_wrapped<FeatT, IdxT>);
  std::string name_scatter = "scatter_" + feat_str + "_" + idx_str;
  m.def(name_scatter.c_str(), &cugraph::ops::binding::scatter_wrapped<FeatT, IdxT>);
}

void init_layers_gather_scatter(nb::module_& m)
{
  init_gather_scatter<float, int32_t>(m, "float32", "int32");
  init_gather_scatter<float, int64_t>(m, "float32", "int64");
  init_gather_scatter<int32_t, int32_t>(m, "int32", "int32");
  init_gather_scatter<int32_t, int64_t>(m, "int32", "int64");
}
