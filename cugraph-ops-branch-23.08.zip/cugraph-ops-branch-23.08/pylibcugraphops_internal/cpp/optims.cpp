/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_optims_adam(nb::module_&);

void init_optims(nb::module_& m)
{
  auto optims = m.def_submodule("optims", "cugraph_ops optimizers");
  init_optims_adam(optims);
}
