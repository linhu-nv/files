/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/io/ogbg_reader.hpp>

#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>

#include <cstdint>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

array_wrapper<float> node_features_wrapped(cugraph::ops::io::ogbg_cuda& d_data)
{
  return {static_cast<size_t>(d_data.n_cols_nodes * d_data.graph->n_nodes), d_data.node_features};
}

array_wrapper<float> edge_features_wrapped(cugraph::ops::io::ogbg_cuda& d_data)
{
  return {static_cast<size_t>(d_data.n_cols_edges * d_data.graph->n_indices), d_data.edge_features};
}

array_wrapper<int32_t> labels_wrapped(cugraph::ops::io::ogbg_cuda& d_data)
{
  return {static_cast<size_t>(d_data.graph->n_nodes), d_data.labels};
}

const fg_csr_seq_s64_t& graph_wrapped(cugraph::ops::io::ogbg_cuda& d_data) { return *d_data.graph; }

}  // namespace cugraph::ops::binding

void init_io_ogbg_reader(nb::module_& m)
{
  auto ogbg_class = nb::class_<cugraph::ops::io::ogbg_cuda>(m, "ogbg")
                      .def(nb::init<const std::string&, bool, cudaMemoryType, cudaMemoryType>())
                      .def_ro("n_cols_nodes", &cugraph::ops::io::ogbg_cuda::n_cols_nodes)
                      .def_ro("n_cols_edges", &cugraph::ops::io::ogbg_cuda::n_cols_edges)
                      .def_ro("n_labels", &cugraph::ops::io::ogbg_cuda::n_labels)
                      .def_prop_ro("graph", &cugraph::ops::binding::graph_wrapped)
                      .def_prop_ro("node_features", &cugraph::ops::binding::node_features_wrapped)
                      .def_prop_ro("edge_features", &cugraph::ops::binding::edge_features_wrapped)
                      .def_prop_ro("labels", &cugraph::ops::binding::labels_wrapped);
}
