/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/operators/common.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_layers_agg_concat_mfg(nb::module_&);
void init_layers_agg_dmpnn_fg(nb::module_&);
void init_layers_agg_hg_basis_mfg(nb::module_&);
void init_layers_agg_simple_mfg(nb::module_&);
void init_layers_bias_activation(nb::module_&);
void init_layers_dense(nb::module_&);
void init_layers_gather_scatter(nb::module_&);
void init_layers_loss(nb::module_&);
void init_layers_metrics(nb::module_&);
void init_layers_mha_gat_mfg(nb::module_&);
void init_layers_weight_init(nb::module_&);

void init_layers(nb::module_& m)
{
  auto layers = m.def_submodule("layers", "cugraph_ops layers");

  init_layers_agg_concat_mfg(layers);
  init_layers_agg_dmpnn_fg(layers);
  init_layers_agg_hg_basis_mfg(layers);
  init_layers_agg_simple_mfg(layers);
  init_layers_bias_activation(layers);
  init_layers_dense(layers);
  init_layers_gather_scatter(layers);
  init_layers_loss(layers);
  init_layers_metrics(layers);
  init_layers_mha_gat_mfg(layers);
  init_layers_weight_init(layers);
}
