/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/cuda/cublas.hpp>
#include <cugraph-ops/cuda/cudnn.hpp>
#include <cugraph-ops/cuda/stream.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_cuda(nb::module_& m)
{
  auto cumod = m.def_submodule("cuda", "cugraph_ops cuda helper methods");
  nb::class_<cugraph::ops::cuda::cublashandle>(cumod, "cublashandle").def(nb::init<>());
  nb::class_<cugraph::ops::cuda::cudnnhandle>(cumod, "cudnnhandle").def(nb::init<>());
  nb::class_<cugraph::ops::cuda::stream>(cumod, "stream")
    .def(nb::init<>())
    .def("sync", &cugraph::ops::cuda::stream::sync);
}
