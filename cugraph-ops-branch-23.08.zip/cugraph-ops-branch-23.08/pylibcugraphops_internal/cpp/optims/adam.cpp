/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/optims.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename FeatT>
void adam_update_wrapped(array_wrapper<FeatT>& params,
                         array_wrapper<FeatT>& m,
                         array_wrapper<FeatT>& v,
                         const array_wrapper<FeatT>& pgrads,
                         float beta1,
                         float beta2,
                         float eta,
                         float epsilon,
                         uint64_t n_params,
                         int step,
                         const cuda::stream& stream)
{
  cugraph::ops::optims::adam_update(params.ptr(),
                                    m.ptr(),
                                    v.ptr(),
                                    pgrads.ptr(),
                                    beta1,
                                    beta2,
                                    eta,
                                    epsilon,
                                    n_params,
                                    step,
                                    stream);
}

}  // namespace cugraph::ops::binding

template <typename FeatT>
void init_adam(nb::module_& m, const std::string& type_str)
{
  std::string name = "adam_update_" + type_str;
  m.def(name.c_str(), &cugraph::ops::binding::adam_update_wrapped<FeatT>);
}

void init_optims_adam(nb::module_& m) { init_adam<float>(m, "float32"); }
