/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_torch_agg_concat_mfg(nb::module_&);
void init_torch_agg_dmpnn_fg(nb::module_&);
void init_torch_agg_simple_mfg(nb::module_&);
void init_torch_dense(nb::module_&);
void init_torch_dimenet(nb::module_&);
void init_torch_gather_scatter(nb::module_&);
void init_torch_ogbg_copy(nb::module_&);
void init_torch_ogbn_copy(nb::module_&);
void init_torch_pool_fg(nb::module_&);
void init_torch_utils(nb::module_&);

void init_torch(nb::module_& m)
{
  auto torch = m.def_submodule("torch", "cugraph_ops pytorch ops");
  init_torch_agg_concat_mfg(torch);
  init_torch_agg_dmpnn_fg(torch);
  init_torch_agg_simple_mfg(torch);
  init_torch_dense(torch);
  init_torch_gather_scatter(torch);
  init_torch_ogbg_copy(torch);
  init_torch_ogbn_copy(torch);
  init_torch_pool_fg(torch);
  init_torch_utils(torch);

  auto dimenet = torch.def_submodule("dimenet", "cugraph_ops dimenet ops");
  init_torch_dimenet(dimenet);
}
