/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_utils_logger(nb::module_&);
void init_utils_nvtx(nb::module_&);
void init_utils_verify(nb::module_& m);
void init_utils_version(nb::module_& m);

void init_utils(nb::module_& m)
{
  auto utils = m.def_submodule("utils", "cugraph_ops utilities");
  init_utils_logger(utils);
  init_utils_nvtx(utils);
  init_utils_verify(utils);
  init_utils_version(utils);
}
