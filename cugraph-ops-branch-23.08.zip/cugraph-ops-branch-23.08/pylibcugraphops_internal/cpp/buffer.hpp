/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/utils/allocator.hpp>
#include <cugraph-ops/utils/print_array.hpp>

#include <string>

namespace cugraph::ops::binding {

// first define a class to simply wrap pointers
template <typename DataT>
class array_wrapper {
 public:
  array_wrapper() = default;
  array_wrapper(size_t len, DataT* data) : len_(len), data_(data) {}
  [[nodiscard]] size_t get_len() const { return len_; }
  [[nodiscard]] DataT* ptr() const { return data_; }
  void print(const std::string& name) const { utils::print_a(data_, len_, name); }

 protected:
  const size_t len_{0};
  DataT* const data_{nullptr};
};

template <typename DataT>
class buffer : public array_wrapper<DataT> {
 public:
  buffer() = delete;
  ~buffer()
  {
    if (this->data_ == nullptr) return;
    allocator_.dealloc(this->data_, n_bytes_, stream_);
  }
  /** deleted copy / copy assignment */
  buffer(const buffer&)            = delete;
  buffer& operator=(const buffer&) = delete;

  [[nodiscard]] cugraph::ops::cuda::stream& get_stream() const { return stream_; }
  [[nodiscard]] cugraph::ops::utils::allocator& get_allocator() const { return allocator_; };

 protected:
  buffer(size_t len, cugraph::ops::utils::allocator& allocator, cugraph::ops::cuda::stream& stream)
    : array_wrapper<DataT>(len,
                           reinterpret_cast<DataT*>(allocator.alloc(len * sizeof(DataT), stream))),
      n_bytes_(len * sizeof(DataT)),
      stream_(stream),
      allocator_(allocator)
  {
  }
  const size_t n_bytes_{0};
  cugraph::ops::cuda::stream& stream_;
  cugraph::ops::utils::allocator& allocator_;
};

template <typename DataT>
class host_buffer : public buffer<DataT> {
 public:
  host_buffer(size_t len, cugraph::ops::cuda::stream& stream)
    : buffer<DataT>(len, cugraph::ops::utils::host_allocator(), stream)
  {
  }

  DataT get_item(size_t i) { return this->data_[i]; }
  void set_item(size_t i, DataT v) { this->data_[i] = v; }
};

template <typename DataT>
class device_buffer : public buffer<DataT> {
 public:
  device_buffer(size_t len, cugraph::ops::cuda::stream& stream)
    : buffer<DataT>(len, cugraph::ops::utils::device_allocator(), stream)
  {
  }
};

}  // namespace cugraph::ops::binding
