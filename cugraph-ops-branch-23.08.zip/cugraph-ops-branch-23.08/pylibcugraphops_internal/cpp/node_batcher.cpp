/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "buffer.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/node_batcher.hpp>

#include <nanobind/nanobind.h>
#include <nanobind/stl/vector.h>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> batch_wrapped(typename ClassT::batch_info& batch_info)
{
  return {static_cast<size_t>(batch_info.curr_size), batch_info.batch};
}

template <typename ClassT, typename IdxT>
nb::object info_mfg_wrapped(typename ClassT::layer_info& layer_info)
{
  auto& mfg = *layer_info.mfg;
  if constexpr (ClassT::IS_CSR) {
    return nb::cast(mfg);
  } else {
    try {
      return nb::cast(dynamic_cast<const graph::mfg_ellpack_hg<IdxT>&>(mfg));
    } catch (const std::bad_cast& e) {
      return nb::cast(mfg);
    }
  }
}

template <typename ClassT, typename IdxT>
nb::object info_mfg_rev_wrapped(typename ClassT::layer_info& layer_info)
{
  auto& mfg = *layer_info.mfg;
  try {
    return nb::cast(dynamic_cast<const graph::mfg_csr_rev_hg<IdxT>&>(mfg));
  } catch (const std::bad_cast& e) {
    return nb::cast(mfg);
  }
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> in_nodes_wrapped(typename ClassT::layer_info& layer_info)
{
  auto& mfg = *layer_info.mfg;
  return {static_cast<size_t>(mfg.n_in_nodes), layer_info.in_nodes};
}

}  // namespace cugraph::ops::binding

template <typename ClassT, typename IdxT>
void init_node_batcher_impl(nb::module_& m,
                            const char* name,
                            const char* subname,
                            const char* subname1)
{
  auto ns_class = nb::class_<ClassT>(m, name)
                    .def(nb::init<cugraph::ops::graph::fg_csr<IdxT>&,
                                  const std::vector<IdxT>&,
                                  IdxT,
                                  IdxT,
                                  raft::random::RngState&,
                                  cugraph::ops::graph::SamplingAlgoT,
                                  const cugraph::ops::cuda::stream&>())
                    .def(nb::init<cugraph::ops::graph::fg_csr<IdxT>&,
                                  const std::vector<IdxT>&,
                                  IdxT,
                                  IdxT,
                                  IdxT,
                                  raft::random::RngState&,
                                  cugraph::ops::graph::SamplingAlgoT,
                                  bool,
                                  const cugraph::ops::cuda::stream&>())
                    .def("reset", &ClassT::reset)
                    .def("next_batch", &ClassT::next_batch)
                    .def("curr_batch", &ClassT::curr_batch)
                    .def("num_batches", &ClassT::num_batches)
                    .def("num_layers", &ClassT::num_layers)
                    // layer_info lifetime is tied to lifetime of parent object
                    .def("get_info", &ClassT::get_info, nb::rv_policy::reference_internal)
                    .def("get_stream", &ClassT::get_stream)
                    .def("max_batch_size", &ClassT::max_batch_size)
                    .def("do_reverse", &ClassT::do_reverse);
  nb::class_<typename ClassT::batch_info>(ns_class, subname1)
    .def_ro("curr_size", &ClassT::batch_info::curr_size)
    .def_prop_ro("batch", &cugraph::ops::binding::batch_wrapped<ClassT, IdxT>);
  nb::class_<typename ClassT::layer_info>(ns_class, subname)
    .def_ro("sample_size", &ClassT::layer_info::sample_size)
    .def_ro("max_out_nodes", &ClassT::layer_info::max_out_nodes)
    .def_prop_ro("mfg", &cugraph::ops::binding::info_mfg_wrapped<ClassT, IdxT>)
    .def_prop_ro("mfg_rev", &cugraph::ops::binding::info_mfg_rev_wrapped<ClassT, IdxT>)
    .def_prop_ro("in_nodes", &cugraph::ops::binding::in_nodes_wrapped<ClassT, IdxT>);
}

template <typename ClassT, typename ParentT, typename IdxT>
void init_node_batcher_hg_impl(nb::module_& m, const char* name)
{
  nb::class_<ClassT, ParentT>(m, name).def(nb::init<cugraph::ops::graph::fg_csr<IdxT>&,
                                                    const std::vector<IdxT>&,
                                                    IdxT,
                                                    IdxT,
                                                    IdxT,
                                                    raft::random::RngState&,
                                                    cugraph::ops::graph::SamplingAlgoT,
                                                    bool,
                                                    const cugraph::ops::cuda::stream&>());
}

void init_node_batcher(nb::module_& m)
{
  init_node_batcher_impl<cugraph::ops::node_batcher<int64_t>, int64_t>(
    m, "node_batcher_int64", "layer_info", "batch_info");
  init_node_batcher_impl<cugraph::ops::node_batcher<int32_t>, int32_t>(
    m, "node_batcher_int32", "layer_info", "batch_info");
  init_node_batcher_hg_impl<cugraph::ops::node_batcher_hg<int64_t>,
                            cugraph::ops::node_batcher<int64_t>,
                            int64_t>(m, "node_batcher_hg_int64");
  init_node_batcher_hg_impl<cugraph::ops::node_batcher_hg<int32_t>,
                            cugraph::ops::node_batcher<int32_t>,
                            int32_t>(m, "node_batcher_hg_int32");
  init_node_batcher_impl<cugraph::ops::node_batcher<int64_t, true>, int64_t>(
    m, "node_batcher_csr_int64", "layer_info", "batch_info");
  init_node_batcher_impl<cugraph::ops::node_batcher<int32_t, true>, int32_t>(
    m, "node_batcher_csr_int32", "layer_info", "batch_info");
}
