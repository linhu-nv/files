/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

#include <raft/random/rng_state.hpp>

namespace nb = nanobind;

void init_rng(nb::module_& m)
{
  nb::class_<raft::random::RngState>(m, "rng_state")
    .def(nb::init<uint64_t>())
    .def_ro("seed", &raft::random::RngState::seed)
    .def_ro("base_subsequence", &raft::random::RngState::base_subsequence);
}
