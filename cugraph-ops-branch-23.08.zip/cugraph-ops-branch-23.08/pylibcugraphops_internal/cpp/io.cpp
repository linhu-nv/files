/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_io_ogbn_reader(nb::module_&);
void init_io_ogbg_reader(nb::module_&);

void init_io(nb::module_& m)
{
  auto io = m.def_submodule("io", "cugraph_ops io methods");
  init_io_ogbg_reader(io);
  init_io_ogbn_reader(io);
}
