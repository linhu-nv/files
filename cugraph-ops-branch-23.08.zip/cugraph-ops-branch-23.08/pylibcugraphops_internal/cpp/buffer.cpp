/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "buffer.hpp"

#include <cugraph-ops/cuda/stream.hpp>
#include <cugraph-ops/utils/allocator.hpp>

#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>

#include <string>

namespace nb = nanobind;

template <typename DataT>
void init_buffer_t(nb::module_& m, const char* type_str)
{
  std::string name1 = std::string("ArrayWrapper_") + type_str;
  nb::class_<cugraph::ops::binding::array_wrapper<DataT>>(m, name1.c_str())
    .def(nb::init<>())
    .def("print", &cugraph::ops::binding::array_wrapper<DataT>::print)
    .def_prop_ro("length", &cugraph::ops::binding::array_wrapper<DataT>::get_len);
  std::string name2 = std::string("Buffer") + type_str;
  nb::class_<cugraph::ops::binding::buffer<DataT>, cugraph::ops::binding::array_wrapper<DataT>>(
    m, name2.c_str())
    .def_prop_ro("stream", &cugraph::ops::binding::buffer<DataT>::get_stream);
  std::string name3 = std::string("HostBuffer") + type_str;
  nb::class_<cugraph::ops::binding::host_buffer<DataT>, cugraph::ops::binding::buffer<DataT>>(
    m, name3.c_str())
    .def(nb::init<size_t, cugraph::ops::cuda::stream&>())
    .def("__getitem__", &cugraph::ops::binding::host_buffer<DataT>::get_item)
    .def("__setitem__", &cugraph::ops::binding::host_buffer<DataT>::set_item);
  std::string name4 = std::string("DeviceBuffer") + type_str;
  nb::class_<cugraph::ops::binding::device_buffer<DataT>, cugraph::ops::binding::buffer<DataT>>(
    m, name4.c_str())
    .def(nb::init<size_t, cugraph::ops::cuda::stream&>());
}

void init_buffer(nb::module_& m)
{
  init_buffer_t<char>(m, "char");
  init_buffer_t<int8_t>(m, "int8");
  init_buffer_t<uint8_t>(m, "uint8");
  init_buffer_t<int16_t>(m, "int16");
  init_buffer_t<uint16_t>(m, "uint16");
  init_buffer_t<int32_t>(m, "int32");
  init_buffer_t<uint32_t>(m, "uint32");
  init_buffer_t<int64_t>(m, "int64");
  init_buffer_t<uint64_t>(m, "uint64");
  init_buffer_t<float>(m, "float32");
  init_buffer_t<double>(m, "float64");
}
