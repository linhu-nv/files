/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_buffer(nb::module_&);
void init_cuda(nb::module_&);
void init_graph_batcher(nb::module_&);
void init_graph(nb::module_&);
void init_io(nb::module_&);
void init_layers(nb::module_&);
void init_node_batcher(nb::module_&);
void init_optims(nb::module_&);
void init_rng(nb::module_&);
#ifdef CUGRAPH_OPS_INTERNAL_TORCH
void init_torch(nb::module_&);
#endif
void init_utils(nb::module_&);

NB_MODULE(pylibcugraphops_internal_ext, m)
{
  // definitions of types first
  init_buffer(m);
  init_cuda(m);
  init_rng(m);
  // types which require prior types
  init_graph(m);
  init_graph_batcher(m);
  init_io(m);
  init_node_batcher(m);
  // methods mainly
  init_utils(m);
  init_layers(m);
  init_optims(m);

#ifdef CUGRAPH_OPS_INTERNAL_TORCH
  init_torch(m);
#endif
}
