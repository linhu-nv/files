/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/graph/format.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> offsets_wrapped(ClassT& csr)
{
  return {static_cast<size_t>(csr.n_nodes + 1), csr.offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> indices_wrapped(ClassT& csr)
{
  return {static_cast<size_t>(csr.n_indices), csr.indices};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> ef_indices_wrapped(ClassT& csr)
{
  return {static_cast<size_t>(csr.n_indices), csr.ef_indices};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> rev_edge_ids_wrapped(ClassT& csr)
{
  return {static_cast<size_t>(csr.n_indices), csr.rev_edge_ids};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> graph_offsets_wrapped(ClassT& csr_seq)
{
  return {static_cast<size_t>(csr_seq.n_graphs + 1), csr_seq.graph_offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> batch_offsets_wrapped(ClassT& csr_batch)
{
  return {static_cast<size_t>(csr_batch.batch_size), csr_batch.batch_offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> nf_offsets_wrapped(ClassT& csr_batch)
{
  return {static_cast<size_t>(csr_batch.batch_size), csr_batch.nf_offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> ef_offsets_wrapped(ClassT& csr_batch)
{
  return {static_cast<size_t>(csr_batch.batch_size), csr_batch.ef_offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> out_nodes_wrapped(ClassT& mfg)
{
  return {static_cast<size_t>(mfg.n_out_nodes), mfg.out_nodes};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> neighbors_wrapped(ClassT& mfg)
{
  return {static_cast<size_t>(mfg.n_out_nodes * mfg.sample_size), mfg.neighbors};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> neighbor_counts_wrapped(ClassT& mfg)
{
  return {static_cast<size_t>(mfg.n_out_nodes), mfg.neighbor_counts};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> in_node_ids_wrapped(ClassT& mfg_rev)
{
  return {static_cast<size_t>(mfg_rev.n_in_nodes), mfg_rev.in_node_ids};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> mfg_offsets_wrapped(ClassT& mfg)
{
  if (mfg.offsets == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(mfg.n_out_nodes) + 1, mfg.offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> mfg_indices_wrapped(ClassT& mfg)
{
  return {static_cast<size_t>(mfg.n_indices), mfg.indices};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> rev_offsets_wrapped(ClassT& mfg_rev)
{
  if (mfg_rev.offsets == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(mfg_rev.n_in_nodes + 1), mfg_rev.offsets};
}

template <typename ClassT, typename IdxT>
array_wrapper<IdxT> rev_indices_wrapped(ClassT& mfg_rev)
{
  return {static_cast<size_t>(mfg_rev.n_indices), mfg_rev.indices};
}

template <typename ClassT>
array_wrapper<int32_t> node_types_wrapped(ClassT& fg)
{
  if (fg.node_types == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(fg.n_nodes), fg.node_types};
}

template <typename ClassT>
array_wrapper<int32_t> edge_types_fg_wrapped(ClassT& fg)
{
  if (fg.edge_types == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(fg.n_indices), fg.edge_types};
}

template <typename ClassT>
array_wrapper<int32_t> out_node_types_wrapped(ClassT& mfg)
{
  if (mfg.out_node_types == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(mfg.n_out_nodes), mfg.out_node_types};
}

template <typename ClassT>
array_wrapper<int32_t> in_node_types_wrapped(ClassT& mfg)
{
  if (mfg.in_node_types == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(mfg.n_in_nodes), mfg.in_node_types};
}

template <typename ClassT>
array_wrapper<int32_t> edge_types_mfg_wrapped(ClassT& mfg)
{
  if (mfg.edge_types == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(mfg.n_out_nodes * mfg.sample_size), mfg.edge_types};
}

template <typename ClassT>
array_wrapper<int32_t> edge_types_mfg_rev_wrapped(ClassT& mfg)
{
  if (mfg.edge_types == nullptr) return {size_t{0}, nullptr};
  return {static_cast<size_t>(mfg.n_indices), mfg.edge_types};
}

}  // namespace cugraph::ops::binding

template <typename ClassT, typename IdxT>
void init_get_fg_csr(nb::module_& m)
{
  m.def("get_offsets", &cugraph::ops::binding::offsets_wrapped<ClassT, IdxT>);
  m.def("get_indices", &cugraph::ops::binding::indices_wrapped<ClassT, IdxT>);
  m.def("get_ef_indices", &cugraph::ops::binding::ef_indices_wrapped<ClassT, IdxT>);
  m.def("get_rev_edge_ids", &cugraph::ops::binding::rev_edge_ids_wrapped<ClassT, IdxT>);
}

template <typename ClassT, typename IdxT>
void init_get_fg_csr_seq(nb::module_& m)
{
  m.def("get_graph_offsets", &cugraph::ops::binding::graph_offsets_wrapped<ClassT, IdxT>);
}

template <typename ClassT, typename IdxT>
void init_get_fg_csr_batch(nb::module_& m)
{
  m.def("get_batch_offsets", &cugraph::ops::binding::batch_offsets_wrapped<ClassT, IdxT>);
  m.def("get_nf_offsets", &cugraph::ops::binding::nf_offsets_wrapped<ClassT, IdxT>);
  m.def("get_ef_offsets", &cugraph::ops::binding::ef_offsets_wrapped<ClassT, IdxT>);
}

template <typename ClassT, typename IdxT>
void init_get_mfg_ellpack(nb::module_& m)
{
  m.def("get_out_nodes", &cugraph::ops::binding::out_nodes_wrapped<ClassT, IdxT>);
  m.def("get_neighbors", &cugraph::ops::binding::neighbors_wrapped<ClassT, IdxT>);
  m.def("get_neighbor_counts", &cugraph::ops::binding::neighbor_counts_wrapped<ClassT, IdxT>);
}

template <typename ClassT, typename IdxT>
void init_get_mfg_csr(nb::module_& m)
{
  m.def("get_out_nodes", &cugraph::ops::binding::out_nodes_wrapped<ClassT, IdxT>);
  m.def("get_offsets", &cugraph::ops::binding::mfg_offsets_wrapped<ClassT, IdxT>);
  m.def("get_indices", &cugraph::ops::binding::mfg_indices_wrapped<ClassT, IdxT>);
}

template <typename ClassT, typename IdxT>
void init_get_mfg_csr_rev(nb::module_& m)
{
  m.def("get_in_node_ids", &cugraph::ops::binding::in_node_ids_wrapped<ClassT, IdxT>);
  m.def("get_offsets", &cugraph::ops::binding::rev_offsets_wrapped<ClassT, IdxT>);
  m.def("get_indices", &cugraph::ops::binding::rev_indices_wrapped<ClassT, IdxT>);
}

template <typename ClassT>
void init_get_fg_hg_types(nb::module_& m)
{
  m.def("get_node_types", &cugraph::ops::binding::node_types_wrapped<ClassT>);
  m.def("get_edge_types", &cugraph::ops::binding::edge_types_fg_wrapped<ClassT>);
}

template <typename ClassT>
void init_get_mfg_hg_types(nb::module_& m)
{
  m.def("get_out_node_types", &cugraph::ops::binding::out_node_types_wrapped<ClassT>);
  m.def("get_in_node_types", &cugraph::ops::binding::in_node_types_wrapped<ClassT>);
  m.def("get_edge_types", &cugraph::ops::binding::edge_types_mfg_wrapped<ClassT>);
}

void init_graph_formats(nb::module_& m)
{
  init_get_fg_csr<cugraph::ops::fg_csr_s32_t, int32_t>(m);
  init_get_fg_csr<cugraph::ops::fg_csr_s64_t, int64_t>(m);
  init_get_fg_csr_seq<cugraph::ops::fg_csr_seq_s32_t, int32_t>(m);
  init_get_fg_csr_seq<cugraph::ops::fg_csr_seq_s64_t, int64_t>(m);
  init_get_fg_csr_batch<cugraph::ops::fg_csr_batch_s32_t, int32_t>(m);
  init_get_fg_csr_batch<cugraph::ops::fg_csr_batch_s64_t, int64_t>(m);
  init_get_mfg_ellpack<cugraph::ops::mfg_ellpack_s32_t, int32_t>(m);
  init_get_mfg_ellpack<cugraph::ops::mfg_ellpack_s64_t, int64_t>(m);
  init_get_mfg_csr<cugraph::ops::mfg_csr_s32_t, int32_t>(m);
  init_get_mfg_csr<cugraph::ops::mfg_csr_s64_t, int64_t>(m);
  init_get_mfg_csr_rev<cugraph::ops::mfg_csr_rev_s32_t, int32_t>(m);
  init_get_mfg_csr_rev<cugraph::ops::mfg_csr_rev_s64_t, int64_t>(m);

  init_get_fg_hg_types<cugraph::ops::fg_csr_hg_s32_t>(m);
  init_get_fg_hg_types<cugraph::ops::fg_csr_hg_s64_t>(m);
  init_get_mfg_hg_types<cugraph::ops::mfg_ellpack_hg_s32_t>(m);
  init_get_mfg_hg_types<cugraph::ops::mfg_ellpack_hg_s64_t>(m);
  init_get_mfg_hg_types<cugraph::ops::mfg_csr_rev_hg_s32_t>(m);
  init_get_mfg_hg_types<cugraph::ops::mfg_csr_rev_hg_s64_t>(m);
}
