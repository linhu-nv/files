/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops-test/random/csr_generator.hpp>

#include <cugraph-ops/graph/format.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_graph_csr_generator(nb::module_& m)
{
  m.def(
    "generate_csr_on_device",
    nb::overload_cast<cugraph::ops::fg_csr_s32_t&,
                      raft::random::RngState&,
                      int32_t,
                      int32_t,
                      bool,
                      cugraph::ops::cuda::stream&>(&cugraph::ops::graph::generate_csr_on_device));
  m.def(
    "generate_csr_on_device",
    nb::overload_cast<cugraph::ops::fg_csr_s64_t&,
                      raft::random::RngState&,
                      int64_t,
                      int64_t,
                      bool,
                      cugraph::ops::cuda::stream&>(&cugraph::ops::graph::generate_csr_on_device));

  m.def("delete_csr_from_device",
        nb::overload_cast<cugraph::ops::fg_csr_s32_t&, cugraph::ops::cuda::stream&>(
          &cugraph::ops::graph::delete_csr_from_device));
  m.def("delete_csr_from_device",
        nb::overload_cast<cugraph::ops::fg_csr_s64_t&, cugraph::ops::cuda::stream&>(
          &cugraph::ops::graph::delete_csr_from_device));

  m.def("generate_csr_seq_on_device",
        nb::overload_cast<cugraph::ops::fg_csr_seq_s32_t&,
                          raft::random::RngState&,
                          int32_t,
                          int32_t,
                          int32_t,
                          bool,
                          cugraph::ops::cuda::stream&>(
          &cugraph::ops::graph::generate_csr_seq_on_device));
  m.def("generate_csr_seq_on_device",
        nb::overload_cast<cugraph::ops::fg_csr_seq_s64_t&,
                          raft::random::RngState&,
                          int64_t,
                          int64_t,
                          int64_t,
                          bool,
                          cugraph::ops::cuda::stream&>(
          &cugraph::ops::graph::generate_csr_seq_on_device));

  m.def("delete_csr_seq_from_device",
        nb::overload_cast<cugraph::ops::fg_csr_seq_s32_t&, cugraph::ops::cuda::stream&>(
          &cugraph::ops::graph::delete_csr_seq_from_device));
  m.def("delete_csr_seq_from_device",
        nb::overload_cast<cugraph::ops::fg_csr_seq_s64_t&, cugraph::ops::cuda::stream&>(
          &cugraph::ops::graph::delete_csr_seq_from_device));
}
