/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/logger.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_utils_logger(nb::module_& m)
{
  auto logger = m.def_submodule("logger", "cugraph_ops logger methods");
  logger.def("get_log_level", &cugraph::ops::utils::get_log_level);
  logger.def("set_log_level", &cugraph::ops::utils::set_log_level);
  logger.def("will_log_for", &cugraph::ops::utils::will_log_for);
  logger.def("fatal", [](const char* msg) { CUGRAPH_OPS_FATAL(msg); });
  logger.def("error", [](const char* msg) { CUGRAPH_OPS_ERROR(msg); });
  logger.def("warn", [](const char* msg) { CUGRAPH_OPS_WARN(msg); });
  logger.def("info", [](const char* msg) { CUGRAPH_OPS_INFO(msg); });
  logger.def("debug", [](const char* msg) { CUGRAPH_OPS_DEBUG(msg); });
  logger.def("trace", [](const char* msg) { CUGRAPH_OPS_TRACE(msg); });
  logger.attr("LEVEL_FATAL") = cugraph::ops::utils::LEVEL_FATAL;
  logger.attr("LEVEL_ERROR") = cugraph::ops::utils::LEVEL_ERROR;
  logger.attr("LEVEL_WARN")  = cugraph::ops::utils::LEVEL_WARN;
  logger.attr("LEVEL_INFO")  = cugraph::ops::utils::LEVEL_INFO;
  logger.attr("LEVEL_DEBUG") = cugraph::ops::utils::LEVEL_DEBUG;
  logger.attr("LEVEL_TRACE") = cugraph::ops::utils::LEVEL_TRACE;
}
