/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/version.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_utils_version(nb::module_& m)
{
  m.def("version_str",
        &cugraph::ops::utils::version_str,
        "Returns the cugraph_ops library version number as a string.");
}
