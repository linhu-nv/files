/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/utils/nvtx.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_utils_nvtx(nb::module_& m)
{
  m.def("disable_nvtx_ranges",
        &cugraph::ops::utils::disable_nvtx_ranges,
        "Disable NVTX range during runtime.");
  m.def("enable_nvtx_ranges",
        &cugraph::ops::utils::enable_nvtx_ranges,
        "Enable NVTX range during runtime.");
  m.def("push_range", &cugraph::ops::utils::push_range);
  m.def("pop_range", &cugraph::ops::utils::pop_range);
}
