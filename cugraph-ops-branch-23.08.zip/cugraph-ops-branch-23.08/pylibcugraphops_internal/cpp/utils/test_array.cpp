/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"

#include <cugraph-ops/utils/test_array.hpp>

#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename DataT>
bool verify_nan_inf_range_wrapped(array_wrapper<DataT>& in,
                                  size_t len,
                                  DataT r1,
                                  DataT r2,
                                  array_wrapper<int32_t>& check_v,
                                  const std::string& name,
                                  const cuda::stream& stream)
{
  len = len > 0 ? len : in.get_len();
  return utils::verify_nan_inf_range(in.ptr(), len, check_v.ptr(), name, stream, r1, r2);
}

}  // namespace cugraph::ops::binding

void init_utils_verify(nb::module_& m)
{
  m.def("verify_nan_inf_range_float32",
        &cugraph::ops::binding::verify_nan_inf_range_wrapped<float>,
        nb::arg("a"),
        nb::arg("len") = 0,
        nb::arg("r1")  = 1.F,
        nb::arg("r2")  = 0.F,
        nb::arg("check_v"),
        nb::arg("name"),
        nb::arg("stream"));
  m.def("verify_nan_inf_range_float64",
        &cugraph::ops::binding::verify_nan_inf_range_wrapped<double>,
        nb::arg("a"),
        nb::arg("len") = 0,
        nb::arg("r1")  = 1.,
        nb::arg("r2")  = 0.,
        nb::arg("check_v"),
        nb::arg("name"),
        nb::arg("stream"));
}
