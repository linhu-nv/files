/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <cugraph-ops/graph/sampling.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_graph_formats(nb::module_&);
void init_graph_csr_generator(nb::module_&);

void init_graph(nb::module_& m)
{
  auto graph = m.def_submodule("graph", "cugraph_ops graph methods");
  nb::enum_<cugraph::ops::graph::SamplingAlgoT>(graph, "SamplingAlgo")
    .value("ReservoirAlgoR", cugraph::ops::graph::SamplingAlgoT::kReservoirAlgoR)
    .value("ReservoirAlgoLST", cugraph::ops::graph::SamplingAlgoT::kReservoirAlgoLST);

  init_graph_formats(graph);
  init_graph_csr_generator(graph);
}
