/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include <nanobind/nanobind.h>
#include <nanobind/stl/optional.h>

#include <torch/extension.h>

#include <c10/core/ScalarType.h>
#include <c10/cuda/CUDAStream.h>

#include <cstdint>
#include <type_traits>

#define CUGRAPH_OPS_TORCH_CHECK_TENSOR_CUDA(t)                                \
  TORCH_CHECK((t).defined() && (t).is_contiguous() && (t).device().is_cuda(), \
              "Input torch tensor '" #t "' must be a contiguous CUDA device tensor")

#define CUGRAPH_OPS_TORCH_CHECK_TENSOR_PINNED(t)                       \
  TORCH_CHECK((t).defined() && (t).is_contiguous() && (t).is_pinned(), \
              "Input torch tensor '" #t "' must be a contiguous pinned host tensor")

#define CUGRAPH_OPS_TORCH_CHECK_TENSOR_TYPE(t, exp_type)                                          \
  switch ((t).scalar_type()) {                                                                    \
    case c10::ScalarType::Byte:                                                                   \
      TORCH_CHECK((std::is_same<exp_type, uint8_t>::value),                                       \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Byte");   \
      break;                                                                                      \
    case c10::ScalarType::Char:                                                                   \
      TORCH_CHECK((std::is_same<exp_type, int8_t>::value),                                        \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Char");   \
      break;                                                                                      \
    case c10::ScalarType::Short:                                                                  \
      TORCH_CHECK((std::is_same<exp_type, int16_t>::value),                                       \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Short");  \
      break;                                                                                      \
    case c10::ScalarType::Int:                                                                    \
      TORCH_CHECK((std::is_same<exp_type, int>::value),                                           \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Int");    \
      break;                                                                                      \
    case c10::ScalarType::Long:                                                                   \
      TORCH_CHECK((std::is_same<exp_type, int64_t>::value),                                       \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Long");   \
      break;                                                                                      \
    case c10::ScalarType::Float:                                                                  \
      TORCH_CHECK((std::is_same<exp_type, float>::value),                                         \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Float");  \
      break;                                                                                      \
    case c10::ScalarType::Double:                                                                 \
      TORCH_CHECK((std::is_same<exp_type, double>::value),                                        \
                  "Expected tensor '" #t "' of type '" #exp_type "' but got ScalarType::Double"); \
      break;                                                                                      \
    default: TORCH_CHECK(false, "Tensor '" #t "' has unsupported type");                          \
  }
#define CUGRAPH_OPS_TORCH_CHECK_TENSOR(t, exp_type) \
  CUGRAPH_OPS_TORCH_CHECK_TENSOR_CUDA(t);           \
  CUGRAPH_OPS_TORCH_CHECK_TENSOR_TYPE(t, exp_type)

#define CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(t, exp_type)        \
  if ((t).has_value()) {                                       \
    CUGRAPH_OPS_TORCH_CHECK_TENSOR_CUDA((t).value());          \
    CUGRAPH_OPS_TORCH_CHECK_TENSOR_TYPE((t).value(), exp_type) \
  }

#define CUGRAPH_OPS_TORCH_CHECK_PINNED_TENSOR(t, exp_type) \
  CUGRAPH_OPS_TORCH_CHECK_TENSOR_PINNED(t);                \
  CUGRAPH_OPS_TORCH_CHECK_TENSOR_TYPE(t, exp_type)

#define CUGRAPH_OPS_TORCH_CHECK_OPT_PINNED_TENSOR(t, exp_type) \
  if ((t).has_value()) {                                       \
    CUGRAPH_OPS_TORCH_CHECK_TENSOR_PINNED((t).value());        \
    CUGRAPH_OPS_TORCH_CHECK_TENSOR_TYPE((t).value(), exp_type) \
  }

namespace cugraph::ops::bind_torch {

// note that the utility functions below do not type check!
// type checking should be done with the macros defined above before
template <typename DataT>
inline DataT* maybe_ptr(std::optional<at::Tensor>& tensor)
{
  if (tensor.has_value()) return reinterpret_cast<DataT*>(tensor.value().data_ptr());
  return nullptr;
}

template <typename DataT>
inline const DataT* maybe_ptr(const std::optional<at::Tensor>& tensor)
{
  if (tensor.has_value()) return reinterpret_cast<const DataT*>(tensor.value().data_ptr());
  return nullptr;
}

template <typename DataT>
inline DataT* get_ptr(at::Tensor& tensor)
{
  return reinterpret_cast<DataT*>(tensor.data_ptr());
}

template <typename DataT>
inline const DataT* get_ptr(const at::Tensor& tensor)
{
  return reinterpret_cast<const DataT*>(tensor.data_ptr());
}

}  // namespace cugraph::ops::bind_torch

namespace nanobind::detail {

template <>
struct TORCH_PYTHON_API type_caster<at::Tensor> {
 public:
  inline bool from_python(handle src, uint8_t /* flags */, cleanup_list* /* list */) noexcept
  {
    try {
      auto* obj = src.ptr();
      if (THPVariable_Check(obj)) {
        value = THPVariable_Unpack(obj);
        return true;
      }
      return false;
    } catch (const std::exception& /* e */) {
      return false;
    }
  }

  inline static handle from_cpp(const at::Tensor& src,
                                rv_policy /* policy */,
                                cleanup_list* /* list */) noexcept
  {
    return {THPVariable_Wrap(src)};
  }

  NB_TYPE_CASTER(at::Tensor, const_name("at::Tensor"));
};

}  // namespace nanobind::detail
