/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../buffer.hpp"
#include "torch_utils.hpp"

#include <cugraph-ops/gather.hpp>
#include <cugraph-ops/scatter.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

template <typename FeatT, typename IdxT>
void gather_wrapped(at::Tensor& out,
                    const at::Tensor& in,
                    const binding::array_wrapper<IdxT>& indices,
                    int32_t n,
                    int32_t n_indices)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::gather(
    get_ptr<FeatT>(out), get_ptr<FeatT>(in), indices.ptr(), n, n_indices, stream);
}

template <typename FeatT, typename IdxT>
void scatter_wrapped(at::Tensor& out,
                     const at::Tensor& in,
                     const binding::array_wrapper<IdxT>& indices,
                     int32_t n,
                     int32_t n_indices)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::scatter(
    get_ptr<FeatT>(out), get_ptr<FeatT>(in), indices.ptr(), n, n_indices, stream);
}

template <typename FeatT, typename IdxT>
void gather_batch_wrapped(std::optional<at::Tensor>& out_node_feat,
                          std::optional<at::Tensor>& out_edge_feat,
                          const std::optional<at::Tensor>& in_node_feat,
                          const std::optional<at::Tensor>& in_edge_feat,
                          const graph::fg_csr_batch<IdxT>& fg_batch,
                          size_t dim_node,
                          size_t dim_edge)
{
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_node_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_edge_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(in_node_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(in_edge_feat, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::gather_batch(maybe_ptr<FeatT>(out_node_feat),
                             maybe_ptr<FeatT>(out_edge_feat),
                             maybe_ptr<FeatT>(in_node_feat),
                             maybe_ptr<FeatT>(in_edge_feat),
                             fg_batch,
                             dim_node,
                             dim_edge,
                             stream);
}

}  // namespace cugraph::ops::bind_torch

template <typename FeatT, typename IdxT>
void init_torch_gather_scatter(nb::module_& m,
                               const std::string& feat_str,
                               const std::string& idx_str)
{
  std::string name_gather = "gather_" + feat_str + "_" + idx_str;
  m.def(name_gather.c_str(), &cugraph::ops::bind_torch::gather_wrapped<FeatT, IdxT>);
  std::string name_scatter = "scatter_" + feat_str + "_" + idx_str;
  m.def(name_scatter.c_str(), &cugraph::ops::bind_torch::scatter_wrapped<FeatT, IdxT>);
}

template <typename FeatT, typename IdxT>
void init_torch_gather_batch(nb::module_& m,
                             const std::string& feat_str,
                             const std::string& idx_str)
{
  std::string name_gather_b = "gather_batch_" + feat_str + "_" + idx_str;
  m.def(name_gather_b.c_str(),
        &cugraph::ops::bind_torch::gather_batch_wrapped<FeatT, IdxT>,
        nb::arg("out_node_feat").none(),
        nb::arg("out_edge_feat").none(),
        nb::arg("in_node_feat").none(),
        nb::arg("in_edge_feat").none(),
        nb::arg("fg_batch"),
        nb::arg("dim_node"),
        nb::arg("dim_edge"));
}

void init_torch_gather_scatter(nb::module_& m)
{
  init_torch_gather_scatter<float, int32_t>(m, "float32", "int32");
  init_torch_gather_scatter<float, int64_t>(m, "float32", "int64");
  init_torch_gather_scatter<int32_t, int32_t>(m, "int32", "int32");
  init_torch_gather_scatter<int32_t, int64_t>(m, "int32", "int64");
  init_torch_gather_batch<float, int32_t>(m, "float32", "int32");
  init_torch_gather_batch<float, int64_t>(m, "float32", "int64");
}
