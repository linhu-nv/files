/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/operators/agg_simple_mfg.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

template <typename FeatT, typename IdxT>
void agg_simple_mfg_n2n_fwd_wrapped(at::Tensor& out,
                                    std::optional<at::Tensor>& out_pos,
                                    const at::Tensor& in,
                                    size_t dim,
                                    const graph::mfg_ellpack<IdxT>& mfg,
                                    AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_mfg_n2n_fwd(
    get_ptr<FeatT>(out), maybe_ptr<IdxT>(out_pos), get_ptr<FeatT>(in), dim, mfg, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_simple_mfg_n2n_bwd_wrapped(at::Tensor& din,
                                    const at::Tensor& dout,
                                    const std::optional<at::Tensor>& out_pos,
                                    size_t dim,
                                    const graph::mfg_ellpack<IdxT>& mfg,
                                    AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(din, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(dout, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_mfg_n2n_bwd(
    get_ptr<FeatT>(din), get_ptr<FeatT>(dout), maybe_ptr<IdxT>(out_pos), dim, mfg, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_simple_mfg_n2n_bwd_rev_wrapped(at::Tensor& din,
                                        const at::Tensor& dout,
                                        const std::optional<at::Tensor>& out_pos,
                                        size_t dim,
                                        const graph::mfg_ellpack<IdxT>& mfg,
                                        const graph::mfg_csr_rev<IdxT>& mfg_rev,
                                        AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(din, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(dout, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_mfg_n2n_bwd_rev(get_ptr<FeatT>(din),
                                           get_ptr<FeatT>(dout),
                                           maybe_ptr<IdxT>(out_pos),
                                           dim,
                                           mfg,
                                           mfg_rev,
                                           op,
                                           stream);
}

template <typename FeatT, typename IdxT>
void agg_simple_mfg_n2n_fwd_csr_wrapped(at::Tensor& out,
                                        std::optional<at::Tensor>& out_pos,
                                        const at::Tensor& in,
                                        size_t dim,
                                        const graph::mfg_csr<IdxT>& mfg,
                                        AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_mfg_n2n_fwd(
    get_ptr<FeatT>(out), maybe_ptr<IdxT>(out_pos), get_ptr<FeatT>(in), dim, mfg, op, stream);
}

template <typename FeatT, typename IdxT>
void agg_simple_mfg_n2n_bwd_csr_wrapped(at::Tensor& din,
                                        const at::Tensor& dout,
                                        const std::optional<at::Tensor>& out_pos,
                                        size_t dim,
                                        const graph::mfg_csr<IdxT>& mfg,
                                        AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(din, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(dout, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_mfg_n2n_bwd(
    get_ptr<FeatT>(din), get_ptr<FeatT>(dout), maybe_ptr<IdxT>(out_pos), dim, mfg, op, stream);
}

}  // namespace cugraph::ops::bind_torch

template <typename FeatT, typename IdxT>
void init_torch_agg_simple_fwd_bwd(nb::module_& m,
                                   const std::string& feat_str,
                                   const std::string& idx_str)
{
  std::string name_fwd = "agg_simple_mfg_fwd_" + feat_str + "_" + idx_str;
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::agg_simple_mfg_n2n_fwd_wrapped<FeatT, IdxT>,
        nb::arg("out"),
        nb::arg("out_pos").none(),
        nb::arg("in"),
        nb::arg("dim"),
        nb::arg("mfg"),
        nb::arg("op"));
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::agg_simple_mfg_n2n_fwd_csr_wrapped<FeatT, IdxT>,
        nb::arg("out"),
        nb::arg("out_pos").none(),
        nb::arg("in"),
        nb::arg("dim"),
        nb::arg("mfg"),
        nb::arg("op"));
  std::string name_bwd = "agg_simple_mfg_bwd_" + feat_str + "_" + idx_str;
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::agg_simple_mfg_n2n_bwd_wrapped<FeatT, IdxT>,
        nb::arg("din"),
        nb::arg("dout"),
        nb::arg("out_pos").none(),
        nb::arg("dim"),
        nb::arg("mfg"),
        nb::arg("op"));
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::agg_simple_mfg_n2n_bwd_csr_wrapped<FeatT, IdxT>,
        nb::arg("din"),
        nb::arg("dout"),
        nb::arg("out_pos").none(),
        nb::arg("dim"),
        nb::arg("mfg"),
        nb::arg("op"));
  std::string name_bwd_rev = "agg_simple_mfg_bwd_rev_" + feat_str + "_" + idx_str;
  m.def(name_bwd_rev.c_str(),
        &cugraph::ops::bind_torch::agg_simple_mfg_n2n_bwd_rev_wrapped<FeatT, IdxT>,
        nb::arg("din"),
        nb::arg("dout"),
        nb::arg("out_pos").none(),
        nb::arg("dim"),
        nb::arg("mfg"),
        nb::arg("mfg_rev"),
        nb::arg("op"));
}

void init_torch_agg_simple_mfg(nb::module_& m)
{
  init_torch_agg_simple_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_torch_agg_simple_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
