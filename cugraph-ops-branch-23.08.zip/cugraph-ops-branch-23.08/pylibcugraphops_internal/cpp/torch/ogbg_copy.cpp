/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/io/ogbg_reader.hpp>

#include <nanobind/nanobind.h>

#include <memory>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

class ogbg_torch {
 public:
  explicit ogbg_torch(const io::ogbg_cuda& data)
    : node_feat_dim(data.n_cols_nodes),
      edge_feat_dim(data.n_cols_edges),
      node_feat(at::from_blob(data.node_features,
                              {data.n_nodes, data.n_cols_nodes},
                              at::device(at::kCUDA).dtype(at::kFloat))),
      edge_feat(at::from_blob(data.edge_features,
                              {data.n_uniq_edges, data.n_cols_edges},
                              at::device(at::kCUDA).dtype(at::kFloat))),
      n_labels(data.n_labels),
      labels(at::from_blob(data.labels, {data.n_labels}, at::device(at::kCUDA).dtype(at::kInt))),
      graph(data.graph.get())
  {
  }

  int64_t node_feat_dim, edge_feat_dim;
  at::Tensor node_feat;
  at::Tensor edge_feat;

  int64_t n_labels;
  at::Tensor labels;
  fg_csr_seq_s64_t* graph;
};

const fg_csr_seq_s64_t& graph_wrapped(const ogbg_torch& t_data) { return *t_data.graph; }

}  // namespace cugraph::ops::bind_torch

void init_torch_ogbg_copy(nb::module_& m)
{
  nb::class_<cugraph::ops::bind_torch::ogbg_torch>(m, "OgbgTorch")
    .def(nb::init<const cugraph::ops::io::ogbg_cuda&>())
    .def_ro("node_feat_dim", &cugraph::ops::bind_torch::ogbg_torch::node_feat_dim)
    .def_ro("edge_feat_dim", &cugraph::ops::bind_torch::ogbg_torch::edge_feat_dim)
    .def_ro("node_feat", &cugraph::ops::bind_torch::ogbg_torch::node_feat)
    .def_ro("edge_feat", &cugraph::ops::bind_torch::ogbg_torch::edge_feat)
    .def_ro("n_labels", &cugraph::ops::bind_torch::ogbg_torch::n_labels)
    .def_ro("labels", &cugraph::ops::bind_torch::ogbg_torch::labels)
    .def_prop_ro("graph", &cugraph::ops::bind_torch::graph_wrapped);
}
