/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/bias_activation.hpp>
#include <cugraph-ops/dense.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

template <typename FeatT>
void dense_fwd_wrapped(std::optional<at::Tensor>& out,
                       at::Tensor& c,
                       int ldc,
                       const at::Tensor& a,
                       int lda,
                       const at::Tensor& b,
                       int ldb,
                       const std::optional<at::Tensor>& bias,
                       int m,
                       int n,
                       int k,
                       const cugraph::ops::activation_params& aparams,
                       std::optional<at::Tensor> drop_v,
                       FeatT p_drop,
                       raft::random::RngState* r,
                       const cuda::cublashandle& cublas)
{
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(c, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(a, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(b, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(bias, FeatT);
  // drop_v must be a long tensor, but we will get the pointer as unsigned long
  CUGRAPH_OPS_TORCH_CHECK_OPT_PINNED_TENSOR(drop_v, int64_t);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::dense_fwd(maybe_ptr<FeatT>(out),
                          get_ptr<FeatT>(c),
                          ldc,
                          get_ptr<FeatT>(a),
                          lda,
                          get_ptr<FeatT>(b),
                          ldb,
                          maybe_ptr<FeatT>(bias),
                          m,
                          n,
                          k,
                          aparams,
                          maybe_ptr<uint64_t>(drop_v),
                          p_drop,
                          r,
                          cublas,
                          stream);
}

template <typename FeatT>
void dense_bwd_wrapped(std::optional<at::Tensor>& da,
                       at::Tensor& db,
                       std::optional<at::Tensor>& dbias,
                       std::optional<at::Tensor>& dgrad,
                       const at::Tensor& dout,
                       const std::optional<at::Tensor>& out,
                       const at::Tensor& c,
                       int ldc,
                       const at::Tensor& a,
                       int lda,
                       const at::Tensor& b,
                       int ldb,
                       const std::optional<at::Tensor>& bias,
                       int m,
                       int n,
                       int k,
                       const cugraph::ops::activation_params& aparams,
                       const std::optional<at::Tensor>& drop_v,
                       FeatT p_drop,
                       const cuda::cublashandle& cublas)
{
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(da, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(db, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(dbias, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(dgrad, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(dout, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(c, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(a, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(b, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(bias, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_PINNED_TENSOR(drop_v, int64_t);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::dense_bwd(maybe_ptr<FeatT>(da),
                          get_ptr<FeatT>(db),
                          maybe_ptr<FeatT>(dbias),
                          maybe_ptr<FeatT>(dgrad),
                          get_ptr<FeatT>(dout),
                          maybe_ptr<FeatT>(out),
                          get_ptr<FeatT>(c),
                          ldc,
                          get_ptr<FeatT>(a),
                          lda,
                          get_ptr<FeatT>(b),
                          ldb,
                          maybe_ptr<FeatT>(bias),
                          m,
                          n,
                          k,
                          aparams,
                          maybe_ptr<uint64_t>(drop_v),
                          p_drop,
                          cublas,
                          stream);
}

template <typename FeatT>
void bias_act_fwd_wrapped(at::Tensor& out,
                          const at::Tensor& in,
                          const std::optional<at::Tensor>& bias,
                          int m,
                          int n,
                          int ld,
                          const cugraph::ops::activation_params& aparams,
                          std::optional<at::Tensor>& drop_v,
                          FeatT p_drop,
                          raft::random::RngState* r)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(bias, FeatT);
  // drop_v must be a long tensor, but we will get the pointer as unsigned long
  CUGRAPH_OPS_TORCH_CHECK_OPT_PINNED_TENSOR(drop_v, int64_t);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::bias_activation_fwd(get_ptr<FeatT>(out),
                                    get_ptr<FeatT>(in),
                                    maybe_ptr<FeatT>(bias),
                                    m,
                                    n,
                                    ld,
                                    aparams,
                                    maybe_ptr<uint64_t>(drop_v),
                                    p_drop,
                                    r,
                                    stream);
}

template <typename FeatT>
void bias_act_bwd_wrapped(at::Tensor& din,
                          std::optional<at::Tensor>& dbias,
                          const at::Tensor& dout,
                          const at::Tensor& out,
                          const at::Tensor& in,
                          const std::optional<at::Tensor>& bias,
                          int m,
                          int n,
                          int ld,
                          const cugraph::ops::activation_params& aparams,
                          const std::optional<at::Tensor>& drop_v,
                          FeatT p_drop)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(din, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(dbias, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(dout, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(bias, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_PINNED_TENSOR(drop_v, int64_t);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::bias_activation_bwd(get_ptr<FeatT>(din),
                                    maybe_ptr<FeatT>(dbias),
                                    get_ptr<FeatT>(dout),
                                    get_ptr<FeatT>(out),
                                    get_ptr<FeatT>(in),
                                    maybe_ptr<FeatT>(bias),
                                    m,
                                    n,
                                    ld,
                                    aparams,
                                    maybe_ptr<uint64_t>(drop_v),
                                    p_drop,
                                    stream);
}

}  // namespace cugraph::ops::bind_torch

template <typename FeatT>
void init_torch_dense_fwd_bwd(nb::module_& m, const std::string& type_str)
{
  std::string name_fwd = "dense_fwd_" + type_str;
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::dense_fwd_wrapped<FeatT>,
        nb::arg("out").none(),
        nb::arg("c"),
        nb::arg("ldc"),
        nb::arg("a"),
        nb::arg("lda"),
        nb::arg("b"),
        nb::arg("ldb"),
        nb::arg("bias").none(),
        nb::arg("m"),
        nb::arg("n"),
        nb::arg("k"),
        nb::arg("aparams"),
        nb::arg("drop_v").none(),
        nb::arg("p_drop"),
        nb::arg("r"),
        nb::arg("cublas"));
  std::string name_bwd = "dense_bwd_" + type_str;
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::dense_bwd_wrapped<FeatT>,
        nb::arg("da").none(),
        nb::arg("db"),
        nb::arg("dbias").none(),
        nb::arg("dgrad").none(),
        nb::arg("dout"),
        nb::arg("out").none(),
        nb::arg("c"),
        nb::arg("ldc"),
        nb::arg("a"),
        nb::arg("lda"),
        nb::arg("b"),
        nb::arg("ldb"),
        nb::arg("bias").none(),
        nb::arg("m"),
        nb::arg("n"),
        nb::arg("k"),
        nb::arg("aparams"),
        nb::arg("drop_v").none(),
        nb::arg("p_drop"),
        nb::arg("cublas"));

  std::string name_b_fwd = "bias_activation_fwd_" + type_str;
  m.def(name_b_fwd.c_str(),
        &cugraph::ops::bind_torch::bias_act_fwd_wrapped<FeatT>,
        nb::arg("out"),
        nb::arg("in"),
        nb::arg("bias").none(),
        nb::arg("m"),
        nb::arg("n"),
        nb::arg("ld"),
        nb::arg("aparams"),
        nb::arg("drop_v").none(),
        nb::arg("p_drop"),
        nb::arg("r"));
  std::string name_b_bwd = "bias_activation_bwd_" + type_str;
  m.def(name_b_bwd.c_str(),
        &cugraph::ops::bind_torch::bias_act_bwd_wrapped<FeatT>,
        nb::arg("din"),
        nb::arg("dbias").none(),
        nb::arg("dout"),
        nb::arg("out"),
        nb::arg("in"),
        nb::arg("bias").none(),
        nb::arg("m"),
        nb::arg("n"),
        nb::arg("ld"),
        nb::arg("aparams"),
        nb::arg("drop_v").none(),
        nb::arg("p_drop"));
}

void init_torch_dense(nb::module_& m) { init_torch_dense_fwd_bwd<float>(m, "float32"); }
