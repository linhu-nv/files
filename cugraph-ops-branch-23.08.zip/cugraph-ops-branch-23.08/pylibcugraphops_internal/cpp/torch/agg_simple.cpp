/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/agg_simple.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

// for now, we keep the interface with out_pos even though it's not used
// since it won't cost much if we provide None and we can always update
// it easily in the future
template <typename FeatT, typename IdxT, typename GraphT>
void agg_simple_fg_e2n_fwd_wrapped(at::Tensor& out,
                                   std::optional<at::Tensor>& out_pos,
                                   const at::Tensor& edge_feat,
                                   size_t dim_edge,
                                   const GraphT& fg,
                                   AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(edge_feat, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_fg_e2n_fwd(get_ptr<FeatT>(out),
                                      maybe_ptr<IdxT>(out_pos),
                                      get_ptr<FeatT>(edge_feat),
                                      dim_edge,
                                      fg,
                                      op,
                                      stream);
}

template <typename FeatT, typename IdxT, typename GraphT>
void agg_simple_fg_e2n_bwd_wrapped(at::Tensor& d_edge_feat,
                                   const at::Tensor& d_out,
                                   const std::optional<at::Tensor>& out_pos,
                                   size_t dim_edge,
                                   const GraphT& fg,
                                   AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(d_edge_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(d_out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::agg_simple_fg_e2n_bwd(get_ptr<FeatT>(d_edge_feat),
                                      get_ptr<FeatT>(d_out),
                                      maybe_ptr<IdxT>(out_pos),
                                      dim_edge,
                                      fg,
                                      op,
                                      stream);
}

}  // namespace cugraph::ops::bind_torch

template <typename FeatT, typename IdxT>
void init_torch_agg_simple_fwd_bwd(nb::module_& m,
                                   const std::string& feat_str,
                                   const std::string& idx_str)
{
  std::string name_fwd = "agg_simple_fg_e2n_fwd_" + feat_str + "_" + idx_str;
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_simple_fg_e2n_fwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr<IdxT>>,
        nb::arg("out"),
        nb::arg("out_pos").none(),
        nb::arg("edge_feat"),
        nb::arg("dim_edge"),
        nb::arg("fg"),
        nb::arg("op"));
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_simple_fg_e2n_fwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr_batch<IdxT>>,
        nb::arg("out"),
        nb::arg("out_pos").none(),
        nb::arg("edge_feat"),
        nb::arg("dim_edge"),
        nb::arg("fg"),
        nb::arg("op"));
  std::string name_bwd = "agg_simple_fg_e2n_bwd_" + feat_str + "_" + idx_str;
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_simple_fg_e2n_bwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr<IdxT>>,
        nb::arg("d_edge_feat"),
        nb::arg("d_out"),
        nb::arg("out_pos").none(),
        nb::arg("dim_edge"),
        nb::arg("fg"),
        nb::arg("op"));
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_simple_fg_e2n_bwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr_batch<IdxT>>,
        nb::arg("d_edge_feat"),
        nb::arg("d_out"),
        nb::arg("out_pos").none(),
        nb::arg("dim_edge"),
        nb::arg("fg"),
        nb::arg("op"));
}

void init_torch_agg_simple_fg(nb::module_& m)
{
  init_torch_agg_simple_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_torch_agg_simple_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
