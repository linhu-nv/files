/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/cuda/stream.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

cuda::stream get_current_stream() { return {c10::cuda::getCurrentCUDAStream()}; }

}  // namespace cugraph::ops::bind_torch

void init_torch_utils(nb::module_& m)
{
  m.def("get_current_stream", &cugraph::ops::bind_torch::get_current_stream);
}
