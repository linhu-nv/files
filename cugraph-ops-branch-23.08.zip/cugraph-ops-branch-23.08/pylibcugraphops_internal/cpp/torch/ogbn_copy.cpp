/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/io/ogbn_reader.hpp>

#include <nanobind/nanobind.h>

#include <memory>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

class ogbn_torch {
 public:
  explicit ogbn_torch(const io::ogbn_cuda& data)
    : n_cols(data.n_cols),
      features(at::from_blob(
        data.features, {data.n_nodes, data.n_cols}, at::device(at::kCUDA).dtype(at::kFloat))),
      labels(at::from_blob(data.labels, {data.n_labels}, at::device(at::kCUDA).dtype(at::kInt))),
      n_labels(data.n_labels),
      graph(data.graph.get())
  {
  }

  int64_t n_cols;
  at::Tensor features;
  at::Tensor labels;

  int64_t n_labels;
  fg_csr_s64_t* graph;
};

const fg_csr_s64_t& graph_wrapped(const ogbn_torch& t_data) { return *t_data.graph; }

}  // namespace cugraph::ops::bind_torch

void init_torch_ogbn_copy(nb::module_& m)
{
  nb::class_<cugraph::ops::bind_torch::ogbn_torch>(m, "OgbnTorch")
    .def(nb::init<const cugraph::ops::io::ogbn_cuda&>())
    .def_ro("n_cols", &cugraph::ops::bind_torch::ogbn_torch::n_cols)
    .def_ro("n_labels", &cugraph::ops::bind_torch::ogbn_torch::n_labels)
    .def_ro("features", &cugraph::ops::bind_torch::ogbn_torch::features)
    .def_ro("labels", &cugraph::ops::bind_torch::ogbn_torch::labels)
    .def_prop_ro("graph", &cugraph::ops::bind_torch::graph_wrapped);
}
