/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/agg_dmpnn.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

template <typename FeatT, typename IdxT, typename GraphT>
void agg_dmpnn_fg_e2e_fwd_wrapped(at::Tensor& out_edge_feat,
                                  const at::Tensor& in_edge_feat,
                                  size_t dim_edge,
                                  const GraphT& fg,
                                  bool concat_own)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out_edge_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(in_edge_feat, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  // for now, we only use the specialization without edge feature index
  cugraph::ops::agg_dmpnn_fg_e2e_fwd(
    get_ptr<FeatT>(out_edge_feat), get_ptr<FeatT>(in_edge_feat), dim_edge, fg, concat_own, stream);
}

template <typename FeatT, typename IdxT, typename GraphT>
void agg_dmpnn_fg_e2e_bwd_wrapped(at::Tensor& d_in_edge_feat,
                                  const at::Tensor& d_out_edge_feat,
                                  size_t dim_edge,
                                  const GraphT& fg,
                                  bool concat_own)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(d_in_edge_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(d_out_edge_feat, FeatT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  // for now, we only use the specialization without edge feature index
  cugraph::ops::agg_dmpnn_fg_e2e_bwd(get_ptr<FeatT>(d_in_edge_feat),
                                     get_ptr<FeatT>(d_out_edge_feat),
                                     dim_edge,
                                     fg,
                                     concat_own,
                                     stream);
}

}  // namespace cugraph::ops::bind_torch

template <typename FeatT, typename IdxT>
void init_torch_agg_dmpnn_fwd_bwd(nb::module_& m,
                                  const std::string& feat_str,
                                  const std::string& idx_str)
{
  std::string name_dmpnn_fwd = "agg_dmpnn_fg_e2e_fwd_" + feat_str + "_" + idx_str;
  m.def(name_dmpnn_fwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_dmpnn_fg_e2e_fwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr<IdxT>>);
  m.def(name_dmpnn_fwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_dmpnn_fg_e2e_fwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr_batch<IdxT>>);
  std::string name_dmpnn_bwd = "agg_dmpnn_fg_e2e_bwd_" + feat_str + "_" + idx_str;
  m.def(name_dmpnn_bwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_dmpnn_fg_e2e_bwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr<IdxT>>);
  m.def(name_dmpnn_bwd.c_str(),
        &cugraph::ops::bind_torch::
          agg_dmpnn_fg_e2e_bwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr_batch<IdxT>>);
}

void init_torch_agg_dmpnn_fg(nb::module_& m)
{
  init_torch_agg_dmpnn_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_torch_agg_dmpnn_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
