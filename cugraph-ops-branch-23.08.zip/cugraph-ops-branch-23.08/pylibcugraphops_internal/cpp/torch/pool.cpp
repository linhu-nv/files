/*
 * Copyright (c) 2021-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "torch_utils.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/pool.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::bind_torch {

template <typename FeatT, typename IdxT>
int64_t pool_fg_n2s_fwd_get_w_size(size_t dim_node, IdxT batch_size, AggOpT op, bool use_atomics)
{
  FeatT* f_null = nullptr;
  IdxT* i_null  = nullptr;
  auto w_size   = int64_t{-1};
  // here we fake the graph, we only need the type and batch size!
  if (batch_size <= 0) {
    cugraph::ops::graph::fg_csr<IdxT> fg;
    cugraph::ops::pool_fg_n2s_fwd(
      f_null, i_null, f_null, dim_node, fg, op, use_atomics, nullptr, w_size, nullptr);
  } else {
    cugraph::ops::graph::fg_csr_seq<IdxT> fg_seq;
    cugraph::ops::graph::fg_csr_batch<IdxT> fg_batch(fg_seq);
    fg_batch.batch_size = batch_size;
    cugraph::ops::pool_fg_n2s_fwd(
      f_null, i_null, f_null, dim_node, fg_batch, op, use_atomics, nullptr, w_size, nullptr);
  }
  return w_size;
}

template <typename FeatT, typename IdxT, typename GraphT>
void pool_fg_n2s_fwd_wrapped(at::Tensor& out,
                             std::optional<at::Tensor>& out_pos,
                             const at::Tensor& node_feat,
                             size_t dim_node,
                             const GraphT& fg,
                             AggOpT op,
                             bool use_atomics,
                             std::optional<at::Tensor>& workspace)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(node_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(workspace, int64_t);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  // we assume that workspace is large enough here, so we simply set size to 0
  int64_t w_size{0};
  cugraph::ops::pool_fg_n2s_fwd(get_ptr<FeatT>(out),
                                maybe_ptr<IdxT>(out_pos),
                                get_ptr<FeatT>(node_feat),
                                dim_node,
                                fg,
                                op,
                                use_atomics,
                                maybe_ptr<int64_t>(workspace),
                                w_size,
                                stream);
}

template <typename FeatT, typename IdxT, typename GraphT>
void pool_fg_n2s_bwd_wrapped(at::Tensor& d_node_feat,
                             const at::Tensor& d_out,
                             const std::optional<at::Tensor>& out_pos,
                             size_t dim_node,
                             const GraphT& fg,
                             AggOpT op)
{
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(d_node_feat, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_TENSOR(d_out, FeatT);
  CUGRAPH_OPS_TORCH_CHECK_OPT_TENSOR(out_pos, IdxT);
  cuda::stream stream(c10::cuda::getCurrentCUDAStream());
  cugraph::ops::pool_fg_n2s_bwd(get_ptr<FeatT>(d_node_feat),
                                get_ptr<FeatT>(d_out),
                                maybe_ptr<IdxT>(out_pos),
                                dim_node,
                                fg,
                                op,
                                stream);
}

}  // namespace cugraph::ops::bind_torch

template <typename FeatT, typename IdxT>
void init_torch_pool_fg_n2s_fwd_bwd(nb::module_& m,
                                    const std::string& feat_str,
                                    const std::string& idx_str)
{
  std::string name_size = "pool_fg_n2s_fwd_get_w_size_" + feat_str + "_" + idx_str;
  m.def(name_size.c_str(), &cugraph::ops::bind_torch::pool_fg_n2s_fwd_get_w_size<FeatT, IdxT>);
  std::string name_fwd = "pool_fg_n2s_fwd_" + feat_str + "_" + idx_str;
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::
          pool_fg_n2s_fwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr<IdxT>>,
        nb::arg("out"),
        nb::arg("out_pos").none(),
        nb::arg("node_feat"),
        nb::arg("dim_node"),
        nb::arg("fg"),
        nb::arg("op"),
        nb::arg("use_atomics"),
        nb::arg("workspace").none());
  m.def(name_fwd.c_str(),
        &cugraph::ops::bind_torch::
          pool_fg_n2s_fwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr_batch<IdxT>>,
        nb::arg("out"),
        nb::arg("out_pos").none(),
        nb::arg("node_feat"),
        nb::arg("dim_node"),
        nb::arg("fg"),
        nb::arg("op"),
        nb::arg("use_atomics"),
        nb::arg("workspace").none());
  std::string name_bwd = "pool_fg_n2s_bwd_" + feat_str + "_" + idx_str;
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::
          pool_fg_n2s_bwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr<IdxT>>,
        nb::arg("d_node_feat"),
        nb::arg("d_out"),
        nb::arg("out_pos").none(),
        nb::arg("dim_node"),
        nb::arg("fg"),
        nb::arg("op"));
  m.def(name_bwd.c_str(),
        &cugraph::ops::bind_torch::
          pool_fg_n2s_bwd_wrapped<FeatT, IdxT, cugraph::ops::graph::fg_csr_batch<IdxT>>,
        nb::arg("d_node_feat"),
        nb::arg("d_out"),
        nb::arg("out_pos").none(),
        nb::arg("dim_node"),
        nb::arg("fg"),
        nb::arg("op"));
}

void init_torch_pool_fg(nb::module_& m)
{
  init_torch_pool_fg_n2s_fwd_bwd<float, int32_t>(m, "float32", "int32");
  init_torch_pool_fg_n2s_fwd_bwd<float, int64_t>(m, "float32", "int64");
}
