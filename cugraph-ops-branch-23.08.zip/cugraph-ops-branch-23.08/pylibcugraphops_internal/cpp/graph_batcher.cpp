/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "buffer.hpp"

#include <cugraph-ops/graph_batcher.hpp>

#include <nanobind/nanobind.h>

namespace nb = nanobind;

template <typename ClassT, typename IdxT>
void init_graph_batcher_impl(nb::module_& m, const char* name)
{
  auto ns_class = nb::class_<ClassT>(m, name)
                    .def(nb::init<cugraph::ops::graph::fg_csr_seq<IdxT>&,
                                  IdxT,
                                  bool,
                                  raft::random::RngState&,
                                  const cugraph::ops::cuda::stream&>())
                    .def("reset", &ClassT::reset)
                    .def("next_batch", &ClassT::next_batch)
                    .def("curr_batch", &ClassT::curr_batch)
                    .def("num_batches", &ClassT::num_batches)
                    .def("get_stream", &ClassT::get_stream)
                    .def("max_batch_size", &ClassT::max_batch_size);
}

void init_graph_batcher(nb::module_& m)
{
  init_graph_batcher_impl<cugraph::ops::graph_batcher<int64_t>, int64_t>(m, "graph_batcher_int64");
  init_graph_batcher_impl<cugraph::ops::graph_batcher<int32_t>, int32_t>(m, "graph_batcher_int32");
}
