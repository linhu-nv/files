# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class RunningAvg(object):

    """
    Simple helper class to keep track of a running average.
    """

    def __init__(self, initial_values=None):
        self.reset()
        self.add(initial_values)

    def reset(self):
        self._avg = 0.
        self._w = 0.

    def _add(self, value, weight):
        if value is None or weight is None:
            return
        new_weight = self._w + weight
        self._avg = (self._avg * self._w + value * weight) / new_weight
        self._w = new_weight

    def add(self, value, weight=1.):
        try:
            for v, w in zip(value, weight):
                self._add(v, w)
        except TypeError:
            try:
                for v in zip(value):
                    self._add(v, weight)
            except TypeError:
                self._add(value, weight)

    def get(self):
        return self._avg
