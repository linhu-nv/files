# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops
import pylibcugraphops_internal_ext as internal_ext

import typing

from .named_object import NamedObject
from .buffer import null_wrapper, make_host_buffer, make_device_buffer
from .running_avg import RunningAvg

DATA_TYPE_SIZES = {
    'char': 1,
    'int8': 1,
    'uint8': 1,
    'int16': 2,
    'uint16': 2,
    'int32': 4,
    'uint32': 4,
    'int64': 8,
    'uint64': 8,
    'float16': 2,
    'float32': 4,
    'float64': 8,
}

__all__ = [
    'NamedObject',
    'null_wrapper',
    'make_host_buffer',
    'make_device_buffer',
    'RunningAvg',
    'DATA_TYPE_SIZES'
]


# declare some types for type annotations
def _get_ops_attr(
    filter: typing.Callable[[str], bool], submodule: str = "", internal = True
) -> typing.List[typing.Type]:
    if submodule and internal:
        m = getattr(internal_ext, submodule)
    elif submodule:
        m = getattr(pylibcugraphops, submodule)
    elif internal:
        m = internal_ext
    else:
        m = pylibcugraphops
    return [getattr(m, x) for x in dir(m) if filter(x)]


ArrayWrapper = typing.TypeVar(
    "ArrayWrapper", *_get_ops_attr(lambda x: "ArrayWrapper_" in x)
)

ArrayWrapperAnyInt = typing.TypeVar(
    "ArrayWrapperAnyInt", *_get_ops_attr(
        lambda x: "ArrayWrapper_" in x and ("char" in x or "int" in x))
)

ArrayWrapperInt = typing.TypeVar(
    "ArrayWrapperInt", *_get_ops_attr(
        lambda x: x == "ArrayWrapper_int32" or x == "ArrayWrapper_int64")
)

ArrayWrapperFloat = typing.TypeVar(
    "ArrayWrapperFloat", *_get_ops_attr(
        lambda x: "ArrayWrapper_" in x and "float" in x)
)

NodeBatcher = typing.TypeVar("NodeBatcher", *_get_ops_attr(
    lambda x: "node_batcher_" in x)
)

MfgAny = typing.TypeVar("MfgAny", *_get_ops_attr(
    lambda x: "mfg_" in x, internal=False)
)

MfgCsr = typing.TypeVar("MfgCsr", *_get_ops_attr(
    lambda x: "mfg_csr_" in x and "_rev_" not in x and "_hg_" not in x,
    internal=False)
)

MfgEllpack = typing.TypeVar("MfgEllpack", *_get_ops_attr(
    lambda x: "mfg_ellpack_" in x and "_rev_" not in x and "_hg_" not in x,
    internal=False)
)

MfgEllpackHg = typing.TypeVar("MfgEllpackHg", *_get_ops_attr(
    lambda x: "mfg_ellpack_" in x and "_rev_" not in x and "_hg_" in x,
    internal=False)
)

FullGraphAny = typing.TypeVar("FullGraphAny", *_get_ops_attr(
    lambda x: "fg_" in x, internal=False)
)

FullGraphAnyNonHg = typing.TypeVar("FullGraphAnyNonHg", *_get_ops_attr(
    lambda x: "fg_" in x and "_hg_" not in x, internal=False)
)

FullGraphSimple = typing.TypeVar("FullGraphSimple", *_get_ops_attr(
    lambda x: "fg_" in x and "_hg_" not in x and "_batch_" not in x
    and "_seq_" not in x, internal=False)
)

FullGraphHg = typing.TypeVar("FullGraphHg", *_get_ops_attr(
    lambda x: "fg_" in x and "_hg_" in x, internal=False)
)

FullGraphBatch = typing.TypeVar("FullGraphBatch", *_get_ops_attr(
    lambda x: "fg_" in x and "_batch_" in x, internal=False)
)

FullGraphSeq = typing.TypeVar("FullGraphSeq", *_get_ops_attr(
    lambda x: "fg_" in x and "_seq_" in x, internal=False)
)

GraphBatcher = typing.TypeVar("GraphBatcher", *_get_ops_attr(
    lambda x: "graph_batcher_" in x)
)

ActivationOp = pylibcugraphops.ActivationOp

AggregationOp = pylibcugraphops.operators.AggOp

RngState = internal_ext.rng_state

CublasHandle = internal_ext.cuda.cublashandle

MMAOp = pylibcugraphops.MMAOp
