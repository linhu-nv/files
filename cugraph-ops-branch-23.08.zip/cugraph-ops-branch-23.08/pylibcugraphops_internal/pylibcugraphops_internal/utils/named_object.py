# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections import defaultdict


class NamedObject(object):

    """
    Simple base class for named objects used for reporting / debugging.
    """

    def __init__(self, name):
        self.name = name or self._get_default_name()

    # used to keep track of classes used for default name
    _name_count = defaultdict(int)

    @classmethod
    def _get_default_name(cls):
        NamedObject._name_count[cls.__name__] += 1
        return cls.__name__ + str(NamedObject._name_count[cls.__name__])
