# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import pylibcugraphops_internal_ext as internal_ext
from pylibcugraphops_internal.utils import ActivationOp
from pylibcugraphops.operators import activation_params

from . import BufferedLayer, Layer
from ..utils import make_host_buffer, null_wrapper


class DenseLayer(BufferedLayer):

    """
    Implements a generic linear layer, assuming dense input/output features.
    """

    def __init__(self, out_feats, in_feats, n_support, stream, cublas, rng,
                 activation=None, dropout=None, use_bias=None,
                 init_w=None, init_b=None, previous_layer=None,
                 previous_output=None, name=None, dtype='float32'):
        """
        Parameters
        ----------

        out_feats: int
            Number of output features of this layer.
        in_feats: int
            Number of input features of this layer.
        n_support: int
            Number of feature vectors in the input and output.
        stream: internal_ext.cuda.stream
            The stream handle used for this layer.
        cublas: internal_ext.cuda.cublashandle
            The cublas handle used for this layer.
        rng: internal_ext.rng
            The random number generator used for initializing weights.
        activation: pylibcugraphops.operators.activation_params | None
            The activation type and optional param. If None, no activation.
        dropout: float | None
            Optional dropout probability. Applied after activation.
            Random number generator is the same as for intializing weights.
        use_bias: bool | None
            Apply a bias after linear layer. By default, True.
        init_w: (int, float, bool) | None
            The fan, gain and type of initialization for weights.
            By default, (in_feats, sqrt(2), False) which corresponds to
            `kaiming_uniform` initialization with a gain of sqrt(2).
            Note that this is not Pytorch's default initialization which is
            `kaiming_uniform` with a gain of 1 / sqrt(3).
            The bool indicates whether to use normal initialization
            (uniform if False).
        init_b: (int, float, bool) | None
            The fan, gain and type of initialization used for bias.
            By default, (in_feats, 1 / sqrt(3), False) which corresponds to
            `kaiming_uniform` initialization with gain of 1 / sqrt(3): the
            default initialization for bias in Pytorch.
            The bool indicates whether to use normal initialization
            (uniform if False).
        previous_layer: pylibcugraphops_internal.layers.Layer | None
            A previous layer if there is one.
        previous_output: int
            Index of the output of previous layer to be used as input.
        name: string
            Name of the layer for debug/reporting purposes.
            If None, a default name (DenseLayer{x}) is given.
        dtype: string
            The data type used for inputs/outputs of this layer
        """
        super(DenseLayer, self).__init__(
            name, dict(), dict(), dict(), dict(), [], stream, dtype)
        self.out_feats = out_feats
        self.in_feats = in_feats
        self.n_support = n_support
        self.stream = stream
        self.cublas = cublas
        self.rng = rng

        self.activation = activation or activation_params()
        dropout = dropout or 0.
        assert 0 <= dropout <= 1, "Dropout must be None or in [0, 1]"
        self.dropout = dropout

        self.use_bias = (use_bias is None) or bool(use_bias)
        init_w = init_w or (self.in_feats, math.sqrt(2), False)
        self.init_w_fan, self.init_w_gain, self.init_w_normal = init_w
        init_b = init_b or (self.in_feats, 1. / math.sqrt(3), False)
        self.init_b_fan, self.init_b_gain, self.init_b_normal = init_b

        self.previous_layer = previous_layer
        self.previous_output = previous_output or 0

        self.dense_fwd = getattr(internal_ext.layers, f"dense_fwd_{self.dtype}")
        self.dense_bwd = getattr(internal_ext.layers, f"dense_bwd_{self.dtype}")

        # first buffer is where forward inputs are placed
        if isinstance(previous_layer, Layer):
            b = previous_layer.get_output_buffers()
            self.fwd_inputs['fc_in'] = b[self.previous_output]
        else:
            # will be overwritten by user
            self.fwd_inputs['fc_in'] = None
        self._inputs = [self.fwd_inputs['fc_in']]

        self._add_buffer('in', self.out_feats * self.in_feats, 'fc_w')
        if self.use_bias:
            self._add_buffer('in', self.out_feats, 'fc_b')
        else:
            self.fwd_inputs['fc_b'] = null_wrapper(self.dtype)
        self._add_buffer('out', self.n_support * self.out_feats, 'fc_out')
        linear = ActivationOp.Linear
        if (self.use_bias or self.dropout > 0 or
                self.activation.type != linear):
            self._add_buffer('out', self.n_support * self.out_feats, 'fc_int')
            self._outputs = [self.fwd_outputs['fc_out']]
        else:
            self.fwd_outputs['fc_int'] = self.fwd_outputs['fc_out']
            self.fwd_outputs['fc_out'] = null_wrapper(self.dtype)
            self._outputs = [self.fwd_outputs['fc_int']]

        # require an additional buffer for dropout values
        if self.dropout <= 0:
            self.fwd_outputs['fc_drop'] = null_wrapper('uint64')
        else:
            self.fwd_outputs['fc_drop'] = make_host_buffer(
                2, 'uint64', self.stream)

        # buffers for backward of linear layer
        # we can re-use the same buffer for data gradient as input of linear
        if isinstance(previous_layer, Layer):
            b = previous_layer.get_grad_input_buffers()
            self.bwd_outputs['fc_gin'] = b[self.previous_output]
        else:
            self.bwd_outputs['fc_gin'] = null_wrapper(self.dtype)
        if (self.use_bias or self.dropout > 0 or
                self.activation.type != linear):
            self.bwd_outputs['fc_gint'] = self.fwd_outputs['fc_int']
        else:
            self.bwd_outputs['fc_gint'] = null_wrapper(self.dtype)
        self._add_buffer(
            'bwd_out', self.out_feats * self.in_feats, 'fc_gw')
        if self.use_bias:
            self._add_buffer('bwd_out', self.out_feats, 'fc_gb')
        else:
            self.bwd_outputs['fc_gb'] = null_wrapper(self.dtype)
        # this is where backward gradients are placed
        self._add_buffer(
            'bwd_in', self.n_support * self.out_feats, 'g_fc_out')
        self._g_inputs = [self.bwd_inputs['g_fc_out']]

        # initialize weights and bias
        init_w = getattr(internal_ext.layers, f"init_weights_{self.dtype}")
        init_w(
            w=self.fwd_inputs['fc_w'], n=self.out_feats * self.in_feats,
            n_fan=self.init_w_fan, gain=self.init_w_gain,
            is_normal=self.init_w_normal, rng=self.rng, stream=self.stream)
        if self.use_bias:
            init_w(
                w=self.fwd_inputs['fc_b'], n=self.out_feats,
                n_fan=self.init_b_fan, gain=self.init_b_gain,
                is_normal=self.init_b_normal, rng=self.rng, stream=self.stream)

    def _get_weight_buffers(self):
        w = [self.fwd_inputs['fc_w']]
        if self.use_bias:
            w += [self.fwd_inputs['fc_b']]
        return w

    def _get_grad_buffers(self):
        g = [self.bwd_outputs['fc_gw']]
        if self.use_bias:
            g += [self.bwd_outputs['fc_gb']]
        return g

    def get_input_buffers(self):
        return self._inputs

    def get_output_buffers(self):
        return self._outputs

    def get_grad_input_buffers(self):
        return self._g_inputs

    def fwd_impl(self):
        if self.previous_layer is None and self.get_input_buffers()[0] is None:
            raise ValueError(
                "Please provide an input for the initial layer as "
                "an `ArrayWrapper` in `layer.get_input_buffers()[0]`")
        self.dense_fwd(
            self.fwd_outputs['fc_out'], self.fwd_outputs['fc_int'],
            self.out_feats, self.fwd_inputs['fc_in'], self.in_feats,
            self.fwd_inputs['fc_w'], self.in_feats,
            self.fwd_inputs['fc_b'], self.n_support, self.out_feats,
            self.in_feats, self.activation, self.fwd_outputs['fc_drop'],
            self.dropout, self.rng, self.cublas, self.stream
        )

    def bwd_impl(self):
        self.dense_bwd(
            self.bwd_outputs['fc_gin'], self.bwd_outputs['fc_gw'],
            self.bwd_outputs['fc_gb'], self.bwd_outputs['fc_gint'],
            self.bwd_inputs['g_fc_out'], self.fwd_outputs['fc_out'],
            self.fwd_outputs['fc_int'], self.out_feats,
            self.fwd_inputs['fc_in'], self.in_feats,
            self.fwd_inputs['fc_w'], self.in_feats,
            self.fwd_inputs['fc_b'], self.n_support, self.out_feats,
            self.in_feats, self.activation, self.fwd_outputs['fc_drop'],
            self.dropout, self.cublas, self.stream
        )
