# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

from . import Layer
from ..utils import make_device_buffer, make_host_buffer, null_wrapper


class SoftmaxCE(Layer):

    """
    Implements a row-wise softmax cross entropy loss.

    We assume that the previous layer has its activations in
    `get_output_buffers()[0]` and requires gradients in
    `get_grad_input_buffers()[0]`
    """

    def __init__(self, previous_layer, labels, cudnn, pre_compute=False,
                 epsilon=1e-8, name=None):
        """
        Parameters
        ----------

        previous_layer: Layer
            The previous layer.
            We expect the following fields to be set on this layer:
            "dtype", "n_max_out", "out_feats", "stream",
            "node_batcher", "idx_type". We also expect a single output.
        labels: ArrayWrapper
            The full graph node labels
        cudnn: internal_ext.cuda.cudnnhandle
            The cudnn handle used for this layer
        pre_compute: bool
            If True, pre compute loss values and accuracy.
        epsilon: float
            Smoothing parameter used for numerical stability
        name: string
            Name of the layer for debug/reporting purposes.
            If None, a default name (SoftmaxCE{x}) is given.
        """
        super(SoftmaxCE, self).__init__(name, dict(), dict(), dict(), dict())
        self.previous_layer = previous_layer
        self.n_out = previous_layer.n_max_out
        self.feats = previous_layer.out_feats
        self.dtype = previous_layer.dtype
        self.stream = previous_layer.stream
        self.loss_in = previous_layer.get_output_buffers()[0]
        self.g_out = previous_layer.get_grad_input_buffers()[0]
        self.node_batcher = previous_layer.node_batcher
        self.labels = labels
        self.epsilon = epsilon
        self.cudnn = cudnn

        self.labels_type = self.labels.__class__.__name__.split("_")[-1]
        self.fwd_inputs['batch_labels'] = make_device_buffer(
            self.n_out, self.labels_type, self.stream)
        self.fwd_outputs['final_loss'] = make_host_buffer(
            1, self.dtype, self.stream)
        self.pre_compute = pre_compute
        self.fwd_outputs['acc_count'] = make_host_buffer(
            1, 'int32', self.stream)

        self.loss_fn = getattr(
            internal_ext.layers, f"softmax_ce_by_row_{self.dtype}")
        self.gather = getattr(
            internal_ext.layers,
            f"gather_{self.labels_type}_{previous_layer.idx_type}")

        self.rows = None
        self.with_grad = None

        self._inputs = [self.loss_in]
        self._g_inputs = [self.g_out]

    def get_input_buffers(self):
        return self._inputs

    def get_output_buffers(self):
        return []

    def get_grad_input_buffers(self):
        return self._g_inputs

    def _fwd_impl(self, with_grad=True):
        # first get the layer info and gather labels
        batch_info = self.node_batcher.curr_batch()
        self.rows = batch_info.curr_size
        self.with_grad = with_grad
        self.gather(self.fwd_inputs['batch_labels'], self.labels,
                    batch_info.batch, 1, self.rows, self.stream)

        if self.pre_compute:
            loss_buffer = self.fwd_outputs['final_loss']
            acc_buffer = self.fwd_outputs['acc_count']
        else:
            loss_buffer = null_wrapper(self.dtype)
            acc_buffer = null_wrapper('int32')
        self.loss_fn(
            loss_buffer, acc_buffer, self.g_out, self.loss_in,
            self.fwd_inputs['batch_labels'], self.rows, self.feats,
            self.epsilon, with_grad, self.cudnn, self.stream)

    def fwd_impl(self):
        self._fwd_impl()

    def bwd_impl(self):
        # this is already done on forward in this layer
        pass

    def fwd_inference_impl(self):
        # no need for gradient here
        self._fwd_impl(False)

    def compute_final_values(self):
        if self.rows is None:
            raise ValueError(
                "Must call forward before compute_final_values for loss")
        # here we simply recalculate the softmax/gradients
        # this isn't ideal but one can simply use pre_compute to avoid this
        self.loss_fn(
            self.fwd_outputs['final_loss'], self.fwd_outputs['acc_count'],
            self.g_out, self.loss_in, self.fwd_inputs['batch_labels'],
            self.rows, self.feats, self.epsilon, self.with_grad, self.cudnn,
            self.stream)

    def get_final_values(self):
        if not self.pre_compute:
            self.compute_final_values()
        # we need to synchronize to be sure the loss was calculated
        self.stream.sync()
        # this works because HostBuffer has __getitem__ implemented
        # (for simple indices)
        final_acc = float(self.fwd_outputs['acc_count'][0]) / self.rows
        return self.fwd_outputs['final_loss'][0], final_acc
