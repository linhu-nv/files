# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

from ..utils import NamedObject, make_device_buffer, DATA_TYPE_SIZES


class Layer(NamedObject):

    """
    Abstract base class for all GNN layers.
    """

    def __init__(self, name, fwd_inputs, fwd_outputs, bwd_inputs, bwd_outputs,
                 workspaces=[]):
        """
        Parameters
        ----------

        name: string
            Name of the layer for debug/reporting purposes.
        fwd_inputs: dict
            List of inputs during fwd pass.
        fwd_outputs: dict
            List of outputs during fwd pass.
        bwd_inputs: dict
            List of inputs during bwd pass.
        bwd_outputs: dict
           List of outputs during bwd pass.
        workspaces: list (default = [])
            List of any temporary scratch buffers for fwd/bwd pass.
        """
        super(Layer, self).__init__(name)
        self.fwd_inputs = fwd_inputs
        self.fwd_outputs = fwd_outputs
        self.bwd_inputs = bwd_inputs
        self.bwd_outputs = bwd_outputs
        self.workspaces = workspaces
        self.children = []

    def is_leaf(self):
        return len(self.children) <= 0

    def _get_first_last(self, is_first, depth=0):
        if self.is_leaf() and depth == 0:
            raise ValueError("This layer does not have any children")
        if self.is_leaf():
            return self
        idx = 0 if is_first else -1
        child = self.children[idx]
        return child._get_first_last(is_first, depth=depth + 1)

    def get_first(self):
        return self._get_first_last(True)

    def get_last(self):
        return self._get_first_last(False)

    @staticmethod
    def _from_previous(value, previous_layer, name, prev_name=None):
        if value is not None:
            return value
        assert previous_layer is not None,\
            f"previous_layer required if {name} is None"
        return getattr(previous_layer, prev_name or name)

    def _get_weight_buffers(self):
        return []

    def _get_grad_buffers(self):
        return []

    def iter_layers(self):
        yield self
        for c in self.children:
            for c2 in c.iter_layers():
                yield c2

    def iter_leaf_layers(self):
        if self.is_leaf():
            yield self
        for c in self.children:
            for c2 in c.iter_leaf_layers():
                yield c2

    def iter_weights(self):
        for c in self.iter_layers():
            for w in c._get_weight_buffers():
                yield w

    def iter_grads(self):
        for c in self.iter_layers():
            for g in c._get_grad_buffers():
                yield g

    def fwd(self):
        internal_ext.utils.push_range(self.name + "::fwd")
        self.fwd_impl()
        internal_ext.utils.pop_range()

    def fwd_inference(self):
        internal_ext.utils.push_range(self.name + "::fwd_inference")
        self.fwd_inference_impl()
        internal_ext.utils.pop_range()

    def bwd(self):
        internal_ext.utils.push_range(self.name + "::bwd")
        self.bwd_impl()
        internal_ext.utils.pop_range()

    def get_input_buffers(self):
        """
        Child class is expected to provide all buffers required from previous
        layers or user here. These are not allocated by the layer!
        """
        raise NotImplementedError

    def get_output_buffers(self):
        """
        Child class is expected to provide all buffers which this layer
        allocated, and can be used by subsequent layers as inputs.
        """
        raise NotImplementedError

    def get_grad_input_buffers(self):
        """
        Child class is expected to provide all buffers which this layer
        allocated and requires as input for gradient calculation.
        """
        raise NotImplementedError

    def fwd_impl(self):
        """
        Child class is expected to overwrite this and implement the fwd pass
        logic. It may make appropriate use of `fwd_inputs` and `fwd_outputs`.
        """
        raise NotImplementedError("fwd_impl to be provided by the child class")

    def fwd_inference_impl(self):
        """
        A special path kept for inference-only cases of GNNs. By default it
        falls back to the `fwd_impl`, but for special cases child classes are
        free to overwrite this as needed.
        """
        self.fwd_impl()

    def bwd_impl(self):
        """
        Child class is expected to overwrite this and implement the fwd pass
        logic. It may make appropriate use of `fwd_inputs` and `fwd_outputs` as
        well as `bwd_inputs` and `bwd_outputs`.
        """
        raise NotImplementedError("bwd_impl to be provided by the child class")


class BufferedLayer(Layer):
    """
    Abstract base class for all GNN layers that manage buffers
    (for weights and inputs/output).
    """

    def __init__(self, name, fwd_inputs, fwd_outputs, bwd_inputs, bwd_outputs,
                 workspaces=[], stream=None, dtype="float32"):
        """
        Parameters
        ----------
        See Layer for initial parameters.

        stream: internal_ext.cuda.stream
            The stream used for allocations.
        dtype: string
            The data type of all allocations.
        """
        super(BufferedLayer, self).__init__(
            name, fwd_inputs, fwd_outputs, bwd_inputs, bwd_outputs, workspaces)
        self.stream = stream
        assert dtype in DATA_TYPE_SIZES,\
            "cannot interpret graph feature type " + str(dtype)
        self.dtype = dtype

    def _make_buffer(self, n_el):
        return make_device_buffer(n_el, self.dtype, self.stream)

    def _add_buffer(self, dict_type, n_el, buffer_name):
        if dict_type == 'in':
            d = self.fwd_inputs
        elif dict_type == 'out':
            d = self.fwd_outputs
        elif dict_type == 'bwd_in':
            d = self.bwd_inputs
        else:
            d = self.bwd_outputs
        d[buffer_name] = self._make_buffer(n_el)
