# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import pylibcugraphops_internal_ext as internal_ext
from pylibcugraphops.operators import activation_params

from . import BufferedLayer
from ..utils import make_host_buffer, null_wrapper, AggregationOp as AggOp


class SAGEConv(BufferedLayer):

    """
    Implements a SAGE conv layer used in GraphSAGE model.
    The aggregator can be mean or sum.

    Before you can successfully call forward, you must have sampled a batch
    using the given node_batcher, and you must provide the full node feature
    matrix in `layer0.get_input_buffers()[0]` where `layer0` is the first layer
    of the model.
    """

    def __init__(self, out_feats, previous_layer=None, in_feats=None,
                 cublas=None, rng=None, node_batcher=None, layer_id=None,
                 activation=None, dropout=None, use_reverse_graph=None,
                 name=None, agg_type='mean', dtype='float32'):
        """
        Parameters
        ----------

        out_feats: int
            Number of output features of this layer
        previous_layer: pylibcugraphops_internal.layers.SAGEConv
            The previous layer in the model.
            If given, the `in_feats`, `cublas`, `rng`, `node_batcher`
            and `layer_id` arguments will be inferred.
        in_feats: int | None
            Number of input features of this layer.
            If None, previous_layer is required to infer this.
        cublas: internal_ext.cuda.cublashandle | None
            The cublas handle used for this layer.
            If None, previous_layer is required to infer this.
        rng: internal_ext.rng_state | None
            The random number generator used for initializing weights.
            If None, previous_layer is required to infer this.
        node_batcher: internal_ext.node_batcher_*
            The node batcher used for the graph.
            If None, previous_layer is required to infer this.
        layer_id: int | None
            The ID of the layer w.r.t. the given node batcher.
            If None, previous_layer is required to infer this.
        activation: pylibcugraphops.operators.activation_params | None
            The activation type and optional param. If None, no activation.
        dropout: float | None
            Optional dropout probability. Applied after activation.
            Random number generator is the same as for intializing weights.
        use_reverse_graph: bool | None
            Whether to use reverse graph for backward ops. Makes the layer
            deterministic and can alter performance.
            If None, node_batcher.do_reverse is used to infer this.
        name: string
            Name of the layer for debug/reporting purposes.
            If None, a default name (SAGEConv{x}) is given.
        agg_type: string
            Type of aggregation, either 'mean' or 'sum'.
        dtype: string
            The data type used for inputs/outputs of this layer
        """
        assert previous_layer is None or isinstance(previous_layer, SAGEConv),\
            "previous_layer must be None or a SAGEConv instance"
        if node_batcher is None:
            assert previous_layer is not None,\
                "previous layer required if node batcher is None"
            stream = previous_layer.stream
        else:
            stream = node_batcher.get_stream()
        super(SAGEConv, self).__init__(
            name, dict(), dict(), dict(), dict(), [], stream, dtype)
        self.out_feats = out_feats
        self.previous_layer = previous_layer
        self.in_feats = self._from_previous(
            in_feats, previous_layer, "in_feats", "out_feats")
        self.cublas = self._from_previous(cublas, previous_layer, "cublas")
        self.rng = self._from_previous(rng, previous_layer, "rng")
        self.node_batcher = self._from_previous(
            node_batcher, previous_layer, "node_batcher")
        self.layer_id = self._from_previous(
            layer_id, previous_layer, "layer_id")
        if layer_id is None:
            # need to increase the layer id from previous layer
            self.layer_id += 1
        assert self.layer_id >= 0, "layer_id must be non-negative"
        self.info_init = self.node_batcher.get_info(self.layer_id)
        self.n_max_out = self.info_init.max_out_nodes
        if self.layer_id == 0:
            self.n_max_in = self.n_max_out * (self.info_init.sample_size + 1)
        else:
            prev_info = self.node_batcher.get_info(self.layer_id - 1)
            self.n_max_in = prev_info.max_out_nodes
        self.activation = activation or activation_params()
        assert dropout is None or 0 <= dropout <= 1,\
            "Dropout must be None or in [0, 1]"
        self.dropout = 0. if dropout is None else dropout
        if use_reverse_graph:
            assert self.node_batcher.do_reverse(),\
                "Node batcher must compute reverse graph to use reverse ops"
        if use_reverse_graph is None:
            self.do_rev = self.node_batcher.do_reverse()
        else:
            self.do_rev = bool(use_reverse_graph)
        self.agg_type = agg_type
        if self.agg_type == 'mean':
            self.agg_op = AggOp.Mean
        elif self.agg_type == 'sum':
            self.agg_op = AggOp.Sum
        else:
            raise AssertionError(f"Unknown agg_type {agg_type}. "
                                 "Must be 'mean' or 'sum'")
        self.idx_type = self.node_batcher.__class__.__name__.split('_')[-1]
        self.agg_concat_fwd = getattr(
            internal_ext.layers, f"agg_concat_mfg_n2n_fwd_{self.dtype}_{self.idx_type}")
        self.agg_concat_bwd = getattr(
            internal_ext.layers, f"agg_concat_mfg_n2n_bwd_{self.dtype}_{self.idx_type}")
        self.agg_concat_mfg_n2n_bwd_rev = getattr(
            internal_ext.layers,
            f"agg_concat_mfg_n2n_bwd_rev_{self.dtype}_{self.idx_type}")
        self.dense_fwd = getattr(internal_ext.layers, f"dense_fwd_{self.dtype}")
        self.dense_bwd = getattr(internal_ext.layers, f"dense_bwd_{self.dtype}")
        self.gather = getattr(
            internal_ext.layers, f"gather_{self.dtype}_{self.idx_type}")

        if previous_layer is None:
            agg_in = self._make_buffer(self.n_max_in * self.in_feats)
        else:
            agg_in = previous_layer.get_output_buffers()[0]
        self.fwd_inputs['agg_in'] = agg_in
        self._add_buffer('in', self.n_max_out * self.in_feats * 2, 'fc_in')
        self._add_buffer('in', self.out_feats * self.in_feats * 2, 'fc_w')
        self._add_buffer('in', self.out_feats, 'fc_b')
        self.fwd_outputs['agg_out'] = self.fwd_inputs['fc_in']
        self._add_buffer('out', self.n_max_out * self.out_feats, 'fc_int')
        self._add_buffer('out', self.n_max_out * self.out_feats, 'final_out')

        # require an additional buffer for dropout values
        if self.dropout <= 0:
            self.fwd_outputs['fc_drop'] = null_wrapper('uint64')
        else:
            self.fwd_outputs['fc_drop'] = make_host_buffer(
                2, 'uint64', self.stream)

        # we'll use the fwd_inputs/fwd_outputs for the gradients:
        # don't need additional buffers for bwd except for output gradients
        self._add_buffer(
            'bwd_out', self.out_feats * self.in_feats * 2, 'fc_gw')
        self._add_buffer('bwd_out', self.out_feats, 'fc_gb')
        self._add_buffer(
            'bwd_in', self.n_max_out * self.out_feats, 'g_final_out')

        # this will be used to place the intial input for the initial layer
        self.fwd_inputs['init_in'] = None
        self._inputs = [self.fwd_inputs['init_in']]
        self._outputs = [self.fwd_outputs['final_out']]
        self._g_inputs = [self.bwd_inputs['g_final_out']]

        # initialize weights and bias
        # we use uniform initialization everywhere, which is default
        # for bias, a gain of sqrt(1/3) means that we end up initializing
        # with a bound of [-1/sqrt(fan_in), 1/sqrt(fan_in)], which is the
        # default in PyTorch
        # for the others, we use the default gain of sqrt(2)
        init_w = getattr(internal_ext.layers, f"init_weights_{self.dtype}")
        init_w(w=self.fwd_inputs['fc_b'], n=self.out_feats,
               n_fan=self.in_feats * 2, gain=1. / math.sqrt(3), rng=self.rng,
               stream=self.stream)
        init_w(w=self.fwd_inputs['fc_w'], n=self.out_feats * self.in_feats * 2,
               n_fan=self.in_feats * 2, rng=self.rng, stream=self.stream)

    def _get_weight_buffers(self):
        return [self.fwd_inputs['fc_w'], self.fwd_inputs['fc_b']]

    def _get_grad_buffers(self):
        return [self.bwd_outputs['fc_gw'], self.bwd_outputs['fc_gb']]

    def get_input_buffers(self):
        return self._inputs

    def get_output_buffers(self):
        return self._outputs

    def get_grad_input_buffers(self):
        return self._g_inputs

    def fwd_impl(self):
        layer_info = self.node_batcher.get_info(self.layer_id)
        n_in_nodes = layer_info.mfg.n_in_nodes
        n_out_nodes = layer_info.mfg.n_out_nodes
        if n_out_nodes <= 0 or n_in_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling forward on this layer "
                f"({self})")
        if self.previous_layer is None:
            if self.get_input_buffers()[0] is None:
                raise ValueError(
                    "Please provide an input for the initial layer as "
                    "an `ArrayWrapper` in `layer.get_input_buffers()[0]`")
            # we should first gather the nodes into `agg_in` renumbered in the
            # way that the aggregation layer expects it (for its input)
            self.gather(
                self.fwd_inputs['agg_in'], self.get_input_buffers()[0],
                layer_info.in_nodes, self.in_feats, n_in_nodes, self.stream
            )
        self.agg_concat_fwd(
            self.fwd_outputs['agg_out'], null_wrapper(self.idx_type),
            self.fwd_inputs['agg_in'], self.in_feats, layer_info.mfg,
            self.agg_op, self.stream
        )
        self.dense_fwd(
            self.fwd_outputs['final_out'], self.fwd_outputs['fc_int'],
            self.out_feats, self.fwd_inputs['fc_in'], self.in_feats * 2,
            self.fwd_inputs['fc_w'], self.in_feats * 2,
            self.fwd_inputs['fc_b'], n_out_nodes, self.out_feats,
            self.in_feats * 2, self.activation, self.fwd_outputs['fc_drop'],
            self.dropout, self.rng, self.cublas, self.stream
        )

    def bwd_impl(self):
        layer_info = self.node_batcher.get_info(self.layer_id)
        n_in_nodes = layer_info.mfg.n_in_nodes
        n_out_nodes = layer_info.mfg.n_out_nodes
        if n_out_nodes <= 0 or n_in_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling backward on this layer "
                f"({self})")
        if self.previous_layer is None:
            da = null_wrapper(self.dtype)
        else:
            da = self.fwd_outputs['agg_out']
        self.dense_bwd(
            da, self.bwd_outputs['fc_gw'], self.bwd_outputs['fc_gb'],
            self.fwd_outputs['fc_int'], self.bwd_inputs['g_final_out'],
            self.fwd_outputs['final_out'], self.fwd_outputs['fc_int'],
            self.out_feats, self.fwd_inputs['fc_in'], self.in_feats * 2,
            self.fwd_inputs['fc_w'], self.in_feats * 2,
            self.fwd_inputs['fc_b'], n_out_nodes, self.out_feats,
            self.in_feats * 2, self.activation, self.fwd_outputs['fc_drop'],
            self.dropout, self.cublas, self.stream
        )
        if self.previous_layer is not None:
            if self.do_rev:
                self.agg_concat_mfg_n2n_bwd_rev(
                    self.previous_layer.get_grad_input_buffers()[0],
                    self.fwd_outputs['agg_out'], null_wrapper(self.idx_type),
                    self.in_feats, layer_info.mfg, layer_info.mfg_rev,
                    self.agg_op, self.stream
                )
            else:
                self.agg_concat_bwd(
                    self.previous_layer.get_grad_input_buffers()[0],
                    self.fwd_outputs['agg_out'], null_wrapper(self.idx_type),
                    self.in_feats, layer_info.mfg, self.agg_op, self.stream
                )
