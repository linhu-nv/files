# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from . import Layer


class Sequential(Layer):

    """
    A container layer consisting of a sequence of other layers.
    """

    def __init__(self, layers=None, name=None):
        """
        Parameters
        ----------

        layers: Iterable[pylibcugraphops_internal.layers.Layer]
            The layers to add to this container
        name: string
            Name of the layer for debug/reporting purposes.
        """
        # we don't use fwd/bwd inputs/outputs for containers
        super(Sequential, self).__init__(name, None, None, None, None)
        if layers is not None:
            for layer in layers:
                self.append(layer)

    # Layer interface
    def get_input_buffers(self):
        return self.get_first().get_input_buffers()

    def get_output_buffers(self):
        return self.get_last().get_output_buffers()

    def get_grad_input_buffers(self):
        return self.get_last().get_grad_input_buffers()

    def fwd_impl(self):
        for layer in self:
            layer.fwd()

    def bwd_impl(self):
        for layer in self[::-1]:
            layer.bwd()

    # python container interface
    def __len__(self):
        return len(self.children)

    def __getitem__(self, idx):
        return self.children[idx]

    def __set_item__(self, idx, layer):
        assert isinstance(layer, Layer),\
            "must only add Layer instances to this container"
        self.children[idx] = layer

    def __delitem__(self, idx):
        del self.children[idx]

    def __iter__(self):
        return self.children.__iter__()

    def __reversed__(self):
        return self.children.__reversed__()

    def __contains__(self, item):
        return item in self.children

    # python list interface
    def append(self, layer):
        assert isinstance(layer, Layer),\
            "must only add Layer instances to this container"
        return self.children.append(layer)

    def extend(self, iterable):
        for layer in iterable:
            self.append(layer)

    def insert(self, idx, layer):
        self[idx] = layer

    def remove(self, layer):
        return self.children.remove(layer)

    def pop(self, idx=-1):
        return self.children.pop(idx)

    def clear(self):
        return self.children.clear()

    def index(self, layer, start=None, end=None):
        if start is None:
            start = 0
        if end is None:
            end = len(self)
        return self.children.index(layer, start, end)

    def count(self, layer):
        return self.children.count(layer)

    def sort(self, key=None, reverse=False):
        self.children.sort(key, reverse)

    def reverse(self):
        self.children.reverse()

    def copy(self):
        return Sequential(layers=self.children, name=self.name)
