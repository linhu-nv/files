# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import pylibcugraphops_internal_ext as internal_ext
from pylibcugraphops_internal.utils import ActivationOp
from pylibcugraphops import mha_params
from pylibcugraphops.operators import activation_params

from . import BufferedLayer
from ..utils import make_host_buffer, null_wrapper


class GATConv(BufferedLayer):

    """
    Implements a GAT conv layer used in GAT model.

    `out_feats` represents the total output features, meaning it must be a
    multiple of the number of heads `num_heads`.
    `attn_act` allows to scale the attention scores before softmax is applied

    Before you can successfully call forward, you must have sampled a batch
    using the given node_batcher, and you must provide the full node feature
    matrix in `layer0.get_input_buffers()[0]` where `layer0` is the first layer
    of the model.
    """

    def __init__(self, out_feats, previous_layer=None, in_feats=None,
                 use_bias=None, num_heads=None, attn_act=None, cublas=None,
                 rng=None, node_batcher=None, layer_id=None, activation=None,
                 dropout=None, name=None, dtype='float32'):
        """
        Parameters
        ----------

        out_feats: int
            Number of output features of this layer.
            Must be multiple of `num_heads`
        previous_layer: pylibcugraphops_internal.layers.GATConv
            The previous layer in the model.
            If given, the `in_feats`, `cublas`, `rng`, `node_batcher`
            and `layer_id` arguments will be inferred.
        in_feats: int | None
            Number of input features of this layer.
            If None, `previous_layer` is required to infer this.
        use_bias: bool | None
            Apply a bias after attention. By default, False.
        num_heads: int | None
            Number of heads for this layer. By default, it is 1.
        attn_act: pylibcugraphops.operators.activation_params | None
            Attention scores before softmax are activated with this.
            By default, leaky relu with slope of 0.2.
        cublas: internal_ext.cuda.cublashandle | None
            The cublas handle used for this layer.
            If None, `previous_layer` is required to infer this.
        rng: internal_ext.rng_state | None
            The random number generator used for initializing weights.
            If None, `previous_layer` is required to infer this.
        node_batcher: internal_ext.node_batcher_*
            The node batcher used for the graph.
            If None, `previous_layer` is required to infer this.
        layer_id: int | None
            The ID of the layer w.r.t. the given node batcher.
            If None, `previous_layer` is required to infer this.
        activation: pylibcugraphops.operators.activation_params | None
            The activation type and optional param. If None, no activation.
        dropout: float | None
            Optional dropout probability. Applied on the inputs.
            Random number generator is the same as for intializing weights.
        name: string
            Name of the layer for debug/reporting purposes.
            If None, a default name (GATConv{x}) is given.
        dtype: string
            The data type used for inputs/outputs of this layer
        """
        assert previous_layer is None or isinstance(previous_layer, GATConv),\
            "previous_layer must be None or a GATConv instance"
        if node_batcher is None:
            assert previous_layer is not None,\
                "previous layer required if node batcher is None"
            stream = previous_layer.stream
        else:
            stream = node_batcher.get_stream()
        super(GATConv, self).__init__(
            name, dict(), dict(), dict(), dict(), [], stream, dtype)
        self.out_feats = out_feats
        self.previous_layer = previous_layer
        self.in_feats = self._from_previous(
            in_feats, previous_layer, "in_feats", "out_feats")
        self.use_bias = bool(use_bias)
        self.num_heads = 1 if num_heads is None else num_heads
        assert self.num_heads > 0, "num_heads must be strictly positive"
        assert self.out_feats % self.num_heads == 0,\
            "out_feats must be multiple of num_heads"
        default_attn_act = activation_params()
        default_attn_act.type = ActivationOp.LeakyReLU
        default_attn_act.alpha = 0.2
        self.attn_act = attn_act or default_attn_act
        self.cublas = self._from_previous(cublas, previous_layer, "cublas")
        self.rng = self._from_previous(rng, previous_layer, "rng")
        self.node_batcher = self._from_previous(
            node_batcher, previous_layer, "node_batcher")
        self.layer_id = self._from_previous(
            layer_id, previous_layer, "layer_id")
        if layer_id is None:
            # need to increase the layer id from previous layer
            self.layer_id += 1
        assert self.layer_id >= 0, "layer_id must be non-negative"
        self.info_init = self.node_batcher.get_info(self.layer_id)
        self.n_max_out = self.info_init.max_out_nodes
        n_neigh_all = self.info_init.sample_size + 1
        if self.layer_id == 0:
            self.n_max_in = self.n_max_out * n_neigh_all
        else:
            prev_info = self.node_batcher.get_info(self.layer_id - 1)
            self.n_max_in = prev_info.max_out_nodes
        self.activation = activation or activation_params()
        self.do_final_act = (
            self.activation.type != ActivationOp.Linear or
            self.use_bias
        )
        assert dropout is None or 0 <= dropout <= 1,\
            "Dropout must be None or in [0, 1]"
        self.dropout = 0. if dropout is None else dropout
        self.idx_type = self.node_batcher.__class__.__name__.split('_')[-1]
        self.mha_gat_mfg_fwd = getattr(
            internal_ext.layers.mha_gat_mfg,
            f"mha_gat_mfg_fwd_{self.dtype}_{self.idx_type}")
        self.mha_gat_mfg_bwd = getattr(
            internal_ext.layers.mha_gat_mfg,
            f"mha_gat_mfg_bwd_{self.dtype}_{self.idx_type}")
        self.dense_fwd = getattr(internal_ext.layers, f"dense_fwd_{self.dtype}")
        self.dense_bwd = getattr(internal_ext.layers, f"dense_bwd_{self.dtype}")
        self.gather = getattr(
            internal_ext.layers, f"gather_{self.dtype}_{self.idx_type}")
        self.bias_act_fwd = getattr(
            internal_ext.layers, f"bias_activation_fwd_{self.dtype}")
        self.bias_act_bwd = getattr(
            internal_ext.layers, f"bias_activation_bwd_{self.dtype}")

        # set mha parameters
        self.mha = mha_params()
        self.mha.activation = self.attn_act
        self.mha.num_heads = self.num_heads
        self.mha.concat_heads = True

        # additional buffer for dropout values
        if self.dropout <= 0:
            self.fwd_outputs['fc_drop'] = null_wrapper('uint64')
        else:
            self.fwd_outputs['fc_drop'] = make_host_buffer(
                2, 'uint64', self.stream)

        # buffers for fully connected
        # (uses previous layer output and outputs to fc_int_out)
        if previous_layer is None:
            drop_in = self._make_buffer(self.n_max_in * self.in_feats)
        else:
            drop_in = previous_layer.get_output_buffers()[0]
        self.fwd_inputs['drop_in'] = drop_in
        self._add_buffer('out', self.n_max_in * self.in_feats, 'fc_in')
        self._add_buffer('in', self.out_feats * self.in_feats, 'fc_w')
        if self.use_bias:
            self._add_buffer('in', self.out_feats, 'fc_b')
        else:
            self.fwd_inputs['fc_b'] = null_wrapper(self.dtype)
        self._add_buffer('out', self.n_max_in * self.out_feats, 'fc_int_out')

        # buffers for attention (uses fc_int_out and outputs to final_out)
        self._add_buffer('in', self.out_feats * 2, 'mha_w')
        self._add_buffer(
            'out', 2 * self.n_max_out * self.num_heads * n_neigh_all,
            'mha_sm_int')
        self._add_buffer('out', self.n_max_out * self.out_feats, 'mha_out_int')

        # buffer for final activation
        if self.do_final_act:
            self._add_buffer(
                'out', self.n_max_out * self.out_feats, 'final_out')
        else:
            self.fwd_outputs['final_out'] = self.fwd_outputs['mha_out_int']

        # backward buffers
        # for the weights
        self._add_buffer('bwd_out', self.out_feats * self.in_feats, 'fc_gw')
        if self.use_bias:
            self._add_buffer('bwd_out', self.out_feats, 'fc_gb')
        else:
            self.bwd_outputs['fc_gb'] = null_wrapper(self.dtype)
        self._add_buffer('bwd_out', self.out_feats * 2, 'mha_gw')
        # we also allocate buffers for the data gradient inputs of the whole
        # layer and between dense and mha layer
        self._add_buffer(
            'bwd_in', self.n_max_out * self.out_feats, 'g_final_out')
        self._add_buffer('bwd_out', self.n_max_in * self.out_feats, 'mha_g_in')
        if self.do_final_act:
            self._add_buffer(
                'bwd_out', self.n_max_out * self.out_feats, 'mha_g_int')
        else:
            self.bwd_outputs['mha_g_int'] = self.bwd_inputs['g_final_out']
        # the data gradient output depends if we have a previous layer or not
        if previous_layer is not None:
            self._add_buffer(
                'bwd_out', self.n_max_in * self.in_feats, 'g_fc_in')
        else:
            self.bwd_outputs['g_fc_in'] = null_wrapper(self.dtype)

        # this will be used to place the intial input for the initial layer
        self.fwd_inputs['init_in'] = None
        self._inputs = [self.fwd_inputs['init_in']]
        self._outputs = [self.fwd_outputs['final_out']]
        self._g_inputs = [self.bwd_inputs['g_final_out']]

        # initialize weights and bias
        init_w = getattr(internal_ext.layers, f"init_weights_{self.dtype}")
        # we use uniform initialization everywhere, which is default
        # for bias, a gain of sqrt(1/3) means that we end up initializing
        # with a bound of [-1/sqrt(fan_in), 1/sqrt(fan_in)], which is the
        # default in PyTorch
        # for the linear weights, we use the default gain of sqrt(2)
        # finally, for the attention weights, we use He/kaiming initialization
        if self.use_bias:
            init_w(w=self.fwd_inputs['fc_b'], n=self.out_feats,
                   n_fan=self.in_feats, gain=1. / math.sqrt(3), rng=self.rng,
                   stream=self.stream)
        init_w(w=self.fwd_inputs['fc_w'], n=self.out_feats * self.in_feats,
               n_fan=self.in_feats, rng=self.rng, stream=self.stream)
        init_w(w=self.fwd_inputs['mha_w'], n=self.out_feats * 2,
               n_fan=self.out_feats * 2 + 1, rng=self.rng, stream=self.stream)

    def _get_weight_buffers(self):
        r = [self.fwd_inputs['fc_w'], self.fwd_inputs['mha_w']]
        if self.use_bias:
            r += [self.fwd_inputs['fc_b']]
        return r

    def _get_grad_buffers(self):
        r = [self.bwd_outputs['fc_gw'], self.bwd_outputs['mha_gw']]
        if self.use_bias:
            r += [self.bwd_outputs['fc_gb']]
        return r

    def get_input_buffers(self):
        return self._inputs

    def get_output_buffers(self):
        return self._outputs

    def get_grad_input_buffers(self):
        return self._g_inputs

    def fwd_impl(self):
        layer_info = self.node_batcher.get_info(self.layer_id)
        n_in_nodes = layer_info.mfg.n_in_nodes
        n_out_nodes = layer_info.mfg.n_out_nodes
        if n_out_nodes <= 0 or n_in_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling forward on this layer "
                f"({self})")
        if self.previous_layer is None:
            if self.get_input_buffers()[0] is None:
                raise ValueError(
                    "Please provide an input for the initial layer as "
                    "an `ArrayWrapper` in `layer.get_input_buffers()[0]`")
            # we should first gather the nodes into `agg_in` renumbered in the
            # way that the aggregation layer expects it (for its input)
            self.gather(
                self.fwd_inputs['drop_in'], self.get_input_buffers()[0],
                layer_info.in_nodes, self.in_feats, n_in_nodes, self.stream
            )
        no_act = activation_params()
        # first we apply dropout only
        if self.dropout > 0:
            self.bias_act_fwd(
                self.fwd_outputs['fc_in'], self.fwd_inputs['drop_in'],
                null_wrapper(self.dtype), n_in_nodes, self.in_feats,
                self.in_feats, no_act, self.fwd_outputs['fc_drop'],
                self.dropout, self.rng, self.stream)
        # we apply linear layer without bias/activation/dropout
        self.dense_fwd(
            null_wrapper(self.dtype), self.fwd_outputs['fc_int_out'],
            self.out_feats, self.fwd_outputs['fc_in'], self.in_feats,
            self.fwd_inputs['fc_w'], self.in_feats,
            null_wrapper(self.dtype), n_in_nodes, self.out_feats,
            self.in_feats, no_act, null_wrapper('uint64'), 0., self.rng,
            self.cublas, self.stream
        )
        # now we apply the multi-head attention
        self.mha_gat_mfg_fwd(
            self.fwd_outputs['mha_out_int'], self.fwd_outputs['mha_sm_int'],
            self.fwd_outputs['fc_int_out'], self.fwd_inputs['mha_w'],
            layer_info.mfg, self.mha, self.out_feats, self.stream
        )
        # finally, apply the activation (including bias if needed)
        if self.do_final_act:
            self.bias_act_fwd(
                self.fwd_outputs['final_out'], self.fwd_outputs['mha_out_int'],
                self.fwd_inputs['fc_b'], n_out_nodes, self.out_feats,
                self.out_feats, self.activation, null_wrapper('uint64'), 0.,
                self.rng, self.stream
            )

    def bwd_impl(self):
        layer_info = self.node_batcher.get_info(self.layer_id)
        n_in_nodes = layer_info.mfg.n_in_nodes
        n_out_nodes = layer_info.mfg.n_out_nodes
        if n_out_nodes <= 0 or n_in_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling backward on this layer "
                f"({self})")

        if self.do_final_act:
            self.bias_act_bwd(
                self.bwd_outputs['mha_g_int'], self.bwd_outputs['fc_gb'],
                self.bwd_inputs['g_final_out'], self.fwd_outputs['final_out'],
                self.fwd_outputs['mha_out_int'], self.fwd_inputs['fc_b'],
                n_out_nodes, self.out_feats, self.out_feats, self.activation,
                null_wrapper('uint64'), 0., self.stream
            )

        self.mha_gat_mfg_bwd(
            self.bwd_outputs['mha_g_in'], self.bwd_outputs['mha_gw'],
            self.bwd_outputs['mha_g_int'], self.fwd_outputs['fc_int_out'],
            self.fwd_inputs['mha_w'], self.fwd_outputs['mha_sm_int'],
            layer_info.mfg, self.mha, self.out_feats, self.stream
        )

        no_act = activation_params()
        self.dense_bwd(
            self.bwd_outputs['g_fc_in'], self.bwd_outputs['fc_gw'],
            null_wrapper(self.dtype), null_wrapper(self.dtype),
            self.bwd_outputs['mha_g_in'], null_wrapper(self.dtype),
            self.fwd_outputs['fc_int_out'], self.out_feats,
            self.fwd_outputs['fc_in'], self.in_feats,
            self.fwd_inputs['fc_w'], self.in_feats,
            null_wrapper(self.dtype), n_in_nodes, self.out_feats,
            self.in_feats, no_act, null_wrapper('uint64'), 0.,
            self.cublas, self.stream
        )

        # we only do backward of dropout if we actually have a previous layer
        if self.previous_layer is not None and self.dropout > 0:
            self.bias_act_bwd(
                self.previous_layer.get_grad_input_buffers()[0],
                null_wrapper(self.dtype), self.bwd_outputs['g_fc_in'],
                self.fwd_outputs['fc_in'], self.fwd_inputs['drop_in'],
                null_wrapper(self.dtype), n_in_nodes, self.in_feats,
                self.in_feats, no_act, self.fwd_outputs['fc_drop'],
                self.dropout, self.stream
            )
