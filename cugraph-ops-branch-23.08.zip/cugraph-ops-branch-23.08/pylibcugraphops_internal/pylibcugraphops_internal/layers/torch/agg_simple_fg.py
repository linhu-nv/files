# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

from ...utils import FullGraphAnyNonHg, AggregationOp as AggOp


def _get_agg_func(is_fwd: bool,
                  torch_feat_type: torch.dtype,
                  idx_type: str) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    f = "fwd" if is_fwd else "bwd"
    return getattr(internal_ext.torch,
        f"agg_simple_fg_e2n_{f}_{dtype}_{idx_type}")


class AggSimpleEdgeFgTorch(torch.autograd.Function):
    _fwd_funcs = {
        (dtype, idx_type): _get_agg_func(True, dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }
    _bwd_funcs = {
        (dtype, idx_type): _get_agg_func(False, dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }

    @staticmethod
    def forward(ctx,
                in_feats: torch.Tensor,
                graph: FullGraphAnyNonHg,
                agg_op: AggOp) -> torch.Tensor:
        in_feats = in_feats.contiguous()
        assert in_feats.size(0) == graph.n_edges,\
            f"Expected {graph.n_edges} features but got {in_feats.size(0)}"
        idx_type = graph.__class__.__name__.split('_')[-1]
        func = AggSimpleEdgeFgTorch._fwd_funcs.get((in_feats.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of full edge aggregation for "
                f"dtype {in_feats.dtype} and index type {idx_type}")
        d = in_feats.size(1)
        out_feats = torch.empty(
            (graph.n_nodes, d), dtype=in_feats.dtype,
            device=in_feats.device, requires_grad=in_feats.requires_grad)
        func(out_feats, None, in_feats, d, graph, agg_op)
        ctx.graph = graph
        ctx.agg_op = agg_op
        return out_feats

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> torch.Tensor:
        grad_output = grad_output.contiguous()
        idx_type = ctx.graph.__class__.__name__.split('_')[-1]
        func = AggSimpleEdgeFgTorch._bwd_funcs.get((grad_output.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of full edge aggregation for "
                f"dtype {grad_output.dtype} and index type {idx_type}")
        d = grad_output.size(1)
        grad_input = torch.empty(
            (ctx.graph.n_edges, d), dtype=grad_output.dtype,
            device=grad_output.device)
        func(grad_input, grad_output, None, d, ctx.graph, ctx.agg_op)
        # return a value for each input to forward (None for non-tensors)
        return grad_input, None, None
