# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext
from pylibcugraphops.operators import activation_params

import math
import torch
import typing

from ...utils import ActivationOp, RngState, CublasHandle

logger = internal_ext.utils.logger

TORCH_TO_OPS_ACTIVATION_TYPE = {
    "ReLU": (ActivationOp.ReLU, None),
    "Sigmoid": (ActivationOp.Sigmoid, None),
    "Tanh": (ActivationOp.Tanh, None),
    "ELU": (ActivationOp.ELU, None),
    "LeakyReLU": (ActivationOp.LeakyReLU, "negative_slope"),
    "NoneType": (ActivationOp.Linear, None),
}


def _get_dense_func(is_fwd: bool, torch_feat_type: torch.dtype) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    f = "fwd" if is_fwd else "bwd"
    return getattr(internal_ext.torch, f"dense_{f}_{dtype}")


def _has_out_feats(bias: typing.Optional[torch.Tensor],
                   activation: ActivationOp,
                   dropout: int) -> bool:
    return (bias is not None or activation.type != ActivationOp.Linear or
            dropout > 0)


class DenseOp(torch.autograd.Function):
    _fwd_funcs = {
        dtype: _get_dense_func(True, dtype) for dtype in [torch.float32]
    }
    _bwd_funcs = {
        dtype: _get_dense_func(False, dtype) for dtype in [torch.float32]
    }

    @staticmethod
    def forward(
        ctx,
        in_feats: torch.Tensor,
        weights: torch.Tensor,
        bias: typing.Optional[torch.Tensor],
        activation: ActivationOp,
        dropout: float,
        rng: RngState,
        cublas: CublasHandle
    ) -> torch.Tensor:
        in_feats = in_feats.contiguous()
        weights = weights.contiguous()
        bias = None if bias is None else bias.contiguous()
        func = DenseOp._fwd_funcs.get(in_feats.dtype, None)
        if not func:
            raise ValueError(
                f"No implementation of dense for dtype {in_feats.dtype}")
        assert in_feats.device == weights.device,\
            "Input features and weights must be on same device"
        if bias is not None:
            assert weights.device == bias.device,\
                "Weights and bias must be on same device"
        int_feats = torch.empty(
            (in_feats.size(0), weights.size(0)), dtype=in_feats.dtype,
            device=in_feats.device,
            requires_grad=in_feats.requires_grad or weights.requires_grad)
        if _has_out_feats(bias, activation, dropout):
            out_feats = torch.empty_like(
                int_feats, requires_grad=int_feats.requires_grad)
        else:
            out_feats = None
        if dropout > 0:
            drop_v = torch.empty((2,), dtype=torch.int64,
                                 device=torch.device('cpu'), pin_memory=True)
        else:
            drop_v = None
        func(out_feats, int_feats, int_feats.size(1), in_feats,
             in_feats.size(1), weights, weights.size(1), bias,
             int_feats.size(0), weights.size(0), weights.size(1), activation,
             drop_v, dropout, rng, cublas)
        ctx.save_for_backward(
            in_feats, weights, bias, int_feats, out_feats, drop_v)
        ctx.activation = activation
        ctx.dropout = dropout
        ctx.cublas = cublas
        return int_feats if out_feats is None else out_feats

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor
                ) -> typing.Tuple[
                    typing.Optional[torch.Tensor],
                    typing.Optional[torch.Tensor],
                    typing.Optional[torch.Tensor],
                    None,
                    None,
                    None,
                    None,
                    ]:
        grad_output = grad_output.contiguous()
        need_in_grad, need_w_grad, need_b_grad = ctx.needs_input_grad[:3]
        in_feats, weights, bias, int_feats, out_feats, drop_v =\
            ctx.saved_tensors
        func = DenseOp._bwd_funcs.get(grad_output.dtype, None)
        if not func:
            raise ValueError(
                f"No implementation of dense for dtype {grad_output.dtype}")
        grad_in = torch.empty_like(in_feats) if need_in_grad else None
        grad_weights = torch.empty_like(weights) if need_w_grad else None
        grad_bias = torch.empty_like(bias) if need_b_grad else None
        func(grad_in, grad_weights, grad_bias, int_feats, grad_output,
             out_feats, int_feats, int_feats.size(1), in_feats,
             in_feats.size(1), weights, weights.size(1), bias,
             int_feats.size(0), weights.size(0), weights.size(1),
             ctx.activation, drop_v, ctx.dropout, ctx.cublas)
        # return a value for each input to forward (None for non-tensors)
        return grad_in, grad_weights, grad_bias, None, None, None, None


class DenseTorch(torch.nn.Module):
    def __init__(self,
                 n_in_feats: int,
                 n_out_feats: int,
                 rng: RngState,
                 cublas: CublasHandle,
                 device: torch.device,
                 dtype: torch.dtype,
                 use_bias: bool = True,
                 activation: typing.Optional[ActivationOp] = None,
                 dropout: typing.Optional[float] = None) -> None:
        super().__init__()
        self.in_features = n_in_feats
        self.out_features = n_out_feats
        self.rng = rng
        self.cublas = cublas
        factory_kwargs = {'device': device, 'dtype': dtype}
        self.weight = torch.nn.Parameter(
            torch.empty((n_out_feats, n_in_feats), **factory_kwargs))
        if use_bias:
            self.bias = torch.nn.Parameter(
                torch.empty((n_out_feats,), **factory_kwargs))
        else:
            self.register_parameter('bias', None)
        self.activation = activation or activation_params()
        assert dropout is None or 0 <= dropout <= 1,\
            "Dropout must be None or in [0, 1]"
        self.dropout = 0. if dropout is None else dropout
        self.reset_parameters()

    def reset_parameters(self) -> None:
        # see torch.nn.Linear
        torch.nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            fan_in, _ = torch.nn.init._calculate_fan_in_and_fan_out(self.weight)
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            torch.nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, input: torch.Tensor) -> torch.Tensor:
        return DenseOp.apply(
            input, self.weight, self.bias, self.activation, self.dropout,
            self.rng, self.cublas)


def make_dense_layer(n_in_feats: int,
                     n_out_feats: int,
                     use_bias: bool,
                     activation: typing.Optional[torch.nn.Module],
                     dropout: float,
                     device: torch.device,
                     dtype: torch.dtype,
                     rng: typing.Optional[RngState] = None,
                     cublas: typing.Optional[CublasHandle] = None
                     ) -> torch.nn.Module:
    ops_act_type = TORCH_TO_OPS_ACTIVATION_TYPE.get(
        activation.__class__.__name__, None)
    if ops_act_type and rng is not None and cublas is not None:
        ops_act = activation_params()
        ops_act.type = ops_act_type[0]
        if ops_act_type[1]:
            ops_act.alpha = getattr(activation, ops_act_type[1])
        return DenseTorch(
            n_in_feats, n_out_feats, rng, cublas,
            device=device, dtype=dtype, use_bias=use_bias,
            activation=ops_act, dropout=dropout)

    if ops_act_type:
        logger.warn("pylibcugraphops_internal.layers.torch.dense warning: "
                    "make_dense_layer: rng or cublas handle not provided, "
                    "but activation could be handled by cugraph_ops.\n")
    seq = [
        torch.nn.Linear(
            n_in_feats, n_out_feats, bias=use_bias, device=device, dtype=dtype),
    ]
    if activation:
        seq.append(activation)
    if dropout > 0:
        seq.append(torch.nn.Dropout(p=dropout))
    if len(seq) == 1:
        return seq[0]
    return torch.nn.Sequential(*seq)
