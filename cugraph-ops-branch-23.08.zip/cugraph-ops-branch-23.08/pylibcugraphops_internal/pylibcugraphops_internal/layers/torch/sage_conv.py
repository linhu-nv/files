# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

from . import NodeBatcherLayer, make_dense_layer
from ...utils import CublasHandle, MfgCsr, MfgEllpack, NodeBatcher, RngState
from ...utils import AggregationOp as AggOp


def _get_agg_func(is_fwd: bool, torch_feat_type: torch.dtype, idx_type: str
                  ) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    f = "fwd" if is_fwd else "bwd"
    return getattr(internal_ext.torch,
        f"agg_concat_mfg_n2n_{f}_{dtype}_{idx_type}")


class SAGEAggregation(torch.autograd.Function):
    _fwd_funcs = {
        (dtype, idx_type): _get_agg_func(True, dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }
    _bwd_funcs = {
        (dtype, idx_type): _get_agg_func(False, dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }

    @staticmethod
    def forward(ctx,
                in_feats: torch.Tensor,
                graph: typing.Union[MfgCsr, MfgEllpack],
                agg_op: AggOp) -> torch.Tensor:
        in_feats = in_feats.contiguous()
        idx_type = graph.__class__.__name__.split('_')[-1]
        func = SAGEAggregation._fwd_funcs.get((in_feats.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of sage aggregation for dtype "
                f"{in_feats.dtype} and index type {idx_type}")
        d = in_feats.size(1)
        out_feats = torch.empty(
            (graph.n_out_nodes, d * 2), dtype=in_feats.dtype,
            device=in_feats.device, requires_grad=in_feats.requires_grad)
        func(out_feats, None, in_feats, d, graph, agg_op)
        ctx.graph = graph
        ctx.agg_op = agg_op
        return out_feats

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> torch.Tensor:
        grad_output = grad_output.contiguous()
        idx_type = ctx.graph.__class__.__name__.split('_')[-1]
        func = SAGEAggregation._bwd_funcs.get((grad_output.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of sage aggregation for dtype "
                f"{grad_output.dtype} and index type {idx_type}")
        d = grad_output.size(1) // 2
        grad_input = torch.empty(
            (ctx.graph.n_in_nodes, d), dtype=grad_output.dtype,
            device=grad_output.device)
        func(grad_input, grad_output, None, d, ctx.graph, ctx.agg_op)
        # return a value for each input to forward (None for non-tensors)
        return grad_input, None, None


class SAGEConvTorch(NodeBatcherLayer):
    def __init__(self,
                 n_in_feats: int,
                 n_out_feats: int,
                 previous_layer: typing.Optional[torch.nn.Module] = None,
                 layer_id: typing.Optional[int] = None,
                 node_batcher: typing.Optional[NodeBatcher] = None,
                 activation: typing.Optional[torch.nn.Module] = None,
                 dropout: typing.Optional[float] = None,
                 use_bias: typing.Optional[bool] = None,
                 agg_op: str = 'mean',
                 device: typing.Optional[torch.device] = None,
                 dtype: typing.Optional[torch.dtype] = None,
                 rng: typing.Optional[RngState] = None,
                 cublas: typing.Optional[CublasHandle] = None) -> None:
        super().__init__(
            previous_layer=previous_layer, layer_id=layer_id,
            node_batcher=node_batcher)

        self.n_in_feats = n_in_feats
        self.n_out_feats = n_out_feats
        self.use_bias = bool(use_bias)
        self.dtype = dtype or torch.float32
        self.device = device or torch.device("cuda")
        self.rng = rng
        self.cublas = cublas
        if agg_op == 'mean':
            self.agg_op = AggOp.Mean
        elif agg_op == 'sum':
            self.agg_op = AggOp.Sum
        else:
            raise AssertionError(
                f"Unknown agg_op {agg_op}. Must be 'mean' or 'sum'")
        self.activation = activation
        assert dropout is None or 0 <= dropout <= 1,\
            "Dropout must be None or in [0, 1]"
        self.dropout = 0. if dropout is None else dropout
        self.linear = make_dense_layer(
            self.n_in_feats * 2, self.n_out_feats, self.use_bias,
            self.activation, self.dropout, self.device, self.dtype,
            rng=self.rng, cublas=self.cublas)

    def forward(self, in_feats: torch.Tensor) -> torch.Tensor:
        layer_info = self.node_batcher.get_info(self.layer_id)
        if layer_info.mfg.n_in_nodes <= 0 or layer_info.mfg.n_out_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling forward on this layer "
                f"({self})")
        assert in_feats.size(0) == layer_info.mfg.n_in_nodes,\
            (f"Expected input features with {layer_info.mfg.n_in_nodes} rows, "
             f"got {in_feats.size(0)}")
        agg_feats = SAGEAggregation.apply(in_feats, layer_info.mfg, self.agg_op)
        return self.linear(agg_feats)
