# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import typing

from ...utils import NodeBatcher


class NodeBatcherLayer(torch.nn.Module):
    def __init__(self,
                 previous_layer: typing.Optional[torch.nn.Module] = None,
                 layer_id: typing.Optional[int] = None,
                 node_batcher: typing.Optional[NodeBatcher] = None) -> None:
        super().__init__()
        if previous_layer is None:
            assert node_batcher is not None and layer_id is not None,\
                "If no previous layer: must have node batcher and layer id"
            self.node_batcher = node_batcher
            self.layer_id = 0
        else:
            assert node_batcher is not None or hasattr(
                previous_layer, "node_batcher"),\
                    "previous layer must have a node batcher defined"
            assert layer_id is not None or hasattr(
                previous_layer, "layer_id"),\
                    "previous layer must have a layer id defined"
            self.node_batcher = node_batcher or previous_layer.node_batcher
            self.layer_id = layer_id or previous_layer.layer_id + 1
