# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

from . import AggSimpleEdgeFgTorch, MPNConvTorch, MPNGatherTorch, MPNReadoutTorch
from . import make_bias_act_layer, make_dense_layer
from ...utils import FullGraphBatch, GraphBatcher, AggregationOp as AggOp

import torch


class MPNTorch(torch.nn.Module):

    """
    Implements the encoder part of the D-MPNN model.

    This is based on the following implementation:
    https://github.com/chemprop/chemprop/blob/master/chemprop/models/mpn.py#L14
    We assume the following arguments:
    args.atom_messages == False
    args.undirected == False
    """

    def __init__(self, graph_batcher, node_feats, edge_feats, hidden_feats,
                 depth, cublas, rng, use_bias=None, activation=None,
                 dropout=None, agg_node='mean', agg_node_factor=0.,
                 device=None, dtype='float32', is_deterministic=True,
                 is_shared=True):
        """
        Parameters
        ----------

        graph_batcher: GraphBatcher
            Graph batcher used to generate batches of graphs for this model.
        node_feats: int
            Number of input node features.
        edge_feats: int
            Number of input edge features.
        hidden_feats: int
            Number of hidden features used throughout the model.
        depth: int
            Number of edge convolution layers (hops in the graph) used
            in the model. Must be at least 1.
        cublas: internal_ext.cuda.cublashandle
            The cublas handle used for the model.
        rng: internal_ext.rng
            The random number generator used for initializing weights, and dropout.
        use_bias: bool
            Whether to use bias in linear layers.
        activation: pylibcugraphops.operators.activation_params | None
            The activation type and optional param. If None, no activation.
        dropout: float | None
            Optional dropout probability. Applied after activation.
            Random number generator is the same as for intializing weights.
        agg_node: str
            How to aggregate nodes into graphs. Must be either 'sum', 'mean' or
            'norm'
        agg_node_factor: float
            In case agg_node == 'norm', factor with which to multiply sum.
        device: torch.device
            The device used for all buffers and weights of this module.
        dtype: string
            The data type used for inputs, outputs, hidden features and weights
            of this module.
        is_deterministic: bool
            If possible, use deterministic implementations of operations.
        is_shared: bool
            If True, we share the weights of edge convolutions across depth.
        """
        super().__init__()

        torch_dtype = getattr(torch, dtype)
        self.linear_in = make_dense_layer(
            edge_feats, hidden_feats, use_bias, activation=None, dropout=0.,
            device=device, dtype=torch_dtype, rng=rng, cublas=cublas)
        self.act_in = make_bias_act_layer(
            hidden_feats, use_bias=False, activation=activation, dropout=0.,
            device=device, dtype=torch_dtype, rng=rng)
        self.depth = depth
        self.is_shared = bool(is_shared)
        if self.is_shared:
            self.convs = MPNConvTorch(
                hidden_feats, activation, dropout, use_bias, device=device,
                dtype=torch_dtype, rng=rng, cublas=cublas
            )
        else:
            self.convs = torch.nn.ModuleList([
                MPNConvTorch(
                    hidden_feats, activation, dropout, use_bias, device=device,
                    dtype=torch_dtype, rng=rng, cublas=cublas
                ) for _ in range(self.depth - 1)
            ])
        self.linear_node = make_dense_layer(
            node_feats + hidden_feats, hidden_feats, True, activation,
            dropout, device=device, dtype=torch_dtype, rng=rng, cublas=cublas)
        graph_type = graph_batcher.__class__.__name__.split("_")[-1]
        self.device = device or torch.device("cuda")
        self.readout = MPNReadoutTorch(
            hidden_feats, graph_batcher.max_batch_size(), graph_type,
            not is_deterministic, agg_node=agg_node,
            agg_node_factor=agg_node_factor, device=self.device,
            dtype=torch_dtype)

    def get_conv(self, i):
        if self.is_shared:
            return self.convs
        return self.convs[i]

    def forward(self,
                graph: FullGraphBatch,
                node_feat: torch.Tensor,
                edge_feat: torch.Tensor) -> torch.Tensor:
        # first we gather the relevant edge features
        in_node_feat, in_edge_feat = MPNGatherTorch.apply(
            node_feat, edge_feat, graph)
        in_edge_feat = self.linear_in(in_edge_feat)
        message = self.act_in(in_edge_feat)

        for d in range(self.depth - 1):
            message = self.get_conv(d)(message, in_edge_feat, graph)
        node_message = AggSimpleEdgeFgTorch.apply(message, graph, AggOp.Sum)
        node_input = torch.cat([in_node_feat, node_message], dim=1)
        node_hidden = self.linear_node(node_input)

        graph_hidden = self.readout(node_hidden, graph)
        return graph_hidden
