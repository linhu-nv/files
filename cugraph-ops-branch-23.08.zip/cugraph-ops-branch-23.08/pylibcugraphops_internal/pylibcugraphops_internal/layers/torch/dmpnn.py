# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

from . import MPNTorch, make_dense_layer
from ...utils import FullGraphBatch, GraphBatcher

import torch


class DMPNNTorch(torch.nn.Module):

    """
    Implements the full D-MPNN model.

    This is based on the following implementation:
    https://github.com/chemprop/chemprop/blob/master/chemprop/models/mpn.py#L14
    We assume the following arguments:
    args.atom_messages == False
    args.undirected == False
    """

    def __init__(self, graph_batcher, node_feats, edge_feats, hidden_feats,
                 depth, n_ffn_layers, ffn_hidden_feats, n_classes, cublas, rng,
                 use_bias=None, activation=None, dropout=None, agg_node='mean',
                 agg_node_factor=0., device=None, dtype='float32',
                 is_deterministic=True):
        """
        Parameters
        ----------

        graph_batcher: GraphBatcher
            Graph batcher used to generate batches of graphs for this model.
        node_feats: int
            Number of input node features.
        edge_feats: int
            Number of input edge features.
        hidden_feats: int
            Number of hidden features used in the MPN encoder.
        depth: int
            Number of edge convolution layers (hops in the graph) used
            in the model. Must be at least 1.
        n_ffn_layers: int
            Number of feed-forward network layers.
        ffn_hidden_feats: int
            Number of hidden features used in the feed-forward network.
        n_classes: int
            Number of output classes / features of the feed-forward network.
        cublas: internal_ext.cuda.cublashandle
            The cublas handle used for the model.
        rng: internal_ext.rng
            The random number generator used for initializing weights, and dropout.
        use_bias: bool
            Whether to use bias in linear layers.
        activation: pylibcugraphops.operators.activation_params | None
            The activation type and optional param. If None, no activation.
        dropout: float | None
            Optional dropout probability. Applied after activation.
            Random number generator is the same as for intializing weights.
        agg_node: str
            How to aggregate nodes into graphs. Must be either 'sum', 'mean' or
            'norm'
        agg_node_factor: float
            In case agg_node == 'norm', factor with which to multiply sum.
        device: torch.device
            The device used for all buffers and weights of this module.
        dtype: string
            The data type used for inputs, outputs, hidden features and weights
            of this module.
        is_deterministic: bool
            If possible, use deterministic implementations of operations.
        """
        super().__init__()

        torch_dtype = getattr(torch, dtype)
        self.mpn = MPNTorch(
            graph_batcher, node_feats, edge_feats, hidden_feats, depth, cublas,
            rng, use_bias=use_bias, activation=activation, dropout=dropout,
            agg_node=agg_node, agg_node_factor=agg_node_factor,
            device=device, dtype=dtype, is_deterministic=is_deterministic)
        self.ffn_in_feats = hidden_feats
        # note: reference implementation starts with a dropout layer here
        # but this doesn't make much sense IMO, so we omit that layer
        ffn_seq = []
        for i in range(n_ffn_layers):
            in_f = self.ffn_in_feats if i == 0 else ffn_hidden_feats
            out_f = ffn_hidden_feats if i < n_ffn_layers - 1 else n_classes
            act = activation if i < n_ffn_layers - 1 else None
            drop = dropout if i < n_ffn_layers - 1 else 0.
            ffn_seq.append(make_dense_layer(
                in_f, out_f, use_bias=True, activation=act, dropout=drop,
                device=device, dtype=torch_dtype, rng=rng, cublas=cublas
            ))
        self.ffn = torch.nn.Sequential(*ffn_seq)

    def forward(self,
                graph: FullGraphBatch,
                node_feat: torch.Tensor,
                edge_feat: torch.Tensor) -> torch.Tensor:
        graph_hidden = self.mpn(graph, node_feat, edge_feat)
        out = self.ffn(graph_hidden)
        return out
