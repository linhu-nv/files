# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

from . import NodeBatcherLayer
from ...utils import ArrayWrapperInt, NodeBatcher, FullGraphBatch


def _get_gather_func(torch_feat_type: torch.dtype,
                     idx_type: str) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    return getattr(internal_ext.torch, f"gather_{dtype}_{idx_type}")


class GatherInput(torch.autograd.Function):
    _funcs = {
        (dtype, idx_type): _get_gather_func(dtype, idx_type)
        for dtype in [torch.int32, torch.float32]
        for idx_type in ["int32", "int64"]
    }

    @staticmethod
    def forward(ctx, in_feats: torch.Tensor,
                nodes_to_gather: ArrayWrapperInt) -> torch.Tensor:
        in_feats = in_feats.contiguous()
        idx_type = nodes_to_gather.__class__.__name__.split('_')[-1]
        func = GatherInput._funcs.get((in_feats.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of gather for dtype "
                f"{in_feats.dtype} and index type {idx_type}")
        len = nodes_to_gather.length
        out_shape = (len,) if in_feats.ndim <= 1 else (len, in_feats.size(1))
        d = 1 if in_feats.ndim <= 1 else out_shape[1]
        out_feats = torch.empty(
            out_shape, dtype=in_feats.dtype, device=in_feats.device,
            requires_grad=in_feats.requires_grad)
        func(out_feats, in_feats, nodes_to_gather, d, len)
        return out_feats

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> torch.Tensor:
        grad_output = grad_output.contiguous()
        # return a value for each input to forward (None for non-tensors)
        raise NotImplementedError("No backward of gather input yet")


class GatherInputTorch(NodeBatcherLayer):
    def __init__(self, n_feats: int, node_batcher: NodeBatcher) -> None:
        super().__init__(
            previous_layer=None, layer_id=0, node_batcher=node_batcher)
        self.n_feats = n_feats

    def forward(self, in_feats: torch.Tensor) -> torch.Tensor:
        layer_info = self.node_batcher.get_info(self.layer_id)
        if layer_info.mfg.n_in_nodes <= 0 or layer_info.mfg.n_out_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling forward on this layer "
                f"({self})")
        return GatherInput.apply(in_feats, layer_info.in_nodes)


class GatherLabelsTorch(NodeBatcherLayer):
    def __init__(self, node_batcher: NodeBatcher) -> None:
        super().__init__(
            previous_layer=None, layer_id=0, node_batcher=node_batcher)
        self.n_feats = 1

    def forward(self, labels: torch.Tensor) -> torch.Tensor:
        batch_info = self.node_batcher.curr_batch()
        return GatherInput.apply(labels, batch_info.batch)


class GatherGraphLabelsTorch(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()

    def forward(self,
                graph: FullGraphBatch,
                labels: torch.Tensor) -> torch.Tensor:
        return GatherInput.apply(
            labels, internal_ext.graph.get_batch_offsets(graph)
        )
