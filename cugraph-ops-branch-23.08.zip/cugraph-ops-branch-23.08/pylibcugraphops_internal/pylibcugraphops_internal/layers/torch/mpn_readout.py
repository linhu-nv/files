# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

from . import PoolFgNodeTorch
from ...utils import FullGraphAnyNonHg, AggregationOp as AggOp

VALID_AGG = {'sum': AggOp.Sum, 'mean': AggOp.Mean, 'norm': AggOp.Sum}


class MPNReadoutTorch(torch.nn.Module):
    def __init__(self,
                 n_feats: int,
                 batch_size: int,
                 idx_type: str,
                 use_atomics: bool,
                 agg_node: str = 'mean',
                 agg_node_factor: float = 0.,
                 device: typing.Optional[torch.device] = None,
                 dtype: typing.Optional[torch.dtype] = None,
                 ) -> None:
        super().__init__()

        self.n_feats = n_feats
        self.batch_size = batch_size
        self.idx_type = idx_type
        self.use_atomics = use_atomics
        self.device = device or torch.device("cuda")
        self.dtype = dtype or torch.float32
        if agg_node not in VALID_AGG:
            raise ValueError(f"Invalid aggregation mode '{agg_node}'")
        self.agg_op = VALID_AGG[agg_node]
        self.agg_node_factor = agg_node_factor if agg_node == 'norm' else None

        self.buffers = PoolFgNodeTorch.make_buffers(
            self.dtype, self.device, self.idx_type, self.n_feats,
            self.batch_size, self.agg_op, self.use_atomics)

    def forward(self,
                node_feat: torch.Tensor,
                graph: FullGraphAnyNonHg
                ) -> torch.Tensor:
        assert node_feat.size(1) == self.n_feats,\
            f"Expected {self.n_feats} but got {node_feat.size(1)}"
        bs = graph.batch_size if "batch" in graph.__class__.__name__ else 1
        if bs == self.batch_size:
            buffers = self.buffers
        else:
            buffers = PoolFgNodeTorch.make_buffers(
                self.dtype, self.device, self.idx_type, self.n_feats,
                bs, self.agg_op, self.use_atomics)

        out = PoolFgNodeTorch.apply(
            node_feat, graph, self.agg_op, self.use_atomics, *buffers)
        if self.agg_node_factor is not None:
            out = out * self.agg_node_factor
        return out
