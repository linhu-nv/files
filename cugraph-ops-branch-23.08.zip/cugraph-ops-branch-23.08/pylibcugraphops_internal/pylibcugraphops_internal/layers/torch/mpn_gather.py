# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

from ...utils import FullGraphBatch


def _get_gather_func(torch_feat_type: torch.dtype, idx_type: str) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    return getattr(internal_ext.torch, f"gather_batch_{dtype}_{idx_type}")


class MPNGatherTorch(torch.autograd.Function):
    _fwd_funcs = {
        (dtype, idx_type): _get_gather_func(dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }

    @staticmethod
    def forward(ctx,
                in_node_feat: torch.Tensor,
                in_edge_feat: torch.Tensor,
                graph: FullGraphBatch) -> torch.Tensor:
        in_node_feat = in_node_feat.contiguous()
        in_edge_feat = in_edge_feat.contiguous()
        e = "gather_batch: node and edge features must have same dtype and device"
        assert (in_node_feat.dtype == in_edge_feat.dtype and
                in_node_feat.device == in_edge_feat.device), e
        idx_type = graph.__class__.__name__.split('_')[-1]
        func = MPNGatherTorch._fwd_funcs.get((in_node_feat.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of MPN aggregation for dtype "
                f"{in_node_feat.dtype} and index type {idx_type}")
        d_node = in_node_feat.size(1)
        out_node_feat = torch.empty(
            (graph.n_nodes, d_node), dtype=in_node_feat.dtype,
            device=in_node_feat.device,
            requires_grad=in_node_feat.requires_grad)
        d_edge = in_edge_feat.size(1)
        out_edge_feat = torch.empty(
            (graph.n_edges, d_edge), dtype=in_edge_feat.dtype,
            device=in_edge_feat.device,
            requires_grad=in_edge_feat.requires_grad)
        func(out_node_feat, out_edge_feat, in_node_feat, in_edge_feat, graph,
             d_node, d_edge)
        ctx.graph = graph
        return out_node_feat, out_edge_feat

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> torch.Tensor:
        grad_output = grad_output.contiguous()
        raise NotImplementedError("No backward of gather_batch yet")
