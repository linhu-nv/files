# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

from . import make_dense_layer, make_bias_act_layer
from ...utils import CublasHandle, FullGraphBatch, RngState


def _get_agg_func(is_fwd: bool, torch_feat_type: torch.dtype, idx_type: str
                  ) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    f = "fwd" if is_fwd else "bwd"
    return getattr(internal_ext.torch,
        f"agg_dmpnn_fg_e2e_{f}_{dtype}_{idx_type}")


class MPNAggregation(torch.autograd.Function):
    _fwd_funcs = {
        (dtype, idx_type): _get_agg_func(True, dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }
    _bwd_funcs = {
        (dtype, idx_type): _get_agg_func(False, dtype, idx_type)
        for dtype in [torch.float32] for idx_type in ["int32", "int64"]
    }

    @staticmethod
    def forward(ctx,
                edge_feat: torch.Tensor,
                graph: FullGraphBatch) -> torch.Tensor:
        edge_feat = edge_feat.contiguous()
        idx_type = graph.__class__.__name__.split('_')[-1]
        func = MPNAggregation._fwd_funcs.get((edge_feat.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of MPN aggregation for dtype "
                f"{edge_feat.dtype} and index type {idx_type}")
        d = edge_feat.size(1)
        out_feats = torch.empty(
            (graph.n_edges, d), dtype=edge_feat.dtype,
            device=edge_feat.device, requires_grad=edge_feat.requires_grad)
        func(out_feats, edge_feat, d, graph, False)
        ctx.graph = graph
        return out_feats

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> torch.Tensor:
        grad_output = grad_output.contiguous()
        idx_type = ctx.graph.__class__.__name__.split('_')[-1]
        func = MPNAggregation._bwd_funcs.get((grad_output.dtype, idx_type), None)
        if not func:
            raise ValueError("No implementation of MPN aggregation for dtype "
                f"{grad_output.dtype} and index type {idx_type}")
        d = grad_output.size(1)
        grad_input = torch.empty(
            (ctx.graph.n_edges, d), dtype=grad_output.dtype,
            device=grad_output.device)
        func(grad_input, grad_output, d, ctx.graph, False)
        # return a value for each input to forward (None for non-tensors)
        return grad_input, None


class MPNConvTorch(torch.nn.Module):
    def __init__(self,
                 n_feats: int,
                 activation: typing.Optional[torch.nn.Module] = None,
                 dropout: typing.Optional[float] = None,
                 use_bias: typing.Optional[bool] = None,
                 device: typing.Optional[torch.device] = None,
                 dtype: typing.Optional[torch.dtype] = None,
                 rng: typing.Optional[RngState] = None,
                 cublas: typing.Optional[CublasHandle] = None) -> None:
        super().__init__()

        self.n_feats = n_feats
        self.activation = activation
        assert dropout is None or 0 <= dropout <= 1,\
            "Dropout must be None or in [0, 1]"
        self.dropout = 0. if dropout is None else dropout
        self.use_bias = bool(use_bias)
        self.device = device or torch.device("cuda")
        self.dtype = dtype or torch.float32
        self.rng = rng
        self.cublas = cublas

        # no activation/dropout in linear layer since we need to
        # add original input between linear and activation/dropout
        self.linear = make_dense_layer(
            self.n_feats, self.n_feats, self.use_bias, None, 0., self.device,
            self.dtype, rng=self.rng, cublas=self.cublas)
        self.act_drop = make_bias_act_layer(
            self.n_feats, False, self.activation, self.dropout, self.device,
            self.dtype, rng=self.rng)

    def forward(self,
                message: torch.Tensor,
                orig_input: torch.Tensor,
                graph: FullGraphBatch
                ) -> torch.Tensor:
        assert message.size() == orig_input.size(),\
            ("Expected message size and original input size to be the same, "
             f"got {message.size()} and {orig_input.size()}")
        assert message.size(0) == graph.n_edges,\
            ("Expected message with #rows == #edges of graph == "
             f"{graph.n_edges}, got {message.size(0)}")

        message = MPNAggregation.apply(message, graph)
        message = self.linear(message)
        message = self.act_drop(message + orig_input)
        return message
