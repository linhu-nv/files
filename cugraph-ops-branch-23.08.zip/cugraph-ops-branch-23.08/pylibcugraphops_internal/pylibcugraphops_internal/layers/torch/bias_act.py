# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext
from pylibcugraphops.operators import activation_params

import math
import torch
import typing

from ...utils import ActivationOp, RngState

logger = internal_ext.utils.logger

TORCH_TO_OPS_ACTIVATION_TYPE = {
    "ReLU": (ActivationOp.ReLU, None),
    "Sigmoid": (ActivationOp.Sigmoid, None),
    "Tanh": (ActivationOp.Tanh, None),
    "ELU": (ActivationOp.ELU, None),
    "LeakyReLU": (ActivationOp.LeakyReLU, "negative_slope"),
    "NoneType": (ActivationOp.Linear, None),
}


def _get_bias_func(is_fwd: bool, torch_feat_type: torch.dtype) -> typing.Callable:
    dtype = str(torch_feat_type).split(".")[-1]
    f = "fwd" if is_fwd else "bwd"
    return getattr(internal_ext.torch, f"bias_activation_{f}_{dtype}")


class BiasActOp(torch.autograd.Function):
    _fwd_funcs = {
        dtype: _get_bias_func(True, dtype) for dtype in [torch.float32]
    }
    _bwd_funcs = {
        dtype: _get_bias_func(False, dtype) for dtype in [torch.float32]
    }

    @staticmethod
    def forward(ctx, in_feats: torch.Tensor,
                bias: typing.Optional[torch.Tensor], activation: ActivationOp,
                dropout: float, rng: typing.Optional[RngState]) -> torch.Tensor:
        in_feats = in_feats.contiguous()
        bias = None if bias is None else bias.contiguous()
        func = BiasActOp._fwd_funcs.get(in_feats.dtype, None)
        if not func:
            raise ValueError(
                "No implementation of bias-activation for dtype "
                f"{in_feats.dtype}")
        assert bias is None or in_feats.device == bias.device,\
            "Input features and bias must be on same device"
        out_feats = torch.empty_like(
            in_feats, requires_grad=in_feats.requires_grad)
        if dropout > 0:
            drop_v = torch.empty((2,), dtype=torch.int64,
                                 device=torch.device('cpu'), pin_memory=True)
        else:
            drop_v = None
        func(out_feats, in_feats, bias, in_feats.size(0), in_feats.size(1),
             in_feats.size(1), activation, drop_v, dropout, rng)
        ctx.save_for_backward(in_feats, bias, out_feats, drop_v)
        ctx.activation = activation
        ctx.dropout = dropout
        return out_feats

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor
                ) -> typing.Tuple[
                    typing.Optional[torch.Tensor],
                    typing.Optional[torch.Tensor],
                    None,
                    None,
                    None,
                    ]:
        grad_output = grad_output.contiguous()
        need_in_grad, need_b_grad = ctx.needs_input_grad[:2]
        in_feats, bias, out_feats, drop_v = ctx.saved_tensors
        func = BiasActOp._bwd_funcs.get(grad_output.dtype, None)
        if not func:
            raise ValueError(
                "No implementation of bias-activation for dtype "
                f"{grad_output.dtype}")
        grad_in = torch.empty_like(in_feats) if need_in_grad else None
        grad_bias = torch.empty_like(bias) if need_b_grad else None
        func(grad_in, grad_bias, grad_output, out_feats, in_feats,
             bias, in_feats.size(0), in_feats.size(1), in_feats.size(1),
             ctx.activation, drop_v, ctx.dropout)
        # return a value for each input to forward (None for non-tensors)
        return grad_in, grad_bias, None, None, None


class BiasActTorch(torch.nn.Module):
    def __init__(self,
                 n_feats: int,
                 device: torch.device,
                 dtype: torch.dtype,
                 use_bias: bool = True,
                 activation: typing.Optional[ActivationOp] = None,
                 dropout: typing.Optional[float] = None,
                 rng: typing.Optional[RngState] = None) -> None:
        super().__init__()
        self.n_feats = n_feats
        self.rng = rng
        factory_kwargs = {'device': device, 'dtype': dtype}
        if use_bias:
            self.bias = torch.nn.Parameter(
                torch.empty((self.n_feats,), **factory_kwargs))
        else:
            self.register_parameter('bias', None)
        self.activation = activation or activation_params()
        assert dropout is None or 0 <= dropout <= 1,\
            "Dropout must be None or in [0, 1]"
        self.dropout = 0. if dropout is None else dropout
        self.reset_parameters()

    def reset_parameters(self) -> None:
        # see torch.nn.Linear, fan in must be the only #features we have
        if self.bias is not None:
            fan_in = self.n_feats
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            torch.nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, in_feats: torch.Tensor) -> torch.Tensor:
        return BiasActOp.apply(
            in_feats, self.bias, self.activation, self.dropout, self.rng)


def make_bias_act_layer(n_feats: int,
                        use_bias: bool,
                        activation: typing.Optional[torch.nn.Module],
                        dropout: float,
                        device: torch.device,
                        dtype: torch.dtype,
                        rng: typing.Optional[RngState] = None
                        ) -> torch.nn.Module:
    ops_act_type = TORCH_TO_OPS_ACTIVATION_TYPE.get(
        activation.__class__.__name__, None)
    if ops_act_type and rng is not None:
        ops_act = activation_params()
        ops_act.type = ops_act_type[0]
        if ops_act_type[1]:
            ops_act.alpha = getattr(activation, ops_act_type[1])
        return BiasActTorch(
            n_feats, device=device, dtype=dtype, use_bias=use_bias,
            activation=ops_act, dropout=dropout, rng=rng)

    if ops_act_type:
        logger.warn("pylibcugraphops_internal.layers.torch.dense warning: "
                    "make_bias_act_layer: rng handle not provided, "
                    "but activation could be handled by cugraph_ops.\n")

    if use_bias:
        # create a cugraph-ops bias layer anyway, but only for bias
        seq = [BiasActTorch(n_feats, device=device, dtype=dtype, use_bias=True)]
    else:
        seq = []
    if activation:
        seq.append(activation)
    if dropout > 0:
        seq.append(torch.nn.Dropout(p=dropout))
    if len(seq) == 1:
        return seq[0]
    return torch.nn.Sequential(*seq)
