# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import pylibcugraphops_internal_ext as internal_ext
from pylibcugraphops.operators import activation_params

from . import BufferedLayer
from ..utils import make_host_buffer, null_wrapper


class RGCNConv(BufferedLayer):

    """
    Implements a RGCN conv layer used for Relational Graph Convolution models.

    Before you can successfully call forward, you must have sampled a batch
    using the given node_batcher, and you must provide the full node feature
    matrix in `layer0.get_input_buffers()[0]` where `layer0` is the first layer
    of the model.
    """

    def __init__(
        self,
        out_feats,
        previous_layer=None,
        in_feats=None,
        cublas=None,
        rng=None,
        node_batcher=None,
        layer_id=None,
        hg_type="basis_post",
        n_bases=0,
        concat_own=None,
        do_norm=None,
        activation=None,
        dropout=None,
        use_reverse_graph=False,
        name=None,
        dtype="float32",
    ):
        """
        Parameters
        ----------

        out_feats: int
            Number of output features of this layer
        previous_layer: pylibcugraphops_internal.layers.SAGEConv
            The previous layer in the model.
            If given, the `in_feats`, `cublas`, `rng`, `node_batcher`
            and `layer_id` arguments will be inferred.
        in_feats: int | None
            Number of input features of this layer.
            If None, previous_layer is required to infer this.
        cublas: internal_ext.cuda.cublashandle | None
            The cublas handle used for this layer.
            If None, previous_layer is required to infer this.
        rng: internal_ext.rng_state | None
            The random number generator used for initializing weights.
            If None, previous_layer is required to infer this.
        node_batcher: internal_ext.node_batcher_*
            The node batcher used for the graph.
            If None, previous_layer is required to infer this.
        layer_id: int | None
            The ID of the layer w.r.t. the given node batcher.
            If None, previous_layer is required to infer this.
        hg_type: str
            The type of regularizer used for heterogeneous graph support.
            Can be 'basis_post', 'basis_pre' or 'bdd'.
            At the moment, only 'basis_post' is supported
        n_bases: int | None
            Number of bases for regularizer.
            If None or <= 0, the number of edge types will be used, without
            basis combination weights.
        concat_own: bool | None
            Whether to add weights for transforming input features without
            aggreagtion for each output node. By default, True.
        do_norm: bool | None
            Whether to norm aggregated features by output node degree.
            By default, True.
        activation: pylibcugraphops.operators.activation_params | None
            The activation type and optional param. If None, no activation.
        dropout: float | None
            Optional dropout probability. Applied after activation.
            Random number generator is the same as for intializing weights.
        use_reverse_graph: None | bool
            Whether to use reverse graph for backward ops. Makes the layer
            deterministic and can alter performance.
            If None, node_batcher.do_reverse is used to infer this.
            At the moment, only False is supported.
        name: string
            Name of the layer for debug/reporting purposes.
            If None, a default name (SAGEConv{x}) is given.
        dtype: string
            The data type used for inputs/outputs of this layer
        """
        assert previous_layer is None or isinstance(
            previous_layer, RGCNConv
        ), "previous_layer must be None or a RGCNConv instance"
        if node_batcher is None:
            assert (
                previous_layer is not None
            ), "previous layer required if node batcher is None"
            stream = previous_layer.stream
        else:
            stream = node_batcher.get_stream()
        super(RGCNConv, self).__init__(
            name, dict(), dict(), dict(), dict(), [], stream, dtype
        )
        self.out_feats = out_feats
        self.previous_layer = previous_layer
        self.in_feats = self._from_previous(
            in_feats, previous_layer, "in_feats", "out_feats"
        )
        self.cublas = self._from_previous(cublas, previous_layer, "cublas")
        self.rng = self._from_previous(rng, previous_layer, "rng")
        self.node_batcher = self._from_previous(
            node_batcher, previous_layer, "node_batcher"
        )
        self.layer_id = self._from_previous(layer_id, previous_layer, "layer_id")
        if layer_id is None:
            # need to increase the layer id from previous layer
            self.layer_id += 1
        assert self.layer_id >= 0, "layer_id must be non-negative"
        self.info_init = self.node_batcher.get_info(self.layer_id)
        self.n_max_out = self.info_init.max_out_nodes
        if self.layer_id == 0:
            self.n_max_in = self.n_max_out * (self.info_init.sample_size + 1)
        else:
            prev_info = self.node_batcher.get_info(self.layer_id - 1)
            self.n_max_in = prev_info.max_out_nodes
        hg_type = hg_type.lower()
        assert hg_type in [
            "basis_post"
        ], f"Only 'basis_post' HG types supported, got {hg_type}"
        self.n_edge_types = self.info_init.mfg.n_edge_types
        if n_bases is None or n_bases <= 0:
            self.n_bases = self.n_edge_types
        else:
            self.n_bases = n_bases
        self.concat_own = True if concat_own is None else bool(concat_own)
        self.agg_out_feats = self.in_feats * (
            self.n_bases + (1 if self.concat_own else 0)
        )
        self.do_norm = True if do_norm is None else bool(do_norm)

        self.activation = activation or activation_params()
        assert dropout is None or 0 <= dropout <= 1, "Dropout must be None or in [0, 1]"
        self.dropout = 0.0 if dropout is None else dropout
        if use_reverse_graph:
            assert (
                self.node_batcher.do_reverse()
            ), "Node batcher must compute reverse graph to use reverse ops"
        if use_reverse_graph is None:
            self.do_rev = self.node_batcher.do_reverse()
        else:
            self.do_rev = bool(use_reverse_graph)
        self.idx_type = self.node_batcher.__class__.__name__.split("_")[-1]
        self.agg_fwd = getattr(
            internal_ext.layers, f"agg_hg_{hg_type}_fwd_{self.dtype}_{self.idx_type}"
        )
        self.agg_bwd = getattr(
            internal_ext.layers, f"agg_hg_{hg_type}_bwd_{self.dtype}_{self.idx_type}"
        )
        self.dense_fwd = getattr(internal_ext.layers, f"dense_fwd_{self.dtype}")
        self.dense_bwd = getattr(internal_ext.layers, f"dense_bwd_{self.dtype}")
        self.gather = getattr(
            internal_ext.layers, f"gather_{self.dtype}_{self.idx_type}"
        )

        # input buffer
        if previous_layer is None:
            agg_in = self._make_buffer(self.n_max_in * self.in_feats)
        else:
            agg_in = previous_layer.get_output_buffers()[0]
        self.fwd_inputs["agg_in"] = agg_in

        # buffers for aggregation
        if self.n_bases < self.n_edge_types:
            self._add_buffer("in", self.n_edge_types * self.n_bases, "agg_w")
        else:
            self.fwd_inputs["agg_w"] = null_wrapper(self.dtype)
        self._add_buffer("out", self.n_max_out * self.agg_out_feats, "agg_out")

        # buffer for linear layer
        self.fwd_inputs["fc_in"] = self.fwd_outputs["agg_out"]
        self._add_buffer("in", self.out_feats * self.agg_out_feats, "fc_w")
        self._add_buffer("in", self.out_feats, "fc_b")
        self._add_buffer("out", self.n_max_out * self.out_feats, "fc_int")
        self._add_buffer("out", self.n_max_out * self.out_feats, "final_out")

        # require an additional buffer for dropout values
        if self.dropout <= 0:
            self.fwd_outputs["fc_drop"] = null_wrapper("uint64")
        else:
            self.fwd_outputs["fc_drop"] = make_host_buffer(2, "uint64", self.stream)

        # buffers for backward of linear layer
        # we can re-use the same buffer for data gradient as input of linear
        self.bwd_outputs["fc_gin"] = self.fwd_inputs["fc_in"]
        self.bwd_outputs["fc_gint"] = self.fwd_outputs["fc_int"]
        self._add_buffer("bwd_out", self.out_feats * self.agg_out_feats, "fc_gw")
        self._add_buffer("bwd_out", self.out_feats, "fc_gb")
        self._add_buffer("bwd_in", self.n_max_out * self.out_feats, "g_final_out")

        # buffers for backward of aggregation
        if previous_layer is None:
            self.bwd_outputs["agg_gin"] = null_wrapper(self.dtype)
        else:
            b = previous_layer.get_grad_input_buffers()[0]
            self.bwd_outputs["agg_gin"] = b
        if self.n_bases < self.n_edge_types:
            self._add_buffer("bwd_out", self.n_edge_types * self.n_bases, "agg_gw")
        else:
            self.bwd_outputs["agg_gw"] = null_wrapper(self.dtype)
        # gradient input of aggregation is gradient output of linear
        self.bwd_inputs["agg_gout"] = self.bwd_outputs["fc_gin"]

        # this will be used to place the intial input for the initial layer
        self.fwd_inputs["init_in"] = None
        self._inputs = [self.fwd_inputs["init_in"]]
        self._outputs = [self.fwd_outputs["final_out"]]
        self._g_inputs = [self.bwd_inputs["g_final_out"]]

        # initialize weights and bias
        # DGL's initialization is a bit strange. Because of how the
        # main basis weight tensor is ordered, they initialize with
        # xavier uniform (gain x sqrt(6 / (fan_in + fan_out))),
        # with a gain of sqrt(2), fan_in = in_feat * out_feat
        # and fan_out = n_bases * out_feat
        # Instead we choose to simply initialize the full matrix using
        # kaiming uniform (gain / sqrt(fan_in)),
        # with the full fan_in = (n_bases +1?) * in_feat and gain sqrt(1/3)
        # for bias and sqrt(2) for weights, which is default for relu layers
        # for the aggregation weights, we use He/kaiming initialization
        init_w = getattr(internal_ext.layers, f"init_weights_{self.dtype}")
        if self.n_bases < self.n_edge_types:
            init_w(
                w=self.fwd_inputs["agg_w"],
                n=self.n_edge_types * self.n_bases,
                n_fan=self.n_edge_types + self.n_bases,
                rng=self.rng,
                stream=self.stream,
            )
        init_w(
            w=self.fwd_inputs["fc_b"],
            n=self.out_feats,
            n_fan=self.agg_out_feats,
            gain=1.0 / math.sqrt(3),
            rng=self.rng,
            stream=self.stream,
        )
        init_w(
            w=self.fwd_inputs["fc_w"],
            n=self.out_feats * self.agg_out_feats,
            n_fan=self.agg_out_feats,
            rng=self.rng,
            stream=self.stream,
        )

    def _get_weight_buffers(self):
        wb = [self.fwd_inputs["fc_w"], self.fwd_inputs["fc_b"]]
        if self.n_bases < self.n_edge_types:
            wb += [self.fwd_inputs["agg_w"]]
        return wb

    def _get_grad_buffers(self):
        gb = [self.bwd_outputs["fc_gw"], self.bwd_outputs["fc_gb"]]
        if self.n_bases < self.n_edge_types:
            gb += [self.bwd_outputs["agg_gw"]]
        return gb

    def get_input_buffers(self):
        return self._inputs

    def get_output_buffers(self):
        return self._outputs

    def get_grad_input_buffers(self):
        return self._g_inputs

    def fwd_impl(self):
        layer_info = self.node_batcher.get_info(self.layer_id)
        n_in_nodes = layer_info.mfg.n_in_nodes
        n_out_nodes = layer_info.mfg.n_out_nodes
        if n_out_nodes <= 0 or n_in_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling forward on this layer "
                f"({self})"
            )
        if self.previous_layer is None:
            if self.get_input_buffers()[0] is None:
                raise ValueError(
                    "Please provide an input for the initial layer as "
                    "an `ArrayWrapper` in `layer.get_input_buffers()[0]`"
                )
            # we should first gather the node features into `agg_in` renumbered
            # in the way that the aggregation layer expects it (for its input)
            self.gather(
                self.fwd_inputs["agg_in"],
                self.get_input_buffers()[0],
                layer_info.in_nodes,
                self.in_feats,
                n_in_nodes,
                self.stream,
            )
        self.agg_fwd(
            self.fwd_outputs["agg_out"],
            self.fwd_inputs["agg_in"],
            self.fwd_inputs["agg_w"],
            self.in_feats,
            self.n_bases,
            layer_info.mfg,
            self.concat_own,
            self.do_norm,
            self.stream,
        )
        self.dense_fwd(
            self.fwd_outputs["final_out"],
            self.fwd_outputs["fc_int"],
            self.out_feats,
            self.fwd_inputs["fc_in"],
            self.agg_out_feats,
            self.fwd_inputs["fc_w"],
            self.agg_out_feats,
            self.fwd_inputs["fc_b"],
            n_out_nodes,
            self.out_feats,
            self.agg_out_feats,
            self.activation,
            self.fwd_outputs["fc_drop"],
            self.dropout,
            self.rng,
            self.cublas,
            self.stream,
        )

    def bwd_impl(self):
        layer_info = self.node_batcher.get_info(self.layer_id)
        n_in_nodes = layer_info.mfg.n_in_nodes
        n_out_nodes = layer_info.mfg.n_out_nodes
        if n_out_nodes <= 0 or n_in_nodes <= 0:
            raise ValueError(
                f"You have to sample a batch using the provided node batcher "
                f"{self.node_batcher} before calling backward on this layer "
                f"({self})"
            )
        self.dense_bwd(
            self.bwd_outputs["fc_gin"],
            self.bwd_outputs["fc_gw"],
            self.bwd_outputs["fc_gb"],
            self.bwd_outputs["fc_gint"],
            self.bwd_inputs["g_final_out"],
            self.fwd_outputs["final_out"],
            self.fwd_outputs["fc_int"],
            self.out_feats,
            self.fwd_inputs["fc_in"],
            self.agg_out_feats,
            self.fwd_inputs["fc_w"],
            self.agg_out_feats,
            self.fwd_inputs["fc_b"],
            n_out_nodes,
            self.out_feats,
            self.agg_out_feats,
            self.activation,
            self.fwd_outputs["fc_drop"],
            self.dropout,
            self.cublas,
            self.stream,
        )
        if self.do_rev:
            raise NotImplementedError
        else:
            self.agg_bwd(
                self.bwd_outputs["agg_gin"],
                self.bwd_outputs["agg_gw"],
                self.bwd_inputs["agg_gout"],
                self.fwd_inputs["agg_in"],
                self.fwd_inputs["agg_w"],
                self.in_feats,
                self.n_bases,
                layer_info.mfg,
                self.concat_own,
                self.do_norm,
                self.stream,
            )
