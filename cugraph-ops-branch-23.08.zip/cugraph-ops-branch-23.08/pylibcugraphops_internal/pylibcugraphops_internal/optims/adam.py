# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext as internal_ext

from . import Optim

from ..utils import make_device_buffer


class Adam(Optim):

    """
    ADAM optimizer
    """

    def __init__(self, layer, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 stream=None, name=None):
        """
        Parameters
        ----------

        layer: pylibcugraphops_internal.layers.Layer
            The layer which should be optimized by this optimizer
        lr: float
            The learning rate
        betas: Tuple[float, float]
            The beta parameters. By default, (0.9, 0.999)
        eps: float
            Numerical smoothing/stability parameter
        stream: internal_ext.cuda.stream | None
            The stream used for applying the update.
            If None, inferred from layer
        name: string
            Name of the layer for debug/reporting purposes.
        """
        super(Adam, self).__init__(layer, name)
        self.eta = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        dtypes = [leaf.dtype for leaf in self.layer.iter_leaf_layers()]
        dtype_set = set(dtypes)
        if len(dtype_set) != 1:
            raise ValueError(f"All leaf layers must have the same data type. "
                             f"Got the following: {dtype_set}")
        self.dtype = dtypes[0]
        self.stream = stream or self.layer.get_last().stream
        self.update_fn = getattr(internal_ext.optims,
                                 f"adam_update_{self.dtype}")
        self._register_additional_buffers(
            [self._make_additional_buffers(w) for w in self._weights])

    def _make_additional_buffers(self, w):
        return [
            make_device_buffer(w.length, self.dtype, self.stream),
            make_device_buffer(w.length, self.dtype, self.stream)
        ]

    def _apply(self, w, g, additional_buffers=None):
        assert len(additional_buffers) == 2,\
               "Expected momentum and 2nd momentum buffers for _apply"
        m, v = additional_buffers
        self.update_fn(w, m, v, g, self.beta1, self.beta2, self.eta, self.eps,
                       w.length, self.n_steps, self.stream)
