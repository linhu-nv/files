# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ..utils import NamedObject


class Optim(NamedObject):

    """
    Abstract base class for all optimizers.
    """

    def __init__(self, layer, name=None):
        """
        Parameters
        ----------

        layer: pylibcugraphops_internal.layers.Layer
            The layer which should be optimized by this optimizer
        name: string
            Name of the layer for debug/reporting purposes.
        """
        super(Optim, self).__init__(name)
        self.layer = layer
        self._weights = list(self.layer.iter_weights())
        self._grads = list(self.layer.iter_grads())
        assert len(self._weights) == len(self._grads),\
            f"Incompatible lengths of weights and gradients: "\
            f"({len(self._weights)} != {len(self._grads)})"
        self._buffers = [None for _ in self._weights]
        self.n_steps = 0

    def _register_additional_buffers(self, buffers):
        if len(buffers) != len(self._weights):
            raise ValueError(f"Attempting to register buffers with length "
                             f"{len(buffers)} while optimizer expects "
                             f"{len(self._weights)}")
        self._buffers = buffers

    def _apply(self, w, g, **kwargs):
        raise NotImplementedError("Must be implemented by all optimizers")

    def step(self):
        for w, g, bfs in zip(self._weights, self._grads, self._buffers):
            self._apply(w, g, additional_buffers=bfs)
        self.n_steps += 1
