# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops
import pylibcugraphops_internal_ext as internal_ext


def test_node_batcher():
    s = internal_ext.cuda.stream()
    r = internal_ext.rng_state(1234)
    n_nodes = 1000
    n_indices = 40000
    batch_size = 100
    g = pylibcugraphops.fg_csr_int32()
    internal_ext.graph.generate_csr_on_device(
        g, r, n_nodes, n_indices, False, s
    )
    for sampling_algo in [internal_ext.graph.SamplingAlgo.ReservoirAlgoR,
                          internal_ext.graph.SamplingAlgo.ReservoirAlgoLST]:
        b = internal_ext.node_batcher_int32(
            g, [25, 10], batch_size, n_nodes, r, sampling_algo, s)
        assert b.num_batches() == (n_nodes / batch_size)
        assert b.num_layers() == 2
        assert b.next_batch() is not None
        assert b.curr_batch() is not None
    s.sync()
    internal_ext.graph.delete_csr_from_device(g, s)
