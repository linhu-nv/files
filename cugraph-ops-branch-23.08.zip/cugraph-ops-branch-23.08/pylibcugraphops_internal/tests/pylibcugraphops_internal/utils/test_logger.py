# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops_internal_ext

logger = pylibcugraphops_internal_ext.utils.logger


def test_logger_get_set_log_level():
    logger.set_log_level(logger.LEVEL_INFO)
    assert logger.get_log_level() == logger.LEVEL_INFO


def test_logger_will_log_for():
    logger.set_log_level(logger.LEVEL_WARN)
    assert logger.will_log_for(logger.LEVEL_FATAL)
    assert logger.will_log_for(logger.LEVEL_ERROR)
    assert logger.will_log_for(logger.LEVEL_WARN)
    assert not logger.will_log_for(logger.LEVEL_INFO)
    assert not logger.will_log_for(logger.LEVEL_DEBUG)
    assert not logger.will_log_for(logger.LEVEL_TRACE)
    logger.set_log_level(logger.LEVEL_INFO)


def test_logger():
    logger.info("This is an info level message\n")
