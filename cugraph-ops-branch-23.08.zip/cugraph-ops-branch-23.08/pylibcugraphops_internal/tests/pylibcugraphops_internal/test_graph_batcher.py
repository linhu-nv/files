# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops
import pylibcugraphops_internal_ext as internal_ext


def test_graph_batcher():
    s = internal_ext.cuda.stream()
    r = internal_ext.rng_state(1234)
    n_graphs = 1000
    n_nodes = 40
    n_indices = 100
    batch_size = 100
    g = pylibcugraphops.fg_csr_seq_int32()
    internal_ext.graph.generate_csr_seq_on_device(
        g, r, n_graphs, n_nodes, n_indices, False, s
    )
    b = internal_ext.graph_batcher_int32(g, batch_size, True, r, s)
    assert b.num_batches() == (n_graphs / batch_size)
    assert b.next_batch() is not None
    assert b.curr_batch() is not None
    s.sync()
    internal_ext.graph.delete_csr_seq_from_device(g, s)
