# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops
import pylibcugraphops_internal_ext as internal_ext


def test_csr_generator_int32():
    s = internal_ext.cuda.stream()
    r = internal_ext.rng_state(1234)
    n_nodes = 100
    n_indices = 1000
    g = pylibcugraphops.fg_csr_int32()
    assert g is not None
    internal_ext.graph.generate_csr_on_device(
        g, r, n_nodes, n_indices, False, s
    )
    assert g.n_nodes == n_nodes
    assert g.n_indices == n_indices
    s.sync()
    internal_ext.graph.delete_csr_from_device(g, s)


def test_csr_generator_int64():
    s = internal_ext.cuda.stream()
    r = internal_ext.rng_state(1234)
    n_nodes = 100
    n_indices = 1000
    g = pylibcugraphops.fg_csr_int64()
    assert g is not None
    internal_ext.graph.generate_csr_on_device(
        g, r, n_nodes, n_indices, False, s
    )
    assert g.n_nodes == n_nodes
    assert g.n_indices == n_indices
    s.sync()
    internal_ext.graph.delete_csr_from_device(g, s)


def test_csr_generator_undirected_int32():
    s = internal_ext.cuda.stream()
    r = internal_ext.rng_state(1234)
    n_nodes = 100
    n_indices = 1000
    g = pylibcugraphops.fg_csr_int32()
    assert g is not None
    internal_ext.graph.generate_csr_on_device(
        g, r, n_nodes, n_indices, True, s
    )
    assert g.n_nodes == n_nodes
    assert g.n_indices == n_indices
    s.sync()
    internal_ext.graph.delete_csr_from_device(g, s)


def test_csr_generator_undirected_int64():
    s = internal_ext.cuda.stream()
    r = internal_ext.rng_state(1234)
    n_nodes = 100
    n_indices = 1000
    g = pylibcugraphops.fg_csr_int64()
    assert g is not None
    internal_ext.graph.generate_csr_on_device(
        g, r, n_nodes, n_indices, True, s
    )
    assert g.n_nodes == n_nodes
    assert g.n_indices == n_indices
    s.sync()
    internal_ext.graph.delete_csr_from_device(g, s)
