# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import torch_scatter
from torch_geometric.utils.random import erdos_renyi_graph

DEG_EPS = 1.0e-15


def test_pyg():
    # graph: 0 links to 1 and 2
    # graph: 1 links to 1, 2, 3
    # graph: 2 links to 3
    # graph: 3 links to 1 and 2
    # i.e. 0 has no incoming edge
    # 1, 2, 3 have incoming and outgoing edges
    edge_index = torch.LongTensor(
        [[0, 0, 0, 1, 1, 1, 2, 3, 3], [1, 2, 3, 1, 2, 3, 3, 1, 3]]
    ).to("cuda")
    # 4 nodes, dim=8
    node_feat = torch.rand(4, 8, device="cuda", dtype=torch.float)

    row, col = edge_index
    edge_feat = node_feat[row]
    print("max")
    out, out_pos = torch_scatter.scatter_max(edge_feat, col.view(-1, 1), dim=0)
    print(out)
    print(out_pos)
    print()

    print("min")
    out, out_pos = torch_scatter.scatter_min(edge_feat, col.view(-1, 1), dim=0)
    print(out)
    print(out_pos)
    print()

    print("mean")
    out = torch_scatter.scatter_mean(edge_feat, col.view(-1, 1), dim=0)
    print(out)
    print()

    print("sum")
    out = torch_scatter.scatter_sum(edge_feat, col.view(-1, 1), dim=0)
    print(out)
    print()


def agg_weighted_pyg(node_feat, edge_index, edge_weight, op, return_degree=False):
    row, col = edge_index
    edge_feat = node_feat[row] * edge_weight.view(-1, 1)
    deg = torch_scatter.scatter_sum(edge_weight, col, dim=0)

    if op == "max":
        out, out_pos = torch_scatter.scatter_max(edge_feat, col.view(-1, 1), dim=0)
    elif op == "min":
        out, out_pos = torch_scatter.scatter_min(edge_feat, col.view(-1, 1), dim=0)
    elif op == "sum":
        out = torch_scatter.scatter_sum(edge_feat, col.view(-1, 1), dim=0)
        out_pos = None
    elif op == "mean":
        out = (
            1.0
            / (deg.view(-1, 1) + DEG_EPS)
            * torch_scatter.scatter_sum(edge_feat, col.view(-1, 1), dim=0)
        )
        out_pos = None
    else:
        raise ValueError("unsupported agg_op")

    if return_degree:
        return out, out_pos, deg

    return out, out_pos


class CustomAgg(torch.autograd.Function):
    @staticmethod
    def forward(ctx, node_feat, edge_weight, edge_index, op):
        out, out_pos, deg = agg_weighted_pyg(
            node_feat, edge_index, edge_weight, op, return_degree=True
        )
        ctx.save_for_backward(node_feat, edge_index, edge_weight, out, out_pos, deg)
        ctx.op = op
        return out, out_pos

    @staticmethod
    def backward(ctx, grad_out, grad_out_pos):
        node_feat, edge_index, edge_weight, out, out_pos, deg = ctx.saved_tensors
        dim_node = node_feat.size(1)
        if ctx.op == "min" or ctx.op == "max":
            node_grad = torch.zeros_like(node_feat)
            weight_grad = torch.zeros_like(edge_weight)

            for d in range(dim_node):
                row, col = edge_index[:, out_pos[:, d]]
                tmp = edge_weight[out_pos[:, d]] * grad_out[col, d]
                torch_scatter.scatter_sum(tmp, row, dim=0, out=node_grad[:, d])
                tmp = node_feat[row, d] * grad_out[col, d]
                weight_grad[out_pos[:, d]] += tmp

        elif ctx.op == "sum":
            row, col = edge_index
            edge_grad = grad_out[col] * edge_weight.view(-1, 1)
            node_grad = torch_scatter.scatter_sum(edge_grad, row.view(-1, 1), dim=0)
            weight_grad = (grad_out[col] * node_feat[row]).sum(-1)

        elif ctx.op == "mean":
            row, col = edge_index
            edge_grad = grad_out[col] * edge_weight.view(-1, 1)
            node_grad = torch_scatter.scatter_sum(
                (1.0 / (deg[col].view(-1, 1) + DEG_EPS) * edge_grad),
                row.view(-1, 1),
                dim=0,
            )
            weight_grad = (
                (1.0 / (deg[col].view(-1, 1) + DEG_EPS))
                * ((node_feat[row] - out[col]) * grad_out[col])
            ).sum(-1)

        else:
            raise ValueError("unsupported agg_op")

        # edge_index and op never will require a gradient
        return node_grad, weight_grad, None, None


def main():
    num_nodes = 100
    dim_node = 128
    edge_index = erdos_renyi_graph(num_nodes, edge_prob=0.2, directed=True)
    num_edges = edge_index.size(1)
    node_feat = torch.randn(num_nodes, dim_node)
    edge_weight = torch.randn(num_edges)
    edge_weight.requires_grad_(True)
    node_feat.requires_grad_(True)
    dout = torch.randn(num_nodes, dim_node)

    for op in ("min", "max", "sum", "mean"):
        print("-----------------------------------")
        print(f"             {op}                  ")
        print("-----------------------------------")
        print()
        print("------------- Autograd ------------")
        out, out_pos = agg_weighted_pyg(node_feat, edge_index, edge_weight, op=op)
        print(op)

        d_feat, d_weight = torch.autograd.grad(
            out, (node_feat, edge_weight), grad_outputs=dout
        )
        print(d_feat.shape)
        print(d_feat)
        print(d_weight.shape)
        print(d_weight)

        print()
        print()
        print("------------- CustomAgg ------------")
        node_feat_custom = node_feat.clone().detach()
        edge_weight_custom = edge_weight.clone().detach()
        dout_custom = dout.clone().detach()
        edge_weight_custom.requires_grad_(True)
        node_feat_custom.requires_grad_(True)

        out_custom, out_pos_custom = CustomAgg.apply(
            node_feat_custom, edge_weight_custom, edge_index, op
        )

        d_feat_custom, d_weight_custom = torch.autograd.grad(
            out_custom, (node_feat_custom, edge_weight_custom), grad_outputs=dout_custom
        )
        print(d_feat_custom.shape)
        print(d_feat_custom)
        print(d_weight_custom.shape)
        print(d_weight_custom)

        print("------------- Deviation ------------")
        print((d_feat_custom - d_feat).abs().mean())
        print((d_weight_custom - d_weight).abs().mean())
        print()


if __name__ == "__main__":
    main()
