# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import warnings
from torch_sparse import SparseTensor

import pylibcugraphops_internal_ext as internal_ext


class NVTXPush(torch.autograd.Function):
    @staticmethod
    def forward(ctx, name, *args):
        assert not ctx.needs_input_grad[0]
        assert len(args) > 0

        ctx.name = name
        internal_ext.utils.push_range(f"{name}: Forward")
        return args[0] if len(args) == 1 else args

    @staticmethod
    def backward(ctx, *grad_args):
        return NVTXPushBackward.apply(ctx.name, *grad_args)


class NVTXPushBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, name, *args):
        internal_ext.utils.pop_range()
        ctx.name = name
        return None, *args

    @staticmethod
    def backward(ctx, *grad_args):
        internal_ext.utils.push_range(f"{ctx.name}: BackwardBackward")
        return grad_args[0] if len(grad_args) == 1 else grad_args


class NVTXPop(torch.autograd.Function):
    @staticmethod
    def forward(ctx, name, *args):
        assert not ctx.needs_input_grad[0]
        assert len(args) > 0

        ctx.name = name
        internal_ext.utils.pop_range()
        return args[0] if len(args) == 1 else args

    @staticmethod
    def backward(ctx, *grad_args):
        return NVTXPopBackward.apply(ctx.name, *grad_args)


class NVTXPopBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, name, *args):
        internal_ext.utils.push_range(f"{name}: Backward")
        return None, *args

    @staticmethod
    def backward(ctx, *grad_args):
        internal_ext.utils.pop_range()
        return grad_args[0] if len(grad_args) == 1 else grad_args


@torch.jit.script
def bessel_basis_jit(dist, vec, env):
    return env * (vec * dist).sin()


def bessel_basis(dist, vec, env):
    return env * (vec * dist).sin()


@torch.jit.script
def bessel_basis_paper_jit(dist, vec, env):
    return env * (vec * dist).sin() / dist


def bessel_basis_paper(dist, vec, env):
    return env * (vec * dist).sin() / dist


def print_stats(v, v_ref, name, rtol, atol):
    if v is None and v_ref is None:
        print("{}: both inputs None".format(name))
        return True
    if v is None or v_ref is None:
        print("{}: one input None but not the other".format(name))
        return False

    def get_val(x1, x2, max_tuple):
        return x1.flatten()[max_tuple[1]].item(), x2.flatten()[max_tuple[1]].item()

    if v.dtype != v_ref.dtype:
        v = v.to(v_ref.dtype)

    is_close = torch.isclose(v, v_ref, rtol=rtol, atol=atol)
    n_failed = (1 - is_close.to(dtype=torch.long)).sum().item()
    abs = torch.abs(v - v_ref)
    abs_max = abs.max().item(), abs.argmax().item()
    abs_max += get_val(v, v_ref, abs_max)
    rel = abs / torch.abs(v_ref)
    rel_max = rel.max().item(), rel.argmax().item()
    rel_max += get_val(v, v_ref, rel_max)
    tol = abs - rtol * torch.abs(v_ref)
    tol_max = tol.max().item(), tol.argmax().item()
    tol_max += get_val(v, v_ref, tol_max)
    s = "{}: #failed: {}/{}, largest absolute diff: {}, largest relative diff: {}, largest tol diff: {}"
    print(s.format(name, n_failed, v.numel(), abs_max, rel_max, tol_max))
    return is_close.all().item()


def get_pbc_distances(row, col, offsets):
    return (
        torch.sqrt(torch.sum(torch.square(row - col + offsets), dim=-1, keepdim=True))
        / 6.0
    )


@torch.jit.script
def get_pbc_distances_jit(row, col, offsets):
    return (
        torch.sqrt(torch.sum(torch.square(row - col + offsets), dim=-1, keepdim=True))
        / 6.0
    )


def get_triplets(row, col, num_nodes):
    value = torch.arange(row.size(0), device=row.device)
    adj_t = SparseTensor(
        row=col, col=row, value=value, sparse_sizes=(num_nodes, num_nodes)
    )
    adj_t_row = adj_t[row]
    num_triplets = adj_t_row.set_value(None).sum(dim=1).to(torch.long)

    # Node indices (k->j->i) for triplets.
    idx_i = col.repeat_interleave(num_triplets)
    idx_j = row.repeat_interleave(num_triplets)
    idx_k = adj_t_row.storage.col()

    # Edge indices (k->j, j->i) for triplets.
    idx_kj = adj_t_row.storage.value()
    idx_ji = adj_t_row.storage.row()

    # Remove self-loop triplets d->b->d
    # Check atom as well as cell offset (removed for tests)
    mask = idx_i != idx_k

    idx_i, idx_j, idx_k = idx_i[mask], idx_j[mask], idx_k[mask]
    idx_kj, idx_ji = idx_kj[mask], idx_ji[mask]

    return idx_i, idx_j, idx_k, idx_kj, idx_ji


@torch.jit.script
def envelope_jit(x):
    x_pow_p0 = torch.pow(x, 5)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 / x - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


@torch.jit.script
def envelope_paper_jit(x):
    x_pow_p0 = torch.pow(x, 6)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


def envelope(x):
    x_pow_p0 = torch.pow(x, 5)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 / x - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


def envelope_paper(x):
    x_pow_p0 = torch.pow(x, 6)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


def get_edge_offsets(edge_index, num_nodes):
    src, dst = edge_index
    dst_nodes, dst_counts = torch.unique(dst, return_counts=True)
    # it's important that this is a stable sort for reproducibility
    # for performance runs, this could be a non-stable sort
    _, dst_e_idx = torch.sort(dst, stable=True)
    src_nodes, src_counts = torch.unique_consecutive(src, return_counts=True)

    n_min, n_max = torch.aminmax(edge_index)
    n_min, n_max = n_min.item(), n_max.item()
    if n_min != 0:
        e = "Found minimum node ID {}. Must norm node IDs to min 0"
        raise ValueError(e.format(n_min))
    if n_max >= num_nodes:
        e = (
            "Found maximum node ID {}, but expected {} nodes. "
            "Must re-norm node IDs or adjust number of nodes"
        )
        raise ValueError(e.format(n_max, num_nodes))

    src_last, exp_last = src_nodes[-1].item(), src_nodes.size(0) - 1
    # anything else would imply negative node IDs
    assert src_last >= exp_last
    # implies all nodes appear as source nodes: don't need to add zero counts
    if src_last == exp_last and src_last == num_nodes - 1:
        src_counts_full = src_counts
    else:
        src_counts_full = torch.zeros(
            num_nodes, device=edge_index.device, dtype=src_counts.dtype
        )
        src_counts_full[src_nodes] = src_counts

    dst_last, exp_last = dst_nodes[-1].item(), dst_nodes.size(0) - 1
    # anything else would imply negative node IDs
    assert dst_last >= exp_last
    # implies all nodes appear as dest nodes: don't need to add zero counts
    if dst_last == exp_last and dst_last == num_nodes - 1:
        dst_counts_full = dst_counts
    else:
        dst_counts_full = torch.zeros(
            num_nodes, device=edge_index.device, dtype=dst_counts.dtype
        )
        dst_counts_full[dst_nodes] = dst_counts

    src_off = torch.zeros(
        num_nodes + 1, device=edge_index.device, dtype=src_counts.dtype
    )
    src_deg = src_counts_full
    src_off[1:] = src_counts_full.cumsum(dim=0)

    dst_off = torch.zeros(
        num_nodes + 1, device=edge_index.device, dtype=dst_counts.dtype
    )
    dst_deg = dst_counts_full
    dst_off[1:] = dst_counts_full.cumsum(dim=0)
    return (src_off, dst_off, dst_e_idx), src_deg, dst_deg


# taken directly from torch_geometric:
# https://pytorch-geometric.readthedocs.io/en/latest/_modules/torch_geometric/utils/random.html
def erdos_renyi_graph(num_nodes, edge_prob, directed=False):
    r"""Returns the :obj:`edge_index` of a random Erdos-Renyi graph.

    Args:
        num_nodes (int): The number of nodes.
        edge_prob (float): Probability of an edge.
        directed (bool, optional): If set to :obj:`True`, will return a
            directed graph. (default: :obj:`False`)
    """

    if directed:
        idx = torch.arange((num_nodes - 1) * num_nodes)
        idx = idx.view(num_nodes - 1, num_nodes)
        idx = idx + torch.arange(1, num_nodes).view(-1, 1)
        idx = idx.view(-1)
    else:
        warnings.filterwarnings("ignore", ".*pass the indexing argument.*")
        idx = torch.combinations(torch.arange(num_nodes), r=2)

    # Filter edges.
    mask = torch.rand(idx.size(0)) < edge_prob
    idx = idx[mask]

    if directed:
        row = idx.div(num_nodes, rounding_mode="floor")
        col = idx % num_nodes
        edge_index = torch.stack([row, col], dim=0)
    else:
        # this replaces to_undirected
        row, col = idx.t()
        mask = row != col
        row, col = torch.cat([row, col[mask]], dim=0), torch.cat(
            [col, row[mask]], dim=0
        )
        edge_index = torch.stack([row, col], dim=0)

    return edge_index


def get_aux_storage(edge_index, src_deg, dst_deg, n_feats, device, dtype):
    # fwd: e_ji -> k, i.e. dst_deg of src-node of e_ji
    _edge_offsets_fwd = dst_deg[edge_index[0]].cumsum(dim=0)
    n_trip_fwd = _edge_offsets_fwd[-1]
    edge_offsets_fwd = torch.zeros(
        (edge_index.size(1) + 1), dtype=edge_index.dtype, device=edge_index.device
    )
    edge_offsets_fwd[1:] = _edge_offsets_fwd
    # bwd: e_kj -> i, i.e. src_deg of dst-node of e_kj
    _edge_offsets_bwd = src_deg[edge_index[1]].cumsum(dim=0)
    n_trip_bwd = _edge_offsets_bwd[-1]
    edge_offsets_bwd = torch.zeros(
        (edge_index.size(1) + 1), dtype=edge_index.dtype, device=edge_index.device
    )
    edge_offsets_bwd[1:] = _edge_offsets_bwd

    aux_tensors = []
    for n in n_feats:
        aux_tensors.append(torch.empty((n_trip_fwd, n), device=device, dtype=dtype))
        aux_tensors.append(torch.empty((n_trip_bwd, n), device=device, dtype=dtype))

    return [edge_offsets_fwd, edge_offsets_bwd] + aux_tensors


## version using triplet indices for comparison with triplet-based reference
# def get_aux_storage(edge_index, triplet_idx_ji, n_feats, device, dtype):
#     ji_v, ji_counts = torch.unique_consecutive(triplet_idx_ji, return_counts=True)
#     ji_counts_full = torch.zeros(
#         edge_index.size(1), device=device, dtype=edge_index.dtype)
#     ji_counts_full[ji_v] = ji_counts
#     ji_off = torch.zeros(
#         edge_index.size(1) + 1, device=device, dtype=edge_index.dtype)
#     ji_off[1:] = ji_counts_full.cumsum(dim=0)
#     dump_tensors = []
#     for n in n_feats:
#         dump_tensors.append(
#             torch.empty((triplet_idx_ji.size(0), n), device=device, dtype=dtype)
#         )
#     return [ji_off, None] + dump_tensors
