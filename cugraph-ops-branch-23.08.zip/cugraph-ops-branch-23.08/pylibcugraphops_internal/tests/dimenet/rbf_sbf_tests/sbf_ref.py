# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch

c_0t = [
    3.14159274101257,
    6.28318548202515,
    9.42477798461914,
    12.5663709640503,
    15.7079629898071,
    18.8495559692383,
]
c_1t = [
    4.49340963363647,
    7.7252516746521,
    10.9041213989258,
    14.0661935806274,
    17.2207546234131,
    20.3713035583496,
]
c_2t = [
    5.76345920562744,
    9.09501171112061,
    12.322940826416,
    15.5146026611328,
    18.6890354156494,
    21.853874206543,
]
c_3t = [
    6.9879322052002,
    10.4171180725098,
    13.6980228424072,
    16.9236221313477,
    20.1218070983887,
    23.3042469024658,
]
c_4t = [
    8.18256187438965,
    11.7049074172974,
    15.0396642684937,
    18.3012561798096,
    21.5254173278809,
    24.7275657653809,
]
c_5t = [
    9.35581207275391,
    12.9665298461914,
    16.3547096252441,
    19.6531524658203,
    22.9045505523682,
    26.1277503967285,
]
c_6t = [
    10.5128355026245,
    14.2073926925659,
    17.6479740142822,
    20.9834632873535,
    24.262767791748,
    27.5078678131104,
]


c_01 = [
    1.41421360172718,
    1.41421360172719,
    1.41421356595183,
    1.41421360172725,
    1.41421353733157,
    1.41421356595183,
]


c_11 = [
    -1.44881182146373,
    -1.42601268061811,
    -1.42014812031817,
    -1.41778280396269,
    -1.41659585719744,
    -1.41591653329072,
]
c_12 = [
    0.322430390191518,
    0.184591096921426,
    0.130239573493567,
    0.100793636589455,
    0.0822609629006305,
    0.0695054456989023,
]


c_21 = [
    -1.48220819228598,
    -1.44054353387536,
    -1.42838784692185,
    -1.42310835777527,
    -1.42032571184861,
    -1.41867612061334,
]
c_22 = [
    -0.771520092051013,
    -0.475164929841922,
    -0.347738709544047,
    -0.27518107724546,
    -0.227993421853001,
    -0.194749375859672,
]
c_23 = [
    0.133864067485322,
    0.0522445649257308,
    0.0282188086790629,
    0.0177369078187767,
    0.0121993145597064,
    0.00891143483389159,
]


c_31 = [
    1.51240002169845,
    1.45553308963651,
    1.43755963546005,
    1.42934084814112,
    1.42484891172507,
    1.42211242909534,
]
c_32 = [
    -1.2985815923397,
    -0.838350729734506,
    -0.629679035580038,
    -0.506749974815456,
    -0.42486708219338,
    -0.366142472240508,
]
c_33 = [
    -0.464580062530277,
    -0.20119545633904,
    -0.114921518752078,
    -0.074858380032724,
    -0.0527868943524713,
    -0.039278513673163,
]
c_34 = [
    0.0664831954415001,
    0.0193139268402827,
    0.00838964280277709,
    0.00442330722417063,
    0.00262336747859482,
    0.00168546590831935,
]


c_41 = [
    1.53965371388729,
    1.47025596792433,
    1.44705837727913,
    1.43603814087772,
    1.42984401711803,
    1.42598923008548,
]
c_42 = [
    1.8816279516397,
    1.25610217621337,
    0.962161356427715,
    0.784666433150088,
    0.664258441700927,
    0.576679986867893,
]
c_43 = [
    -1.03480131435123,
    -0.482913669578201,
    -0.287887151377108,
    -0.192937518303847,
    -0.138866668279757,
    -0.104946033326849,
]
c_44 = [
    -0.29508318265335,
    -0.0962671913734207,
    -0.044664340543412,
    -0.0245987236223508,
    -0.0150530055260025,
    -0.00990287843478219,
]
c_45 = [
    0.0360624444010527,
    0.00822451540549208,
    0.00296976978648244,
    0.00134410028364549,
    0.000699313063097041,
    0.000400479308345281,
]


c_51 = [
    -1.56444176824918,
    -1.48446325845568,
    -1.45659317306845,
    -1.44295592066705,
    -1.43511786437635,
    -1.43015328644677,
]
c_52 = [
    2.50824047568009,
    1.71726353472865,
    1.33593919407179,
    1.10131638410929,
    0.939846774833116,
    0.821054203709311,
]
c_53 = [
    1.87666053926973,
    0.927067217342765,
    0.571797028060223,
    0.392263516103712,
    0.287232330046817,
    0.219972226414288,
]
c_54 = [
    -0.802350677707587,
    -0.285987763369108,
    -0.13984889763561,
    -0.079837271254251,
    -0.0501616182147035,
    -0.0336764127143271,
]
c_55 = [
    -0.192959094390048,
    -0.0496256496698302,
    -0.0192397191323062,
    -0.00914020591019553,
    -0.00492756409801779,
    -0.00290005559057712,
]
c_56 = [
    0.0206245158506321,
    0.00382721130930852,
    0.00117640236807439,
    0.000465075815500423,
    0.000215134721231555,
    0.000110995227164304,
]

c_61 = [
    -1.58717984397985,
    -1.49808440567462,
    -1.46601645543643,
    -1.44995111708105,
    -1.44054685504282,
    -1.43450193707163,
]
c_62 = [
    -3.1704839969441,
    -2.21432413391576,
    -1.74446911238934,
    -1.4510937990419,
    -1.24682741126459,
    -1.09512452521481,
]
c_63 = [
    3.01582194085753,
    1.55857178148839,
    0.988481233583851,
    0.691541610252895,
    0.513885069488506,
    0.398113198978247,
]
c_64 = [
    1.72122275104826,
    0.658208785474305,
    0.33606619075387,
    0.197739029286842,
    0.12707991286879,
    0.0868362175541293,
]
c_65 = [
    -0.613971874174155,
    -0.173732295498539,
    -0.0714103621360227,
    -0.0353383685843968,
    -0.0196411916953696,
    -0.0118379155389421,
]
c_66 = [
    -0.128484662662698,
    -0.0269022654872332,
    -0.00890203014646945,
    -0.0037050323781646,
    -0.0017809436293789,
    -0.00094676237222793,
]
c_67 = [
    0.0122216943878387,
    0.0018935399386342,
    0.000504422215222279,
    0.000176569154835254,
    0.0000734023275771782,
    0.0000344178755932766,
]


def get_pows(x):
    return [x**i for i in range(1, 8)]


def fr1(x, c_trig, c1):
    return c1 * torch.sin(x * c_trig) / x


def fr2(x1, x2, c_trig, c1, c2):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x1 * _cos
    t += c2 * _sin
    return t / x2


def fr3(x1, x2, x3, c_trig, c1, c2, c3):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x2 * _sin
    t += c2 * x1 * _cos
    t += c3 * _sin
    return t / x3


def fr4(x1, x2, x3, x4, c_trig, c1, c2, c3, c4):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x3 * _cos
    t += c2 * x2 * _sin
    t += c3 * x1 * _cos
    t += c4 * _sin
    return t / x4


def fr5(x1, x2, x3, x4, x5, c_trig, c1, c2, c3, c4, c5):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x4 * _sin
    t += c2 * x3 * _cos
    t += c3 * x2 * _sin
    t += c4 * x1 * _cos
    t += c5 * _sin
    return t / x5


def fr6(x1, x2, x3, x4, x5, x6, c_trig, c1, c2, c3, c4, c5, c6):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x5 * _cos
    t += c2 * x4 * _sin
    t += c3 * x3 * _cos
    t += c4 * x2 * _sin
    t += c5 * x1 * _cos
    t += c6 * _sin
    return t / x6


def fr7(x1, x2, x3, x4, x5, x6, x7, c_trig, c1, c2, c3, c4, c5, c6, c7):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x6 * _sin
    t += c2 * x5 * _cos
    t += c3 * x4 * _sin
    t += c4 * x3 * _cos
    t += c5 * x2 * _sin
    t += c6 * x1 * _cos
    t += c7 * _sin
    return t / x7


def get_cos_pow(theta):
    _cos = torch.cos(theta)
    return _cos, _cos**2, _cos**4, _cos**6


def fc1(c1):
    return 0.48860251190292 * c1


def fc2(c2):
    return 0.94617469575756 * c2 - 0.31539156525252


def fc3(c1, c2):
    return (1.86588166295058 * c2 - 1.11952899777035) * c1


def fc4(c2, c4):
    return 3.70249414203215 * c4 - 3.17356640745613 * c2 + 0.317356640745613


def fc5(c1, c2, c4):
    return (7.36787031456569 * c4 - 8.18652257173965 * c2 + 1.75425483680135) * c1


def fc6(c2, c4, c6):
    return (
        14.6844857238222 * c6
        - 20.024298714303 * c4
        + 6.67476623810098 * c2
        - 0.317846011338142
    )


class SphericalBasisLayer(torch.nn.Module):
    def __init__(
        self,
        num_spherical,
        num_radial,
        dtype,
        device="cuda",
        rbf_only=False,
        cos_angle=False,
    ):
        super().__init__()
        assert num_radial <= 64
        self.num_spherical = num_spherical
        self.num_radial = num_radial
        self.device = device
        self.rbf_only = rbf_only
        self.cos_angle = cos_angle

        self.c_01 = torch.tensor(c_01, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_0t = torch.tensor(c_0t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_11 = torch.tensor(c_11, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_12 = torch.tensor(c_12, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_1t = torch.tensor(c_1t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_21 = torch.tensor(c_21, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_22 = torch.tensor(c_22, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_23 = torch.tensor(c_23, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_2t = torch.tensor(c_2t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_31 = torch.tensor(c_31, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_32 = torch.tensor(c_32, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_33 = torch.tensor(c_33, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_34 = torch.tensor(c_34, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_3t = torch.tensor(c_3t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_41 = torch.tensor(c_41, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_42 = torch.tensor(c_42, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_43 = torch.tensor(c_43, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_44 = torch.tensor(c_44, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_45 = torch.tensor(c_45, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_4t = torch.tensor(c_4t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_51 = torch.tensor(c_51, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_52 = torch.tensor(c_52, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_53 = torch.tensor(c_53, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_54 = torch.tensor(c_54, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_55 = torch.tensor(c_55, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_56 = torch.tensor(c_56, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_5t = torch.tensor(c_5t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_61 = torch.tensor(c_61, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_62 = torch.tensor(c_62, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_63 = torch.tensor(c_63, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_64 = torch.tensor(c_64, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_65 = torch.tensor(c_65, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_66 = torch.tensor(c_66, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_67 = torch.tensor(c_67, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_6t = torch.tensor(c_6t, device=device, dtype=dtype)  # .unsqueeze(0)

        """
        ct = torch.cat([self.c_0t, self.c_1t, self.c_2t, self.c_3t, self.c_4t, self.c_5t, self.c_6t])

        ci = torch.cat([
            self.c_01,
            self.c_11,
            self.c_12,
            self.c_21,
            self.c_22,
            self.c_23,
            self.c_31,
            self.c_32,
            self.c_33,
            self.c_34,
            self.c_41,
            self.c_42,
            self.c_43,
            self.c_44,
            self.c_45,
            self.c_51,
            self.c_52,
            self.c_53,
            self.c_54,
            self.c_55,
            self.c_56,
            self.c_61,
            self.c_62,
            self.c_63,
            self.c_64,
            self.c_65,
            self.c_66,
            self.c_67
        ])
        """

    def calc_rbf(self, x):

        x_1, x_2, x_3, x_4, x_5, x_6, x_7 = get_pows(x)

        if self.num_spherical == 7:
            x7 = fr7(
                x_1,
                x_2,
                x_3,
                x_4,
                x_5,
                x_6,
                x_7,
                self.c_6t,
                self.c_61,
                self.c_62,
                self.c_63,
                self.c_64,
                self.c_65,
                self.c_66,
                self.c_67,
            )
            x6 = fr6(
                x_1,
                x_2,
                x_3,
                x_4,
                x_5,
                x_6,
                self.c_5t,
                self.c_51,
                self.c_52,
                self.c_53,
                self.c_54,
                self.c_55,
                self.c_56,
            )
            x5 = fr5(
                x_1,
                x_2,
                x_3,
                x_4,
                x_5,
                self.c_4t,
                self.c_41,
                self.c_42,
                self.c_43,
                self.c_44,
                self.c_45,
            )
            x4 = fr4(
                x_1,
                x_2,
                x_3,
                x_4,
                self.c_3t,
                self.c_31,
                self.c_32,
                self.c_33,
                self.c_34,
            )
            x3 = fr3(x_1, x_2, x_3, self.c_2t, self.c_21, self.c_22, self.c_23)
            x2 = fr2(x_1, x_2, self.c_1t, self.c_11, self.c_12)
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1, x2, x3, x4, x5, x6, x7], 1)

        elif self.num_spherical == 6:
            x6 = fr6(
                x_1,
                x_2,
                x_3,
                x_4,
                x_5,
                x_6,
                self.c_5t,
                self.c_51,
                self.c_52,
                self.c_53,
                self.c_54,
                self.c_55,
                self.c_56,
            )
            x5 = fr5(
                x_1,
                x_2,
                x_3,
                x_4,
                x_5,
                self.c_4t,
                self.c_41,
                self.c_42,
                self.c_43,
                self.c_44,
                self.c_45,
            )
            x4 = fr4(
                x_1,
                x_2,
                x_3,
                x_4,
                self.c_3t,
                self.c_31,
                self.c_32,
                self.c_33,
                self.c_34,
            )
            x3 = fr3(x_1, x_2, x_3, self.c_2t, self.c_21, self.c_22, self.c_23)
            x2 = fr2(x_1, x_2, self.c_1t, self.c_11, self.c_12)
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1, x2, x3, x4, x5, x6], 1)

        elif self.num_spherical == 5:
            x5 = fr5(
                x_1,
                x_2,
                x_3,
                x_4,
                x_5,
                self.c_4t,
                self.c_41,
                self.c_42,
                self.c_43,
                self.c_44,
                self.c_45,
            )
            x4 = fr4(
                x_1,
                x_2,
                x_3,
                x_4,
                self.c_3t,
                self.c_31,
                self.c_32,
                self.c_33,
                self.c_34,
            )
            x3 = fr3(x_1, x_2, x_3, self.c_2t, self.c_21, self.c_22, self.c_23)
            x2 = fr2(x_1, x_2, self.c_1t, self.c_11, self.c_12)
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1, x2, x3, x4, x5], 1)
        elif self.num_spherical == 4:
            x4 = fr4(
                x_1,
                x_2,
                x_3,
                x_4,
                self.c_3t,
                self.c_31,
                self.c_32,
                self.c_33,
                self.c_34,
            )
            x3 = fr3(x_1, x_2, x_3, self.c_2t, self.c_21, self.c_22, self.c_23)
            x2 = fr2(x_1, x_2, self.c_1t, self.c_11, self.c_12)
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1, x2, x3, x4], 1)

        elif self.num_spherical == 3:
            x3 = fr3(x_1, x_2, x_3, self.c_2t, self.c_21, self.c_22, self.c_23)
            x2 = fr2(x_1, x_2, self.c_1t, self.c_11, self.c_12)
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1, x2, x3], 1)

        elif self.num_spherical == 2:
            x2 = fr2(x_1, x_2, self.c_1t, self.c_11, self.c_12)
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1, x2], 1)

        elif self.num_spherical == 1:
            x1 = fr1(x_1, self.c_0t, self.c_01)
            out = torch.cat([x1], 1)

        else:
            raise AssertionError(f"num_spherical == {self.num_spherical} not supported")

        return out

    @staticmethod
    def calc_cbf_cos(c1):
        c2 = c1 * c1
        c3, c4 = c2 * c1, c2 * c2
        c6 = c3 * c3
        out = torch.stack(
            [
                0.282094791773878
                * torch.ones(c1.shape, dtype=c1.dtype, device=c1.device),
                fc1(c1),
                fc2(c2),
                fc3(c1, c2),
                fc4(c2, c4),
                fc5(c1, c2, c4),
                fc6(c2, c4, c6),
            ],
            1,
        )
        return out

    @staticmethod
    def calc_cbf_angle(x):
        c1, c2, c4, c6 = get_cos_pow(x)
        out = torch.stack(
            [
                0.282094791773878
                * torch.ones(x.shape, dtype=x.dtype, device=c1.device),
                fc1(c1),
                fc2(c2),
                fc3(c1, c2),
                fc4(c2, c4),
                fc5(c1, c2, c4),
                fc6(c2, c4, c6),
            ],
            1,
        )
        return out

    def calc_cbf(self, x):
        if self.cos_angle:
            return self.calc_cbf_cos(x)
        return self.calc_cbf_angle(x)

    def forward(self, dist, angle, idx_kj, env):
        rbf = self.calc_rbf(dist)
        rbf = env * rbf
        if self.rbf_only:
            return rbf

        return rbf, self.calc_cbf(angle)
