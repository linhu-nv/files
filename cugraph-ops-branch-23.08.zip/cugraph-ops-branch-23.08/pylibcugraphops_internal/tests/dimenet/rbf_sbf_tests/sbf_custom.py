# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# from tkinter import W
from venv import create
import torch

import os
import time

from rbf_test import generate_input

n_spherical, n_radial, n_vec = 7, 6, 3
DEVICE = "cuda"  # nothing else implemented


c_01 = torch.tensor(
    [
        1.41421360172718,
        1.41421360172719,
        1.41421356595183,
        1.41421360172725,
        1.41421353733157,
        1.41421356595183,
    ],
    device=DEVICE,
    dtype=torch.float64,
).unsqueeze(0)
c_0t = torch.tensor(
    [
        3.14159274101257,
        6.28318548202515,
        9.42477798461914,
        12.5663709640503,
        15.7079629898071,
        18.8495559692383,
    ],
    device=DEVICE,
    dtype=torch.float64,
).unsqueeze(0)

c_11 = torch.tensor(
    [
        -1.44881182146373,
        -1.42601268061811,
        -1.42014812031817,
        -1.41778280396269,
        -1.41659585719744,
        -1.41591653329072,
    ],
    device=DEVICE,
    dtype=torch.float64,
).unsqueeze(0)
c_12 = torch.tensor(
    [
        0.322430390191518,
        0.184591096921426,
        0.130239573493567,
        0.100793636589455,
        0.0822609629006305,
        0.0695054456989023,
    ],
    device=DEVICE,
    dtype=torch.float64,
).unsqueeze(0)
c_1t = torch.tensor(
    [
        4.49340963363647,
        7.7252516746521,
        10.9041213989258,
        14.0661935806274,
        17.2207546234131,
        20.3713035583496,
    ],
    device=DEVICE,
    dtype=torch.float64,
).unsqueeze(0)

c_21 = torch.tensor(
    [
        -1.48220819228598,
        -1.44054353387536,
        -1.42838784692185,
        -1.42310835777527,
        -1.42032571184861,
        -1.41867612061334,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_22 = torch.tensor(
    [
        -0.771520092051013,
        -0.475164929841922,
        -0.347738709544047,
        -0.27518107724546,
        -0.227993421853001,
        -0.194749375859672,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_23 = torch.tensor(
    [
        0.133864067485322,
        0.0522445649257308,
        0.0282188086790629,
        0.0177369078187767,
        0.0121993145597064,
        0.00891143483389159,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_2t = torch.tensor(
    [
        5.76345920562744,
        9.09501171112061,
        12.322940826416,
        15.5146026611328,
        18.6890354156494,
        21.853874206543,
    ],
    device=DEVICE,
    dtype=torch.float64,
)

c_31 = torch.tensor(
    [
        1.51240002169845,
        1.45553308963651,
        1.43755963546005,
        1.42934084814112,
        1.42484891172507,
        1.42211242909534,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_32 = torch.tensor(
    [
        -1.2985815923397,
        -0.838350729734506,
        -0.629679035580038,
        -0.506749974815456,
        -0.42486708219338,
        -0.366142472240508,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_33 = torch.tensor(
    [
        -0.464580062530277,
        -0.20119545633904,
        -0.114921518752078,
        -0.074858380032724,
        -0.0527868943524713,
        -0.039278513673163,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_34 = torch.tensor(
    [
        0.0664831954415001,
        0.0193139268402827,
        0.00838964280277709,
        0.00442330722417063,
        0.00262336747859482,
        0.00168546590831935,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_3t = torch.tensor(
    [
        6.9879322052002,
        10.4171180725098,
        13.6980228424072,
        16.9236221313477,
        20.1218070983887,
        23.3042469024658,
    ],
    device=DEVICE,
    dtype=torch.float64,
)

c_41 = torch.tensor(
    [
        1.53965371388729,
        1.47025596792433,
        1.44705837727913,
        1.43603814087772,
        1.42984401711803,
        1.42598923008548,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_42 = torch.tensor(
    [
        1.8816279516397,
        1.25610217621337,
        0.962161356427715,
        0.784666433150088,
        0.664258441700927,
        0.576679986867893,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_43 = torch.tensor(
    [
        -1.03480131435123,
        -0.482913669578201,
        -0.287887151377108,
        -0.192937518303847,
        -0.138866668279757,
        -0.104946033326849,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_44 = torch.tensor(
    [
        -0.29508318265335,
        -0.0962671913734207,
        -0.044664340543412,
        -0.0245987236223508,
        -0.0150530055260025,
        -0.00990287843478219,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_45 = torch.tensor(
    [
        0.0360624444010527,
        0.00822451540549208,
        0.00296976978648244,
        0.00134410028364549,
        0.000699313063097041,
        0.000400479308345281,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_4t = torch.tensor(
    [
        8.18256187438965,
        11.7049074172974,
        15.0396642684937,
        18.3012561798096,
        21.5254173278809,
        24.7275657653809,
    ],
    device=DEVICE,
    dtype=torch.float64,
)

c_51 = torch.tensor(
    [
        -1.56444176824918,
        -1.48446325845568,
        -1.45659317306845,
        -1.44295592066705,
        -1.43511786437635,
        -1.43015328644677,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_52 = torch.tensor(
    [
        2.50824047568009,
        1.71726353472865,
        1.33593919407179,
        1.10131638410929,
        0.939846774833116,
        0.821054203709311,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_53 = torch.tensor(
    [
        1.87666053926973,
        0.927067217342765,
        0.571797028060223,
        0.392263516103712,
        0.287232330046817,
        0.219972226414288,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_54 = torch.tensor(
    [
        -0.802350677707587,
        -0.285987763369108,
        -0.13984889763561,
        -0.079837271254251,
        -0.0501616182147035,
        -0.0336764127143271,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_55 = torch.tensor(
    [
        -0.192959094390048,
        -0.0496256496698302,
        -0.0192397191323062,
        -0.00914020591019553,
        -0.00492756409801779,
        -0.00290005559057712,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_56 = torch.tensor(
    [
        0.0206245158506321,
        0.00382721130930852,
        0.00117640236807439,
        0.000465075815500423,
        0.000215134721231555,
        0.000110995227164304,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_5t = torch.tensor(
    [
        9.35581207275391,
        12.9665298461914,
        16.3547096252441,
        19.6531524658203,
        22.9045505523682,
        26.1277503967285,
    ],
    device=DEVICE,
    dtype=torch.float64,
)

c_61 = torch.tensor(
    [
        -1.58717984397985,
        -1.49808440567462,
        -1.46601645543643,
        -1.44995111708105,
        -1.44054685504282,
        -1.43450193707163,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_62 = torch.tensor(
    [
        -3.1704839969441,
        -2.21432413391576,
        -1.74446911238934,
        -1.4510937990419,
        -1.24682741126459,
        -1.09512452521481,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_63 = torch.tensor(
    [
        3.01582194085753,
        1.55857178148839,
        0.988481233583851,
        0.691541610252895,
        0.513885069488506,
        0.398113198978247,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_64 = torch.tensor(
    [
        1.72122275104826,
        0.658208785474305,
        0.33606619075387,
        0.197739029286842,
        0.12707991286879,
        0.0868362175541293,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_65 = torch.tensor(
    [
        -0.613971874174155,
        -0.173732295498539,
        -0.0714103621360227,
        -0.0353383685843968,
        -0.0196411916953696,
        -0.0118379155389421,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_66 = torch.tensor(
    [
        -0.128484662662698,
        -0.0269022654872332,
        -0.00890203014646945,
        -0.0037050323781646,
        -0.0017809436293789,
        -0.00094676237222793,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_67 = torch.tensor(
    [
        0.0122216943878387,
        0.0018935399386342,
        0.000504422215222279,
        0.000176569154835254,
        0.0000734023275771782,
        0.0000344178755932766,
    ],
    device=DEVICE,
    dtype=torch.float64,
)
c_6t = torch.tensor(
    [
        10.5128355026245,
        14.2073926925659,
        17.6479740142822,
        20.9834632873535,
        24.262767791748,
        27.5078678131104,
    ],
    device=DEVICE,
    dtype=torch.float64,
)


def env_auto(x):
    x_pow_p0 = torch.pow(x, 5)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 / x - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


def env_grad_auto(x):
    x_pow_p0 = torch.pow(x, 4)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (-1.0 / x**2 - 140 * x_pow_p0 + 288 * x_pow_p1 - 147 * x_pow_p2) * (
        x < 1.0
    )


def env_grad_grad_auto(x):
    x_pow_p0 = torch.pow(x, 3)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (2.0 / x**3 - 560 * x_pow_p0 + 1440 * x_pow_p1 - 882 * x_pow_p2) * (
        x < 1.0
    )


def get_pows(x):
    return [x**i for i in range(1, 8)]


# f(x) = g(x) / x^p

# f'(x) = g'(x) / x^p - p * g(x) / x^(p + 1)
#       = g'(x) / x^p - p * f(x) / x

# f''(x) = g''(x) / x^p
#           - p * g'(x) / x^(p + 1) = -p/x * (f'(x) + p * f(x) / x)
#           - p * f'(x) / x
#           + p * f(x) / x2

#         = g''(x) / x^p
#           - 2 * p * f'(x) / x
#           - p * (p - 1) * f(x) / x2


def fr1(x1, c_trig, c1):
    return c1 * torch.sin(x1 * c_trig) / x1


def fr1_bwd(x1, c_trig, c1, out):
    grad = c1 * torch.cos(x1 * c_trig) * c_trig
    return grad / x1 - out / x1


def fr1_bwd_bwd(x1, c_trig, c1, d_out, out):
    grad = -c1 * torch.sin(x1 * c_trig) * c_trig * c_trig
    return grad / x1 - 2 * d_out / x1


def fr2(x1, x2, c_trig, c1, c2):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x1 * _cos
    t += c2 * _sin
    return t / x2


def fr2_bwd(x1, x2, c_trig, c1, c2, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * _cos
    grad -= c1 * x1 * _sin * c_trig

    grad += c2 * _cos * c_trig
    return grad / x2 - 2 * out / x1


def fr2_bwd_bwd(x1, x2, c_trig, c1, c2, d_out, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = -2 * c1 * _sin * c_trig
    grad -= c1 * x1 * _cos * c_trig * c_trig

    grad -= c2 * _sin * c_trig * c_trig
    return grad / x2 - 4 * d_out / x1 - 2 * out / x2


def fr3(x1, x2, x3, c_trig, c1, c2, c3):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x2 * _sin
    t += c2 * x1 * _cos
    t += c3 * _sin
    return t / x3


def fr3_bwd(x1, x2, x3, c_trig, c1, c2, c3, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 2 * x1 * _sin
    grad += c1 * x2 * _cos * c_trig

    grad += c2 * _cos
    grad -= c2 * x1 * _sin * c_trig

    grad += c3 * _cos * c_trig
    return grad / x3 - 3 * out / x1


def fr3_bwd_bwd(x1, x2, x3, c_trig, c1, c2, c3, d_out, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 2 * _sin
    grad += 2 * c1 * 2 * x1 * _cos * c_trig
    grad -= c1 * x2 * _sin * c_trig * c_trig

    grad -= 2 * c2 * _sin * c_trig
    grad -= c2 * x1 * _cos * c_trig * c_trig

    grad -= c3 * _sin * c_trig * c_trig
    return grad / x3 - 6 * d_out / x1 - 6 * out / x2


def fr4(x1, x2, x3, x4, c_trig, c1, c2, c3, c4):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x3 * _cos
    t += c2 * x2 * _sin
    t += c3 * x1 * _cos
    t += c4 * _sin
    return t / x4


def fr4_bwd(x1, x2, x3, x4, c_trig, c1, c2, c3, c4, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 3 * x2 * _cos
    grad -= c1 * x3 * _sin * c_trig

    grad += c2 * 2 * x1 * _sin
    grad += c2 * x2 * _cos * c_trig

    grad += c3 * _cos
    grad -= c3 * x1 * _sin * c_trig

    grad += c4 * _cos * c_trig

    return grad / x4 - 4 * out / x1


def fr4_bwd_bwd(x1, x2, x3, x4, c_trig, c1, c2, c3, c4, d_out, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 6 * x1 * _cos
    grad -= 2 * c1 * 3 * x2 * _sin * c_trig
    grad -= c1 * x3 * _cos * c_trig * c_trig

    grad += c2 * 2 * _sin
    grad += 2 * c2 * 2 * x1 * _cos * c_trig
    grad -= c2 * x2 * _sin * c_trig * c_trig

    grad -= 2 * c3 * _sin * c_trig
    grad -= c3 * x1 * _cos * c_trig * c_trig

    grad -= c4 * _sin * c_trig * c_trig

    return grad / x4 - 8 * d_out / x1 - 12 * out / x2


def fr5(x1, x2, x3, x4, x5, c_trig, c1, c2, c3, c4, c5):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x4 * _sin
    t += c2 * x3 * _cos
    t += c3 * x2 * _sin
    t += c4 * x1 * _cos
    t += c5 * _sin
    return t / x5


def fr5_bwd(x1, x2, x3, x4, x5, c_trig, c1, c2, c3, c4, c5, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 4 * x3 * _sin
    grad += c1 * x4 * _cos * c_trig

    grad += c2 * 3 * x2 * _cos
    grad -= c2 * x3 * _sin * c_trig

    grad += c3 * 2 * x1 * _sin
    grad += c3 * x2 * _cos * c_trig

    grad += c4 * _cos
    grad -= c4 * x1 * _sin * c_trig

    grad += c5 * _cos * c_trig
    return grad / x5 - 5 * out / x1


def fr5_bwd_bwd(x1, x2, x3, x4, x5, c_trig, c1, c2, c3, c4, c5, d_out, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 12 * x2 * _sin
    grad += 2 * c1 * 4 * x3 * _cos * c_trig
    grad -= c1 * x4 * _sin * c_trig * c_trig

    grad += c2 * 6 * x1 * _cos
    grad -= 2 * c2 * 3 * x2 * _sin * c_trig
    grad -= c2 * x3 * _cos * c_trig * c_trig

    grad += c3 * 2 * _sin
    grad += 2 * c3 * 2 * x1 * _cos * c_trig
    grad -= c3 * x2 * _sin * c_trig * c_trig

    grad -= 2 * c4 * _sin * c_trig
    grad -= c4 * x1 * _cos * c_trig * c_trig

    grad -= c5 * _sin * c_trig * c_trig

    return grad / x5 - 10 * d_out / x1 - 20 * out / x2


def fr6(x1, x2, x3, x4, x5, x6, c_trig, c1, c2, c3, c4, c5, c6):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x5 * _cos
    t += c2 * x4 * _sin
    t += c3 * x3 * _cos
    t += c4 * x2 * _sin
    t += c5 * x1 * _cos
    t += c6 * _sin
    return t / x6


def fr6_bwd(x1, x2, x3, x4, x5, x6, c_trig, c1, c2, c3, c4, c5, c6, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 5 * x4 * _cos
    grad -= c1 * x5 * _sin * c_trig

    grad += c2 * 4 * x3 * _sin
    grad += c2 * x4 * _cos * c_trig

    grad += c3 * 3 * x2 * _cos
    grad -= c3 * x3 * _sin * c_trig

    grad += c4 * 2 * x1 * _sin
    grad += c4 * x2 * _cos * c_trig

    grad += c5 * _cos
    grad -= c5 * x1 * _sin * c_trig

    grad += c6 * _cos * c_trig
    return grad / x6 - 6 * out / x1


def fr6_bwd_bwd(x1, x2, x3, x4, x5, x6, c_trig, c1, c2, c3, c4, c5, c6, d_out, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 20 * x3 * _cos
    grad -= 2 * c1 * 5 * x4 * _sin * c_trig
    grad -= c1 * x5 * _cos * c_trig * c_trig

    grad += c2 * 12 * x2 * _sin
    grad += 2 * c2 * 4 * x3 * _cos * c_trig
    grad -= c2 * x4 * _sin * c_trig * c_trig

    grad += c3 * 6 * x1 * _cos
    grad -= 2 * c3 * 3 * x2 * _sin * c_trig
    grad -= c3 * x3 * _cos * c_trig * c_trig

    grad += c4 * 2 * _sin
    grad += 2 * c4 * 2 * x1 * _cos * c_trig
    grad -= c4 * x2 * _sin * c_trig * c_trig

    grad -= 2 * c5 * _sin * c_trig
    grad -= c5 * x1 * _cos * c_trig * c_trig

    grad -= c6 * _sin * c_trig * c_trig
    return grad / x6 - 12 * d_out / x1 - 30 * out / x2


def fr7(x1, x2, x3, x4, x5, x6, x7, c_trig, c1, c2, c3, c4, c5, c6, c7):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)
    t = c1 * x6 * _sin
    t += c2 * x5 * _cos
    t += c3 * x4 * _sin
    t += c4 * x3 * _cos
    t += c5 * x2 * _sin
    t += c6 * x1 * _cos
    t += c7 * _sin
    return t / x7


def fr7_bwd(x1, x2, x3, x4, x5, x6, x7, c_trig, c1, c2, c3, c4, c5, c6, c7, out):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 6 * x5 * _sin
    grad += c1 * x6 * _cos * c_trig

    grad += c2 * 5 * x4 * _cos
    grad -= c2 * x5 * _sin * c_trig

    grad += c3 * 4 * x3 * _sin
    grad += c3 * x4 * _cos * c_trig

    grad += c4 * 3 * x2 * _cos
    grad -= c4 * x3 * _sin * c_trig

    grad += c5 * 2 * x1 * _sin
    grad += c5 * x2 * _cos * c_trig

    grad += c6 * _cos
    grad -= c6 * x1 * _sin * c_trig

    grad += c7 * _cos * c_trig

    return grad / x7 - 7 * out / x1


def fr7_bwd_bwd(
    x1, x2, x3, x4, x5, x6, x7, c_trig, c1, c2, c3, c4, c5, c6, c7, d_out, out
):
    _sin, _cos = torch.sin(x1 * c_trig), torch.cos(x1 * c_trig)

    grad = c1 * 30 * x4 * _sin
    grad += 2 * c1 * 6 * x5 * _cos * c_trig
    grad -= c1 * x6 * _sin * c_trig * c_trig

    grad += c2 * 20 * x3 * _cos
    grad -= 2 * c2 * 5 * x4 * _sin * c_trig
    grad -= c2 * x5 * _cos * c_trig * c_trig

    grad += c3 * 12 * x2 * _sin
    grad += 2 * c3 * 4 * x3 * _cos * c_trig
    grad -= c3 * x4 * _sin * c_trig * c_trig

    grad += c4 * 6 * x1 * _cos
    grad -= 2 * c4 * 3 * x2 * _sin * c_trig
    grad -= c4 * x3 * _cos * c_trig * c_trig

    grad += c5 * 2 * _sin
    grad += 2 * c5 * 2 * x1 * _cos * c_trig
    grad -= c5 * x2 * _sin * c_trig * c_trig

    grad -= 2 * c6 * _sin * c_trig
    grad -= c6 * x1 * _cos * c_trig * c_trig

    grad -= c7 * _sin * c_trig * c_trig

    return grad / x7 - 14 * d_out / x1 - 42 * out / x2


def sbf_auto(x):
    env = env_auto(x)
    x1, x2, x3, x4, x5, x6, x7 = get_pows(x)
    fr_out_1 = fr1(x1, c_0t, c_01)
    fr_out_2 = fr2(x1, x2, c_1t, c_11, c_12)
    fr_out_3 = fr3(x1, x2, x3, c_2t, c_21, c_22, c_23)
    fr_out_4 = fr4(x1, x2, x3, x4, c_3t, c_31, c_32, c_33, c_34)
    fr_out_5 = fr5(x1, x2, x3, x4, x5, c_4t, c_41, c_42, c_43, c_44, c_45)
    fr_out_6 = fr6(x1, x2, x3, x4, x5, x6, c_5t, c_51, c_52, c_53, c_54, c_55, c_56)
    fr_out_7 = fr7(
        x1, x2, x3, x4, x5, x6, x7, c_6t, c_61, c_62, c_63, c_64, c_65, c_66, c_67
    )
    fr_out = torch.cat(
        [fr_out_1, fr_out_2, fr_out_3, fr_out_4, fr_out_5, fr_out_6, fr_out_7], dim=1
    )
    return env * fr_out


class SBFForward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        env = env_auto(x)

        x1, x2, x3, x4, x5, x6, x7 = get_pows(x)

        fr_out_1 = fr1(x1, c_0t, c_01)
        fr_out_2 = fr2(x1, x2, c_1t, c_11, c_12)
        fr_out_3 = fr3(x1, x2, x3, c_2t, c_21, c_22, c_23)
        fr_out_4 = fr4(x1, x2, x3, x4, c_3t, c_31, c_32, c_33, c_34)
        fr_out_5 = fr5(x1, x2, x3, x4, x5, c_4t, c_41, c_42, c_43, c_44, c_45)
        fr_out_6 = fr6(x1, x2, x3, x4, x5, x6, c_5t, c_51, c_52, c_53, c_54, c_55, c_56)
        fr_out_7 = fr7(
            x1, x2, x3, x4, x5, x6, x7, c_6t, c_61, c_62, c_63, c_64, c_65, c_66, c_67
        )
        fr_out = torch.cat(
            [fr_out_1, fr_out_2, fr_out_3, fr_out_4, fr_out_5, fr_out_6, fr_out_7],
            dim=1,
        )
        ctx.save_for_backward(x, fr_out)
        return env * fr_out

    @staticmethod
    def backward(ctx, grad_out):
        x, fr_out = ctx.saved_tensors
        print("SBF simple backward: ", ctx.needs_input_grad)
        return SBFBackward.apply(grad_out, x, fr_out)


class SBFBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, grad_out, x, fr_out):
        env = env_auto(x)
        env_grad = env_grad_auto(x)

        x1, x2, x3, x4, x5, x6, x7 = get_pows(x)

        (
            fr_out_1,
            fr_out_2,
            fr_out_3,
            fr_out_4,
            fr_out_5,
            fr_out_6,
            fr_out_7,
        ) = fr_out.split(n_radial, dim=-1)

        d_x_1 = fr1_bwd(x1, c_0t, c_01, fr_out_1)
        d_x_2 = fr2_bwd(x1, x2, c_1t, c_11, c_12, fr_out_2)
        d_x_3 = fr3_bwd(x1, x2, x3, c_2t, c_21, c_22, c_23, fr_out_3)
        d_x_4 = fr4_bwd(x1, x2, x3, x4, c_3t, c_31, c_32, c_33, c_34, fr_out_4)
        d_x_5 = fr5_bwd(
            x1, x2, x3, x4, x5, c_4t, c_41, c_42, c_43, c_44, c_45, fr_out_5
        )
        d_x_6 = fr6_bwd(
            x1, x2, x3, x4, x5, x6, c_5t, c_51, c_52, c_53, c_54, c_55, c_56, fr_out_6
        )
        d_x_7 = fr7_bwd(
            x1,
            x2,
            x3,
            x4,
            x5,
            x6,
            x7,
            c_6t,
            c_61,
            c_62,
            c_63,
            c_64,
            c_65,
            c_66,
            c_67,
            fr_out_7,
        )

        d_x_i = torch.cat([d_x_1, d_x_2, d_x_3, d_x_4, d_x_5, d_x_6, d_x_7], dim=1)
        # d_x = env * d_x_i + env_grad * fr_out
        # d_x = (grad_out * env).sum(-1, keepdim=True)
        d_x = env * (grad_out * d_x_i).sum(-1, keepdim=True) + env_grad * (
            grad_out * fr_out
        ).sum(-1, keepdim=True)
        ctx.save_for_backward(x, d_x_i, fr_out, grad_out)
        return d_x

    @staticmethod
    def backward(ctx, grad_d_x):
        print("SBF second backward: ", ctx.needs_input_grad)

        x, d_x_i, fr_out, grad_out = ctx.saved_tensors

        env = env_auto(x)
        env_grad = env_grad_auto(x)
        env_grad_grad = env_grad_grad_auto(x)

        x1, x2, x3, x4, x5, x6, x7 = get_pows(x)

        (
            fr_out_1,
            fr_out_2,
            fr_out_3,
            fr_out_4,
            fr_out_5,
            fr_out_6,
            fr_out_7,
        ) = fr_out.split(6, dim=-1)
        d_x_1, d_x_2, d_x_3, d_x_4, d_x_5, d_x_6, d_x_7 = d_x_i.split(6, dim=-1)

        d_d_x_1 = fr1_bwd_bwd(x1, c_0t, c_01, d_x_1, fr_out_1)
        d_d_x_2 = fr2_bwd_bwd(x1, x2, c_1t, c_11, c_12, d_x_2, fr_out_2)
        d_d_x_3 = fr3_bwd_bwd(x1, x2, x3, c_2t, c_21, c_22, c_23, d_x_3, fr_out_3)
        d_d_x_4 = fr4_bwd_bwd(
            x1, x2, x3, x4, c_3t, c_31, c_32, c_33, c_34, d_x_4, fr_out_4
        )
        d_d_x_5 = fr5_bwd_bwd(
            x1, x2, x3, x4, x5, c_4t, c_41, c_42, c_43, c_44, c_45, d_x_5, fr_out_5
        )
        d_d_x_6 = fr6_bwd_bwd(
            x1,
            x2,
            x3,
            x4,
            x5,
            x6,
            c_5t,
            c_51,
            c_52,
            c_53,
            c_54,
            c_55,
            c_56,
            d_x_6,
            fr_out_6,
        )
        d_d_x_7 = fr7_bwd_bwd(
            x1,
            x2,
            x3,
            x4,
            x5,
            x6,
            x7,
            c_6t,
            c_61,
            c_62,
            c_63,
            c_64,
            c_65,
            c_66,
            c_67,
            d_x_7,
            fr_out_7,
        )

        d_d_x_i = torch.cat(
            [d_d_x_1, d_d_x_2, d_d_x_3, d_d_x_4, d_d_x_5, d_d_x_6, d_d_x_7], dim=1
        )

        d_d_x = env * (grad_out * d_d_x_i).sum(-1, keepdim=True)
        d_d_x += 2 * env_grad * (grad_out * d_x_i).sum(-1, keepdim=True)
        d_d_x += env_grad_grad * (grad_out * fr_out).sum(-1, keepdim=True)
        d_d_x *= grad_d_x
        d_d_grad_out = grad_d_x * (env_grad * fr_out + env * d_x_i)

        return d_d_grad_out, d_d_x, None


if __name__ == "__main__":
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
    torch.use_deterministic_algorithms(True, warn_only=True)
    # setup debugging / printing stuff
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

    n_edges = 10
    n_hidden = 32

    dtype = torch.float64

    dist_ref, _ = generate_input(n_edges, DEVICE, dtype, 0.2, 0.8)
    dist_ref.requires_grad_(True)
    const_ref = torch.randn(n_edges, device=DEVICE, dtype=dtype, requires_grad=True)

    dist_test = dist_ref.clone().detach().requires_grad_(True)
    const_test = const_ref.clone().detach().requires_grad_(True)

    grad_inputs_ref = [dist_ref]
    grad_inputs_test = [dist_test]

    sbf_test = sbf_auto(dist_test)
    sbf_ref = SBFForward.apply(dist_ref)

    assert torch.allclose(sbf_test, sbf_ref)
    print("FWD PASSED")

    loss_ref = torch.sigmoid(sbf_ref.sum(-1) * const_ref).sum()
    loss_test = torch.sigmoid(sbf_test.sum(-1) * const_test).sum()
    loss_test.backward()
    loss_ref.backward()

    for i_ref, i_test in zip(grad_inputs_ref, grad_inputs_test):
        assert torch.allclose(i_test.grad, i_ref.grad)
        print("BWD PASSED")
        i_ref.grad.zero_()
        i_test.grad.zero_()

    sbf_test = sbf_auto(dist_test)
    sbf_ref = SBFForward.apply(dist_ref)

    grad_init_ref = torch.randn_like(sbf_ref)
    grad_init_test = grad_init_ref.clone().detach()
    grad_dist_ref = torch.autograd.grad(
        sbf_ref, dist_ref, grad_outputs=grad_init_ref, create_graph=True
    )[0]
    grad_dist_test = torch.autograd.grad(
        sbf_test, dist_test, grad_outputs=grad_init_test, create_graph=True
    )[0]
    assert torch.allclose(grad_dist_ref, grad_dist_test)
    print("GRAD PASSED")

    target_ref = torch.randn_like(sbf_ref)
    target_test = target_ref.clone().detach()

    loss_ref = ((grad_dist_ref - target_ref) ** 2).sum()
    loss_test = ((grad_dist_test - target_test) ** 2).sum()

    loss_ref.backward()
    loss_test.backward()

    for i_ref, i_test in zip(grad_inputs_ref, grad_inputs_test):
        assert torch.allclose(i_test.grad, i_ref.grad)
        print("BWD BWD PASSED")
