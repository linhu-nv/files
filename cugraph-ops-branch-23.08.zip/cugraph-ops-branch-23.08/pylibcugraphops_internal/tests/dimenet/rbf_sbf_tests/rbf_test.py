# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pickle import TRUE
import torch

import pylibcugraphops_internal_ext as internal_ext

from util import envelope, bessel_basis, envelope_paper, bessel_basis_paper
from util import (
    envelope_jit,
    bessel_basis_jit,
    envelope_paper_jit,
    bessel_basis_paper_jit,
)
from util import NVTXPush, NVTXPop
from sbf_ref import SphericalBasisLayer
from sbf_jit import SphericalBasisLayerJIT

from radial_basis import RadialBasis

import os
import time
import pandas as pd

n_spherical, n_radial, n_vec = 7, 6, 3
DEVICE = "cuda"  # nothing else implemented
USE_PAPER_VERSION = False

NEEDS_DIST_GRAD = True
NEEDS_FREQ_GRAD = True


# for debugging: zero out gradient for certain radial components
def get_rbf_grad(rbf, component=-1):
    # all radial components
    if component == -1:
        grad = torch.ones_like(rbf)
    # no radial compnent
    elif component == -2:
        grad = torch.zeros_like(rbf)
    # in [0, 5]: one specific radial component
    else:
        grad = torch.zeros_like(rbf)
        grad[:, component] = 1
    grad.requires_grad_(False)
    return grad


# for debugging: zero out gradient for certain spherical components
def get_sbf_rad_grad(sbf_rad, component=-1):
    # all spherical components
    if component == -1:
        grad = torch.ones_like(sbf_rad)
    # no spherial component
    elif component == -2:
        grad = torch.zeros_like(sbf_rad)
    # in [0, 6]: one specific spherical component with all radial components
    else:
        grad = torch.zeros_like(sbf_rad)
        for c in range(n_radial):
            grad[:, component * n_radial + c] = 1
    grad.requires_grad_(False)
    return grad


def test_impl_batch(num_edges, device, dtype, num_batches):
    layer = RadialBasis(n_spherical, n_radial)

    dist, freq = generate_input(num_edges, device, dtype, 0.1, 1.0)
    dist.requires_grad_(NEEDS_DIST_GRAD)
    freq.requires_grad_(NEEDS_FREQ_GRAD)

    w1 = torch.ones(
        (1, n_radial * n_spherical),
        dtype=dist.dtype,
        device=dist.device,
        requires_grad=True,
    )
    w2 = torch.ones(
        (1, n_radial), dtype=dist.dtype, device=dist.device, requires_grad=True
    )

    internal_ext.utils.push_range("custom kernel")

    for _ in range(num_batches):

        nvtx_range = "RBF custom kernel"
        dist_nvtx, freq_nvtx, w1_nvtx, w2_nvtx = NVTXPush.apply(
            nvtx_range, dist, freq, w1, w2
        )

        rbf, sbf_rad = layer(dist_nvtx, freq_nvtx)
        rbf, sbf_rad = NVTXPop.apply(nvtx_range, rbf, sbf_rad)

        energy = (w1_nvtx * sbf_rad * get_sbf_rad_grad(sbf_rad)).sum(
            -1, keepdim=True
        ) + (w2_nvtx * rbf * get_rbf_grad(rbf)).sum(-1, keepdim=True)

        grad_x = torch.autograd.grad(
            energy, inputs=dist, grad_outputs=torch.ones_like(energy), create_graph=True
        )[0]
        loss = ((grad_x - torch.ones_like(dist)) ** 2).sum()

        loss.backward()

    internal_ext.utils.pop_range()


def test_impl_forward(num_edges, dist, freq, device, dtype):
    layer = RadialBasis(n_spherical, n_radial)

    nvtx_range = "RBF custom kernel"

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    dist, freq = NVTXPush.apply(nvtx_range, dist, freq)
    start.record()
    rbf, sbf_rad = layer(dist, freq)
    end.record()
    rbf, sbf_rad = NVTXPop.apply(nvtx_range, rbf, sbf_rad)

    torch.cuda.synchronize()
    elapsed = start.elapsed_time(end)

    out = {"rbf": rbf, "sbf_rad": sbf_rad}
    return out, elapsed


def test_ref_jit_batch(num_edges, device, dtype, num_batches):
    # create sbf_layer
    sbf_layer = SphericalBasisLayerJIT(
        n_spherical, n_radial, dtype=dtype, device=device, rbf_only=True
    )
    env_func = envelope_paper_jit if USE_PAPER_VERSION else envelope_jit
    rbf_func = bessel_basis_paper_jit if USE_PAPER_VERSION else bessel_basis_jit

    dist, freq = generate_input(num_edges, device, dtype, 0.1, 1.0)
    dist.requires_grad_(NEEDS_DIST_GRAD)
    freq.requires_grad_(NEEDS_FREQ_GRAD)

    w1 = torch.ones(
        (1, n_radial * n_spherical),
        dtype=dist.dtype,
        device=dist.device,
        requires_grad=True,
    )
    w2 = torch.ones(
        (1, n_radial), dtype=dist.dtype, device=dist.device, requires_grad=True
    )

    internal_ext.utils.push_range("JIT Reference")

    for _ in range(num_batches):

        nvtx_range = "RBF JIT reference"
        dist_nvtx, freq_nvtx, w1_nvtx, w2_nvtx = NVTXPush.apply(
            nvtx_range, dist, freq, w1, w2
        )

        env = env_func(dist_nvtx)
        sbf_rad = sbf_layer(dist_nvtx, None, None, env)
        rbf = rbf_func(dist_nvtx, freq_nvtx, env)
        rbf, sbf_rad = NVTXPop.apply(nvtx_range, rbf, sbf_rad)

        energy = (w1_nvtx * sbf_rad * get_sbf_rad_grad(sbf_rad)).sum(
            -1, keepdim=True
        ) + (w2_nvtx * rbf * get_rbf_grad(rbf)).sum(-1, keepdim=True)

        grad_x = torch.autograd.grad(
            energy, inputs=dist, grad_outputs=torch.ones_like(energy), create_graph=True
        )[0]
        loss = ((grad_x - torch.ones_like(dist)) ** 2).sum()

        loss.backward()

    internal_ext.utils.pop_range()


def test_ref_jit_forward(num_edges, dist, freq, device, dtype):
    # create sbf_layer
    sbf_layer = SphericalBasisLayerJIT(
        n_spherical, n_radial, dtype=dtype, device=device, rbf_only=True
    )
    env_func = envelope_paper_jit if USE_PAPER_VERSION else envelope_jit
    rbf_func = bessel_basis_paper_jit if USE_PAPER_VERSION else bessel_basis_jit

    nvtx_range = "RBF JIT reference"

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    dist, freq = NVTXPush.apply(nvtx_range, dist, freq)
    start.record()
    env = env_func(dist)
    sbf_rad = sbf_layer(dist, None, None, env)
    rbf = rbf_func(dist, freq, env)
    end.record()
    rbf, sbf_rad = NVTXPop.apply(nvtx_range, rbf, sbf_rad)

    torch.cuda.synchronize()
    elapsed = start.elapsed_time(end)

    out = {"rbf": rbf, "sbf_rad": sbf_rad}
    return out, elapsed


def test_ref_batch(num_edges, device, dtype, num_batches):
    # create sbf_layer
    sbf_layer = SphericalBasisLayer(
        n_spherical, n_radial, dtype=dtype, device=device, rbf_only=True
    )
    env_func = envelope_paper if USE_PAPER_VERSION else envelope
    rbf_func = bessel_basis_paper if USE_PAPER_VERSION else bessel_basis

    dist, freq = generate_input(num_edges, device, dtype, 0.1, 1.0)
    dist.requires_grad_(NEEDS_DIST_GRAD)
    freq.requires_grad_(NEEDS_FREQ_GRAD)

    w1 = torch.ones(
        (1, n_radial * n_spherical),
        dtype=dist.dtype,
        device=dist.device,
        requires_grad=True,
    )
    w2 = torch.ones(
        (1, n_radial), dtype=dist.dtype, device=dist.device, requires_grad=True
    )

    internal_ext.utils.push_range("Reference")

    for _ in range(num_batches):

        nvtx_range = "RBF reference"
        dist_nvtx, freq_nvtx, w1_nvtx, w2_nvtx = NVTXPush.apply(
            nvtx_range, dist, freq, w1, w2
        )

        env = env_func(dist_nvtx)
        sbf_rad = sbf_layer(dist_nvtx, None, None, env)
        rbf = rbf_func(dist_nvtx, freq_nvtx, env)
        rbf, sbf_rad = NVTXPop.apply(nvtx_range, rbf, sbf_rad)

        energy = (w1_nvtx * sbf_rad * get_sbf_rad_grad(sbf_rad)).sum(
            -1, keepdim=True
        ) + (w2_nvtx * rbf * get_rbf_grad(rbf)).sum(-1, keepdim=True)

        grad_x = torch.autograd.grad(
            energy, inputs=dist, grad_outputs=torch.ones_like(energy), create_graph=True
        )[0]
        loss = ((grad_x - torch.ones_like(dist)) ** 2).sum()

        loss.backward()

    internal_ext.utils.pop_range()


def test_ref_forward(num_edges, dist, freq, device, dtype):
    # create sbf_layer
    sbf_layer = SphericalBasisLayer(
        n_spherical, n_radial, dtype=dtype, device=device, rbf_only=True
    )
    env_func = envelope_paper if USE_PAPER_VERSION else envelope
    rbf_func = bessel_basis_paper if USE_PAPER_VERSION else bessel_basis

    nvtx_range = "RBF reference"

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    dist, freq = NVTXPush.apply(nvtx_range, dist, freq)
    start.record()
    env = env_func(dist)
    sbf_rad = sbf_layer(dist, None, None, env)
    rbf = rbf_func(dist, freq, env)
    end.record()
    rbf, sbf_rad = NVTXPop.apply(nvtx_range, rbf, sbf_rad)

    torch.cuda.synchronize()
    elapsed = start.elapsed_time(end)

    out = {"rbf": rbf, "sbf_rad": sbf_rad}
    return out, elapsed


def test_backward(out, dist, freq):
    sbf_rad, rbf = out["sbf_rad"], out["rbf"]
    nvtx_range = "setup_gradient"
    rbf, sbf_rad = NVTXPush.apply(nvtx_range, rbf, sbf_rad)
    tmp = (sbf_rad * get_sbf_rad_grad(sbf_rad)).sum() + (rbf * get_rbf_grad(rbf)).sum()
    tmp = NVTXPop.apply(nvtx_range, tmp)

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    start.record()
    tmp.backward()
    end.record()

    torch.cuda.synchronize()
    elapsed = start.elapsed_time(end)

    out_grad = {"grad_x": dist.grad, "grad_w": freq.grad}
    return out_grad, elapsed


def test_backward_backward(out, dist, freq):
    sbf_rad, rbf = out["sbf_rad"], out["rbf"]
    # to allow for comparing grad_grad_out implicitly through gradient on w1, and w2
    nvtx_range = "calculate_energy"
    sbf_rad, rbf = NVTXPush.apply(nvtx_range, sbf_rad, rbf)
    w1 = torch.ones(
        (1, sbf_rad.size(1)),
        dtype=sbf_rad.dtype,
        device=sbf_rad.device,
        requires_grad=True,
    )
    w2 = torch.ones(
        (1, rbf.size(1)), dtype=rbf.dtype, device=rbf.device, requires_grad=True
    )
    energy = (w1 * sbf_rad * get_sbf_rad_grad(sbf_rad)).sum(-1, keepdim=True) + (
        w2 * rbf * get_rbf_grad(rbf)
    ).sum(-1, keepdim=True)
    energy = NVTXPop.apply(nvtx_range, energy)

    nvtx_range = "calculate_loss"
    energy = NVTXPush.apply(nvtx_range, energy)
    grad_x = torch.autograd.grad(
        energy, inputs=dist, grad_outputs=torch.ones_like(energy), create_graph=True
    )[0]
    loss = ((grad_x - torch.ones_like(dist)) ** 2).sum()
    loss = NVTXPop.apply(nvtx_range, loss)

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    start.record()
    loss.backward()
    end.record()

    torch.cuda.synchronize()
    elapsed = start.elapsed_time(end)

    out_grad_grad = {"grad_w": freq.grad, "grad_w1": w1.grad, "grad_w2": w2.grad}
    return out_grad_grad, elapsed


def generate_input(num_edges, device, dtype, min_dist, max_dist):
    internal_ext.utils.push_range("generate_input")
    dist = (max_dist - min_dist) * torch.rand(
        num_edges, 1, device=device, dtype=dtype
    ) + min_dist
    # create vector of frequencies
    freq = torch.arange(1, n_radial + 1, device=device)
    freq = freq.to(dtype)
    freq = freq * 3.141592653589793
    internal_ext.utils.pop_range()
    return dist, freq


def test_against(
    mode,
    num_edges,
    model1,
    dtype1,
    model2,
    dtype2,
    min_dist,
    max_dist,
    relative_error=False,
):
    fwd_funcs = {
        "ref": test_ref_forward,
        "ref_jit": test_ref_jit_forward,
        "impl": test_impl_forward,
    }

    # convert lower precision targets later, start with torch.float64
    dist, freq = generate_input(num_edges, DEVICE, torch.float64, min_dist, max_dist)

    # adapt to dtypes
    dist1 = dist.clone()
    dist2 = dist.clone()
    freq1 = freq.clone()
    freq2 = freq.clone()

    if dtype1 != torch.float64:
        dist1 = dist.to(dtype1)
        freq1 = freq.to(dtype1)

    if dtype2 != torch.float64:
        dist2 = dist.to(dtype2)
        freq2 = freq.to(dtype2)

    # enable gradient
    dist1.requires_grad_(NEEDS_DIST_GRAD)
    freq1.requires_grad_(NEEDS_FREQ_GRAD)
    dist2.requires_grad_(NEEDS_DIST_GRAD)
    freq2.requires_grad_(NEEDS_FREQ_GRAD)

    if mode == "fwd":
        out1, time1 = fwd_funcs[model1](num_edges, dist1, freq1, DEVICE, dtype1)
        time.sleep(0.1)
        out2, time2 = fwd_funcs[model2](num_edges, dist2, freq2, DEVICE, dtype2)

    elif mode == "bwd":
        _tmp, _ = fwd_funcs[model1](num_edges, dist1, freq1, DEVICE, dtype1)
        out1, time1 = test_backward(_tmp, dist1, freq1)
        time.sleep(0.1)
        _tmp, _ = fwd_funcs[model2](num_edges, dist2, freq2, DEVICE, dtype2)
        out2, time2 = test_backward(_tmp, dist2, freq2)

    elif mode == "bwd_bwd":
        _tmp, _ = fwd_funcs[model1](num_edges, dist1, freq1, DEVICE, dtype1)
        out1, time1 = test_backward_backward(_tmp, dist1, freq1)
        time.sleep(0.1)
        _tmp, _ = fwd_funcs[model2](num_edges, dist2, freq2, DEVICE, dtype2)
        out2, time2 = test_backward_backward(_tmp, dist2, freq2)

    else:
        raise ValueError("Mode {} not implemented yet".format(mode))

    print(f"elapsed time: {time1} vs {time2}")

    res = {}
    for k, v in out1.items():
        if v is None:
            res[k] = None

        else:
            # ensure comparison in torch.float64
            if (v.dtype == torch.float32) and (out2[k].dtype == torch.float64):
                v = v.to(torch.float64)
            elif (v.dtype == torch.float64) and (out2[k].dtype == torch.float32):
                out2[k] = out2[k].to(torch.float64)

            tol = torch.abs(v - out2[k])
            if relative_error:
                mask = torch.abs(v) < torch.abs(out2[k])
                rel_tol = torch.zeros_like(tol)
                rel_tol[mask] = tol[mask] / torch.abs(out2[k][mask])
                rel_tol[~mask] = tol[~mask] / torch.abs(v[~mask])
                rel_tol = torch.nan_to_num(rel_tol, 0)
                res[k] = rel_tol.detach().cpu()
            else:
                res[k] = tol.detach().cpu()

    return res


def summarize_results(res, min_in, max_in):
    ranges = [
        (0, 1.0e-16),
        (1.0e-16, 1.0e-12),
        (1.0e-12, 1.0e-10),
        (1.0e-10, 1.0e-8),
        (1.0e-8, 1.0e-6),
        (1.0e-6, 1.0e-4),
        (1.0e-4, 1.0e-2),
        (1.0e-2, 1.0),
        (1.0, 100.0),
        (100.0, None),
    ]
    summary = {}
    for k, v in res.items():
        _sum = {}
        _sum["input_range"] = f"{min_in} - {max_in}"
        _sum["mean_error"] = v.mean().item() if v is not None else "x"
        _sum["max_error"] = v.max().item() if v is not None else "x"

        for a, b in ranges:
            if v is not None:
                if b is not None:
                    num_range = ((a <= v) & (v < b)).sum() * 100.0 / v.numel()
                else:
                    num_range = (a <= v).sum() * 100.0 / v.numel()
                num_range = num_range.item()
            range_str = f"{a} - {b}"
            _sum[range_str] = f"{num_range:.2f}" if v is not None else "x"

        _sum["NaN"] = (
            v.isnan().sum().item() * 100.0 / v.numel() if v is not None else "x"
        )

        summary[k] = _sum

    return summary


def test_fwd_detailed(min_max_pairs, num_edges, model1, dtype1, model2, dtype2):
    summary = {"rbf": {}, "sbf_rad": {}}

    for a, b in min_max_pairs:
        res = test_against("fwd", num_edges, model1, dtype1, model2, dtype2, a, b)
        rbf, sbf_rad = res["rbf"], res["sbf_rad"]
        rbf = rbf * get_rbf_grad(rbf)
        sbf_rad = sbf_rad * get_sbf_rad_grad(sbf_rad)
        res["rbf"] = rbf
        res["sbf_rad"] = sbf_rad
        tmp = summarize_results(res, a, b)
        for k, v in tmp.items():
            for v_k, v_v in v.items():
                if v_k not in summary[k]:
                    summary[k][v_k] = [v_v]
                else:
                    summary[k][v_k].append(v_v)

    summary = {k: pd.DataFrame(v) for k, v in summary.items()}
    for k, v in summary.items():
        print()
        print(f"{k}: FORWARD with #edges: {num_edges}")
        print(f"comparing {model1}-{dtype1} against {model2}-{dtype2}")
        print(v)
        print()


def test_bwd_detailed(min_max_pairs, num_edges, model1, dtype1, model2, dtype2):
    summary = {"grad_x": {}, "grad_w": {}}

    for a, b in min_max_pairs:
        res = test_against("bwd", num_edges, model1, dtype1, model2, dtype2, a, b)
        tmp = summarize_results(res, a, b)

        for k, v in tmp.items():
            for v_k, v_v in v.items():
                if v_k not in summary[k]:
                    summary[k][v_k] = [v_v]
                else:
                    summary[k][v_k].append(v_v)

    summary = {k: pd.DataFrame(v) for k, v in summary.items()}
    for k, v in summary.items():
        print()
        print(f"{k}: BACKWARD with #edges: {num_edges}")
        print(f"comparing {model1}-{dtype1} against {model2}-{dtype2}")
        print(v)
        print()


def test_bwd_bwd_detailed(min_max_pairs, num_edges, model1, dtype1, model2, dtype2):
    summary = {"grad_w": {}, "grad_w1": {}, "grad_w2": {}}

    for a, b in min_max_pairs:
        res = test_against("bwd_bwd", num_edges, model1, dtype1, model2, dtype2, a, b)
        tmp = summarize_results(res, a, b)

        for k, v in tmp.items():
            for v_k, v_v in v.items():
                if v_k not in summary[k]:
                    summary[k][v_k] = [v_v]
                else:
                    summary[k][v_k].append(v_v)

    summary = {k: pd.DataFrame(v) for k, v in summary.items()}
    for k, v in summary.items():
        print()
        print(f"{k}: BACKWARD-BACKWARD with #edges: {num_edges}")
        print(f"comparing {model1}-{dtype1} against {model2}-{dtype2}")
        print(v)
        print()


def fwd_detailed(tests, min_max_pairs, num_edges):
    for test in tests:
        test_fwd_detailed(min_max_pairs, num_edges, *test)


def bwd_detailed(tests, min_max_pairs, num_edges):
    for test in tests:
        test_bwd_detailed(min_max_pairs, num_edges, *test)


def bwd_bwd_detailed(tests, min_max_pairs, num_edges):
    for test in tests:
        test_bwd_bwd_detailed(min_max_pairs, num_edges, *test)


def gradcheck(min_dist, max_dist, num_edges=100):
    layer = RadialBasis(num_radial=6, num_spherical=7)

    def func1(f):
        return layer(dist, f)[1]

    def func0(f):
        return layer(dist, f)[0]

    dist, freq = generate_input(num_edges, DEVICE, torch.float64, min_dist, max_dist)
    dist.requires_grad_(False)
    freq.requires_grad_(NEEDS_FREQ_GRAD)

    try:
        torch.autograd.gradcheck(func0, freq)
        torch.autograd.gradcheck(func1, freq)
        print(f"GRADCHECK FP64 - PASSED")
    except Exception as e:
        print(f"GRADCHECK FP64 - FAILED: {e}")
    print()


def gradgradcheck(min_dist, max_dist, num_edges=100):
    layer = RadialBasis(num_radial=6, num_spherical=7)

    def func1(x, f):
        return layer(x, f)[1]

    def func0(x, f):
        return layer(x, f)[0]

    dist, freq = generate_input(num_edges, DEVICE, torch.float64, min_dist, max_dist)
    dist.requires_grad_(NEEDS_DIST_GRAD)
    freq.requires_grad_(NEEDS_FREQ_GRAD)

    try:
        torch.autograd.gradgradcheck(func0, (dist, freq))
        torch.autograd.gradgradcheck(func1, (dist, freq))
        print(f"GRADGRADCHECK FP64 - PASSED")
    except Exception as e:
        print(f"GRADGRADCHECK FP64 - FAILED: {e}")
    print()


if __name__ == "__main__":
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
    torch.use_deterministic_algorithms(True, warn_only=True)
    # setup debugging / printing stuff
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

    # enable nvtx
    internal_ext.utils.enable_nvtx_ranges()

    min_max_pairs = [
        (0.001, 0.01),
        (0.01, 0.05),
        (0.05, 0.1),
        (0.1, 0.25),
        (0.25, 0.5),
        (0.5, 1.0),
    ]
    min_max_pairs = list(reversed(min_max_pairs))

    tests = [
        # compare against reference
        ("impl", torch.float32, "ref", torch.float32),
        ("impl", torch.float64, "ref", torch.float64),
        # compare reference with different precisions
        ("ref", torch.float32, "ref", torch.float64),
        # compare against jit reference
        ("ref", torch.float32, "ref_jit", torch.float32),
    ]

    num_edges = 25_000
    num_batches = 100
    torch.set_printoptions(precision=60)

    fwd_detailed(tests, min_max_pairs, num_edges)
    bwd_detailed(tests, min_max_pairs, num_edges)
    bwd_bwd_detailed(tests, min_max_pairs, num_edges)

    # torch._C._jit_set_profiling_executor(False)
    # torch._C._jit_set_profiling_mode(False)

    # test_impl_batch(num_edges, DEVICE, torch.float64, num_batches)
    # test_impl_batch(num_edges, DEVICE, torch.float32, num_batches)
    # test_ref_batch(num_edges, DEVICE, torch.float64, num_batches)
    # test_ref_batch(num_edges, DEVICE, torch.float32, num_batches)
    # test_ref_jit_batch(num_edges, DEVICE, torch.float64, num_batches)
    # test_ref_jit_batch(num_edges, DEVICE, torch.float32, num_batches)
