# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops
import pylibcugraphops_internal_ext as internal_ext

import torch
import typing

NUM_RADIAL = 6
NUM_SPHERICAL = 7


class RadialBasis(torch.nn.Module):
    def __init__(self, num_spherical: int, num_radial: int) -> None:
        super().__init__()
        assert num_radial == NUM_RADIAL
        assert num_spherical == NUM_SPHERICAL

    def forward(
        self, x: torch.Tensor, w: torch.Tensor
    ) -> typing.Tuple[torch.Tensor, torch.Tensor]:
        # return RadialBasisForward.apply(x, w)
        return internal_ext.torch.dimenet.radial_basis(x, w)


# The following autograd classes aren't used/tested anymore but just kept
# for reference
class RadialBasisForward(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx, x: torch.Tensor, w: torch.Tensor
    ) -> typing.Tuple[torch.Tensor, torch.Tensor]:
        x = x.detach().contiguous()
        w = w.detach().contiguous()
        func = pylibcugraphops.dimenet.radial_basis_fwd
        if not func:
            raise ValueError(
                f"Implementation of RadialBasis does not support input of dtype {x.type}"
            )

        n = x.size(0)
        rbf = torch.empty(
            (n, NUM_RADIAL),
            dtype=x.dtype,
            device=x.device,
            requires_grad=(x.requires_grad or w.requires_grad),
        )
        sbf_rad = torch.empty(
            (n, NUM_RADIAL * NUM_SPHERICAL),
            dtype=x.dtype,
            device=x.device,
            requires_grad=x.requires_grad,
        )

        func(rbf, sbf_rad, x, w)

        ctx.save_for_backward(x, w)
        return rbf, sbf_rad

    @staticmethod
    def backward(
        ctx, grad_rbf: torch.Tensor, grad_sbf_rad: torch.Tensor
    ) -> typing.Tuple[torch.Tensor, torch.Tensor]:
        x, w = ctx.saved_tensors
        grad_rbf = grad_rbf.detach().contiguous()
        grad_sbf_rad = grad_sbf_rad.detach().contiguous()
        needs_grad_x, needs_grad_w = ctx.needs_input_grad
        return RadialBasisBackward.apply(
            grad_rbf, grad_sbf_rad, x, w, (needs_grad_x, needs_grad_w)
        )


class RadialBasisBackward(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        grad_rbf: torch.Tensor,
        grad_sbf_rad: torch.Tensor,
        x: torch.Tensor,
        w: torch.Tensor,
        others,
    ):
        needs_grad_x, needs_grad_w = others
        n = x.size(0)

        ctx.save_for_backward(grad_rbf, grad_sbf_rad, x, w)
        func = pylibcugraphops.dimenet.radial_basis_bwd
        if func is None:
            raise ValueError(
                f"Implementation of RadialBasis does not support input of dtype {x.type}"
            )

        if needs_grad_w and needs_grad_x:
            grad_x = torch.empty_like(x)
            grad_w = torch.zeros_like(w)
            func(grad_x, grad_w, grad_rbf, grad_sbf_rad, x, w)
            return grad_x, grad_w

        elif needs_grad_w:
            grad_w = torch.zeros_like(w)
            func(None, grad_w, grad_rbf, grad_sbf_rad, x, w)
            return None, grad_w

        elif needs_grad_x:
            grad_x = torch.empty_like(x)
            func(grad_x, None, grad_rbf, grad_sbf_rad, x, w)
            return grad_x, None

        else:
            raise AssertionError("EITHER grad_x OR grad_w is REQUIRED!")

    @staticmethod
    def backward(ctx, grad_grad_x: torch.Tensor, grad_grad_w: torch.Tensor):
        grad_rbf, grad_sbf_rad, x, w = ctx.saved_tensors
        grad_grad_x = grad_grad_x.detach().contiguous()
        grad_grad_w = grad_grad_w.detach().contiguous()

        func = pylibcugraphops.dimenet.radial_basis_bwd_bwd
        if func is None:
            raise ValueError(
                f"Implementation of RadialBasis does not support input of dtype {x.type}"
            )

        grad_grad_rbf = torch.empty_like(grad_rbf)
        grad_grad_sbf_rad = torch.empty_like(grad_sbf_rad)

        # DimeNet specific: we know that in the second backward pass, grad_x is NOT needed
        grad_w = torch.zeros_like(w)
        func(
            grad_grad_rbf,
            grad_grad_sbf_rad,
            grad_w,
            grad_grad_x,
            grad_grad_w,
            grad_rbf,
            grad_sbf_rad,
            x,
            w,
        )

        return grad_grad_rbf, grad_grad_sbf_rad, None, grad_w, None
