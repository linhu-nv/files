# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch

from sbf_ref import get_pows, get_cos_pow

from sbf_ref import fr1, fr2, fr3, fr4, fr5, fr6, fr7
from sbf_ref import fc1, fc2, fc3, fc4, fc5, fc6

from sbf_ref import (
    c_0t,
    c_1t,
    c_2t,
    c_3t,
    c_4t,
    c_5t,
    c_6t,
    c_01,
    c_11,
    c_12,
    c_21,
    c_22,
    c_23,
    c_31,
    c_32,
    c_33,
    c_34,
    c_41,
    c_42,
    c_43,
    c_44,
    c_45,
    c_51,
    c_52,
    c_53,
    c_54,
    c_55,
    c_56,
    c_61,
    c_62,
    c_63,
    c_64,
    c_65,
    c_66,
    c_67,
)

fr1_jit = torch.jit.script(fr1)
fr2_jit = torch.jit.script(fr2)
fr3_jit = torch.jit.script(fr3)
fr4_jit = torch.jit.script(fr4)
fr5_jit = torch.jit.script(fr5)
fr6_jit = torch.jit.script(fr6)
fr7_jit = torch.jit.script(fr7)

get_cos_pow_jit = torch.jit.script(get_cos_pow)
get_pows_jit = torch.jit.script(get_pows)

fc1_jit = torch.jit.script(fc1)
fc2_jit = torch.jit.script(fc2)
fc3_jit = torch.jit.script(fc3)
fc4_jit = torch.jit.script(fc4)
fc5_jit = torch.jit.script(fc5)
fc6_jit = torch.jit.script(fc6)


class SphericalBasisLayerJIT(torch.jit.ScriptModule):
    def __init__(
        self,
        num_spherical,
        num_radial,
        dtype,
        device="cuda",
        rbf_only=False,
        cos_angle=False,
    ):
        super().__init__()
        assert num_radial <= 64
        self.num_spherical = num_spherical
        self.num_radial = num_radial
        self.device = device
        self.rbf_only = rbf_only
        self.cos_angle = cos_angle

        self.c_01 = torch.tensor(c_01, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_0t = torch.tensor(c_0t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_11 = torch.tensor(c_11, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_12 = torch.tensor(c_12, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_1t = torch.tensor(c_1t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_21 = torch.tensor(c_21, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_22 = torch.tensor(c_22, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_23 = torch.tensor(c_23, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_2t = torch.tensor(c_2t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_31 = torch.tensor(c_31, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_32 = torch.tensor(c_32, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_33 = torch.tensor(c_33, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_34 = torch.tensor(c_34, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_3t = torch.tensor(c_3t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_41 = torch.tensor(c_41, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_42 = torch.tensor(c_42, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_43 = torch.tensor(c_43, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_44 = torch.tensor(c_44, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_45 = torch.tensor(c_45, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_4t = torch.tensor(c_4t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_51 = torch.tensor(c_51, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_52 = torch.tensor(c_52, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_53 = torch.tensor(c_53, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_54 = torch.tensor(c_54, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_55 = torch.tensor(c_55, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_56 = torch.tensor(c_56, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_5t = torch.tensor(c_5t, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_61 = torch.tensor(c_61, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_62 = torch.tensor(c_62, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_63 = torch.tensor(c_63, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_64 = torch.tensor(c_64, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_65 = torch.tensor(c_65, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_66 = torch.tensor(c_66, device=device, dtype=dtype)  # .unsqueeze(0)

        self.c_67 = torch.tensor(c_67, device=device, dtype=dtype)  # .unsqueeze(0)
        self.c_6t = torch.tensor(c_6t, device=device, dtype=dtype)  # .unsqueeze(0)

    def calc_rbf(self, x):
        x_1, x_2, x_3, x_4, x_5, x_6, x_7 = get_pows_jit(x)
        x7 = fr7_jit(
            x_1,
            x_2,
            x_3,
            x_4,
            x_5,
            x_6,
            x_7,
            self.c_6t,
            self.c_61,
            self.c_62,
            self.c_63,
            self.c_64,
            self.c_65,
            self.c_66,
            self.c_67,
        )

        x6 = fr6_jit(
            x_1,
            x_2,
            x_3,
            x_4,
            x_5,
            x_6,
            self.c_5t,
            self.c_51,
            self.c_52,
            self.c_53,
            self.c_54,
            self.c_55,
            self.c_56,
        )
        x5 = fr5_jit(
            x_1,
            x_2,
            x_3,
            x_4,
            x_5,
            self.c_4t,
            self.c_41,
            self.c_42,
            self.c_43,
            self.c_44,
            self.c_45,
        )
        x4 = fr4_jit(
            x_1, x_2, x_3, x_4, self.c_3t, self.c_31, self.c_32, self.c_33, self.c_34
        )
        x3 = fr3_jit(x_1, x_2, x_3, self.c_2t, self.c_21, self.c_22, self.c_23)
        x2 = fr2_jit(x_1, x_2, self.c_1t, self.c_11, self.c_12)
        x1 = fr1_jit(x_1, self.c_0t, self.c_01)

        out = torch.cat([x1, x2, x3, x4, x5, x6, x7], 1)
        return out

    def calc_cbf(self, x):
        if self.cos_angle:
            c1, c2 = x, x * x
            c3 = c2 * c1
            c4, c6 = c2 * c2, c3 * c3
        else:
            c1, c2, c4, c6 = get_cos_pow_jit(x)
        out = torch.stack(
            [
                0.282094791773878
                * torch.ones(x.shape, device=self.device, dtype=x.dtype),
                fc1_jit(c1),
                fc2_jit(c2),
                fc3_jit(c1, c2),
                fc4_jit(c2, c4),
                fc5_jit(c1, c2, c4),
                fc6_jit(c2, c4, c6),
            ],
            1,
        )
        return out

    def forward(self, dist, angle, idx_kj, env):
        rbf = env * self.calc_rbf(dist)
        if self.rbf_only:
            return rbf

        return rbf, self.calc_cbf(angle)
