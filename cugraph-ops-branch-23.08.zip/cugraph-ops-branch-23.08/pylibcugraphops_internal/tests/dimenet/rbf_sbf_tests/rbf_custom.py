# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch

import os
import time

from rbf_test import generate_input

n_spherical, n_radial, n_vec = 7, 6, 3
DEVICE = "cuda"  # nothing else implemented


def env_auto(x):
    x_pow_p0 = torch.pow(x, 5)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 / x - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


def env_grad_auto(x):
    x_pow_p0 = torch.pow(x, 4)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (-1.0 / x**2 - 140 * x_pow_p0 + 288 * x_pow_p1 - 147 * x_pow_p2) * (
        x < 1.0
    )


def env_grad_grad_auto(x):
    x_pow_p0 = torch.pow(x, 3)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (2.0 / x**3 - 560 * x_pow_p0 + 1440 * x_pow_p1 - 882 * x_pow_p2) * (
        x < 1.0
    )


def rbf_auto(x, w):
    env = env_auto(x)
    return env * (x * w).sin()


class RBFForward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, w):
        env = env_auto(x)
        ctx.save_for_backward(x, w)
        return env * (x * w).sin()

    @staticmethod
    def backward(ctx, grad_out):
        x, w = ctx.saved_tensors
        print("RBF simple backward: ", ctx.needs_input_grad)
        return RBFBackward.apply(grad_out, x, w)


class RBFBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, grad_out, x, w):
        ctx.save_for_backward(grad_out, x, w)
        env = env_auto(x)
        env_grad = env_grad_auto(x)
        d_x = env * torch.cos(x * w) * w + env_grad * torch.sin(x * w)
        d_x = (grad_out * d_x).sum(-1, keepdim=True)
        d_w = env * torch.cos(x * w) * x
        d_w = (grad_out * d_w).sum(0)

        return d_x, d_w

    @staticmethod
    def backward(ctx, grad_d_x, grad_d_w):
        print("RBF second backward: ", ctx.needs_input_grad)
        grad_out, x, w = ctx.saved_tensors

        assert torch.all(grad_d_w == 0).item()

        env = env_auto(x)
        env_grad = env_grad_auto(x)
        env_grad_grad = env_grad_grad_auto(x)

        d_d_x = (
            env * (-(x * w).sin()) * w**2
            + 2 * env_grad * (x * w).cos() * w
            + env_grad_grad * (x * w).sin()
        )
        d_d_x = grad_d_x * (grad_out * d_d_x).sum(-1, keepdim=True)

        d_d_w = env * (-(x * w).sin()) * x**2
        d_d_w = grad_d_w * (grad_out * d_d_w).sum(0)

        dd_xw = (
            env * torch.cos(x * w)
            - env * torch.sin(x * w) * x * w
            + env_grad * torch.cos(x * w) * x
        )
        d_d_x_w = (grad_d_w.unsqueeze(0) * grad_out * dd_xw).sum(-1, keepdim=True)
        d_d_w_x = (grad_d_x * grad_out * dd_xw).sum(0)

        d_d_x_grad_out = env * (x * w).cos() * w + env_grad * (x * w).sin()
        d_d_x_grad_out *= grad_d_x

        d_d_w_grad_out = env * (x * w).cos() * x
        d_d_w_grad_out *= grad_d_w.unsqueeze(0)

        d_d_grad_out = d_d_x_grad_out + d_d_w_grad_out
        d_d_w = d_d_w + d_d_w_x
        d_d_x = d_d_x + d_d_x_w

        return d_d_grad_out, d_d_x, d_d_w


if __name__ == "__main__":
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
    torch.use_deterministic_algorithms(True, warn_only=True)
    # setup debugging / printing stuff
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

    n_edges = 5
    n_hidden = 32

    dtype = torch.float64

    dist_impl, freq_impl = generate_input(n_edges, DEVICE, dtype, 0.2, 0.8)
    dist_impl.requires_grad_(True)
    freq_impl.requires_grad_(True)
    const_impl = torch.randn(n_edges, device=DEVICE, dtype=dtype, requires_grad=True)

    dist_ref = dist_impl.clone().detach().requires_grad_(True)
    freq_ref = freq_impl.clone().detach().requires_grad_(True)
    const_ref = const_impl.clone().detach().requires_grad_(True)

    grad_inputs_impl = [dist_impl, freq_impl]
    grad_inputs_ref = [dist_ref, freq_ref]

    rbf_ref = rbf_auto(dist_ref, freq_ref)
    rbf_impl = RBFForward.apply(dist_impl, freq_impl)

    assert torch.allclose(rbf_ref, rbf_impl)

    loss_impl = torch.sigmoid(rbf_impl.sum(-1) * const_impl).sum()
    loss_ref = torch.sigmoid(rbf_ref.sum(-1) * const_ref).sum()
    loss_ref.backward()
    loss_impl.backward()

    for i_impl, i_ref in zip(grad_inputs_impl, grad_inputs_ref):
        assert torch.allclose(i_ref.grad, i_impl.grad)
        i_impl.grad.zero_()
        i_ref.grad.zero_()

    rbf_ref = rbf_auto(dist_ref, freq_ref)
    rbf_impl = RBFForward.apply(dist_impl, freq_impl)

    grad_init_impl = torch.randn_like(rbf_impl)
    grad_init_ref = grad_init_impl.clone().detach()
    grad_dist_impl = torch.autograd.grad(
        rbf_impl, dist_impl, grad_outputs=grad_init_impl, create_graph=True
    )[0]
    grad_dist_ref = torch.autograd.grad(
        rbf_ref, dist_ref, grad_outputs=grad_init_ref, create_graph=True
    )[0]
    assert torch.allclose(grad_dist_impl, grad_dist_ref)

    target_impl = torch.randn_like(rbf_impl)
    target_ref = target_impl.clone().detach()

    loss_impl = ((grad_dist_impl - target_impl) ** 2).sum()
    loss_ref = ((grad_dist_ref - target_ref) ** 2).sum()

    loss_impl.backward()
    loss_ref.backward()

    for i_impl, i_ref in zip(grad_inputs_impl, grad_inputs_ref):
        assert torch.allclose(i_ref.grad, i_impl.grad)
