# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# This is tested with the following conda environment:
# mamba env create -f <repo>/conda/envs/cugraph_ops_dev_torch_cuda11.5.yaml
# then installing pytorch scatter/sparse with the following command:
# mamba install -c pyg -c conda-forge
# pytorch-sparse=0.6.14=py39_torch_1.11.0_cu113
# pytorch-scatter=2.0.9=py39_torch_1.11.0_cu113
# magma=2.5.4 libprotobuf=3.20.1 sleef=3.5.1 --no-deps

import argparse
import os
import sys
import torch
from torch.linalg import vector_norm
from torch_scatter import scatter
from util import erdos_renyi_graph, get_triplets, print_stats, get_edge_offsets
from sbf_ref import SphericalBasisLayer

from pylibcugraphops_internal.utils import MMAOp
import pylibcugraphops_internal_ext as internal_ext

try:
    import torchviz

    HAS_TORCHVIZ = True
except Exception:
    HAS_TORCHVIZ = False

n_spherical, n_radial, n_vec, n_feat, n_mid = 7, 6, 3, 64, 8
n_sbf = n_spherical * n_radial

LOG_MODEL_BWD_POS = False


def ib_cos(e_vec, idx_kj, idx_ji):
    pos_ji, pos_kj = e_vec[idx_ji], e_vec[idx_kj]
    a = (pos_ji * pos_kj).sum(dim=-1)
    return a * (1.0 / vector_norm(pos_ji, dim=-1)) * (1.0 / vector_norm(pos_kj, dim=-1))


def ib_angle(e_vec, idx_kj, idx_ji):
    pos_ji, pos_kj = e_vec[idx_ji], e_vec[idx_kj]
    a = (pos_ji * pos_kj).sum(dim=-1)
    b = torch.cross(pos_ji, pos_kj).norm(p=2, dim=-1)
    return torch.atan2(b, a)


def ib_cbf(cbf, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji):
    # required for JIT as it doesn't like global variables
    n_spherical, n_radial = 7, 6
    n_sbf = n_spherical * n_radial
    sbf = (
        e_rbf[idx_kj].view(-1, n_spherical, n_radial) * cbf.view(-1, n_spherical, 1)
    ).view(-1, n_spherical * n_radial)
    sbf_mid = torch.matmul(sbf, sbf_weights[:n_sbf])
    sbf_ft = torch.matmul(sbf_mid, sbf_weights[n_sbf:].t())
    x_kj = e_in_ft[idx_kj] * sbf_ft
    x_ji = scatter(x_kj, idx_ji, dim=0, dim_size=e_in_ft.size(0))
    return x_ji


cbf_cos_jit = torch.jit.script(SphericalBasisLayer.calc_cbf_cos)
cbf_angle_jit = torch.jit.script(SphericalBasisLayer.calc_cbf_angle)


def ib_full_cos_jit(e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji):
    cbf = cbf_cos_jit(ib_cos(e_vec, idx_kj, idx_ji))
    return ib_cbf(cbf, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji)


def ib_full_angle_jit(e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji):
    cbf = cbf_angle_jit(ib_angle(e_vec, idx_kj, idx_ji))
    return ib_cbf(cbf, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji)


ib_full_cos_full_jit = torch.jit.script(ib_full_cos_jit)
ib_full_angle_full_jit = torch.jit.script(ib_full_angle_jit)


class IBAutograd(object):
    # this is just a class to keep the same API as the custom functions
    need_sbf_layer = True
    need_triplets = True
    need_offsets = False
    need_aux_storage = False

    @staticmethod
    def apply(e_vec, e_rbf, e_in_ft, sbf_weights, others):
        sbf_layer, triplets = others[-2:]
        idx_kj, idx_ji = triplets[-2:]
        if sbf_layer.cos_angle:
            cbf = SphericalBasisLayer.calc_cbf_cos(ib_cos(e_vec, idx_kj, idx_ji))
        else:
            cbf = SphericalBasisLayer.calc_cbf_angle(ib_angle(e_vec, idx_kj, idx_ji))
        return ib_cbf(cbf, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji)


class IBAutogradJIT(object):
    # this is just a class to keep the same API as the custom functions
    need_sbf_layer = True
    need_triplets = True
    need_offsets = False
    need_aux_storage = False

    @staticmethod
    def apply(e_vec, e_rbf, e_in_ft, sbf_weights, others):
        sbf_layer, triplets = others[-2:]
        idx_kj, idx_ji = triplets[-2:]
        if sbf_layer.cos_angle:
            return ib_full_cos_jit(e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji)
        else:
            return ib_full_angle_jit(e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji)


class IBAutogradJITFull(object):
    # this is just a class to keep the same API as the custom functions
    need_sbf_layer = True
    need_triplets = True
    need_offsets = False
    need_aux_storage = False

    @staticmethod
    def apply(e_vec, e_rbf, e_in_ft, sbf_weights, others):
        sbf_layer, triplets = others[-2:]
        idx_kj, idx_ji = triplets[-2:]
        if sbf_layer.cos_angle:
            return ib_full_cos_full_jit(
                e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji
            )
        else:
            return ib_full_angle_full_jit(
                e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji
            )


class IBTorchCustomFwd(torch.autograd.Function):
    need_sbf_layer = True
    need_triplets = True
    need_offsets = False
    need_aux_storage = False

    @staticmethod
    def forward(ctx, e_vec, e_rbf, e_in_ft, sbf_weights, others):
        edge_index, i, sbf_layer, triplets = others
        idx_kj, idx_ji = triplets[-2:]
        ctx.save_for_backward(e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji)
        ctx.sbf_layer = sbf_layer
        ctx.n_edges = edge_index.size(1)
        ctx.i = i
        return IBAutograd.apply(e_vec, e_rbf, e_in_ft, sbf_weights, others)

    @staticmethod
    def backward(ctx, grad_e_out_ft):
        e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji = ctx.saved_tensors
        if LOG_MODEL_BWD_POS:
            print("simple backward", ctx.i, ":", ctx.needs_input_grad)
        assert not ctx.needs_input_grad[0]
        assert not ctx.needs_input_grad[-1]
        outputs = IBTorchCustomBwd.apply(
            grad_e_out_ft,
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            (idx_kj, idx_ji, ctx.sbf_layer, ctx.n_edges, ctx.i),
        )
        return (None,) + outputs + (None,)


class IBTorchCustomBwd(torch.autograd.Function):
    @staticmethod
    def forward(ctx, grad_e_out_ft, e_vec, e_rbf, e_in_ft, sbf_weights, others):
        idx_kj, idx_ji, sbf_layer, n_edges, i = others
        ctx.save_for_backward(
            grad_e_out_ft, e_vec, e_rbf, e_in_ft, sbf_weights, idx_kj, idx_ji
        )
        ctx.sbf_layer = sbf_layer
        ctx.n_edges = n_edges
        ctx.i = i

        # repeat forward:
        pos_ji, pos_kj = e_vec[idx_ji], e_vec[idx_kj]
        a = (pos_ji * pos_kj).sum(dim=-1)
        if sbf_layer.cos_angle:
            angle = (
                a
                * (1.0 / vector_norm(pos_ji, dim=-1))
                * (1.0 / vector_norm(pos_kj, dim=-1))
            )
        else:
            b = torch.cross(pos_ji, pos_kj).norm(dim=-1)
            angle = torch.atan2(b, a)
        cbf = sbf_layer.calc_cbf(angle)
        sbf = (
            e_rbf[idx_kj].view(-1, n_spherical, n_radial) * cbf.view(-1, n_spherical, 1)
        ).view(-1, n_spherical * n_radial)

        sbf_mid = torch.matmul(sbf, sbf_weights[:n_sbf])
        sbf_ft = torch.matmul(sbf_mid, sbf_weights[n_sbf:].t())

        grad_t_in_ft = grad_e_out_ft[idx_ji] * sbf_ft
        grad_e_in_ft = scatter(grad_t_in_ft, idx_kj, dim=0, dim_size=n_edges)

        grad_sbf_ft = grad_e_out_ft[idx_ji] * e_in_ft[idx_kj]
        grad_w2 = torch.matmul(grad_sbf_ft.t(), sbf_mid)
        grad_sbf_mid = torch.matmul(grad_sbf_ft, sbf_weights[n_sbf:])
        grad_w1 = torch.matmul(sbf.t(), grad_sbf_mid)

        grad_sbf_weights = torch.cat([grad_w1, grad_w2])

        grad_sbf = torch.matmul(grad_sbf_mid, sbf_weights[:n_sbf].t())
        grad_rbf = (
            grad_sbf.view(-1, n_spherical, n_radial) * cbf.view(-1, n_spherical, 1)
        ).view(-1, n_spherical * n_radial)
        grad_e_rbf = scatter(grad_rbf, idx_kj, dim=0, dim_size=n_edges)

        return grad_e_rbf, grad_e_in_ft, grad_sbf_weights

    @staticmethod
    def backward(ctx, grad_grad_e_rbf, grad_grad_e_in_ft, grad_grad_sbf_weights):
        if LOG_MODEL_BWD_POS:
            print("second backward", ctx.i, ":", ctx.needs_input_grad)
        (
            grad_e_out_ft,
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            idx_kj,
            idx_ji,
        ) = ctx.saved_tensors
        assert not ctx.needs_input_grad[1]
        assert not ctx.needs_input_grad[-1]
        # the following holds
        # assert torch.all(grad_grad_sbf_weights == 0).item()

        # repeat part of forward up to cbf
        pos_ji, pos_kj = e_vec[idx_ji], e_vec[idx_kj]
        a = (pos_ji * pos_kj).sum(dim=-1)
        if ctx.sbf_layer.cos_angle:
            angle = (
                a
                * (1.0 / vector_norm(pos_ji, dim=-1))
                * (1.0 / vector_norm(pos_kj, dim=-1))
            )
        else:
            b = torch.cross(pos_ji, pos_kj).norm(dim=-1)
            angle = torch.atan2(b, a)
        cbf = ctx.sbf_layer.calc_cbf(angle)

        # re-calculate part of backward for rbf:
        grad_sbf_ft = grad_e_out_ft[idx_ji] * e_in_ft[idx_kj]
        grad_sbf_mid = torch.matmul(grad_sbf_ft, sbf_weights[n_sbf:])

        grad_grad_t_rbf = grad_grad_e_rbf[idx_kj]
        grad_grad_sbf = (
            grad_grad_t_rbf.view(-1, n_spherical, n_radial)
            * cbf.view(-1, n_spherical, 1)
        ).view(-1, n_spherical * n_radial)
        grad_w1_grad_e_rbf = torch.matmul(grad_grad_sbf.t(), grad_sbf_mid)
        grad_grad_sbf_mid_grad_e_rbf = torch.matmul(grad_grad_sbf, sbf_weights[:n_sbf])
        grad_w2_grad_e_rbf = torch.matmul(grad_sbf_ft.t(), grad_grad_sbf_mid_grad_e_rbf)
        grad_grad_sbf_ft_grad_e_rbf = torch.matmul(
            grad_grad_sbf_mid_grad_e_rbf, sbf_weights[n_sbf:].t()
        )
        grad_grad_t_sbf_ft_grad_e_rbf = grad_grad_sbf_ft_grad_e_rbf * e_in_ft[idx_kj]
        grad_grad_e_out_ft_grad_e_rbf = scatter(
            grad_grad_t_sbf_ft_grad_e_rbf, idx_ji, dim=0, dim_size=ctx.n_edges
        )
        grad_t_in_ft_grad_e_rbf = grad_grad_sbf_ft_grad_e_rbf * grad_e_out_ft[idx_ji]
        grad_e_in_ft_grad_e_rbf = scatter(
            grad_t_in_ft_grad_e_rbf, idx_kj, dim=0, dim_size=ctx.n_edges
        )

        # repeat last part of forward
        sbf = (
            e_rbf[idx_kj].view(-1, n_spherical, n_radial) * cbf.view(-1, n_spherical, 1)
        ).view(-1, n_spherical * n_radial)
        sbf_mid = torch.matmul(sbf, sbf_weights[:n_sbf])
        sbf_ft = torch.matmul(sbf_mid, sbf_weights[n_sbf:].t())

        grad_grad_t_in_ft = grad_grad_e_in_ft[idx_kj]
        grad_grad_e_out_ft_grad_t_in_ft = grad_grad_t_in_ft * sbf_ft
        grad_grad_e_out_ft_grad_e_in_ft = scatter(
            grad_grad_e_out_ft_grad_t_in_ft, idx_ji, dim=0, dim_size=ctx.n_edges
        )

        grad_sbf_ft_grad_e_in_ft = grad_e_out_ft[idx_ji] * grad_grad_t_in_ft
        grad_w2_grad_e_in_ft = torch.matmul(grad_sbf_ft_grad_e_in_ft.t(), sbf_mid)
        grad_sbf_mid_grad_e_in_ft = torch.matmul(
            grad_sbf_ft_grad_e_in_ft, sbf_weights[n_sbf:]
        )
        grad_w1_grad_e_in_ft = torch.matmul(sbf.t(), grad_sbf_mid_grad_e_in_ft)
        grad_sbf_grad_e_in_ft = torch.matmul(
            grad_sbf_mid_grad_e_in_ft, sbf_weights[:n_sbf].t()
        )
        grad_rbf_grad_e_in_ft = (
            grad_sbf_grad_e_in_ft.view(-1, n_spherical, n_radial)
            * cbf.view(-1, n_spherical, 1)
        ).view(-1, n_spherical * n_radial)
        grad_rbf_grad_e_in_ft = scatter(
            grad_rbf_grad_e_in_ft, idx_kj, dim=0, dim_size=ctx.n_edges
        )

        grad_grad_e_out_ft = (
            grad_grad_e_out_ft_grad_e_rbf + grad_grad_e_out_ft_grad_e_in_ft
            if ctx.needs_input_grad[0]
            else None
        )
        grad_sbf_weights = torch.cat(
            [
                grad_w1_grad_e_rbf + grad_w1_grad_e_in_ft,
                grad_w2_grad_e_rbf + grad_w2_grad_e_in_ft,
            ]
        )

        return (
            grad_grad_e_out_ft,
            None,
            grad_rbf_grad_e_in_ft,
            grad_e_in_ft_grad_e_rbf,
            grad_sbf_weights,
            None,
        )


# the following interface is deprecated
class IBCustomDeprecated(torch.autograd.Function):
    need_sbf_layer = False
    need_triplets = False
    need_offsets = True
    need_aux_storage = False

    @staticmethod
    def forward(ctx, e_vec, e_rbf, e_in_ft, sbf_weights, others):
        edge_index, _, edge_offsets = others
        src_offsets, dst_offsets, dst_e_idx = edge_offsets
        # must create contiguous tensor to safely access pointer
        e_vec = e_vec.contiguous()
        e_rbf = e_rbf.contiguous()
        e_in_ft = e_in_ft.contiguous()
        sbf_weights = sbf_weights.contiguous()

        f_dtype = str(e_in_ft.dtype).split(".")[-1]
        i_dtype = str(edge_index.dtype).split(".")[-1]
        agg_func = getattr(
            internal_ext.torch.dimenet, "agg_dimenet_fwd_{}_{}".format(f_dtype, i_dtype)
        )

        ctx.save_for_backward(
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            edge_index,
            src_offsets,
            dst_offsets,
            dst_e_idx,
        )
        if torch.backends.cuda.matmul.allow_tf32:
            ctx.mma_op = MMAOp.LowPrecision
        else:
            ctx.mma_op = MMAOp.HighPrecision
        e_out_ft = torch.empty_like(e_in_ft)
        # must detach to safely access data pointer
        agg_func(
            e_out_ft,
            e_vec.detach(),
            e_rbf.detach(),
            e_in_ft.detach(),
            sbf_weights.detach(),
            edge_index,
            dst_offsets,
            dst_e_idx,
            ctx.mma_op,
        )
        return e_out_ft

    @staticmethod
    def backward(ctx, grad_e_out_ft):
        grad_e_out_ft = grad_e_out_ft.contiguous()
        (
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            edge_index,
            src_offsets,
            dst_offsets,
            dst_e_idx,
        ) = ctx.saved_tensors
        assert not ctx.needs_input_grad[0]
        assert not ctx.needs_input_grad[-1]
        outputs = IBCustomBwd.apply(
            grad_e_out_ft,
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            (edge_index, src_offsets, dst_offsets, dst_e_idx, ctx.mma_op),
        )
        return (None,) + outputs + (None,)


class IBCustomBwd(torch.autograd.Function):
    @staticmethod
    def forward(ctx, grad_e_out_ft, e_vec, e_rbf, e_in_ft, sbf_weights, others):
        edge_index, src_offsets, dst_offsets, dst_e_idx, mma_op = others
        ctx.save_for_backward(
            grad_e_out_ft,
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            edge_index,
            src_offsets,
            dst_offsets,
            dst_e_idx,
        )
        ctx.mma_op = mma_op

        f_dtype = str(e_in_ft.dtype).split(".")[-1]
        i_dtype = str(edge_index.dtype).split(".")[-1]
        agg_func = getattr(
            internal_ext.torch.dimenet, "agg_dimenet_bwd_{}_{}".format(f_dtype, i_dtype)
        )

        grad_e_rbf = torch.empty_like(e_rbf)
        grad_e_in_ft = torch.empty_like(e_in_ft)
        grad_sbf_weights = torch.empty_like(sbf_weights)

        agg_func(
            grad_e_rbf,
            grad_e_in_ft,
            grad_sbf_weights,
            e_vec.detach(),
            e_rbf.detach(),
            e_in_ft.detach(),
            grad_e_out_ft.detach(),
            sbf_weights.detach(),
            edge_index,
            src_offsets,
            ctx.mma_op,
        )

        return grad_e_rbf, grad_e_in_ft, grad_sbf_weights

    @staticmethod
    def backward(ctx, grad_grad_e_rbf, grad_grad_e_in_ft, grad_grad_sbf_weights):
        grad_grad_e_rbf = grad_grad_e_rbf.contiguous()
        grad_grad_e_in_ft = grad_grad_e_in_ft.contiguous()
        grad_grad_sbf_weights = grad_grad_sbf_weights.contiguous()

        (
            grad_e_out_ft,
            e_vec,
            e_rbf,
            e_in_ft,
            sbf_weights,
            edge_index,
            src_offsets,
            dst_offsets,
            dst_e_idx,
        ) = ctx.saved_tensors
        assert not ctx.needs_input_grad[1]
        assert not ctx.needs_input_grad[-1]

        f_dtype = str(e_in_ft.dtype).split(".")[-1]
        i_dtype = str(edge_index.dtype).split(".")[-1]
        agg_func = getattr(
            internal_ext.torch.dimenet, "agg_dimenet_bwd2_main_{}_{}".format(f_dtype, i_dtype)
        )

        grad_rbf_grad_e_in_ft = torch.empty_like(e_rbf)
        grad_e_in_ft_grad_e_rbf = torch.empty_like(e_in_ft)
        grad_sbf_weights = torch.empty_like(sbf_weights)
        agg_func(
            grad_rbf_grad_e_in_ft,
            grad_e_in_ft_grad_e_rbf,
            grad_sbf_weights,
            e_vec.detach(),
            e_rbf.detach(),
            grad_grad_e_rbf.detach(),
            e_in_ft.detach(),
            grad_grad_e_in_ft.detach(),
            grad_e_out_ft.detach(),
            sbf_weights.detach(),
            edge_index,
            src_offsets,
            ctx.mma_op,
        )

        if ctx.needs_input_grad[0]:
            grad_grad_e_out_ft = torch.empty_like(grad_e_out_ft)
            agg_func_grad = getattr(
                internal_ext.torch.dimenet, "agg_dimenet_bwd2_grad_{}_{}".format(f_dtype, i_dtype)
            )
            agg_func_grad(
                grad_grad_e_out_ft,
                e_vec.detach(),
                e_rbf.detach(),
                grad_grad_e_rbf.detach(),
                e_in_ft.detach(),
                grad_grad_e_in_ft.detach(),
                sbf_weights.detach(),
                edge_index,
                dst_offsets,
                dst_e_idx,
                ctx.mma_op,
            )
        else:
            grad_grad_e_out_ft = None

        return (
            grad_grad_e_out_ft,
            None,
            grad_rbf_grad_e_in_ft,
            grad_e_in_ft_grad_e_rbf,
            grad_sbf_weights,
            None,
        )


class IBCustom(object):
    need_sbf_layer = False
    need_triplets = False
    need_offsets = True
    need_aux_storage = False

    def apply(e_vec, e_rbf, e_in_ft, sbf_weights, others):
        edge_index, _, edge_offsets = others
        src_offsets, dst_offsets, dst_e_idx = edge_offsets
        if torch.backends.cuda.matmul.allow_tf32:
            mma_op = MMAOp.LowPrecision
        else:
            mma_op = MMAOp.HighPrecision
        return internal_ext.torch.dimenet.ib_agg_edge(
            e_vec, e_rbf, e_in_ft, sbf_weights, edge_index, src_offsets,
            dst_offsets, dst_e_idx, mma_op
        )


def get_args():
    parser = argparse.ArgumentParser(
        "Tests perf and correctness of Dimenet++ interaction block"
    )
    parser.add_argument(
        "-nodes",
        default=450,
        type=int,
        help="Number of nodes to use in test (default 450)",
    )
    parser.add_argument(
        "-edge_prob", default=0.08, type=float, help="Edge probability (default 0.08)"
    )
    parser.add_argument(
        "-dtype_ref", default="float64", help="Data type of reference (default float64)"
    )
    parser.add_argument(
        "-dtype_test", default="float64", help="Data type of test (default float64)"
    )
    parser.add_argument(
        "-rtol",
        default=1e-3,
        type=float,
        help="Relative tolerance for test (default 1e-3)",
    )
    parser.add_argument(
        "-atol",
        default=1e-5,
        type=float,
        help="Absolute tolerance for test (default 1e-5)",
    )
    parser.add_argument(
        "-no_cos_angle",
        action="store_true",
        help="If set, do not use direct cosine of angle in reference",
    )
    parser.add_argument(
        "-ref_class",
        default="IBAutograd",
        help="Class to use as reference (default IBAutograd)",
    )
    parser.add_argument(
        "-test_class",
        default="IBCustom",
        help="Class to use for test (default IBCustom)",
    )
    parser.add_argument(
        "-viz_graph", action="store_true", help="If set, visualize autograd graph"
    )
    parser.add_argument(
        "-timing",
        action="store_true",
        help="If set, after correctness check, time both reference and test",
    )
    args = parser.parse_args()
    if not hasattr(sys.modules[__name__], args.ref_class):
        raise ValueError(
            "No class {} in current module {}".format(args.ref_class, __name__)
        )
    args.ref_class = getattr(sys.modules[__name__], args.ref_class)
    if not hasattr(sys.modules[__name__], args.test_class):
        raise ValueError(
            "No class {} in current module {}".format(args.test_class, __name__)
        )
    args.test_class = getattr(sys.modules[__name__], args.test_class)
    if not hasattr(torch, args.dtype_ref):
        raise ValueError("Unknown pytorch data type {}".format(args.dtype_ref))
    args.dtype_ref = getattr(torch, args.dtype_ref)
    if not hasattr(torch, args.dtype_test):
        raise ValueError("Unknown pytorch data type {}".format(args.dtype_test))
    args.dtype_test = getattr(torch, args.dtype_test)
    args.use_cos_angle = not args.no_cos_angle
    return args


def main():
    args = get_args()

    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    if args.timing:
        # allow TF32 always to have a "competitive" reference
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    else:
        # as in pytorch 1.12 default: don't allow TF32 for MMs
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = True
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
        torch.use_deterministic_algorithms(True, warn_only=True)
        # setup debugging / printing stuff
        os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
    torch.set_printoptions(precision=4, sci_mode=False, edgeitems=6, linewidth=120)

    # create graph
    device = torch.device("cuda:0")
    edge_index = erdos_renyi_graph(args.nodes, edge_prob=args.edge_prob, directed=True)
    _, idx = torch.sort(edge_index[0], stable=True)
    edge_index = edge_index[:, idx]
    edge_index = edge_index.to(device=device)
    triplets = get_triplets(edge_index[0], edge_index[1], args.nodes)
    edge_offsets, src_deg, dst_deg = get_edge_offsets(edge_index, args.nodes)

    # is_ref is currently unused, but might be important if aux_storage
    # is used, e.g. if additional input is created based on dtype_ref or dtype_test
    def get_other_args(typ, i, sbf, is_ref):
        t = (edge_index, i)
        if typ.need_sbf_layer:
            t = t + (sbf,)
        if typ.need_triplets:
            t = t + (triplets,)
        if typ.need_offsets:
            t = t + (edge_offsets,)
        if typ.need_aux_storage:
            raise NotImplementedError

        return t

    print(
        "#nodes: {}, #edges: {}, #triplets: {}".format(
            args.nodes, edge_index.size(1), triplets[-1].size(0)
        )
    )

    # setup input tensors
    n_edges = edge_index.size(1)
    e_vec_ref = torch.randn(n_edges, n_vec, device=device, dtype=args.dtype_ref)
    e_vec_test = e_vec_ref.clone().detach().to(dtype=args.dtype_test)
    e_rbf_ref = torch.randn(
        n_edges, n_sbf, device=device, dtype=args.dtype_ref, requires_grad=True
    )
    e_rbf_test = (
        e_rbf_ref.clone().detach().to(dtype=args.dtype_test).requires_grad_(True)
    )
    e_in_ft_ref = torch.randn(
        n_edges, n_feat, device=device, dtype=args.dtype_ref, requires_grad=True
    )
    e_in_ft_test = (
        e_in_ft_ref.clone().detach().to(dtype=args.dtype_test).requires_grad_(True)
    )
    sbf_weights_ref = torch.randn(
        n_sbf + n_feat, n_mid, device=device, dtype=args.dtype_ref, requires_grad=True
    )
    sbf_weights_test = (
        sbf_weights_ref.clone().detach().to(dtype=args.dtype_test).requires_grad_(True)
    )
    sbf_weights2_ref = torch.randn(
        n_sbf + n_feat, n_mid, device=device, dtype=args.dtype_ref, requires_grad=True
    )
    sbf_weights2_test = (
        sbf_weights2_ref.clone().detach().to(dtype=args.dtype_test).requires_grad_(True)
    )
    grad_inputs_ref = [e_rbf_ref, e_in_ft_ref, sbf_weights_ref, sbf_weights2_ref]
    grad_inputs_test = [e_rbf_test, e_in_ft_test, sbf_weights_test, sbf_weights2_test]

    # setup SBF layers
    sbf_layer_ref = SphericalBasisLayer(
        n_spherical,
        n_radial,
        device=device,
        dtype=args.dtype_ref,
        cos_angle=args.use_cos_angle,
    )
    sbf_layer_test = SphericalBasisLayer(
        n_spherical,
        n_radial,
        device=device,
        dtype=args.dtype_test,
        cos_angle=args.use_cos_angle,
    )

    # setup other args
    ref_others0 = get_other_args(args.ref_class, 0, sbf_layer_ref, is_ref=True)
    ref_others1 = get_other_args(args.ref_class, 1, sbf_layer_ref, is_ref=True)
    test_others0 = get_other_args(args.test_class, 0, sbf_layer_test, is_ref=False)
    test_others1 = get_other_args(args.test_class, 1, sbf_layer_test, is_ref=False)

    # call several times just to make sure JIT is being done
    for i in range(10):
        out_ref = args.ref_class.apply(
            e_vec_ref, e_rbf_ref, e_in_ft_ref, sbf_weights_ref, ref_others0
        )
        g_init_ref = torch.randn_like(out_ref)
        g_rbf_ref = torch.autograd.grad(
            out_ref, e_rbf_ref, grad_outputs=g_init_ref, create_graph=True
        )[0]
        g_i_out_ref = torch.randn_like(out_ref)
        g_i_rbf_ref = torch.randn_like(g_rbf_ref)
        loss_ref = (out_ref * g_i_out_ref).sum() + (g_rbf_ref * g_i_rbf_ref).sum()
        loss_ref.backward()

        out_test = args.test_class.apply(
            e_vec_test, e_rbf_test, e_in_ft_test, sbf_weights_test, test_others0
        )
        g_init_test = g_init_ref.clone().detach()
        g_rbf_test = torch.autograd.grad(
            out_test, e_rbf_test, grad_outputs=g_init_test, create_graph=True
        )[0]
        g_i_out_test = g_i_out_ref.clone().detach()
        g_i_rbf_test = g_i_rbf_ref.clone().detach()
        loss_test = (out_test * g_i_out_test).sum() + (g_rbf_test * g_i_rbf_test).sum()
        loss_test.backward()

    # forward pass
    h_ref = args.ref_class.apply(
        e_vec_ref, e_rbf_ref, e_in_ft_ref, sbf_weights_ref, ref_others0
    )
    out_ref = args.ref_class.apply(
        e_vec_ref, e_rbf_ref, h_ref, sbf_weights2_ref, ref_others1
    )

    h_test = args.test_class.apply(
        e_vec_test, e_rbf_test, e_in_ft_test, sbf_weights_test, test_others0
    )
    out_test = args.test_class.apply(
        e_vec_test, e_rbf_test, h_test, sbf_weights2_test, test_others1
    )

    print()
    print("Forward")
    all_close_fwd = print_stats(
        out_test, out_ref, "Forward output", args.rtol, args.atol
    )

    # simple backward test on all inputs with gradients
    loss_ref = out_ref.sum()
    loss_ref.backward()
    loss_test = out_test.sum()
    loss_test.backward()

    print()
    print("Single Backward")
    all_close_bwd1 = True
    for i, x in enumerate(zip(grad_inputs_ref, grad_inputs_test)):
        i_ref, i_test = x
        b = print_stats(
            i_test.grad,
            i_ref.grad,
            "Backward output {}".format(i),
            args.rtol,
            args.atol,
        )
        all_close_bwd1 = all_close_bwd1 and b
        # reset gradients
        if i_ref.grad is not None:
            i_ref.grad.zero_()
        if i_test.grad is not None:
            i_test.grad.zero_()

    # get gradients on inputs (here we use rbf as substitute)
    h_ref = args.ref_class.apply(
        e_vec_ref, e_rbf_ref, e_in_ft_ref, sbf_weights_ref, ref_others0
    )
    out_ref = args.ref_class.apply(
        e_vec_ref, e_rbf_ref, h_ref, sbf_weights2_ref, ref_others1
    )

    h_test = args.test_class.apply(
        e_vec_test, e_rbf_test, e_in_ft_test, sbf_weights_test, test_others0
    )
    out_test = args.test_class.apply(
        e_vec_test, e_rbf_test, h_test, sbf_weights2_test, test_others1
    )

    grad_init_ref = torch.randn_like(out_ref)
    grad_init_test = grad_init_ref.clone().detach()
    g_rbf_ref = torch.autograd.grad(
        out_ref, e_rbf_ref, grad_outputs=grad_init_ref, create_graph=True
    )[0]
    g_rbf_test = torch.autograd.grad(
        out_test, e_rbf_test, grad_outputs=grad_init_test, create_graph=True
    )[0]
    all_close_bwd2 = print_stats(
        g_rbf_test, g_rbf_ref, "Backward inputs grad", args.rtol, args.atol
    )
    if args.viz_graph:
        assert (
            HAS_TORCHVIZ
        ), "Trying to visualize graph, but cannot find torchviz module"
        torchviz.make_dot(
            (
                out_ref,
                e_vec_ref,
                e_rbf_ref,
                e_in_ft_ref,
                sbf_weights_ref,
                sbf_weights2_ref,
            ),
            params={
                "out": out_ref,
                "vec": e_vec_ref,
                "rbf": e_rbf_ref,
                "feat": e_in_ft_ref,
                "w1": sbf_weights_ref,
                "w2": sbf_weights2_ref,
            },
        ).render("ref_out")
        torchviz.make_dot(
            (
                out_test,
                e_vec_test,
                e_rbf_test,
                e_in_ft_test,
                sbf_weights_test,
                sbf_weights2_test,
            ),
            params={
                "out": out_test,
                "vec": e_vec_test,
                "rbf": e_rbf_test,
                "feat": e_in_ft_test,
                "w1": sbf_weights_test,
                "w2": sbf_weights2_test,
            },
        ).render("test_out")
        torchviz.make_dot(
            (
                g_rbf_ref,
                e_vec_ref,
                e_rbf_ref,
                e_in_ft_ref,
                sbf_weights_ref,
                sbf_weights2_ref,
            ),
            params={
                "g_rbf": g_rbf_ref,
                "out": out_ref,
                "vec": e_vec_ref,
                "rbf": e_rbf_ref,
                "feat": e_in_ft_ref,
                "w1": sbf_weights_ref,
                "w2": sbf_weights2_ref,
            },
        ).render("g_ref_out")
        torchviz.make_dot(
            (
                g_rbf_test,
                e_vec_test,
                e_rbf_test,
                e_in_ft_test,
                sbf_weights_test,
                sbf_weights2_test,
            ),
            params={
                "g_rbf": g_rbf_test,
                "out": out_test,
                "vec": e_vec_test,
                "rbf": e_rbf_test,
                "feat": e_in_ft_test,
                "w1": sbf_weights_test,
                "w2": sbf_weights2_test,
            },
        ).render("g_test_out")

    g_i_out_ref = torch.randn_like(out_ref)
    g_i_out_test = g_i_out_ref.clone().detach()
    g_i_rbf_ref = torch.randn_like(g_rbf_ref)
    g_i_rbf_test = g_i_rbf_ref.clone().detach()
    loss_ref = (out_ref * g_i_out_ref).sum() + (g_rbf_ref * g_i_rbf_ref).sum()
    loss_test = (out_test * g_i_out_test).sum() + (g_rbf_test * g_i_rbf_test).sum()

    loss_ref.backward()
    loss_test.backward()

    print()
    print("Full Backward")
    all_close_bwd3 = True
    for i, x in enumerate(zip(grad_inputs_ref, grad_inputs_test)):
        i_ref, i_test = x
        b = print_stats(
            i_test.grad,
            i_ref.grad,
            "Backward outputs {}".format(i),
            args.rtol,
            args.atol,
        )
        all_close_bwd3 = all_close_bwd3 and b

    print()
    print("Forward test {}".format("passed" if all_close_fwd else "failed"))
    print("Simple backward test {}".format("passed" if all_close_bwd1 else "failed"))
    print("Backward input test {}".format("passed" if all_close_bwd2 else "failed"))
    print("Full backward test {}".format("passed" if all_close_bwd3 else "failed"))

    if args.timing:
        n_timing = 10
        # just repeat the operations several times and time
        torch.cuda.synchronize(device)
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()
        for i in range(n_timing):
            h_ref = args.ref_class.apply(
                e_vec_ref, e_rbf_ref, e_in_ft_ref, sbf_weights_ref, ref_others0
            )
            out_ref = args.ref_class.apply(
                e_vec_ref, e_rbf_ref, h_ref, sbf_weights2_ref, ref_others1
            )
            g_rbf_ref = torch.autograd.grad(
                out_ref, e_rbf_ref, grad_outputs=grad_init_ref, create_graph=True
            )[0]
            loss_ref = (out_ref * g_i_out_ref).sum() + (g_rbf_ref * g_i_rbf_ref).sum()
            loss_ref.backward()
        end.record()
        torch.cuda.synchronize(device)
        time_ref = start.elapsed_time(end)

        start.record()
        for i in range(n_timing):
            h_test = args.test_class.apply(
                e_vec_test, e_rbf_test, e_in_ft_test, sbf_weights_test, test_others0
            )
            out_test = args.test_class.apply(
                e_vec_test, e_rbf_test, h_test, sbf_weights2_test, test_others1
            )
            g_rbf_test = torch.autograd.grad(
                out_test, e_rbf_test, grad_outputs=grad_init_test, create_graph=True
            )[0]
            loss_test = (out_test * g_i_out_test).sum() + (
                g_rbf_test * g_i_rbf_test
            ).sum()
            loss_test.backward()
        end.record()
        torch.cuda.synchronize(device)
        time_test = start.elapsed_time(end)
        print(
            "Reference/Test full fwd-bwd: {:.3f}ms / {:.3f}ms".format(
                time_ref / n_timing, time_test / n_timing
            )
        )


if __name__ == "__main__":
    main()
