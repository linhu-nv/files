# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import torch
from util import erdos_renyi_graph, get_edge_offsets, get_triplets
from agg_full_test import IBCustom

import pylibcugraphops_internal_ext as internal_ext


n_nodes = 450
edge_prob = 0.08
n_spherical, n_radial, n_vec, n_feat, n_mid = 7, 6, 3, 64, 8
n_sbf = n_spherical * n_radial
dtype_ref = torch.float64
dtype_test = torch.float32

fast_mode = True


def main():
    internal_ext.utils.push_range("setup")
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    if fast_mode:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    else:
        # as in pytorch 1.12 default: don't allow TF32 for MMs
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = True
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
        torch.use_deterministic_algorithms(True, warn_only=True)
        # setup debugging / printing stuff
        os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
    torch.set_printoptions(precision=4, sci_mode=False, edgeitems=6, linewidth=120)

    # create graph
    device = torch.device("cuda:0")
    edge_index = erdos_renyi_graph(n_nodes, edge_prob=edge_prob, directed=False)
    _, idx = torch.sort(edge_index[0], stable=True)
    edge_index = edge_index[:, idx]
    edge_index = edge_index.to(device=device)
    triplets = get_triplets(edge_index[0], edge_index[1], n_nodes)
    edge_offsets, src_deg, dst_deg = get_edge_offsets(edge_index, n_nodes)

    def get_other_args(typ, i, sbf, is_ref):
        t = (edge_index, i)
        if typ.need_sbf_layer:
            t = t + (sbf,)
        if typ.need_triplets:
            t = t + (triplets,)
        if typ.need_offsets:
            t = t + (edge_offsets,)
        return t

    print(f"#nodes: {n_nodes}, #edges: {edge_index.size(1)}")

    # setup input tensors
    n_edges = edge_index.size(1)
    e_vec_ref = torch.randn(n_edges, n_vec, device=device, dtype=dtype_ref)
    e_vec_test = e_vec_ref.clone().detach().to(dtype=dtype_test)
    e_rbf_ref = torch.randn(
        n_edges, n_sbf, device=device, dtype=dtype_ref, requires_grad=True
    )
    e_rbf_test = e_rbf_ref.clone().detach().to(dtype=dtype_test).requires_grad_(True)
    e_in_ft_ref = torch.randn(
        n_edges, n_feat, device=device, dtype=dtype_ref, requires_grad=True
    )
    e_in_ft_test = (
        e_in_ft_ref.clone().detach().to(dtype=dtype_test).requires_grad_(True)
    )
    sbf_weights_ref = torch.randn(
        n_sbf + n_feat, n_mid, device=device, dtype=dtype_ref, requires_grad=True
    )
    sbf_weights_test = (
        sbf_weights_ref.clone().detach().to(dtype=dtype_test).requires_grad_(True)
    )
    sbf_weights2_ref = torch.randn(
        n_sbf + n_feat, n_mid, device=device, dtype=dtype_ref, requires_grad=True
    )
    sbf_weights2_test = (
        sbf_weights2_ref.clone().detach().to(dtype=dtype_test).requires_grad_(True)
    )

    # setup other args
    ref_others0 = get_other_args(IBCustom, 0, None, is_ref=True)
    ref_others1 = get_other_args(IBCustom, 1, None, is_ref=True)
    test_others0 = get_other_args(IBCustom, 0, None, is_ref=False)
    test_others1 = get_other_args(IBCustom, 1, None, is_ref=False)

    # warmup
    h_ref = IBCustom.apply(
        e_vec_ref, e_rbf_ref, e_in_ft_ref, sbf_weights_ref, ref_others0
    )
    out_ref = IBCustom.apply(e_vec_ref, e_rbf_ref, h_ref, sbf_weights2_ref, ref_others1)
    g_i_out_ref = torch.randn_like(out_ref)
    grad_init_ref = torch.randn_like(out_ref)
    g_i_rbf_ref = torch.randn_like(e_rbf_ref)

    g_i_out_test = g_i_out_ref.clone().detach()
    g_i_rbf_test = g_i_rbf_ref.clone().detach()
    grad_init_test = grad_init_ref.clone().detach()

    h_test = IBCustom.apply(
        e_vec_test, e_rbf_test, e_in_ft_test, sbf_weights_test, test_others0
    )
    out_test = IBCustom.apply(
        e_vec_test, e_rbf_test, h_test, sbf_weights2_test, test_others1
    )
    internal_ext.utils.pop_range()

    # profiling
    internal_ext.utils.push_range("dimenet")
    for i in range(1):
        h_ref = IBCustom.apply(
            e_vec_ref, e_rbf_ref, e_in_ft_ref, sbf_weights_ref, ref_others0
        )
        out_ref = IBCustom.apply(
            e_vec_ref, e_rbf_ref, h_ref, sbf_weights2_ref, ref_others1
        )
        g_rbf_ref = torch.autograd.grad(
            out_ref, e_rbf_ref, grad_outputs=grad_init_ref, create_graph=True
        )[0]
        loss_ref = (out_ref * g_i_out_ref).sum() + (g_rbf_ref * g_i_rbf_ref).sum()
        loss_ref.backward()
        print(loss_ref.item())

    for i in range(1):
        h_test = IBCustom.apply(
            e_vec_test, e_rbf_test, e_in_ft_test, sbf_weights_test, test_others0
        )
        out_test = IBCustom.apply(
            e_vec_test, e_rbf_test, h_test, sbf_weights2_test, test_others1
        )
        g_rbf_test = torch.autograd.grad(
            out_test, e_rbf_test, grad_outputs=grad_init_test, create_graph=True
        )[0]
        loss_test = (out_test * g_i_out_test).sum() + (g_rbf_test * g_i_rbf_test).sum()
        loss_test.backward()
        print(loss_test.item())
    internal_ext.utils.pop_range()


if __name__ == "__main__":
    internal_ext.utils.enable_nvtx_ranges()
    main()
