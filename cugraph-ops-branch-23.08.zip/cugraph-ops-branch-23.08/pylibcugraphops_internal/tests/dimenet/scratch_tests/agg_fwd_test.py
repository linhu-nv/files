# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#############################################################################
# DISCLAIMER: this file is experimental, use at own risk :)                 #
# These tests don't work with the latest version of the bindings anymore,   #
# since this was mainly for debugging usage before those bindings           #
#############################################################################

import os
import torch
from torch.linalg import vector_norm
from torch_scatter import scatter

import pylibcugraphops
import pylibcugraphops_internal_ext as internal_ext

from util import (
    get_pbc_distances, envelope, get_triplets, get_edge_offsets,
    erdos_renyi_graph, get_aux_storage, print_stats
)
from sbf_ref import SphericalBasisLayer

n_spherical, n_radial, n_vec, n_feat, n_mid = 7, 6, 3, 64, 8
use_cos_angle = True
n_nodes, edge_prob = 450, 0.08
# n_nodes, edge_prob = 20, 0.4
dtype_ref, dtype_test, rtol, atol = torch.float64, torch.float64, 1e-2, 1e-3
verbose = False


def forward_ref(x_kj, pos, offsets, sbf_layer, sbf_weights, edge_index, triplets, dump_feat):
    j, i = edge_index
    pos_j, pos_i = pos[j], pos[i]
    dist = get_pbc_distances(pos_j, pos_i, offsets)
    env = envelope(dist)

    idx_i, idx_j, idx_k, idx_kj, idx_ji = triplets
    pos_i = pos[idx_i].detach()
    pos_j = pos[idx_j].detach()
    pos_ji, pos_kj = (
        pos[idx_j].detach() - pos_i + offsets[idx_ji],
        pos[idx_k].detach() - pos_j + offsets[idx_kj],
    )

    a = (pos_ji * pos_kj).sum(dim=-1)
    if sbf_layer.cos_angle:
        angle = a * (1. / vector_norm(pos_ji, dim=-1)) * (1. / vector_norm(pos_kj, dim=-1))
    else:
        b = torch.cross(pos_ji, pos_kj).norm(dim=-1)
        angle = torch.atan2(b, a)

    rbf = env * sbf_layer.calc_rbf(dist)
    cbf = sbf_layer.calc_cbf(angle)
    sbf = (rbf[idx_kj].view(-1, n_spherical, n_radial) * cbf.view(-1, n_spherical, 1)).view(-1, n_spherical * n_radial)
    dump_feat.append(sbf)

    n_sbf = n_spherical * n_radial
    sbf = torch.matmul(sbf, sbf_weights[:n_sbf])
    dump_feat.append(sbf)
    sbf = torch.matmul(sbf, sbf_weights[n_sbf:].t())
    dump_feat.append(sbf)

    x_kj = x_kj[idx_kj] * sbf
    x_ji = scatter(x_kj, idx_ji, dim=0, dim_size=j.size(0))
    return x_ji


def test_forward(x_kj, pos, offsets, sbf_layer, sbf_weights, edge_index, edge_offsets, aux_storage):
    j, i = edge_index
    pos_j, pos_i = pos[j], pos[i]
    dist = get_pbc_distances(pos_j, pos_i, offsets)
    env = envelope(dist)
    rbf = env * sbf_layer.calc_rbf(dist)

    vec = pos_j - pos_i + offsets
    _, dst_offsets, dst_e_idx = edge_offsets
    x_ji_out = torch.empty_like(x_kj)
    # this is out-of-date and would need to be updated to a debugging
    # function which stores the intermediate values to the aux_storage tensors
    pylibcugraphops.dimenet.agg_edge_to_edge_fwd(
        x_ji_out, vec, rbf, x_kj, sbf_weights.detach(), edge_index,
        dst_offsets, dst_e_idx, pylibcugraphops.MMAOp.SIMT, *aux_storage
    )
    return x_ji_out


def test_against_ref(num_nodes, edge_prob, device, dtype_ref, dtype_test):
    # create a random graph, undirected, with "low-ish" connectivity
    edge_index = erdos_renyi_graph(num_nodes, edge_prob=edge_prob, directed=False)
    # make sure edge index is sorted w.r.t. source nodes
    # use stable sort for reproducibility
    _, idx = torch.sort(edge_index[0], stable=True)
    edge_index = edge_index[:, idx]
    # move it to device
    edge_index = edge_index.to(device=device)
    # create random position features for the nodes
    pos = torch.randn(num_nodes, n_vec, device=device, dtype=dtype_ref)
    # create random edge features for the offsets
    offsets = torch.randn(edge_index.size(1), n_vec, device=device, dtype=dtype_ref)
    # create random edge input features (x_kj)
    x_kj = torch.randn(edge_index.size(1), n_feat, device=device, dtype=dtype_ref)
    # create the SBF layer
    sbf_layer_ref = SphericalBasisLayer(n_spherical, n_radial, device=device, dtype=dtype_ref, cos_angle=use_cos_angle)
    sbf_layer_test = SphericalBasisLayer(n_spherical, n_radial, device=device, dtype=dtype_test, rbf_only=True)
    # generate random weights as in linear layer
    sbf_linear = torch.nn.Linear(
        n_mid, n_spherical * n_radial + n_feat, bias=False,
        device=device, dtype=dtype_ref
    )
    sbf_weights = sbf_linear.weight
    # create additional indexes needed by methods
    triplets = get_triplets(edge_index[0], edge_index[1], num_nodes)
    edge_offsets = get_edge_offsets(edge_index, num_nodes)
    # create the dump info for debugging/tests
    aux_storage = get_aux_storage(
        edge_index, edge_offsets[-2], edge_offsets[-1],
        [n_spherical * n_radial, n_mid, n_feat],
        device, dtype_test
    )
    # import pdb; pdb.set_trace()
    if verbose:
        print(edge_index)
        for t in triplets:
            print(t)
        print(aux_storage[0])
        for x in edge_offsets:
            print(x)
    print("#nodes: {}, #edges: {}, #triplets: {}".format(num_nodes, edge_index.size(1), aux_storage[-1].size(0)))

    dump_ref = []
    x_ji_ref = forward_ref(
        x_kj, pos, offsets, sbf_layer_ref, sbf_weights, edge_index, triplets, dump_ref
    )
    x_ji_test = test_forward(
        x_kj.to(dtype=dtype_test), pos.to(dtype=dtype_test),
        offsets.to(dtype=dtype_test), sbf_layer_test,
        sbf_weights.to(dtype=dtype_test), edge_index, edge_offsets, aux_storage
    )
    for i in range(n_spherical):
        s, e = i * n_radial, (i + 1) * n_radial
        print_stats(aux_storage[2][:, s:e], dump_ref[0][:, s:e], "SBF spherical dim {}".format(i), rtol, atol)
    for i, ref in enumerate(dump_ref):
        print_stats(aux_storage[2 + i], ref, "dump info {}".format(i), rtol, atol)
    all_close = print_stats(x_ji_test, x_ji_ref, "Forward output", rtol, atol)
    if all_close:
        print("Test with num nodes {}, dtype {} vs {} passed".format(num_nodes, dtype_test, dtype_ref))
    else:
        print("Test with num nodes {}, dtype {} vs {} failed".format(num_nodes, dtype_test, dtype_ref))
        if verbose:
            print(x_ji_test)
            print(x_ji_ref)
    if verbose:
        print("Dump info:")
        for i, ref in enumerate(dump_ref):
            print(ref)
            print(aux_storage[2 + i])


def test_ref_dtypes(num_nodes, edge_prob, device, dtype_ref, dtype_test):
    # create a random graph, undirected, with "low-ish" connectivity
    edge_index = erdos_renyi_graph(num_nodes, edge_prob=edge_prob, directed=False)
    # make sure edge index is sorted w.r.t. source nodes
    # use stable sort for reproducibility
    _, idx = torch.sort(edge_index[0], stable=True)
    edge_index = edge_index[:, idx]
    # move it to device
    edge_index = edge_index.to(device=device)
    # create random position features for the nodes
    pos_ref = torch.randn(num_nodes, n_vec, device=device, dtype=dtype_ref)
    pos_test = pos_ref.to(dtype=dtype_test)
    # create random edge features for the offsets
    offsets_ref = torch.randn(edge_index.size(1), n_vec, device=device, dtype=dtype_ref)
    offsets_test = offsets_ref.to(dtype=dtype_test)
    # create random edge input features (x_kj)
    x_kj_ref = torch.randn(edge_index.size(1), n_feat, device=device, dtype=dtype_ref)
    x_kj_test = x_kj_ref.to(dtype=dtype_test)
    # create the SBF layer
    sbf_layer_ref = SphericalBasisLayer(n_spherical, n_radial, device=device, dtype=dtype_ref, cos_angle=use_cos_angle)
    sbf_layer_test = SphericalBasisLayer(n_spherical, n_radial, device=device, dtype=dtype_test, cos_angle=use_cos_angle)
    # generate random weights as in linear layer
    sbf_linear_ref = torch.nn.Linear(
        n_mid, n_spherical * n_radial + n_feat, bias=False,
        device=device, dtype=dtype_ref
    )
    sbf_weights_ref = sbf_linear_ref.weight
    sbf_weights_test = sbf_weights_ref.to(dtype=dtype_test)
    # create additional indexes needed by methods
    triplets = get_triplets(edge_index[0], edge_index[1], num_nodes)

    dump_ref, dump_test = [], []
    x_ji_ref = forward_ref(
        x_kj_ref, pos_ref, offsets_ref, sbf_layer_ref, sbf_weights_ref,
        edge_index, triplets, dump_ref
    )
    x_ji_test = forward_ref(
        x_kj_test, pos_test, offsets_test, sbf_layer_test, sbf_weights_test,
        edge_index, triplets, dump_test
    )

    for i in range(n_spherical):
        s, e = i * n_radial, (i + 1) * n_radial
        print_stats(dump_test[0][:, s:e], dump_ref[0][:, s:e], "SBF spherical dim {}".format(i), rtol, atol)
    for i, ref in enumerate(dump_ref):
        print_stats(dump_test[i], ref, "dump info {}".format(i), rtol, atol)
    all_close = print_stats(x_ji_test, x_ji_ref, "forward output", rtol, atol)
    if all_close:
        print("REF test with num nodes {}, dtype {} vs {} passed".format(num_nodes, dtype_test, dtype_ref))
    else:
        print("REF test with num nodes {}, dtype {} vs {} failed".format(num_nodes, dtype_test, dtype_ref))
        if verbose:
            print(x_ji_test)
            print(x_ji_ref)
    if verbose:
        print("Dump info:")
        for i, ref in enumerate(dump_ref):
            print(ref)
            print(dump_test[i])


def main():
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
    torch.use_deterministic_algorithms(True, warn_only=True)
    # setup debugging / printing stuff
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
    torch.set_printoptions(precision=4, sci_mode=False, edgeitems=6, linewidth=120)
    # we choose some number of nodes
    test_against_ref(n_nodes, edge_prob, device=torch.device("cuda"), dtype_ref=dtype_ref, dtype_test=dtype_test)
    test_ref_dtypes(n_nodes, edge_prob, device=torch.device("cuda"), dtype_ref=torch.float64, dtype_test=torch.float32)


if __name__ == "__main__":
    main()
