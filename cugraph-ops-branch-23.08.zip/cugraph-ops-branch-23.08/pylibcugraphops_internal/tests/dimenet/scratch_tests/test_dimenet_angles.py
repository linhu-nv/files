# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#############################################################################
# DISCLAIMER: this file is experimental, use at own risk :)                 #
#############################################################################

import torch
from torch.linalg import vector_norm


def dimenet_method(vec1, vec2):
    a = (vec1 * vec2).sum(dim=-1)
    b = vector_norm(torch.cross(vec1, vec2), dim=-1)
    angle = torch.atan2(b, a)
    return angle.cos()


def alt_method(vec1, vec2):
    a = (vec1 * vec2).sum(dim=-1)
    return a / (vector_norm(vec1, dim=-1) * vector_norm(vec2, dim=-1))


def alt_grads(grad_out, vec1, vec2, cos):
    n1 = vector_norm(vec1, dim=-1, keepdim=True)
    n2 = vector_norm(vec2, dim=-1, keepdim=True)
    n1_sq = vec1.square().sum(dim=-1, keepdim=True)
    n2_sq = vec2.square().sum(dim=-1, keepdim=True)
    # this method for g1/g2 is accurate
    nprod = n1 * n2
    dot = (vec1 * vec2).sum(dim=-1, keepdim=True)
    g1 = (vec2 * n1_sq - dot * vec1) / (nprod * n1_sq)
    g2 = (vec1 * n2_sq - dot * vec2) / (nprod * n2_sq)
    # this method re-uses the cosine output, and is very inaccurate
    # g1 = (vec2 - cos * vec1) / (n1_sq * n2)
    # g2 = (vec1 - cos * vec2) / (n2_sq * n1)
    return g1 * grad_out.unsqueeze(-1), g2 * grad_out.unsqueeze(-1)


def main():
    torch.set_printoptions(precision=10, threshold=20, linewidth=120, edgeitems=5, sci_mode=False)
    vec1_d = torch.randn(100, 3, requires_grad=True, dtype=torch.float64)
    vec2_d = torch.randn(100, 3, requires_grad=True, dtype=torch.float64)
    print("Average absolute values: {}, {}".format(vec1_d.abs().mean().item(), vec2_d.abs().mean().item()))
    vec1_f = vec1_d.clone().detach().to(dtype=torch.float32).requires_grad_()
    vec2_f = vec2_d.clone().detach().to(dtype=torch.float32).requires_grad_()

    cos_d_dimenet = dimenet_method(vec1_d, vec2_d)
    cos_d_alt = alt_method(vec1_d, vec2_d)
    print("Double outputs following:")
    print(cos_d_dimenet)
    print(cos_d_alt)
    assert torch.allclose(cos_d_dimenet, cos_d_alt, rtol=1e-8, atol=1e-12)
    cos_ref = (cos_d_dimenet + cos_d_alt) / 2.

    cos_f_dimenet = dimenet_method(vec1_f, vec2_f)
    cos_f_alt = alt_method(vec1_f, vec2_f)
    print("Float outputs following:")
    print(cos_f_dimenet)
    print(cos_f_alt)
    err1 = torch.abs(cos_ref - cos_f_dimenet.to(dtype=torch.float64))
    err2 = torch.abs(cos_ref - cos_f_alt.to(dtype=torch.float64))
    print("Float errors following (dimenet then alt):")
    print(err1)
    print(err2)
    print("Average absolute error of dimenet method: {}, of alt method: {}"
          .format(err1.mean().item(), err2.mean().item()))

    vecs = [vec1_d, vec2_d, vec1_f, vec2_f]
    outputs = [cos_d_dimenet, cos_d_alt, cos_f_dimenet, cos_f_alt]
    scale = torch.randn_like(cos_d_dimenet)
    grads = []
    for out in outputs:
        loss = (out * scale.to(dtype=out.dtype)).sum()
        loss.backward()
        gs = []
        for v in vecs:
            if v.grad is None:
                gs.append(None)
                continue
            gs.append(v.grad.clone())
            v.grad.zero_()
        grads.append(gs)
    grads_alt = alt_grads(scale.to(torch.float32), vec1_f, vec2_f, cos_f_alt.unsqueeze(-1))

    assert torch.allclose(grads[0][0], grads[1][0], rtol=1e-8, atol=1e-12)
    assert torch.allclose(grads[0][1], grads[1][1], rtol=1e-8, atol=1e-12)
    ref_grad1 = (grads[0][0] + grads[1][0]) / 2.
    ref_grad2 = (grads[0][1] + grads[1][1]) / 2.
    err1 = torch.abs(ref_grad1 - grads[2][0].to(dtype=torch.float64))
    err2 = torch.abs(ref_grad2 - grads[2][1].to(dtype=torch.float64))
    print("Float errors following (dimenet vec1 then vec2):")
    print(err1)
    print(err2)
    print("Average absolute error of gradients with dimenet method: {}, {}"
          .format(err1.mean().item(), err2.mean().item()))
    err1 = torch.abs(ref_grad1 - grads[3][0].to(dtype=torch.float64))
    err2 = torch.abs(ref_grad2 - grads[3][1].to(dtype=torch.float64))
    print("Float errors following (alt vec1 then vec2):")
    print(err1)
    print(err2)
    print("Average absolute error of gradients with alt method: {}, {}"
          .format(err1.mean().item(), err2.mean().item()))
    err1 = torch.abs(ref_grad1 - grads_alt[0].to(dtype=torch.float64))
    err2 = torch.abs(ref_grad2 - grads_alt[1].to(dtype=torch.float64))
    print("Float errors following (alt grads vec1 then vec2):")
    print(err1)
    print(err2)
    print("Average absolute error of gradients with alt grad method: {}, {}"
          .format(err1.mean().item(), err2.mean().item()))


if __name__ == "__main__":
    main()
