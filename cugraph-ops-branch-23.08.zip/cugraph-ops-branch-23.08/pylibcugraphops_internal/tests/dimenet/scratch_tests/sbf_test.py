# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#############################################################################
# DISCLAIMER: this file is experimental, use at own risk :)                 #
#############################################################################

import os
import torch
from sbf_ref import SphericalBasisLayer
from util import erdos_renyi_graph, get_pbc_distances, envelope, get_triplets

n_spherical, n_radial, n_vec, n_feat, n_mid = 7, 6, 3, 64, 8
n_nodes, edge_prob = 450, 0.08


def main():
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":16:8"
    torch.use_deterministic_algorithms(True, warn_only=True)
    # setup debugging / printing stuff
    os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
    # torch.set_printoptions(precision=4, sci_mode=False, edgeitems=6, linewidth=120)
    torch.set_printoptions(precision=10, sci_mode=True, linewidth=120)

    device = torch.device("cuda:0")
    dtype = torch.float64

    # create a random graph, undirected, with "low-ish" connectivity
    edge_index = erdos_renyi_graph(n_nodes, edge_prob=edge_prob, directed=False)
    # make sure edge index is sorted w.r.t. source nodes
    # use stable sort for reproducibility
    _, idx = torch.sort(edge_index[0], stable=True)
    edge_index = edge_index[:, idx]
    # move it to device
    edge_index = edge_index.to(device=device)
    # create random position features for the nodes
    pos = torch.randn(n_nodes, n_vec, device=device, dtype=dtype)
    # create random edge features for the offsets
    offsets = torch.randn(edge_index.size(1), n_vec, device=device, dtype=dtype)
    # create random edge input features (x_kj)
    x_kj = torch.randn(edge_index.size(1), n_feat, device=device, dtype=dtype)
    # create the SBF layer
    sbf_layer_ref = SphericalBasisLayer(n_spherical, n_radial, device=device, dtype=dtype, cos_angle=True)
    sbf_layer_test = SphericalBasisLayer(n_spherical, n_radial, device=device, dtype=dtype, rbf_only=True)
    triplets = get_triplets(edge_index[0], edge_index[1], n_nodes)
    idx_kj = triplets[-2]

    j, i = edge_index
    pos_j_ref, pos_i_ref = pos[j], pos[i]
    dist_ref = get_pbc_distances(pos_j_ref, pos_i_ref, offsets)
    env_ref = envelope(dist_ref)

    pos_test = pos.to(dtype=dtype)
    offsets_test = offsets.to(dtype=dtype)
    print(torch.sum((pos_test != pos).to(dtype=torch.long)).item(), pos.numel())
    print(torch.sum((offsets_test != offsets).to(dtype=torch.long)).item(), offsets.numel())
    pos_j_test, pos_i_test = pos_test[j], pos_test[i]
    print(torch.sum((pos_j_test != pos_j_ref).to(dtype=torch.long)).item(), pos_j_ref.numel())
    print(torch.sum((pos_i_test != pos_i_ref).to(dtype=torch.long)).item(), pos_i_ref.numel())
    dist_test = get_pbc_distances(pos_j_test, pos_i_test, offsets_test)
    env_test = envelope(dist_test)
    print(torch.sum((dist_test != dist_ref).to(dtype=torch.long)).item(), dist_ref.numel())
    print(torch.sum((env_test != env_ref).to(dtype=torch.long)).item(), env_ref.numel())

    rbf_ref = env_ref * sbf_layer_ref.calc_rbf(dist_ref)
    rbf_test = env_test * sbf_layer_test.calc_rbf(dist_test)
    # print(rbf_ref[idx_kj][280700])
    # print(rbf_test[idx_kj][280700])
    # rbf_test = env_ref * sbf_layer_test.calc_rbf(dist_ref)
    print(rbf_ref.shape, rbf_ref.numel())
    print(torch.sum((rbf_test != rbf_ref).to(dtype=torch.long)))
    print(rbf_ref.numel() - torch.sum(torch.isclose(rbf_test, rbf_ref, rtol=1e-7, atol=1e-9).to(dtype=torch.long)))


if __name__ == '__main__':
    main()
