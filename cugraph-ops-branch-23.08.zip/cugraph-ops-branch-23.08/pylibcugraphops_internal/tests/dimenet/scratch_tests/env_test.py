# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#############################################################################
# DISCLAIMER: this file is experimental, use at own risk :)                 #
#############################################################################

import torch


# makes this non-deterministic on CUDA, but on CPU!
@torch.jit.script
def envelope(x):
    x_pow_p0 = torch.pow(x, 5)
    x_pow_p1 = x_pow_p0 * x
    x_pow_p2 = x_pow_p1 * x
    return (1.0 / x - 28 * x_pow_p0 + 48 * x_pow_p1 - 21 * x_pow_p2) * (x < 1.0)


def main():
    # set the pytorch seed and use deterministic algos when available
    # (scatter may not be deterministic in any case)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True, warn_only=True)
    torch.set_printoptions(precision=10, sci_mode=True, linewidth=120)

    device = torch.device("cuda:0")
    dtype = torch.float64

    inputs_ref = torch.randn(20000, 40, device=device, dtype=dtype)
    inputs_test = inputs_ref.to(dtype=dtype)

    print(type(envelope))
    print(envelope.code)
    # discard_ref = envelope(inputs_ref.to(dtype=dtype))
    outputs_ref = envelope(inputs_ref)
    outputs_test = envelope(inputs_test)
    n_in = torch.sum((inputs_test == inputs_ref).to(dtype=torch.long)).item()
    n_out = torch.sum((outputs_test == outputs_ref).to(dtype=torch.long)).item()
    print("Inputs equal: {}/{}, outputs equal {}/{} values".format(
        n_in, inputs_ref.numel(), n_out, outputs_ref.numel()))


if __name__ == '__main__':
    main()
