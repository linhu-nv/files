# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import time
import torch

import pylibcugraphops_internal_ext as internal_ext
import pylibcugraphops_internal.layers.torch as layers
from pylibcugraphops_internal.utils import RunningAvg

from common import add_common_args, parse_common_args, load_dataset

logger = internal_ext.utils.logger


def parse_args():
    parser = argparse.ArgumentParser(
        description="Performs GraphSAGE training, using Pytorch backend")
    add_common_args(parser)
    args = parser.parse_args()
    args = parse_common_args(args)
    return args


def make_model(args, torch_data, rng, cublas, node_batcher):
    feat = torch_data.features
    seq_layers = [layers.GatherInputTorch(feat.size(1), node_batcher)]
    for i, dim in enumerate(args.dims_vec):
        if i == 0:
            # init layer has activation unless we only have 1 layer
            act = torch.nn.ReLU() if len(args.dims_vec) > 1 else None
            layer = layers.SAGEConvTorch(
                torch_data.n_cols, dim, layer_id=0, node_batcher=node_batcher,
                activation=act, dropout=args.dropout, use_bias=True, rng=rng,
                cublas=cublas)
        else:
            # last layer does not have activation / dropout
            if i < len(args.dims_vec) - 1:
                act = torch.nn.ReLU()
                drop = args.dropout
            else:
                act, drop = None, None
            layer = layers.SAGEConvTorch(
                args.dims_vec[i - 1], dim, previous_layer=layer,
                activation=act, dropout=drop, use_bias=True, rng=rng,
                cublas=cublas)
        seq_layers.append(layer)

    return torch.nn.Sequential(*seq_layers)


def main():
    args = parse_args()
    logger.set_log_level(args.verbosity)
    if args.nvtx:
        internal_ext.utils.enable_nvtx_ranges()
    else:
        internal_ext.utils.disable_nvtx_ranges()
    data, t_data = load_dataset(args, is_torch=True)
    stream = internal_ext.torch.get_current_stream()
    rng = internal_ext.rng_state(args.seed)
    cublas = internal_ext.cuda.cublashandle()
    batcher_class = internal_ext.node_batcher_int64
    logger.debug('batcher_class\n')
    batcher = batcher_class(
        t_data.graph, args.sample_sizes_vec, args.batch_size,
        t_data.graph.n_nodes, t_data.n_labels, rng, args.sample_type,
        False, stream)
    logger.debug('make_model')
    model = make_model(args, t_data, rng, cublas, batcher)
    if args.opt_fused is None:
        optimizer_class = getattr(torch.optim, args.opt.__name__)
    else:
        optimizer_class = args.opt_fused
    optimizer = optimizer_class(model.parameters(), **args.opt_kwargs)
    loss = torch.nn.CrossEntropyLoss()
    gather_labels = layers.GatherLabelsTorch(batcher)
    loss_avg = RunningAvg()
    acc_avg = RunningAvg()

    n_batches = args.nbatches if args.nbatches != 0 else batcher.num_batches()
    logger.debug("Running for %d epochs\n" % args.epochs)
    logger.debug("Running for %d batches per epoch\n" % n_batches)
    for epoch in range(args.epochs):
        start = time.time()
        logger.debug("Epoch#%d started...\n" % epoch)
        for batch in range(n_batches):
            logger.trace("Batch#%d.%d begin...\n" % (epoch, batch))
            batch_info = batcher.next_batch()
            logger.trace("Generated batch of size %d: %s\n" %
                         (batch_info.curr_size, batch_info.batch))
            logger.trace("Batch#%d.%d end...\n" % (epoch, batch))
            logger.trace("Forward#%d.%d begin...\n" % (epoch, batch))
            batch_labels = gather_labels(t_data.labels)
            batch_labels_long = batch_labels.to(torch.long)
            logits = model(t_data.features)
            loss_val = loss(logits, batch_labels_long)
            logger.trace("Forward#%d.%d end...\n" % (epoch, batch))
            if batch % args.eval_every == 0:
                hits = logits.detach().argmax(1) == batch_labels_long
                acc_v = torch.mean(hits.to(torch.float64)).item()
                loss_v = loss_val.item()
                logger.trace("loss %.4f, acc %.4f\n" % (loss_v, acc_v))
                loss_avg.add(loss_v)
                acc_avg.add(acc_v)
            logger.trace("Backward#%d.%d begin...\n" % (epoch, batch))
            optimizer.zero_grad()
            loss_val.backward()
            logger.trace("Backward#%d.%d end...\n" % (epoch, batch))
            optimizer.step()
            logger.trace("Optimizer#%d.%d step end...\n" % (epoch, batch))
        # sync for timing
        stream.sync()
        logger.debug("Epoch#%d ended...\n" % epoch)
        print(f"Epoch {epoch}, loss: {loss_avg.get():.4f}, "
              f"accuracy: {acc_avg.get():.4f}, time: {time.time()-start:.4f}s")
        loss_avg.reset()
        acc_avg.reset()
    return


if __name__ == "__main__":
    main()
