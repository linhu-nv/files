# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse

import pylibcugraphops_internal_ext as internal_ext
import pylibcugraphops_internal.layers as layers
from pylibcugraphops_internal.utils import RunningAvg, ActivationOp
from pylibcugraphops.operators import activation_params

import time

from common import add_common_args, parse_common_args, load_dataset

logger = internal_ext.utils.logger


def parse_args():
    parser = argparse.ArgumentParser(description="Performs GraphSAGE training")
    add_common_args(parser)
    parser.add_argument(
        "-use_rev", action="store_true",
        help="Use reverse graph for backward ops.")
    parser.add_argument(
        "-use_csr", action="store_true",
        help="Use CSR MFG for all ops.")
    args = parser.parse_args()
    args = parse_common_args(args)
    return args


def make_model(args, d_data, rng, cublas, cudnn, node_batcher):
    activation = activation_params()
    activation.type = ActivationOp.ReLU

    container = layers.Sequential()
    for i, dim in enumerate(args.dims_vec):
        if i == 0:
            # init layer has activation unless we only have 1 layer
            act = activation if len(args.dims_vec) > 1 else None
            layer = layers.SAGEConv(
                dim, in_feats=d_data.n_cols, cublas=cublas, rng=rng,
                node_batcher=node_batcher, layer_id=0, activation=act,
                dropout=args.dropout)
        else:
            # last layer does not have activation / dropout
            if i < len(args.dims_vec) - 1:
                act = activation
                drop = args.dropout
            else:
                act, drop = None, None
            layer = layers.SAGEConv(
                dim, previous_layer=layer, activation=act, dropout=drop)
        container.append(layer)
    container.append(layers.SoftmaxCE(
        container[-1], d_data.labels, cudnn, pre_compute=args.eval_every <= 2))

    return container


def main():
    args = parse_args()
    logger.set_log_level(args.verbosity)
    if args.nvtx:
        internal_ext.utils.enable_nvtx_ranges()
    else:
        internal_ext.utils.disable_nvtx_ranges()
    d_data = load_dataset(args)
    rng = internal_ext.rng_state(args.seed)
    stream = internal_ext.cuda.stream()
    cublas = internal_ext.cuda.cublashandle()
    cudnn = internal_ext.cuda.cudnnhandle()
    if args.use_csr:
        batcher_class = internal_ext.node_batcher_csr_int64
    else:
        batcher_class = internal_ext.node_batcher_int64
    batcher = batcher_class(
        d_data.graph, args.sample_sizes_vec, args.batch_size,
        d_data.graph.n_nodes, d_data.n_labels, rng, args.sample_type,
        args.use_rev, stream)
    model = make_model(args, d_data, rng, cublas, cudnn, batcher)
    optimizer = args.opt(model, **args.opt_kwargs)
    loss_avg = RunningAvg()
    acc_avg = RunningAvg()
    # set the initial input (stays constant as it is the full feature matrix)
    model.get_first().get_input_buffers()[0] = d_data.features
    n_batches = args.nbatches if args.nbatches != 0 else batcher.num_batches()
    logger.debug("Running for %d epochs\n" % args.epochs)
    logger.debug("Running for %d batches per epoch\n" % n_batches)
    for epoch in range(args.epochs):
        start = time.time()
        logger.debug("Epoch#%d started...\n" % epoch)
        for batch in range(n_batches):
            logger.trace("Batch#%d.%d begin...\n" % (epoch, batch))
            batch_info = batcher.next_batch()
            logger.trace("Generated batch of size %d: %s\n" %
                         (batch_info.curr_size, batch_info.batch))
            logger.trace("Batch#%d.%d end...\n" % (epoch, batch))
            logger.trace("Forward#%d.%d begin...\n" % (epoch, batch))
            model.fwd()
            logger.trace("Forward#%d.%d end...\n" % (epoch, batch))
            if batch % args.eval_every == 0:
                loss_v, accuracy = model.get_last().get_final_values()
                logger.trace("loss %.4f, acc %.4f\n" % (loss_v, accuracy))
                loss_avg.add(loss_v)
                acc_avg.add(accuracy)
            logger.trace("Backward#%d.%d begin...\n" % (epoch, batch))
            model.bwd()
            logger.trace("Backward#%d.%d end...\n" % (epoch, batch))
            optimizer.step()
            logger.trace("Optimizer#%d.%d step end...\n" % (epoch, batch))
        # sync for timing
        stream.sync()
        logger.debug("Epoch#%d ended...\n" % epoch)
        print(f"Epoch {epoch}, loss: {loss_avg.get():.4f}, "
              f"accuracy: {acc_avg.get():.4f}, time: {time.time()-start:.4f}s")
        loss_avg.reset()
        acc_avg.reset()
    return


if __name__ == "__main__":
    main()
