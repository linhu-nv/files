# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import logging
import time
import torch
from torch.utils.data import DataLoader

import dgl
import dgl.function as fn

from ogb.graphproppred import DglGraphPropPredDataset, collate_dgl

import pylibcugraphops_internal.optims as optims
from pylibcugraphops_internal.utils import RunningAvg
from common import ApexOptNames


def make_dense_layer_components(in_feat,
                                out_feat,
                                use_bias=False,
                                activation=None,
                                dropout=0.,
                                device=None,
                                dtype=None
):
    seq = []
    if in_feat > 0 and out_feat > 0:
        seq.append(torch.nn.Linear(
            in_feat, out_feat, bias=use_bias, device=device, dtype=dtype))
    if activation is not None:
        seq.append(activation)
    if dropout > 0:
        seq.append(torch.nn.Dropout(p=dropout))
    return seq


def make_dense_layer(in_feat,
                     out_feat,
                     use_bias=False,
                     activation=None,
                     dropout=0.,
                     device=None,
                     dtype=None
):
    seq = make_dense_layer_components(
        in_feat, out_feat, use_bias, activation, dropout, device, dtype)
    return torch.nn.Sequential(*seq) if len(seq) != 1 else seq[0]


class MPNConv(torch.nn.Module):
    def __init__(self, args, device, dtype):
        super().__init__()
        # no activation/dropout in linear layer since we need to
        # add original input between linear and activation/dropout
        self.linear = make_dense_layer(
            args.mpn_dim, args.mpn_dim, use_bias=args.use_bias,
            activation=None, dropout=0., device=device, dtype=dtype)
        self.act_drop = make_dense_layer(
            0, 0, use_bias=False, activation=args.activation,
            dropout=args.dropout, device=device, dtype=dtype)
        self.last_graph = None
        self.lg = None

    def forward(self, message, in_edge_feat, graph):
        # option 1: as in chemprop, first aggregate then remove reverse edge.
        # To get the reverse edge data, we can assume that the edges are always
        # doubled such that an edge is always next to its reverse edge in the
        # graph structure.
        graph.edata['m'] = message
        n_ef = message.size(-1)
        graph.edata['mr'] = message.view(-1, 2, n_ef).flip(1).view(-1, n_ef)
        graph.update_all(fn.copy_e('m', 'mh'), fn.sum('mh', 'nh'))
        graph.apply_edges(fn.u_sub_e('nh', 'mr', 'm'))
        message = graph.edata['m']
        # option 2: create (and cache) line graph, then aggregate.
        # if graph is not self.last_graph:
        #     self.lg = dgl.line_graph(graph, backtracking=False, shared=False)
        #     self.last_graph = graph
        # self.lg.ndata['lg_m'] = message
        # self.lg.update_all(fn.copy_u('lg_m', 'lg_mh'), fn.sum('lg_mh', 'm'))
        # message = self.lg.ndata['m']

        message = self.linear(message)
        message = self.act_drop(message + in_edge_feat)
        return message


class MPNReadout(torch.nn.Module):
    def __init__(self, args, device, dtype):
        super().__init__()
        self.batch_size = args.batch_size
        if args.agg_node_type == 'norm':
            self.agg_op = 'sum'
            self.agg_node_factor = args.agg_node_factor
        else:
            self.agg_op = args.agg_node_type
            self.agg_node_factor = None

    def forward(self, node_feat, graph):
        graph.ndata['h'] = node_feat
        out = dgl.readout_nodes(graph, 'h', op=self.agg_op)
        if self.agg_node_factor is not None:
            out = out * self.agg_node_factor
        return out


class MPN(torch.nn.Module):
    def __init__(self, n_feat, e_feat, args, device, dtype, is_shared=True):
        super().__init__()
        self.linear_in = make_dense_layer(
            e_feat, args.mpn_dim, use_bias=args.use_bias, activation=None,
            dropout=0., device=device, dtype=dtype)
        self.act_in = make_dense_layer(
            0, 0, use_bias=False, activation=args.activation, dropout=0.,
            device=device, dtype=dtype)
        self.depth = args.mpn_depth
        self.is_shared = bool(is_shared)
        if self.is_shared:
            self.convs = MPNConv(args, device, dtype)
        else:
            self.convs = torch.nn.ModuleList([
                MPNConv(args, device, dtype) for _ in range(self.depth - 1)
            ])
        self.linear_node = make_dense_layer(
            n_feat + args.mpn_dim, args.mpn_dim, use_bias=True,
            activation=args.activation, dropout=args.dropout, device=device,
            dtype=dtype)
        self.readout = MPNReadout(args, device, dtype)

    def get_conv(self, i):
        if self.is_shared:
            return self.convs
        return self.convs[i]

    def forward(self, graph):
        in_edge_feat = self.linear_in(graph.edata['feat'])
        message = self.act_in(in_edge_feat)

        for d in range(self.depth - 1):
            message = self.get_conv(d)(message, in_edge_feat, graph)
        graph.edata['m'] = message
        graph.update_all(fn.copy_e('m', 'mh'), fn.sum('mh', 'h'))
        node_input = torch.cat([graph.ndata['feat'], graph.ndata['h']], dim=1)
        node_hidden = self.linear_node(node_input)

        graph_hidden = self.readout(node_hidden, graph)
        return graph_hidden


class DMPNN(torch.nn.Module):
    def __init__(self, n_feat, e_feat, args, device, dtype):
        super().__init__()
        self.mpn = MPN(n_feat, e_feat, args, device, dtype)
        self.ffn_in_feats = args.mpn_dim
        # note: reference implementation starts with a dropout layer here
        # but this doesn't make much sense IMO, so we omit that layer
        ffn_seq = []
        for i in range(args.ffn_depth):
            in_f = self.ffn_in_feats if i == 0 else args.ffn_dim
            out_f = args.ffn_dim if i < args.ffn_depth - 1 else args.n_classes
            act = args.activation if i < args.ffn_depth - 1 else None
            drop = args.dropout if i < args.ffn_depth - 1 else 0.
            ffn_seq.extend(make_dense_layer_components(
                in_f, out_f, use_bias=True, activation=act, dropout=drop,
                device=device, dtype=dtype))
        self.ffn = torch.nn.Sequential(*ffn_seq)

    def forward(self, graph):
        graph_hidden = self.mpn(graph)
        out = self.ffn(graph_hidden)
        return out


def parse_args():
    parser = argparse.ArgumentParser(description="Performs D-MPNN training")
    parser.add_argument("-mpn_dim", type=int, default=300,
        help="Hidden dimension of MPN encoder.")
    parser.add_argument("-mpn_depth", type=int, default=3,
        help="Number of layers in MPN encoder.")
    parser.add_argument("-ffn_depth", type=int, default=2,
        help="Number of layers in feed-forward network.")
    parser.add_argument("-ffn_dim", type=int, default=300,
        help="Hidden dimension of feed-forward network.")
    parser.add_argument("-n_classes", type=int, default=2,
        help="Number of classes.")
    parser.add_argument("-use_bias", action="store_true",
        help="Use bias in MPN encoder (feed-forward net always uses bias).")
    parser.add_argument("-activation", type=str, default='ReLU',
        choices=['none', 'ReLU', 'LeakyReLU'],
        help="Activation to use throughout the model.")
    parser.add_argument("-agg_node_type", type=str, default='mean',
        choices=['sum', 'mean', 'norm'],
        help="How to aggregate node features into graph features.")
    parser.add_argument("-agg_node_factor", type=float, default=.01,
        help="Aggregation norm factor if -agg_node_type is 'norm'.")
    # add common args as in other examples
    parser.add_argument(
        "-opt", type=str, default="Adam", help="Optimizer to be used")
    parser.add_argument(
        "-adam_beta1", type=float, default=0.9,
        help="Exponential decay for first moment estimates")
    parser.add_argument(
        "-adam_beta2", type=float, default=0.999,
        help="Exponential decay for second moment estimates")
    parser.add_argument(
        "-adam_epsilon", type=float, default=1e-8,
        help="Smoothing parameter to avoid division-by-zero")
    parser.add_argument(
        "-lr", type=float, default=0.003, help="Learning rate for ADAM")
    parser.add_argument(
        "-batch_size", type=int, default=1000, help="Training Mini-batch size")
    parser.add_argument(
        "-dropout", type=float, default=0., help="Dropout at each layer")
    parser.add_argument(
        "-dataset", type=str, default="ogbg-molhiv",
        help="Dataset used in this example.")
    parser.add_argument(
        "-epochs", type=int, default=20, help="Number of training epochs")
    parser.add_argument(
        "-nbatches", type=int, default=200,
        help="Number of batches to be run per epoch. This is only to be"
        " used during debug/profile sessions. It is NOT recommended to be used"
        " during a full training session.")
    parser.add_argument(
        "-eval_every", type=int, default=1,
        help="Number of batches after which loss and accuracy are "
        "re-evaluated.")
    parser.add_argument(
        "-verbosity", type=int, default=logging.INFO,
        help="Logging verbosity level")
    args = parser.parse_args()
    if args.activation == "none":
        args.activation = None
    else:
        args.activation = getattr(torch.nn, args.activation)()

    args.opt_fused = None
    if args.opt in ApexOptNames:
        try:
            import apex.optimizers
            args.opt_fused = getattr(apex.optimizers, ApexOptNames[args.opt])
        except ImportError:
            pass
    args.opt = getattr(optims, args.opt)
    if args.opt is optims.Adam:
        args.opt_kwargs = {
            'lr': args.lr,
            'betas': (args.adam_beta1, args.adam_beta2),
            'eps': args.adam_epsilon
        }
    if args.eval_every <= 0:
        raise Exception("eval_every option must be strictly positive")
    return args


def get_label_stats(labels):
    low, high = labels.min().item(), labels.max().item()
    n_low = torch.sum(labels == low).item()
    n_high = torch.sum(labels == high).item()
    return "Labels stats: shape {}, min {}, max {}, #min {}, #max {}".format(
        labels.shape, low, high, n_low, n_high)


def get_log_level(ops_verbosity):
    if ops_verbosity <= 0: return logging.CRITICAL
    if ops_verbosity <= 10: return logging.ERROR
    if ops_verbosity <= 100: return logging.WARNING
    if ops_verbosity <= 1000: return logging.INFO
    return logging.DEBUG


def train_loop(train_loader,
               n_batches,
               model,
               loss,
               optimizer,
               epoch,
               loss_avg,
               acc_avg,
               args
):
    for b, batch in enumerate(train_loader):
        batch_graph, batch_labels = batch
        logging.debug("Batch#%d.%d begin...\n", epoch, b)
        logging.debug("Generated batch of size %d: %s\n",
                    len(batch_labels), batch_graph)
        logging.debug("Batch#%d.%d end...\n", epoch, b)
        logging.debug("Forward#%d.%d begin...\n", epoch, b)
        logits = model(batch_graph)
        if get_log_level(args.verbosity) == logging.DEBUG and epoch == 0:
            print(get_label_stats(batch_labels))
        loss_val = loss(logits, batch_labels)
        logging.debug("Forward#%d.%d end...\n", epoch, b)
        if b % args.eval_every == 0:
            hits = logits.detach().argmax(1) == batch_labels
            acc_v = torch.mean(hits.to(torch.float64)).item()
            loss_v = loss_val.item()
            logging.debug("loss %.4f, acc %.4f\n", loss_v, acc_v)
            loss_avg.add(loss_v)
            acc_avg.add(acc_v)
        logging.debug("Backward#%d.%d begin...\n", epoch, b)
        optimizer.zero_grad()
        loss_val.backward()
        logging.debug("Backward#%d.%d end...\n", epoch, b)
        optimizer.step()
        logging.debug("Optimizer#%d.%d step end...", epoch, b)
        if b + 1 >= n_batches:
            break


def main():
    args = parse_args()
    logging.basicConfig(level=get_log_level(args.verbosity))
    device = torch.device("cuda")
    dtype = torch.float32
    dataset = DglGraphPropPredDataset(name=args.dataset)
    # move entire dataset to device and given data type
    for i, g in enumerate(dataset.graphs):
        g_d = g.to(device=device)
        g_d.ndata['feat'] = g_d.ndata['feat'].to(dtype=dtype)
        g_d.edata['feat'] = g_d.edata['feat'].to(dtype=dtype)
        dataset.graphs[i] = g_d
    dataset.labels = dataset.labels[:, 0].to(device=device)

    train_loader = DataLoader(
        dataset, batch_size=args.batch_size, shuffle=True,
        collate_fn=collate_dgl
    )

    n_feat = dataset.graphs[0].ndata['feat'].shape[1]
    e_feat = dataset.graphs[0].edata['feat'].shape[1]
    model = DMPNN(n_feat, e_feat, args, device, dtype)

    if args.opt_fused is None:
        optimizer_class = getattr(torch.optim, args.opt.__name__)
    else:
        optimizer_class = args.opt_fused
    optimizer = optimizer_class(model.parameters(), **args.opt_kwargs)

    loss = torch.nn.CrossEntropyLoss()

    print(get_label_stats(dataset.labels))

    loss_avg = RunningAvg()
    acc_avg = RunningAvg()
    batcher_batches = -(len(dataset) // -args.batch_size)
    e = "expected at most {} batches, but asking for {}".format(
        batcher_batches, args.nbatches)
    assert args.nbatches <= batcher_batches, e
    if args.nbatches != 0:
        n_batches = args.nbatches
    else:
        n_batches = batcher_batches
    logging.debug("Running for %d epochs\n", args.epochs)
    logging.debug("Running for %d batches per epoch\n", n_batches)
    with torch.autograd.profiler.emit_nvtx():
        for epoch in range(args.epochs):
            start = time.time()
            logging.debug("Epoch#%d started...\n", epoch)
            train_loop(
                train_loader, n_batches, model, loss, optimizer, epoch,
                loss_avg, acc_avg, args
            )
            logging.debug("Epoch#%d ended...\n", epoch)
            print(
                f"Epoch {epoch}, loss: {loss_avg.get():.4f}, "
                f"accuracy: {acc_avg.get():.4f}, time: "
                f"{time.time()-start:.4f}s"
            )
            loss_avg.reset()
            acc_avg.reset()


if __name__ == "__main__":
    main()
