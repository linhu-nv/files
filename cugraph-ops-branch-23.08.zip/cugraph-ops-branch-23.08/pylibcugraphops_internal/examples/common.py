# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import argparse
import numpy as np
import os.path as osp

import pylibcugraphops_internal_ext as internal_ext
import pylibcugraphops_internal.optims as optims

logger = internal_ext.utils.logger


DatasetSizes = {
    # (num-vertices, feature-dim, is-undirected, is-hg, default sampling type,
    #  dataset type)
    "products": (2_449_029, 100, True, False, "algoR", "ogbn"),
    "arxiv": (169_343, 128, False, False, "algoR", "ogbn"),
    "mag": (193_9743, 128, True, True, "algoLST", "ogbn"),
    "papers100M": (111_059_956, 128, True, False, "algoR", "ogbn"),
    "hiv": (-1, -1, True, False, "-NA-", "ogbg"),
    "pcba": (-1, -1, True, False, "-NA-", "ogbg"),
}

HGTypes = {
    # (#node types, #edge types)
    "mag": (4, 4),
}

ApexOptNames = {
    "Adagrad": "FusedAdagrad",
    "Adam": "FusedAdam",
    "NovoGrad": "FusedNovoGrad",
    "SGD": "FusedSGD",
}


def add_common_args(parser):
    parser.add_argument(
        "-adam_beta1", type=float, default=0.9,
        help="Exponential decay for first moment estimates")
    parser.add_argument(
        "-adam_beta2", type=float, default=0.999,
        help="Exponential decay for second moment estimates")
    parser.add_argument(
        "-adam_epsilon", type=float, default=1e-8,
        help="Smoothing parameter to avoid division-by-zero")
    parser.add_argument(
        "-lr", type=float, default=0.003, help="Learning rate for ADAM")
    parser.add_argument(
        "-batch_size", type=int, default=1000, help="Training Mini-batch size")
    parser.add_argument(
        "-dropout", default=None, help="Dropout at each layer")
    parser.add_argument(
        "-dataset", type=str, default="products",
        help="Type of datasets supported in this example. The datasets will"
        " will not be downloaded by this exe, but instead is expected to be"
        " already available.")
    parser.add_argument(
        "-dataset_dir", type=str, default=None,
        help="Path to the dir containing the datasets. Inside this dir, a"
        " sub-directory named <dataset_type>/<dataset>/raw will be looked for"
        " and further if this dir has a file named `graph.bin`, then the"
        " dataset will be loaded from this file. Else, the files"
        " `edge.csv.gz`, `edge-feat.csv.gz`, `graph-label.csv.gz`,"
        " `node-label.csv.gz`, `node-feat.csv.gz`, `num-edge-list.csv.gz`,"
        " `num-node-list.csv.gz` will be read to construct the dataset. Which"
        " exact files will be read depends on the dataset-type, which is"
        " inferred from the '-dataset' option.")
    parser.add_argument(
        "-dims", type=str, default="256,47",
        help="Dimensions of all hidden and output layers of the model.")
    parser.add_argument(
        "-epochs", type=int, default=20, help="Number of training epochs")
    parser.add_argument(
        "-nbatches", type=int, default=200,
        help="Number of batches to be run per epoch. This is only to be"
        " used during debug/profile sessions. It is NOT recommended to be used"
        " during a full training session.")
    parser.add_argument(
        "-eval_every", type=int, default=1,
        help="Number of batches after which loss and accuracy are "
        "re-evaluated.")
    parser.add_argument(
        "-nlayers", type=int, default=2, help="Number of layers in the model")
    parser.add_argument(
        "-nvtx", action="store_true", help="Enable NVTX markers")
    parser.add_argument(
        "-opt", type=str, default="Adam", help="Optimizer to be used")
    parser.add_argument(
        "-sample_sizes", type=str, default="25,10",
        help="Comma-separated list of sample sizes for each layer. The length"
             " of the resulting list must match the value passed for"
             " `-nlayers`. The first element in the list corresponds to the"
             " neighborhood sample size for the first layer of the network,"
             " and so on.")
    parser.add_argument(
        "-sample_type", type=str, default=None,
        choices=['algoR', 'algoLST'],
        help="Type of sampling algorithm to use. AlgoLST is 'safer' since it"
             " behaves well even if the dataset contains many nodes with"
             " a large number of neighbors. By default, this is chosen based"
             " on the chosen dataset.")
    parser.add_argument(
        "-seed", type=int, default=0,
        help="Random seed for reproducibility. If not passed, then the seed"
             " for the RNG will be different between successive calls.")
    parser.add_argument(
        "-feats_mem_type", type=str, default='cudaDevice',
        choices=['cudaHost', 'cudaDevice', 'cudaManaged'],
        help="Memory types of feature-related buffers")
    parser.add_argument(
        "-graph_mem_type", type=str, default='cudaDevice',
        choices=['cudaHost', 'cudaDevice', 'cudaManaged'],
        help="Memory type of graph-related buffers")
    parser.add_argument(
        "-resize_factor", type=int, default=1,
        help="Number of redundant connected components if artififally"
             " increased dataset is desired"
    )
    parser.add_argument(
        "-verbosity", type=int, default=logger.LEVEL_INFO,
        help="Logging verbosity level")


def parse_common_args(args):
    assert args.dataset in DatasetSizes, f"Unknown dataset '{args.dataset}'"
    if args.dropout is not None:
        args.dropout = float(args.dropout)
        assert 0 <= args.dropout <= 1, f"Invalid dropout value {args.dropout}"
    if args.dataset_dir is None:
        raise Exception("`-dataset_dir` option is mandatory")
    dataset_type = DatasetSizes[args.dataset][5]
    args.dataset_dir = os.path.join(
        args.dataset_dir, dataset_type, args.dataset, "raw")
    args.sample_sizes_vec = [int(v) for v in args.sample_sizes.split(",")]
    if len(args.sample_sizes_vec) != args.nlayers:
        raise Exception("Bad `-sample_sizes` and `-nlayers` args! (%s, %d)" %
                        (args.sample_sizes, args.nlayers))
    args.dims_vec = [int(v) for v in args.dims.split(",")]
    if len(args.dims_vec) != args.nlayers:
        raise Exception("Bad `-dims` and `-nlayers` args! (%s, %d)" %
                        (args.dims, args.nlayers))
    if not hasattr(optims, args.opt):
        raise Exception("Bad optimizer given in `opt` (%s)" % args.opt)
    args.opt_fused = None
    if args.opt in ApexOptNames:
        try:
            import apex.optimizers
            args.opt_fused = getattr(apex.optimizers, ApexOptNames[args.opt])
        except ImportError:
            pass
    args.opt = getattr(optims, args.opt)
    if args.opt is optims.Adam:
        args.opt_kwargs = {
            'lr': args.lr,
            'betas': (args.adam_beta1, args.adam_beta2),
            'eps': args.adam_epsilon
        }
    if args.eval_every <= 0:
        raise Exception("eval_every option must be strictly positive")
    if args.sample_type is None:
        args.sample_type = DatasetSizes[args.dataset][4]
    if args.sample_type == 'algoR':
        args.sample_type = internal_ext.graph.SamplingAlgo.ReservoirAlgoR
    else:
        args.sample_type = internal_ext.graph.SamplingAlgo.ReservoirAlgoLST
    assert args.resize_factor > 0
    return args


def load_dataset(args, is_torch=False):
    logger.debug("load_dataset: started\n")
    n_nodes, n_cols, undirected, is_hg, _, dataset_type = DatasetSizes[args.dataset]

    feats_mem_type = getattr(internal_ext.io.cudaMemoryType, args.feats_mem_type)
    graph_mem_type = getattr(internal_ext.io.cudaMemoryType, args.graph_mem_type)

    if dataset_type == "ogbn":
        if (is_hg):
            n_node_types, n_edge_types = HGTypes[args.dataset]
            data = internal_ext.io.ogbn(
                args.dataset_dir, n_nodes, n_cols,
                undirected, n_node_types, n_edge_types, args.resize_factor, feats_mem_type, graph_mem_type)
        else:
            data = internal_ext.io.ogbn(
                args.dataset_dir, n_nodes, n_cols, undirected, args.resize_factor, feats_mem_type, graph_mem_type)

        if is_torch:
            data_torch = internal_ext.torch.OgbnTorch(data)

    elif dataset_type == "ogbg":
        data = internal_ext.io.ogbg(args.dataset_dir, undirected, feats_mem_type, graph_mem_type)

        if is_torch:
            data_torch = internal_ext.torch.OgbgTorch(data)

    else:
        raise Exception(f"Unknown dataset-type {dataset_type}")

    logger.debug("load_dataset: ended\n")

    if is_torch:
        return data, data_torch

    return data
