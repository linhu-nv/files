#!/bin/bash
# Copyright (c) 2023, NVIDIA CORPORATION.
#
# A script to setup environment variables for a local cugraph-ops build within
# a docker environment (see other files in this folder).

set -e
REPODIR=$(dirname -- "$(dirname -- "$(readlink -f -- "${BASH_SOURCE[0]}")")")

# we overwrite PYTHONPATH entirely, because nothing else should rely on this
export PYTHONPATH="$REPODIR/pylibcugraphops:$REPODIR/pylibcugraphops_internal"
# we only add to LD_LIBRARY_PATH
export LD_LIBRARY_PATH="$REPODIR/build:$REPODIR/cpp/build:$REPODIR/build/internal:$REPODIR/cpp_internal/build:$LD_LIBRARY_PATH"

# go to the repo for build
cd "$REPODIR"
