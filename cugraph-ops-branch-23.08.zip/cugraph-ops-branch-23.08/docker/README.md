# Bare-minimum container environment
This folder contains files to create a bare-minimum container environment,
useful for running benchmarks and low-level tests, without the need to install
many tools only required for development or higher-level builds/tests
(clang, PyTorch, docs utilities, etc.).

You can also use the `Dockerfile` here as a guide to create/modify your own
Dockerfiles, since the requirements are kept at a minimum, in particular
excluding conda. Note that changing the CUDA version should always work well,
but changing the OS may cause a different default compiler to be installed,
so make sure to install the current version used by cugraph-ops through conda.  
The individual parts of this Dockerfile can often be re-composed to install
a base version of cugraph-ops into a pre-existing docker.

To use this environment, there are two separate types of Dockerfiles described below

### 1 - Dockerfiles without a cugraph-ops build (all current Dockerfiles)
1. Go to this folder and run:
   `docker build -t <cugraph-ops:tag> [optional: -f <Dockerfile>] .`
3. Run: `docker run --gpus all -it --rm [volume mount cugraph-ops] <cugraphs-ops:tag>`
4. Within the docker, go to the folder where cugraph-ops was mounted and build
   using the normal build script.  
   On systems like computelab, use a local install (`build.sh python`) and add the
   `pylibcugraphops`/`pylibcugraphops_internal` folders to `PYTHONPATH`,
   as well as the `build` and `build/internal` folders to `LD_LIBRARY_PATH`,
   or simply use `source /cugraph-ops/docker/setup_local_build.sh` if you
   mounted cugraph-ops to `/cugraph-ops`.

### 2 - Dockerfiles including a cugraph-ops build (none available currently)
1. Place all files from this folder in a separate folder on the target system
   and clone cugraph-ops into this folder.
2. Run: `docker build -t <cugraph-ops:tag> [optional: -f <Dockerfile>] .`
3. Run: `docker run --gpus all -it --rm [volume mount data] <cugraphs-ops:tag>`
4. Within the docker, cugraph-ops is already built and the code is available
   under `/cugraph-ops` for re-building.
