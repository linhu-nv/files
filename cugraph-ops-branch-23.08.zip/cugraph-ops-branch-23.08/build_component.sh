#!/bin/bash

# Copyright (c) 2019-2023, NVIDIA CORPORATION.

# cugraphops build script for single components

# This script is used to build single components in this repo from
# source, and can be called with various options to customize the
# build as needed (see the help output for details)

# Abort script on first error
set -e

NUMARGS=$#
ARGS=$*

# NOTE: ensure all dir changes are relative to the location of this
# script, and that this script resides in the repo dir!
REPODIR=$(cd $(dirname $0); pwd)

VALIDARGS="clean libcugraphops libcugraphops-internal tests tests-internal "
VALIDARGS+="benchmarks pylibcugraphops pylibcugraphops-internal -v -g -n "
VALIDARGS+="--native --cmake-args --compile-cmd -h --help"
HELP="$0 [<target> ...] [<flag> ...]
 where <target> is:
   clean                    - remove all existing build artifacts and configuration (start over).
   libcugraphops            - build the libcugraphops C++ library.
   libcugraphops-internal   - build the internal libcugraphops C++ library.
   tests                    - build the C++ (OPG) tests.
   tests-internal           - build the internal C++ (OPG) tests.
   benchmarks               - build benchmarks.
   pylibcugraphops          - build the pylibcugraphops Python package.
   pylibcugraphops-internal - build the internal pylibcugraphops Python package.
 and <flag> is:
   -v                          - verbose build mode
   -g                          - build for debug
   -n                          - no install step
   --native                    - build for the GPU architecture of the current system
   --cmake-args=\\\"<args>\\\" - add arbitrary CMake arguments to any cmake call
   --compile-cmd               - only output compile commands (invoke CMake without build)
   -h | --h[elp]               - print this text
"
LIBCUGRAPH_OPS_BUILD_DIR=${REPODIR}/build
LIBCUGRAPH_OPS_I_BUILD_DIR=${REPODIR}/build/internal
PYLIBCUGRAPH_OPS_BUILD_DIRS="${REPODIR}/pylibcugraphops/build"
PYLIBCUGRAPH_OPS_BUILD_DIRS+=" ${REPODIR}/pylibcugraphops/_skbuild"
PYLIBCUGRAPH_OPS_BUILD_DIRS+=" ${REPODIR}/pylibcugraphops/pylibcugraphops/binding/include"
PYLIBCUGRAPH_OPS_BUILD_DIRS+=" ${REPODIR}/pylibcugraphops/pylibcugraphops/binding/lib"
PYLIBCUGRAPH_OPS_BUILD_DIRS+=" ${REPODIR}/pylibcugraphops_internal/_skbuild"
PYLIBCUGRAPH_OPS_BUILD_DIRS+=" ${REPODIR}/pylibcugraphops_internal/pylibcugraphops_internal_ext/binding/include"
PYLIBCUGRAPH_OPS_BUILD_DIRS+=" ${REPODIR}/pylibcugraphops_internal/pylibcugraphops_internal_ext/binding/lib"
BUILD_DIRS="${LIBCUGRAPH_OPS_BUILD_DIR} ${PYLIBCUGRAPH_OPS_BUILD_DIRS}"

# Set defaults for vars modified by flags to this script
VERBOSE_FLAG=""
BUILD_TYPE=Release
BUILD_ALL_GPU_ARCH=1
INSTALL_TARGET="--target install"

# Set defaults for vars that may not have been defined externally
#  FIXME: if INSTALL_PREFIX is not set, check PREFIX, then check
#         CONDA_PREFIX, but there is no fallback from there!
INSTALL_PREFIX=${INSTALL_PREFIX:=${PREFIX:=${CONDA_PREFIX}}}
PARALLEL_LEVEL=${PARALLEL_LEVEL:=""}

export CMAKE_GENERATOR="${CMAKE_GENERATOR:=Ninja}"

function hasArg {
    (( ${NUMARGS} != 0 )) && (echo " ${ARGS} " | grep -q " $1 ")
}

function cmakeArgs {
    # Check for multiple cmake args options
    if [[ $(echo $ARGS | { grep -Eo "\-\-cmake\-args" || true; } | wc -l ) -gt 1 ]]; then
        echo "Multiple --cmake-args options were provided, please provide only one: ${ARGS}"
        exit 1
    fi

    # Check for cmake args option
    if [[ -n $(echo $ARGS | { grep -E "\-\-cmake\-args" || true; } ) ]]; then
        # There are possible weird edge cases that may cause this regex filter to output nothing and fail silently
        # the true pipe will catch any weird edge cases that may happen and will cause the program to fall back
        # on the invalid option error
        EXTRA_CMAKE_ARGS=$(echo $ARGS | { grep -Eo "\-\-cmake\-args=\".+\"" || true; })
        if [[ -n ${EXTRA_CMAKE_ARGS} ]]; then
            # Remove the full  EXTRA_CMAKE_ARGS argument from list of args so that it passes validArgs function
            ARGS=${ARGS//$EXTRA_CMAKE_ARGS/}
            # Filter the full argument down to just the extra string that will be added to cmake call
            EXTRA_CMAKE_ARGS=$(echo $EXTRA_CMAKE_ARGS | grep -Eo "\".+\"" | sed -e 's/^"//' -e 's/"$//')
        fi
    fi
}

if hasArg -h || hasArg --h || hasArg --help; then
    echo "${HELP}"
    exit 0
fi

# Check for valid usage
if (( ${NUMARGS} != 0 )); then
    # Check for cmake args
    cmakeArgs
    for a in ${ARGS}; do
    if ! (echo " ${VALIDARGS} " | grep -q " ${a} "); then
        echo "Invalid option: ${a}"
        exit 1
    fi
    done
fi

# Process flags
if hasArg -v; then
    VERBOSE_FLAG=-v
fi
if hasArg -g; then
    BUILD_TYPE=Debug
fi
if hasArg -n; then
    INSTALL_TARGET=""
fi
if hasArg --native; then
    BUILD_ALL_GPU_ARCH=0
fi

# If clean given, run it prior to any other steps
if hasArg clean; then
    # If the dirs to clean are mounted dirs in a container, the
    # contents should be removed but the mounted dirs will remain.
    # The find removes all contents but leaves the dirs, the rmdir
    # attempts to remove the dirs but can fail safely.
    for bd in ${BUILD_DIRS}; do
    if [ -d ${bd} ]; then
        find ${bd} -mindepth 1 -delete
        rmdir ${bd} || true
    fi
    done
    # remove any left-over cpython shared libraries
    find ${REPODIR}/pylibcugraphops -name "*.cpython*.so" -type f -delete
    find ${REPODIR}/pylibcugraphops_internal -name "*.cpython*.so" -type f -delete
fi

# set values based on flags
if (( ${BUILD_ALL_GPU_ARCH} == 0 )); then
    CUGRAPH_OPS_CMAKE_CUDA_ARCHITECTURES="${CUGRAPH_OPS_CMAKE_CUDA_ARCHITECTURES:=NATIVE}"
    echo "Building for the architecture of the GPU in the system..."
else
    CUGRAPH_OPS_CMAKE_CUDA_ARCHITECTURES="RAPIDS"
    echo "Building for *ALL* supported GPU architectures..."
fi
if hasArg tests; then
    BUILD_TESTS=ON
else
    BUILD_TESTS=OFF
fi
if hasArg tests-internal; then
    BUILD_TESTS_INTERNAL=ON
else
    BUILD_TESTS_INTERNAL=OFF
fi
if hasArg benchmarks; then
    BUILD_BENCHMARKS=ON
else
    BUILD_BENCHMARKS=OFF
fi

################################################################################
# libcugraphops
if hasArg libcugraphops; then
    cmake -S ${REPODIR}/cpp -B ${LIBCUGRAPH_OPS_BUILD_DIR} \
          -DCMAKE_INSTALL_PREFIX=${INSTALL_PREFIX} \
          -DCMAKE_CUDA_ARCHITECTURES=${CUGRAPH_OPS_CMAKE_CUDA_ARCHITECTURES} \
          -DCMAKE_BUILD_TYPE=${BUILD_TYPE} \
          -DCMAKE_PREFIX_PATH=${INSTALL_PREFIX} \
          -DCMAKE_MESSAGE_LOG_LEVEL=VERBOSE \
          -DBUILD_CUGRAPH_OPS_CPP_TESTS=${BUILD_TESTS} \
          -DBUILD_CUGRAPH_OPS_BENCHMARKS=${BUILD_BENCHMARKS} \
          ${EXTRA_CMAKE_ARGS}

    cd ${LIBCUGRAPH_OPS_BUILD_DIR}

    if ! hasArg --compile-cmd; then
        ## Build and (optionally) install library + tests
        cmake --build . -j${PARALLEL_LEVEL} ${INSTALL_TARGET} ${VERBOSE_FLAG}
    fi
fi

################################################################################
# libcugraphops-internal
if hasArg libcugraphops-internal; then
    # cmake references an env var to find the cugraph-ops package
    LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR:=${LIBCUGRAPH_OPS_BUILD_DIR}}
    env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} \
    cmake -S ${REPODIR}/cpp_internal -B ${LIBCUGRAPH_OPS_I_BUILD_DIR} \
        -DCMAKE_INSTALL_PREFIX=${INSTALL_PREFIX} \
        -DCMAKE_CUDA_ARCHITECTURES=${CUGRAPH_OPS_CMAKE_CUDA_ARCHITECTURES} \
        -DCMAKE_BUILD_TYPE=${BUILD_TYPE} \
        -DCMAKE_PREFIX_PATH=${INSTALL_PREFIX} \
        -DCMAKE_MESSAGE_LOG_LEVEL=VERBOSE \
        -DBUILD_CUGRAPH_OPS_I_CPP_TESTS=${BUILD_TESTS_INTERNAL} \
        ${EXTRA_CMAKE_ARGS}

    cd ${LIBCUGRAPH_OPS_I_BUILD_DIR}

    if ! hasArg --compile-cmd; then
        ## Build and (optionally) install library + tests
        cmake --build . -j${PARALLEL_LEVEL} ${INSTALL_TARGET} ${VERBOSE_FLAG}
    fi
fi

################################################################################
# pylibcugraphops
if hasArg pylibcugraphops; then
    # setup.py and cmake reference an env var LIBCUGRAPHOPS_DIR to find the
    # libcugraph-ops package (cmake).
    # If not set by the user, set it to LIBCUGRAPH_OPS_BUILD_DIR
    LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR:=${LIBCUGRAPH_OPS_BUILD_DIR}}
    if ! hasArg --compile-cmd; then
        cd ${REPODIR}/pylibcugraphops
        env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} \
        python setup.py build_ext --inplace \
            --build-type=${BUILD_TYPE} \
            ${EXTRA_CMAKE_ARGS}
        if ! hasArg -n; then
            env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} \
            python setup.py install \
                --build-type=${BUILD_TYPE} \
                ${EXTRA_CMAKE_ARGS}
        fi
    else
        # just invoke cmake without going through scikit-build
        env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} \
        cmake -S ${REPODIR}/pylibcugraphops -B ${REPODIR}/pylibcugraphops/_skbuild/build \
           -DCMAKE_BUILD_TYPE=${BUILD_TYPE} \
            ${EXTRA_CMAKE_ARGS}
    fi
fi

################################################################################
# pylibcugraphops-internal
if hasArg pylibcugraphops-internal; then
    # setup.py and cmake reference an env var LIBCUGRAPHOPS_DIR to find the
    # libcugraph-ops package (cmake), plus LIBCUGRAPHOPS_I_DIR to find the
    # internal package.
    # If not set by the user, set it to LIBCUGRAPH_OPS_BUILD_DIR
    LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR:=${LIBCUGRAPH_OPS_BUILD_DIR}}
    LIBCUGRAPHOPS_I_DIR=${LIBCUGRAPHOPS_I_DIR:=${LIBCUGRAPH_OPS_I_BUILD_DIR}}
    if ! hasArg --compile-cmd; then
        cd ${REPODIR}/pylibcugraphops_internal
        env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} LIBCUGRAPHOPS_I_DIR=${LIBCUGRAPHOPS_I_DIR} \
        python setup.py build_ext --inplace \
            --build-type=${BUILD_TYPE} \
            ${EXTRA_CMAKE_ARGS}
        if ! hasArg -n; then
            env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} LIBCUGRAPHOPS_I_DIR=${LIBCUGRAPHOPS_I_DIR} \
            python setup.py install \
                --build-type=${BUILD_TYPE} \
                ${EXTRA_CMAKE_ARGS}
        fi
    else
        # just invoke cmake without going through scikit-build
        env LIBCUGRAPHOPS_DIR=${LIBCUGRAPHOPS_DIR} LIBCUGRAPHOPS_I_DIR=${LIBCUGRAPHOPS_I_DIR} \
        cmake -S ${REPODIR}/pylibcugraphops_internal -B ${REPODIR}/pylibcugraphops_internal/_skbuild/build \
           -DCMAKE_BUILD_TYPE=${BUILD_TYPE} \
            ${EXTRA_CMAKE_ARGS}
    fi
fi
