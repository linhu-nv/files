# Build Documentation (Local Build)

1. Create a conda environment for building documentations:
```bash
mamba env create -f conda/environments/all_cuda-115_arch-x86_64.yaml
conda activate all_cuda-115_arch-x86_64
```

2. Build libcugraphops and pylibcugraphops
```bash
./build.sh cpp python
```

3. Build and view documentation
```bash
cd docs
make clean html
firefox build/html/index.html
```
or any other browser.


As an alternative, build a text-only version of the documentation
```bash
cd docs
make clean text
cat build/text/index.html
```
or just have a look at any file of interest.
