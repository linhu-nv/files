=============================
Operators for Message-Passing
=============================

.. currentmodule:: pylibcugraphops

Simple Neighborhood Aggregator (SAGEConv)
-----------------------------------------
.. autosummary::
   :toctree: api/

   operators.agg_simple_fg_n2n_fwd
   operators.agg_simple_fg_n2n_bwd
   operators.agg_simple_fg_e2n_fwd
   operators.agg_simple_fg_e2n_bwd
   operators.agg_simple_fg_n2n_e2n_fwd
   operators.agg_simple_fg_n2n_e2n_bwd

   operators.agg_concat_fg_n2n_fwd
   operators.agg_concat_fg_n2n_bwd
   operators.agg_concat_fg_e2n_fwd
   operators.agg_concat_fg_e2n_bwd
   operators.agg_concat_fg_n2n_e2n_fwd
   operators.agg_concat_fg_n2n_e2n_bwd

   operators.agg_simple_mfg_n2n_fwd
   operators.agg_simple_mfg_n2n_bwd
   operators.agg_concat_mfg_n2n_fwd
   operators.agg_concat_mfg_n2n_bwd

Weighted Neighborhood Aggregation
---------------------------------
.. autosummary::
   :toctree: api/

   operators.agg_weighted_fg_n2n_fwd
   operators.agg_weighted_fg_n2n_bwd
   operators.agg_concat_weighted_fg_n2n_fwd
   operators.agg_concat_weighted_fg_n2n_bwd

Heterogenous Aggregator using Basis Decomposition (RGCNConv)
------------------------------------------------------------
.. autosummary::
   :toctree: api/

   operators.agg_hg_basis_fg_n2n_post_fwd
   operators.agg_hg_basis_fg_n2n_post_bwd

   operators.agg_hg_basis_mfg_n2n_post_fwd
   operators.agg_hg_basis_mfg_n2n_post_bwd

Graph Attention (GATConv/GATv2Conv)
-----------------------------------
.. autosummary::
   :toctree: api/

   operators.mha_gat_fg_n2n_fwd
   operators.mha_gat_fg_n2n_bwd
   operators.mha_gat_fg_n2n_efeat_fwd
   operators.mha_gat_fg_n2n_efeat_bwd

   operators.mha_gat_mfg_n2n_fwd
   operators.mha_gat_mfg_n2n_bwd

   operators.mha_gat_v2_fg_n2n_fwd
   operators.mha_gat_v2_fg_n2n_bwd
   operators.mha_gat_v2_fg_n2n_efeat_fwd
   operators.mha_gat_v2_fg_n2n_efeat_bwd

Transformer-like Graph Attention (TransformerConv)
--------------------------------------------------
.. autosummary::
   :toctree: api/

   operators.mha_gat_v2_fg_n2n_fwd
   operators.mha_gat_v2_fg_n2n_bwd
   operators.mha_gat_v2_fg_n2n_efeat_fwd
   operators.mha_gat_v2_fg_n2n_efeat_bwd

Directional Message-Passing (DMPNN)
-----------------------------------
.. autosummary::
   :toctree: api/

   operators.agg_dmpnn_fg_e2e_fwd
   operators.agg_dmpnn_fg_e2e_bwd

Graph Pooling
-------------
.. autosummary::
   :toctree: api/

   operators.pool_fg_n2s_fwd
   operators.pool_fg_n2s_bwd

Update Edges: Concatenation or Sum of Edge and Node Features
------------------------------------------------------------
.. autosummary::
   :toctree: api/

   operators.update_efeat_bipartite_e2e_concat_fwd
   operators.update_efeat_bipartite_e2e_concat_bwd

   operators.update_efeat_bipartite_e2e_sum_fwd
   operators.update_efeat_bipartite_e2e_sum_bwd

   operators.update_efeat_static_e2e_concat_fwd
   operators.update_efeat_static_e2e_concat_bwd

   operators.update_efeat_static_e2e_sum_fwd
   operators.update_efeat_static_e2e_sum_bwd
