# Introduction
`cugraph-ops` aims to be a low-level, framework agnostic library providing
commonly used computational operators for GNNs and other graph operations.

# Pre-requisites
Developing and using via anaconda is the only supported approach currently.  
Use `mamba env create -f conda/environments/<option>.yaml` to create a full
development environment with all features for developing and testing.

However, folks are free to either use docker or bare-metal as per their
convenience.

A good indicator of the bare-minimum requirements needed to create a
development/test environment (excluding utilities for building docs, as well as
excluding anything related to PyTorch) can be found in the `docker` folder.  
This is useful for benchmarking and other low-level tests.

In any case, you need Linux OS with CUDA toolkit >= 11.

# Datasets
A few simple datasets used for benchmarking can all be downloaded by:
`./scripts/download_all_datasets.sh`

# Aggregator Overview

| Aggregator                          | MFG | Graph | Batched | Feat.T. | Ind.T. | OP* |
|-------------------------------------|-----|-------|---------|---------|-------|----|
| `mha_gat_<GT>_n2n`                |  ✅ |  ✅    | 〽️      |fp32,fp64|int32,int64 | linear,relu,sigmoid,tanh,elu,scalar,leakyrelu      |
| `mha_gat_<GT>_n2n_efeat`          |  ❌ |  ✅    | 〽️      |fp32,fp64|int32,int64 | linear,relu,sigmoid,tanh,elu,scalar,leakyrelu      |
| `mha_gat_v2_<GT>_n2n`                |  ❌ |  ✅    | 〽️      |fp32,fp64|int32,int64 | linear,relu,sigmoid,tanh,elu,scalar,leakyrelu      |
| `mha_gat_v2_<GT>_n2n_efeat`          |  ❌ |  ✅    | 〽️      |fp32,fp64|int32,int64 | linear,relu,sigmoid,tanh,elu,scalar,leakyrelu      |
| `mha_simple_<GT>_n2n`                |  ❌ |  ✅    | 〽️      |fp32,fp64|int32,int64 | norm/no-norm, add. bias     |
| `mha_simple_<GT>_n2n_efeat`          |  ❌ |  ✅    | 〽️      |fp32,fp64|int32,int64 | norm/no-norm, add. bias      |
| `agg_hg_basis_<GT>_n2n_pre`       |  ✅ |  ✅   | 〽️      | fp32    |int32,int64 | norm/no-norm |
| `agg_hg_basis_<GT>_n2n_post`      |  ✅ |  ✅   | 〽️      | fp32    |int32,int64 | norm/no-norm |
| `agg_simple_<GT>_n2n`             |  ✅ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_simple_<GT>_e2n`             |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_simple_<GT>_e2n_n2n`         |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_concat_<GT>_n2n`             |  ✅ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_concat_<GT>_e2n`             |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_concat_<GT>_e2n_n2n`         |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_weighted_<GT>_e2n_n2n`         |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_concat_weighted_<GT>_n2n`      |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `agg_dmpnn_<GT>_e2e`.             |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |
| `pool_<GT>_n2s`                   |  ❌ |  ✅   | 〽️      | fp32    |int32,int64 | min,max,sum,mean |

✅  : yes (implemented and exposed in C++ API and wrapped in nanobind bindings)

〽️  : partially (implemented and exposed in C++ API but not available as nanobind binding)

✖️   : partially (implemented but not exposed in C++ API and not available as nanobind binding)

❌  : no  (not implemented, not exposed, not wrapped)

*: not always for both MFG and Graph or Batched

# Developers
## Cloning
`git clone git@github.com:rapidsai/cugraph-ops.git`

## Building

1. Make sure that `nvcc` is available on `PATH`.
2. Activate the build environment: `conda activate <option>`
3. For running python code, you should either install the packages into your
   environment, or only build locally and add both `pylibcugraphops` and
   `pylibcugraphops_internal` folders to your `PYTHONPATH`, as well as the
   `build` and `build/internal` folders to your `LD_LIBRARY_PATH`.

### Everything
`./build.sh python --internal`

### Only C++ library
`./build.sh cpp`

### Only C++ unit-tests
`./build.sh tests`

### Only public pylibcugraphops wrapper
`./build.sh python`

## Testing
1. Running C++ unit-tests: `./build/[[internal/]]cugraph-ops[[-internal]]_sg_tests`
2. Running python unit-tests: `./scripts/run-py-tests.sh`
3. Running pytorch unit-tests: `./scripts/run-pytorch-tests.sh`
4. Doxygen documentation: `cd cpp; doxygen Doxyfile`
5. Sphinx pylibcugraphops docs: `cd docs; make clean html`
   (see also `README.md` in that folder)

## Developing python code
Due to the bindings being open-source, but (some) proof of concepts being
closed-source, there are two python packages, which need to interact to
a certain degree: `pylibcugraphops` and `pylibcugraphops_internal`.

Basically, `pylibcugraphops_internal` depends on `pylibcugraphops` (public),
but not the other way around.

However, we only create the *extension module* once, since nanobind contains
global singletons per extension module which means that it's easier to have
a single module.  
These extension modules always have the `_ext` suffix, and they are placed
either in `pylibcugraphops/pylibcugraphops/binding` or
`pylibcugraphops_internal/pylibcugraphops_internal_ext/binding`.  
Also note that the *internal* extension module will contain all sub-modules
and functions/classes from the *external* extension module:
the naming of sub-modules must not overlap.

For the external bindings, we expose all extension attributes/functions directly
in the `pylibcugraphops` package, whereas for the internal binding, the
extension bindings are exposed in the `pylibcugraphops_internal_ext` package.  
This is because for the internal bindings, we want to make it more explicit
what is a binding function and what is part of the pure python package.  
For external users (of `pylibcugraphops`), this will be completely transparent
and we simply add everything to the common `pylibcugraphops` python package:
note that sub-modules of the extension module require sub-packages since
otherwise, it would not be possible for someone to write
`from pylibcugraphops.submodule import foo`: cython creates this same structure,
but automatically.

In both cases (internal/external), for development, it's easiest to set your
`PYTHONPATH` to include both the `pylibcugraphops` and
`pylibcugraphops_internal` folders, then build locally (without install).  
Some test scripts will conditionally add the necessary folders to `PYTHONPATH`
if the required extensions cannot be imported. For these scripts, it should
not matter how your `PYTHONPATH` is set, but setting it during development
allows running all tests individually, as well as giving you better control
over where the latest packages and extension modules should be found.  
In this case, you should also add the `build` and `build/internal` folders to
your `LD_LIBRARY_PATH`, so that python extensions can find the locally built
C++ libraries.

## Clang-format and clang-tidy
Before merging an MR, you are expected to run `pre-commit run --all-files` and
`scripts/run-clang-tidy.py` and fix all the errors.

Please see the options for both scripts using `--help`: in particular, for
`python scripts/run-clang-tidy.py`, it's often very fast to check new changes by
running `python scripts/run-clang-tidy.py -git_modified_only -check_once`.  
Note that this may not catch all possible warnings, and our CI (once re-enabled)
checks without the `-check_once` option, to be sure everything gets caught.  
Also note that currently, we report all compiler warnings as errors, this may
change in the future in case it is too difficult to maintain.

Fixing clang-format issues is easy: simply run
`pre-commit run clang-format --all-files`.

Fixing clang-tidy issues is much more complicated, however we try to have
a relaxed set of rules such that it should be easy to adapt you C++/CUDA code.

The following rules describe the general guidelines, we follow approximately
the Google guidelines: https://google.github.io/styleguide/cppguide.html

1. Fundamental types
    1. Do not use `long long` or similar, prefer `int64_t`, `uint32_t`, `size_t`
    2. For fundamental typed constants, always use `static constexpr`.
2. Usage of "modern" C++ constructs (`auto`, trailing return type, etc.)
    1. `auto` is enforced for all variables with types longer than 8 characters.
        For shorter types, especially fundamental types, it is encouraged
        if the type is evident from the declaration (`auto x = int32_t{0}`),
        but not otherwise.
    2. Trailing return type is discouraged as it only adds characters to code
       without truly improving readability.
    3. Type aliases should be declared with `using` rather than `typedef`
    4. Use qualified `auto` (`const auto&`): this makes code more explicit
3. Casting
    1. C-style casts will always give a warning: state your intentions more
       explicitly, either using `<type>{...}` or `reinterpret_cast`.
       For simple value conversions, we encourage use of brace initialization:
       `int64_t{0}`.
    2. `reinterpret_cast` is OK: it's up to the programmer to know what to do.
    3. `static_cast` is discouraged with fundamental integral/floating point
       types, instead the shorter `<type>{...}` should be used. This will error
       if you cast with information loss (to a lower precision type), so use
       `static_cast` only in those cases where needed. This makes code shorter
       and easier to read.
4. Structs/classes
    1. By default, members should either be `const` or default-initialized.
       For default-initialization, we encourage initializer list `{...}` since
       it does not allow narrowing conversions.
    2. If special destructor is used, define special functions
       (`= default;` if nothing special is necessary):
       applies at least for copy constructor (`A(const A&)`) and
       copy assignment operator (`A& operator=(const A&)`).
    3. Be mindful of the ABI ! Unfortunately, we cannot include the clang-tidy
       check `altera-struct-pack-align` because it simply has too many false
       positives, but whenever you add a new struct, especially one that goes
       in the public API, try to be careful about how the members are ordered
       for better alignment within the struct, and packing.  
       In case you're unsure, you can simply run `clang-tidy` with only that
       specific check, and see what it tells you (even though we are not
       recommending to follow its advice in general, it can still be helpful
       to understand how a struct should be packed).  
       Using `__attribute__((packed))` is not recommended since it means that
       we cannot take references to members, but `__attribute__((aligned(X)))`
       should be used in most structs to ensure best performance.  
       In general, the largest alignment used in code should always be 16,
       please comment the code if you think you need a larger alignment.  
       Concerning order of members, the code currently follows the following
       convention: value-members that are always larger than 8 bytes, pointers,
       value-members that are <= 8 bytes (depending on template parameter),
       value-members that are always < 8 bytes in decreasing size.
5. Macros
    1. Try to avoid macros as much as possible, since they aren't parsed the
       same way as regular C++ code. Many macros can be replaced with functions
       using variadic templates and parameter packs.
6. Naming variables
    1. Please follow clang-tidy rules, it is perfectly reasonable to change
       those rules if you strongly believe it makes sense, though.
    2. `constexpr` and template variables should always be `UPPER_CASE` to keep
       in line with many CUDA variables following this rule, also distinguishing
       them clearly from other variables in code.  
       Global constants (static or non-static) are also `UPPER_CASE`, but try
       to use `constexpr` whenever possible.  
       Any other "local" constants like function-local static or class-local
       constants are `kCamelCase` just like enum members.
    3. Enum members are `kCamelCase`: this was used by the code-base before,
       and distinguishes them from other variables.
    4. template typenames (including template template parameters,
       which we consider as typenames for the purpose of naming)
       are `CamelCaseT`.
    5. type aliases are `using lower_case_t = ...;`.
7. Include order/style
    1. We approximately follow LLVM guidelines here.
    2. Includes should be grouped (separate groups by a single empty line).
    3. Within a group, includes are simply sorted alphabetically (this is
       already enforced by `clang-format`).
    4. The groups are sorted as follows:
        1. local includes (all `#include "..."`): do not use this include style
           for includes available through `-I` or `-isystem` compiler options
        2. private API includes (`#include <utils/device.cuh>`)
        3. public API includes (`#include <cugraph-ops/graph/format.hpp>`): always
           prefix these with `cugraph-ops/`
        4. other projects (`<catch2/catch.hpp>` / `<cub/cub.cuh>` /
           `<cuda_runtime.h>`): each separate project gets its separate group
        5. system headers (`<algorithm>` / `<cstdint>`)
    5. These rules aren't ideal, but better than no rule at all.
       Please provide an updated clang-tidy / clang-format rule if you don't
       like this style.
8. Misc
    1. Avoid magic numbers if possible and try to use `static constexpr` instead.
    2. Literals should be suffixed with upper-case letters (`0xffU`, `2.F`) to
       distinguish from the lower-case hex values.
