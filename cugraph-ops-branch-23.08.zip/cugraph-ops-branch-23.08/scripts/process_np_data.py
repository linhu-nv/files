#!/usr/bin/env python
#
# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from __future__ import print_function
import argparse
import os.path as osp
import numpy as np


def process_np_dataset(name: str, root_dir: str = ""):
    if root_dir:
        raw_dir = osp.join(root_dir, name, 'raw')
    else:
        raw_dir = osp.join(name, "raw")

    data_path = osp.join(raw_dir, 'data.npz')
    label_path = osp.join(raw_dir, 'node-label.npz')
    assert osp.isfile(data_path)
    assert osp.isfile(label_path)

    labels = np.load(label_path)['node_label'].squeeze()
    data_dict = np.load(data_path)
    edge_index = data_dict['edge_index']
    node_feat = data_dict['node_feat']

    num_nodes_list = data_dict['num_nodes_list']
    num_edges_list = data_dict['num_edges_list']
    num_nodes = num_nodes_list[0]
    num_edges = num_edges_list[0]

    # relabel nodes such that labeled nodes come first
    unlabeled = np.isnan(labels)
    labeled = np.invert(unlabeled)
    num_labeled = labeled.sum()

    indices_old = np.concatenate((np.nonzero(labeled)[0], np.nonzero(unlabeled)[0]))
    indices_new = np.zeros_like(indices_old)
    for n in range(num_nodes):
        idx_old = indices_old[n]
        indices_new[idx_old] = n

    node_feat = node_feat[indices_old]
    labels = labels[indices_old]

    edge_index[0, :] = indices_new[edge_index[0, :]]
    edge_index[1, :] = indices_new[edge_index[1, :]]

    # create offsets and indices from edge_index
    start, end = edge_index
    indices = np.argsort(start, kind='mergesort')
    start = start[indices]
    end = end[indices]

    offsets = np.zeros(num_nodes + 1, dtype=np.int64)
    indices = np.zeros(num_edges, dtype=np.int64)

    idx_count = 0
    for e in range(num_edges):
        s = start[e]
        t = end[e]

        indices[idx_count] = t
        offsets[s] += 1

    prev = offsets[0]
    offsets[0] = 0
    for i in range(1, num_nodes + 1):
        curr = offsets[i]
        offsets[i] = prev + offsets[i - 1]
        prev = curr

    # dump files
    def dump_vec(data, f):
        f.write(np.array([len(data)], dtype=np.uint64).tobytes())
        f.write(data.tobytes())

    node_feat = node_feat.flatten().astype(np.float32)
    labels_labeled = labels[:num_labeled].astype(np.int32)

    with open(osp.join(raw_dir, 'graph.bin.gz'), 'wb') as f:
        dump_vec(indices, f)
        dump_vec(offsets, f)
        dump_vec(node_feat, f)
        dump_vec(labels_labeled, f)


def main():
    argparser = argparse.ArgumentParser("Processes OGBN data s.t. they can be "
                                        "read conveniently by OGBN reader")
    argparser.add_argument("-root", default="", type=str, help="root data directory")
    argparser.add_argument("datasets", nargs='+', help='datasets to process')
    args = argparser.parse_args()
    for d_name in args.datasets:
        print("Processing dataset {}. This may take a while".format(d_name))
        process_np_dataset(d_name, args.root)


if __name__ == "__main__":
    main()
