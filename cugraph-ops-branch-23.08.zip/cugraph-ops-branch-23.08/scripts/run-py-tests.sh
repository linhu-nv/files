#!/bin/bash
# Copyright (c) 2019-2023, NVIDIA CORPORATION.
#
# A simple wrapper script to run the python unit-tests

set -e
# NOTE: ensure all dir changes are relative to the location of this
# script, and that this script resides in a child folder (scripts) of the repo dir!
REPODIR=$(cd $(dirname $(dirname "$0")); pwd)
TESTS=${1:-pylibcugraphops_internal/tests/pylibcugraphops_internal/}

# check if we have the extension module installed and set PYTHONPATH otherwise
set +e
python -c "from pylibcugraphops_internal_ext.binding import pylibcugraphops_ext"\
    > /dev/null 2> /dev/null
test_ext=$?
set -e
if [ $test_ext -ne 0 ]; then
    export PYTHONPATH="$REPODIR/pylibcugraphops_internal"
fi
export PYTHONDONTWRITEBYTECODE=1
exec pytest "$TESTS"
