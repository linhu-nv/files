#!/bin/bash
# Copyright (c) 2019-2022, NVIDIA CORPORATION.

script_path=$(readlink -f "$0")
script_dir=$(dirname "$script_path")
python3 $script_dir/download_datasets.py --root ${1:-gnn-datasets}
