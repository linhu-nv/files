#!/usr/bin/env python
#
# Copyright (c) 2022-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import argparse
import os
import re
import subprocess

from download_datasets import download_datasets, DOWNLOAD_URLS


DATASET_DIR = "gnn-datasets"
COMMON_ARGS = (
    "-nlayers 2 -batch_size 1024 -nbatches 0 -dropout 0.5 "
    "-epochs 2 -eval_every 40 -dataset_dir ./" + DATASET_DIR
)

EXAMPLE_TESTS = {
    "gat.py": (
        "-dataset products -dims 256,47 -sample_sizes 25,10 -use_bias",
        0.75,
        0.85,
    ),
    "graphsage.py": ("-dataset products -dims 256,47 -sample_sizes 25,10", 0.8, 0.75),
    "rgcn.py": ("-dataset mag -dims 128,349 -sample_sizes 30,30 -n_bases 2", 0.3, 3.0),
}

LOSS_REGEX = re.compile(r"loss:\s*([0-9.+-]+)")
ACC_REGEX = re.compile(r"accuracy:\s*([0-9.+-]+)")


def main():
    argparser = argparse.ArgumentParser("Calls end-to-end examples")
    argparser.add_argument(
        "--use_s3",
        action="store_true",
        help="If specified, fetch data from RAPIDS S3 storage",
    )
    args = argparser.parse_args()
    # get source directory
    src_dir = os.path.dirname(os.path.realpath(os.path.dirname(__file__)))
    # first download data and pre-process if it hasn't been done before
    # we only need to products and mag datasets for our tests
    datasets = ["ogbn-products", "ogbn-mag"]
    if args.use_s3:
        for i, d in enumerate(datasets):
            if d + "-s3" in DOWNLOAD_URLS:
                datasets[i] = d + "-s3"

    download_datasets(os.path.join(src_dir, DATASET_DIR), datasets)

    # make sure we update the PYTHONPATH accordingly, if necessary
    env = os.environ.copy()
    try:
        import pylibcugraphops
        import pylibcugraphops_internal
        import pylibcugraphops_internal_ext

        # if we're able to import all extension modules directly, it was
        # installed in the system and should be available for the sub-process
    except ImportError:
        # if we can't import the extension module, try adding to PYTHONPATH
        python_path = env.get("PYTHONPATH", "")
        if python_path:
            python_path += ":"
        python_path += ":" + os.path.join(src_dir, "pylibcugraphops_internal")
        env["PYTHONPATH"] = python_path

    for example in EXAMPLE_TESTS:
        print("Testing {} ...".format(example))
        script = os.path.join(src_dir, "pylibcugraphops_internal", "examples", example)
        args, min_acc, max_loss = EXAMPLE_TESTS[example]
        cmd_list = ["python", script, args, COMMON_ARGS]
        cmd = " ".join(cmd_list)
        try:
            ret = subprocess.check_output(
                cmd, shell=True, cwd=src_dir, env=env, stderr=subprocess.STDOUT
            )
        except subprocess.CalledProcessError as e:
            print(str(e.output, "utf-8"))
            raise e
        output = ret.decode("utf-8").strip()
        last_line = output.splitlines()[-1]
        # parse last line to see if accuracy is as expected
        for name, limit, regex in [
            ("loss", max_loss, LOSS_REGEX),
            ("accuracy", min_acc, ACC_REGEX),
        ]:
            is_min = name == "accuracy"
            m = regex.search(last_line)
        print(output)
        assert m, "Cannot parse output of {}: no {} found".format(cmd, name)
        try:
            val = float(m.group(1))
            min_max = "min" if is_min else "max"
            e = "Expected {} {} {}, got {}".format(min_max, name, limit, val)
            assert (is_min and val > limit) or (not is_min and val < limit), e
        except ValueError:
            assert False, "Parsed {} {} is not a float".format(name, m.group(1))


if __name__ == "__main__":
    main()
