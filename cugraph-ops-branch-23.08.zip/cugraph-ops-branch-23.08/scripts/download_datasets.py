#!/usr/bin/env python
#
# Copyright (c) 2021-2023, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import argparse
import os
import os.path as osp
import time
import zipfile
import argparse
import subprocess

from pathlib import PurePath
from process_hg_data import process_hg_dataset
from process_np_data import process_np_dataset

from typing import List, Callable


DOWNLOAD_URLS = {
    'ogbn-arxiv': {
        'URL': 'http://snap.stanford.edu/ogb/data/nodeproppred/arxiv.zip'
    },
    'ogbn-products': {
        'URL': 'http://snap.stanford.edu/ogb/data/nodeproppred/products.zip'
    },
    'ogbn-mag': {
        'URL': 'http://snap.stanford.edu/ogb/data/nodeproppred/mag.zip',
        'POST_CMD': process_hg_dataset
    },
    'ogbn-papers100M': {
        'URL': 'http://snap.stanford.edu/ogb/data/nodeproppred/'
            'papers100M-bin.zip',
        'POST_CMD': process_np_dataset
    },
    'ogbg-hiv': {
        'URL': 'http://snap.stanford.edu/ogb/data/graphproppred/'
            'csv_mol_download/hiv.zip'
    },
    'ogbg-pcba': {
        'URL': 'http://snap.stanford.edu/ogb/data/graphproppred/'
            'csv_mol_download/pcba.zip'
    },
    'ogbn-products-s3': {
        'URL': 'https://data.rapids.ai/gnn-datasets/'
            'ogbn/products/raw/graph.bin.gz',
    },
    'ogbn-mag-s3': {
        'URL': 'https://data.rapids.ai/gnn-datasets/'
            'ogbn/mag/raw/graph.bin.gz',
    },
}

DEFAULT_DATASETS = [
    'ogbn-arxiv', 'ogbn-products', 'ogbn-mag', 'ogbg-hiv', 'ogbg-pcba'
]
S3_DATASETS = {'ogbn-products-s3', 'ogbn-mag-s3'}
ALL_DATASETS = list(DOWNLOAD_URLS.keys())


def maybe_download(url: str, root: str, filename: str = None) -> None:
    root = osp.expanduser(root)
    if not filename:
        filename = osp.basename(url)

    file_path = osp.join(root, filename)
    os.makedirs(root, exist_ok=True)

    if not osp.exists(file_path):
        print(f'downloading {url} to {file_path}')

        try:
            cmd = f"wget --no-verbose {url} -O {file_path}"
            subprocess.check_output([cmd], shell=subprocess.PIPE)
        except Exception as e:
            if osp.exists(file_path):
                os.remove(file_path)
            raise e

    return file_path


def maybe_extract_and_process(
    path: str, post_cmd: Callable[[str, str], None]
) -> None:
    base_dir, zip_file_name = osp.split(path)
    dataset, _ = osp.splitext(zip_file_name)

    if not osp.exists(osp.join(base_dir, dataset)):
        with zipfile.ZipFile(path, 'r') as zip_file:
            # ensure consistent naming of extracted files
            zipinfos = zip_file.infolist()
            for zipinfo in zipinfos:
                if not zipinfo.filename.startswith(dataset):
                    parts = PurePath(zipinfo.filename).parts
                    new_filename = osp.join(dataset, *parts[1:])
                    if zipinfo.filename.endswith(os.sep):
                        new_filename += os.sep
                    zipinfo.filename = new_filename

                zip_file.extract(zipinfo, path=base_dir)

        if post_cmd is not None:
            post_cmd(dataset, base_dir)


def download_and_extract(root: str, dataset: str) -> None:
    url = DOWNLOAD_URLS[dataset]['URL']
    if dataset in S3_DATASETS:
        items = dataset.split('-')
        data_dir = osp.join(root, items[0], items[1], 'raw')
        maybe_download(url, data_dir)
        return
    sub_dir = dataset.split('-')[0]
    dataset_short = dataset[len(f'{sub_dir}-'):]
    data_dir = osp.join(root, sub_dir)
    file_path = maybe_download(url, data_dir, filename=f'{dataset_short}.zip')
    post_cmd = DOWNLOAD_URLS[dataset].get('POST_CMD')
    maybe_extract_and_process(file_path, post_cmd)


def download_datasets(root: str, datasets: List[str]) -> None:
    for dataset in datasets:
        assert dataset in ALL_DATASETS,\
            f'{dataset} not in available datasets {ALL_DATASETS}'
        download_and_extract(root, dataset)
        time.sleep(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        "Download, extract, and process OGB datasets"
    )
    parser.add_argument(
        'datasets', nargs="+", choices=ALL_DATASETS,
        help="The possible datasets to download"
    )
    parser.add_argument(
        '--root', default="gnn-datasets", type=str,
        help='dataset root (./gnn-datasets by default)'
    )

    args = parser.parse_args()

    if len(args.datasets) == 0:
        datasets = DEFAULT_DATASETS
    else:
        datasets = args.datasets

    download_datasets(args.root, datasets)
