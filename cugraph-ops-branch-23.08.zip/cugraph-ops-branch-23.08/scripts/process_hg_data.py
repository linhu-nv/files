#!/usr/bin/env python
#
# Copyright (c) 2021-2022, NVIDIA CORPORATION.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from __future__ import print_function
import argparse
import csv
import itertools
import gzip
import numpy as np
import os


def str2bool(s):
    return s.lower() in ['true', 't', 'yes', 'y', '1']


def generate_features(ntypes, n_ntypes, n_feat, has_no_feat_fun):
    r_gen = np.random.default_rng(seed=1769439313)
    out = dict()
    # first filter those that already have features
    for nt in sorted(filter(has_no_feat_fun, ntypes)):
        ft = r_gen.normal(size=(n_ntypes[nt], n_feat))
        out[nt] = ft.astype(np.float64, copy=False)
    return out


def process_hg_dataset(name, root: str = "", dry_run: bool = False):
    # check if the desired files are already present
    out_names = ['edge.csv.gz', 'node-feat.csv.gz', 'node-label.csv.gz',
                 'node-types.csv.gz']
    if not dry_run and all(
            os.path.isfile(os.path.join(root, name, "raw", n)) for n in out_names):
        return

    f_nt_label = os.path.join(root, name, "raw", "nodetype-has-label.csv.gz")
    with gzip.open(f_nt_label, mode="rt", newline='') as f:
        csv_nt_label = list(csv.reader(f, delimiter=','))
        assert len(csv_nt_label) == 2,\
            "Expected 2 lines in has-label but got {}".format(
                len(csv_nt_label))
        assert len(set(csv_nt_label[0])) == len(csv_nt_label[0]),\
            "Duplicate entries in node types {}".format(csv_nt_label[0])
        assert any(str2bool(x) for x in csv_nt_label[1]),\
            "Expected any node type to have labels, but got {}".format(
                csv_nt_label)
        ntypes_ = csv_nt_label[0]
        node_labels = dict()
        # we need to make sure that:
        # 1. labeled types come before all other types
        # 2. non-labeled types are sorted alphabetically
        ntypes = (
            sorted(nt for i, nt in enumerate(ntypes_)
                   if str2bool(csv_nt_label[1][i])) +
            sorted(nt for i, nt in enumerate(ntypes_)
                   if not str2bool(csv_nt_label[1][i])))
        for i, nt in enumerate(ntypes_):
            if not str2bool(csv_nt_label[1][i]):
                continue
            node_labels[nt] = []
            f_label = os.path.join(
                root, name, "raw", "node-label", nt, "node-label.csv.gz")
            with gzip.open(f_label, mode="rt", newline='') as f:
                for label_row in csv.reader(f, delimiter=','):
                    node_labels[nt].append(int(label_row[0]))

    f_n_nodes = os.path.join(root, name, "raw", "num-node-dict.csv.gz")
    with gzip.open(f_n_nodes, mode="rt", newline='') as f:
        csv_n_nodes = list(csv.reader(f, delimiter=','))
        assert len(csv_n_nodes) == 2,\
            "Expected 2 lines in num-node-dict but got {}".format(
                len(csv_n_nodes))
        assert len(set(csv_n_nodes[0])) == len(csv_n_nodes[0]),\
            "Duplicate entries in node types {}".format(csv_n_nodes[0])
        assert set(csv_n_nodes[0]) == set(ntypes),\
            "Unexpected node types: {} vs. {}".format(csv_n_nodes[0], ntypes)

        n_ntypes = dict()
        for nt in ntypes:
            # ensure that #nodes is ordered as ntypes
            n_ntypes[nt] = int(csv_n_nodes[1][csv_n_nodes[0].index(nt)])

        node_offsets, global_offset = dict(), 0
        for nt in ntypes:
            node_offsets[nt] = global_offset
            global_offset += n_ntypes[nt]

    f_nt_feat = os.path.join(root, name, "raw", "nodetype-has-feat.csv.gz")
    with gzip.open(f_nt_feat, mode="rt", newline='') as f:
        csv_nt_feat = list(csv.reader(f, delimiter=','))
        assert len(csv_nt_feat) == 2,\
            "Expected 2 lines in has-feat but got {}".format(
                len(csv_nt_feat))
        assert len(set(csv_nt_feat[0])) == len(csv_nt_feat[0]),\
            "Duplicate entries in node types {}".format(csv_nt_feat[0])
        assert set(csv_nt_feat[0]) == set(ntypes),\
            "Unexpected node types: {} vs. {}".format(csv_nt_feat[0], ntypes)

        def has_no_feat_f(nt):
            return not str2bool(csv_nt_feat[1][csv_nt_feat[0].index(nt)])

        # first find the number of features
        assert not all(has_no_feat_f(nt) for nt in csv_nt_feat[0]),\
            "Expected any node type to have features, but got {}".format(
                csv_nt_feat)
        for nt in csv_nt_feat[0]:
            if has_no_feat_f(nt):
                continue
            f_feat = os.path.join(root, name, "raw", "node-feat", nt,
                                  "node-feat.csv.gz")
            with gzip.open(f_feat, mode="rt", newline='') as f:
                n_feat = len(next(csv.reader(f, delimiter=',')))
            break

        n_nodes = sum(n_ntypes[nt] for nt in n_ntypes)
        node_feats = np.empty((n_nodes, n_feat), dtype=np.float64)

        # we need to make sure that we assign features to all nodes
        # in the correct order
        gen_feats = generate_features(ntypes, n_ntypes, n_feat, has_no_feat_f)
        for nt in ntypes:
            if has_no_feat_f(nt):
                off = node_offsets[nt]
                node_feats[off:off + n_ntypes[nt], :] = gen_feats[nt]
            else:
                # copy over the features
                f_feat = os.path.join(root, name, "raw", "node-feat", nt,
                                      "node-feat.csv.gz")
                with gzip.open(f_feat, mode="rt", newline='') as f:
                    for j, feat_row in enumerate(csv.reader(f, delimiter=',')):
                        a = np.fromiter(map(float, feat_row), dtype=np.float64)
                        node_feats[node_offsets[nt] + j, :] = a

    f_relations = os.path.join(root, name, "raw", "triplet-type-list.csv.gz")
    with gzip.open(f_relations, mode="rt", newline='') as f:
        csv_rels = csv.reader(f, delimiter=',')
        rels = ['___'.join(row) for row in csv_rels]
    edges = []
    nodes_per_type = {n: set() for n in ntypes}
    for rel in rels:
        n1, _, n2 = rel.split('___')
        f_rel_edge = os.path.join(root, name, "raw", "relations", rel, "edge.csv.gz")
        f_rel_type = os.path.join(
            root, name, "raw", "relations", rel, "edge_reltype.csv.gz")
        with gzip.open(f_rel_edge, mode="rt", newline='') as f1:
            csv_rel = list(csv.reader(f1, delimiter=','))
            with gzip.open(f_rel_type, mode="rt", newline='') as f2:
                csv_rel_type = list(csv.reader(f2, delimiter=','))
                assert len(csv_rel) == len(csv_rel_type),\
                    "Expected equal edge line nums {} != {}".format(
                        len(csv_rel), len(csv_rel_type))
                for row_edge, row_type in zip(csv_rel, csv_rel_type):
                    n_ids = [int(row_edge[0]) + node_offsets[n1],
                             int(row_edge[1]) + node_offsets[n2]]
                    nodes_per_type[n1].add(n_ids[0])
                    nodes_per_type[n2].add(n_ids[1])
                    edges.append(n_ids + [int(row_type[0])])

    # the sets of node IDs must be exclusive
    for n1, n2 in itertools.combinations(ntypes, 2):
        assert nodes_per_type[n1].isdisjoint(nodes_per_type[n2]),\
            "Expected disjoints node sets {}/{}, got intersection: {}".format(
                n1, n2, nodes_per_type[n1].intersection(nodes_per_type[n2]))
    # the node IDs (based on edges) must be according to the offsets
    for nt in ntypes:
        min_id = node_offsets[nt]
        max_id = node_offsets[nt] + n_ntypes[nt] - 1
        assert all(min_id <= ni <= max_id for ni in nodes_per_type[nt]),\
            "Expected IDs in range [{}, {}] for node type {}".format(
                min_id, max_id, nt)

    if dry_run:
        print('Using following nodes types: {}'.format(ntypes))
        print('Following node types have labels: {}'.format(list(node_labels)))
        print('Using following #nodes, offsets: {} | {}'.format(
            [n_ntypes[nt] for nt in ntypes],
            [node_offsets[nt] for nt in ntypes]))
        return

    # write out the required data. first convert to numpy arrays
    a_edges = np.asarray(edges, dtype=int)
    np.savetxt(os.path.join(root, name, "raw", "edge.csv.gz"), a_edges,
               fmt='%d', delimiter=',')

    a_labels = np.empty((sum(n_ntypes[nt] for nt in node_labels)), dtype=int)
    for nt in node_labels:
        off = node_offsets[nt]
        a_labels[off:off + n_ntypes[nt]] = np.asarray(node_labels[nt])
    np.savetxt(os.path.join(root, name, "raw", "node-label.csv.gz"), a_labels,
               fmt='%d', delimiter=',')

    np.savetxt(os.path.join(root, name, "raw", "node-feat.csv.gz"), node_feats,
               fmt='%.6f', delimiter=',')

    node_types = np.repeat(np.arange(len(ntypes), dtype=int),
                           [n_ntypes[nt] for nt in ntypes])
    np.savetxt(os.path.join(root, name, "raw", "node-types.csv.gz"), node_types,
               fmt='%d', delimiter=',')


def main():
    argparser = argparse.ArgumentParser("Processes OGBN data s.t. they can be "
                                        "read conveniently by OGBN reader")
    argparser.add_argument("--dry-run", action='store_true')
    argparser.add_argument("-root", default="", type=str, help="root data directory")
    argparser.add_argument("datasets", nargs='+', help='datasets to process')
    args = argparser.parse_args()
    for d_name in args.datasets:
        print("Processing dataset {}. This may take a while".format(d_name))
        process_hg_dataset(d_name, args.root, args.dry_run)


if __name__ == "__main__":
    main()
