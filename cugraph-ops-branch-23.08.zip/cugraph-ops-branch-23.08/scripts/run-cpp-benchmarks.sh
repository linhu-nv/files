#!/bin/bash
# Copyright (c) 2023, NVIDIA CORPORATION.
#
# A script to run nvbench benchmarks.

set -e
REPODIR=$(dirname "$(dirname "$(readlink -f "$0")")")
OUTPUTDIR="${REPODIR}/cpp/benchmarks/data"
mkdir -p ${OUTPUTDIR}

pushd "${REPODIR}/build/benchmarks"
find . -name "*_bench" -type f -printf "%f\n" | while read bench; do
    echo Running ${bench}...
    ./${bench} --quiet --run-once --devices 0 \
               --csv ${OUTPUTDIR}/${bench}.csv
    python ${REPODIR}/scripts/convert_to_us.py ${OUTPUTDIR}/${bench}.csv
done
popd
