#!/bin/bash

# Copyright (c) 2019-2023, NVIDIA CORPORATION.

# cugraphops build script

# This script is used to build the component(s) in this repo from
# source, and can be called with various options to customize the
# build as needed (see the help output for details)

# Abort script on first error
set -e

NUMARGS=$#
ARGS=$*

# NOTE: ensure all dir changes are relative to the location of this
# script, and that this script resides in the repo dir!
REPODIR=$(cd $(dirname $0); pwd)

VALIDARGS="clean cpp tests benchmarks python -v -g --install --allgpuarch "
VALIDARGS+="--no-lineinfo --kernelinfo --pre-cxx11 --internal --torch "
VALIDARGS+="-h --help"
HELP="$0 [<target> ...] [<flag> ...]
 where <target> is:
   clean           - remove all existing build artifacts and configuration (start over).
   cpp             - build the libcugraphops C++ library.
   tests           - build the C++ (OPG) tests (including C++ library).
   benchmarks      - build benchmarks (including C++ library).
   python          - build the python extensions (including C++ library).
 and <flag> is:
   -v            - verbose build mode
   -g            - build for debug
   --install     - install into default system install prefix
   --allgpuarch  - build for all supported GPU architectures
   --no-lineinfo - disable CUDA line-info (always disabled for debug builds)
   --kernelinfo  - build all cuda kernels with verbose ptxas output
   --pre-cxx11   - build using pre-CXX11-ABI
   --internal    - build using internal symbols
   --torch       - build the internal pytorch extension
   --no-leak-w   - build python extension without leak warnings
   -h | --h[elp] - print this text
"
function hasArg {
    (( ${NUMARGS} != 0 )) && (echo " ${ARGS} " | grep -q " $1 ")
}

if hasArg -h || hasArg --h || hasArg --help; then
    echo "${HELP}"
    exit 0
fi

# Check for valid usage
if (( ${NUMARGS} != 0 )); then
    for a in ${ARGS}; do
    if ! (echo " ${VALIDARGS} " | grep -q " ${a} "); then
        echo "Invalid option: ${a}"
        exit 1
    fi
    done
fi

if hasArg clean; then
    ./build_component.sh clean
fi

BUILD_CPP=OFF
if hasArg cpp || hasArg tests || hasArg benchmarks || hasArg python || hasArg --internal; then
    BUILD_CPP=ON
fi
BUILD_PYTHON=OFF
if hasArg python || hasArg --torch || hasArg --no-leak-w; then
    BUILD_PYTHON=ON
fi

COMPONENT_FLAGS=""
if hasArg -v; then
    COMPONENT_FLAGS+=" -v"
fi
if hasArg -g; then
    COMPONENT_FLAGS+=" -g"
fi
if ! hasArg --install; then
    COMPONENT_FLAGS+=" -n"
fi
if ! hasArg --allgpuarch; then
    COMPONENT_FLAGS+=" --native"
fi

EXTRA_CMAKE_ARGS="--cmake-args=\""
if ! hasArg --no-lineinfo && ! hasArg -g; then
    EXTRA_CMAKE_ARGS+=" -DCUDA_ENABLE_LINEINFO=ON"
else
    EXTRA_CMAKE_ARGS+=" -DCUDA_ENABLE_LINEINFO=OFF"
fi
if hasArg --kernelinfo; then
    EXTRA_CMAKE_ARGS+=" -DCUDA_ENABLE_KERNELINFO=ON"
else
    EXTRA_CMAKE_ARGS+=" -DCUDA_ENABLE_KERNELINFO=OFF"
fi
if hasArg --pre-cxx11; then
    EXTRA_CMAKE_ARGS+=" -DCMAKE_CXX11_ABI=OFF"
else
    EXTRA_CMAKE_ARGS+=" -DCMAKE_CXX11_ABI=ON"
fi
if hasArg --torch; then
    EXTRA_CMAKE_ARGS+=" -DBUILD_CUGRAPH_OPS_INTERNAL_TORCH=ON"
else
    EXTRA_CMAKE_ARGS+=" -DBUILD_CUGRAPH_OPS_INTERNAL_TORCH=OFF"
fi
if hasArg --no-leak-w; then
    EXTRA_CMAKE_ARGS+=" -DNB_LEAK_WARNINGS=OFF"
else
    EXTRA_CMAKE_ARGS+=" -DNB_LEAK_WARNINGS=ON"
fi
EXTRA_CMAKE_ARGS+="\""

if [[ "$BUILD_CPP" == "ON" ]]; then
    COMPONENTS="libcugraphops"
    if hasArg --internal; then
        COMPONENTS+=" libcugraphops-internal"
    fi
    if hasArg tests; then
        COMPONENTS+=" tests"
        if hasArg --internal; then
            COMPONENTS+=" tests-internal"
        fi
    fi
    if hasArg benchmarks; then
        COMPONENTS+=" benchmarks"
    fi
    ./build_component.sh ${COMPONENTS} ${COMPONENT_FLAGS} ${EXTRA_CMAKE_ARGS}
fi

if [[ "$BUILD_PYTHON" == "ON" ]]; then
    COMPONENTS="pylibcugraphops"
    if hasArg --internal; then
        COMPONENTS+=" pylibcugraphops-internal"
    fi
    ./build_component.sh ${COMPONENTS} ${COMPONENT_FLAGS} ${EXTRA_CMAKE_ARGS}
fi
