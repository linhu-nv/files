#!/bin/bash
# Copyright (c) 2022-2023, NVIDIA CORPORATION.
# Only add the license notice to libcugraphops and not our examples / tests
if [[ "$PKG_NAME" == "libcugraphops" ]]; then
  cat ./cugraphops.txt >> $PREFIX/.messages.txt
fi
