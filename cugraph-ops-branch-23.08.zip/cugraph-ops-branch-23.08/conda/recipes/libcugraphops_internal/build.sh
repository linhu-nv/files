#!/usr/bin/env bash
# Copyright (c) 2021-2023, NVIDIA CORPORATION.

./build_component.sh -n libcugraphops-internal tests-internal -v
