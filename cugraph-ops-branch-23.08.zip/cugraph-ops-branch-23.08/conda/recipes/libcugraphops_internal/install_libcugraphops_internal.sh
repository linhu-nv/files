#!/bin/bash
# Copyright (c) 2022-2023, NVIDIA CORPORATION.

cmake --install build/internal
