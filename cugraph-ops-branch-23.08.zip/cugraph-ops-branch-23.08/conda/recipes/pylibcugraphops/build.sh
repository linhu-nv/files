#!/usr/bin/env bash
# Copyright (c) 2022-2023, NVIDIA CORPORATION.

# remove leak warnings in nightly/release builds
CMAKE_EXTRA_ARGS=""
if [[ "${RAPIDS_BUILD_TYPE}" == "branch" || "${RAPIDS_BUILD_TYPE}" == "nightly" ]]; then
    CMAKE_EXTRA_ARGS="--cmake-args=\"-DNB_LEAK_WARNINGS=OFF\""
fi
./build_component.sh pylibcugraphops -v ${CMAKE_EXTRA_ARGS}
