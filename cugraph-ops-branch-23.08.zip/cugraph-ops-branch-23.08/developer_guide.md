# Developer Guide

The focus of cugraph-ops is providing specialized graph aggregation operators.
Those can be rather diverse of nature. To avoid a too dynamic growth of the code base,
we implemented several guidelines which should make it easier to maintain and develop code.

## Structure
Usually, functionality related to the core operators is to be placed in
the `gnn::operators` namespace, under the `<cugraph-ops/operators>` include path.  
This includes basic aggregation operators (e.g. for GraphSAGE),
specialized operators (e.g. for RGCN), and operators performing pooling-like
operations (e.g. readout operations aggregating from a graph-to-scalar level).  
Then, we distinguish between essential graph characteristics those operators
are intended for. Currently, we provide operators for message flow graphs, full graphs, and bipartite graphs in the API.
The implementation of these APIs follows more the nature of operators. APIs shall all be defined under `src/cpp/operators/api/<operator type>`
and the actual kernels are in `src/cpp/operators/impl/<operator type>`. Operators of one family ideally then should be grouped in one directory.
When exposing templated operator kernels in our APIs, we use a single file for
all instantiations, which allows more caching and thus better overal compile times.  
Overall, this leads to the following exemplary paths
- header-file: `cpp/include/cugraph-ops/operators/agg_simple_bipartite.hpp`
- implementation: `cpp/src/operators/api/aggregation/agg_simple_bipartite_bwd.cu`
- kernel (templated): `cpp/src/operators/impl/aggregation/agg_simple/agg_simple_bwd.cuh`

## Naming Convention
The name of exposed operators and corresponding files should be self-explanatory
and provide an easy overview of all relevant charateristics.  
Therefore, we adopt the following naming convention for operators.

`<operator family>_<graph type>_<"direction">_(<operator specification>_)<[fwd|bwd|bwd_rev|...]`

Examples
- `agg_simple_fg_bwd`
- `pool_fg_n2s_bwd`
- `agg_hg_basis_mfg_n2n_post_bwd`

"full_graph" currently is only represented as CSC for now and thus not explicitly
specified. If we introduce multiple datatypes for indices in full graphs, too,
we might discuss how to adopt this convention.


### Explanation of Individual Parts

- `<operator family>` denotes the underlying operator, we currently have
    - `agg_simple`: basic aggregator performing a mean/sum/min/max reduction of the specified set
    - `agg_concat`: like `agg_simple` but additionally concatenates the self representation of each set member
    - `agg_dmpnn`: implmements the DMPNN edge-to-edge aggregation
    - `pool`: sum/mean/min/max pooling, e.g. node-to-scalar readout
    - `hg_basis`: heterogenous aggregation using different edge types and potentially using a basis decomposition
    - `mha_gat`: multi-headed attention aggregation, in this case GAT as specific variant
- `<graph type>` which graph type the operator is intended for
    - `fg`: full graph or sequence of graphs
    - `mfg`: message flow graph
- `<"direction">`: for easier overview of which operators we already have,
  multiple directions are combined and separated through underscores (e.g. `e2n_n2n`)
    - `n2n`: node-to-node (basic aggregation)
    - `e2n`: edge-to-node
    - `e2e`: edge-to-edge
    - `n2s`: node-to-scalar
- `<operator specification>`: some operators define different kinds of "flavors",
  e.g. the "pre" and the "post" variant of the `hg_basis` operators
- `<operator graph direction>`: fwd for "forward", bwd for "backward", etc.


## Function Signatures

The following pattern should be used (both in our C++ API and in our bindings)
```
func(output_vector_arg_0, ..., output_vector_arg_n,
     input_vector_arg_0, ..., input_vector_arg_n,
     graph_structure_arg_0, ..., graph_structure_arg_n,
     *args,
     **kwargs,
     cuda_stream=None)
```
- `*args`: arguments necessary for `func` but neither a buffer nor a graph structure
- `**kwargs`: optional arguments or arguments with default values
- `cuda_stream` should be the last argument in a binding if applicable and defaulted to the null stream

Example for RGCN (hg_basis_pre):
```python
def agg_hg_basis_mfg_n2n_pre_bwd(output_gradient,
                                 input_gradient,
                                 input_embedding,
                                 message_flow_graph_hg_csr_int32 mfg,
                                 output_weight_gradient=None,
                                 weights_combination=None,
                                 norm_by_degree=False,
                                 cuda_stream=None):
```
