# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
from typing import Optional
from torch.autograd.function import once_differentiable

from ..utils import maybe_empty_like, maybe_detach
from ..graph import BipartiteCSC, UnsupportedGraphError
from pylibcugraphops import ActivationOp, mha_params
from pylibcugraphops.operators import (
    activation_params,
    mha_gat_bipartite_n2n_fwd as bipartite_n2n_fwd,
    mha_gat_bipartite_n2n_bwd as bipartite_n2n_bwd,
    mha_gat_bipartite_n2n_efeat_fwd as bipartite_n2n_efeat_fwd,
    mha_gat_bipartite_n2n_efeat_bwd as bipartite_n2n_efeat_bwd,
)

_activation_ops = [x for x in dir(ActivationOp) if not x.startswith("__")]


def mha_gat_n2n_bipartite(
    src_feat: torch.Tensor,
    dst_feat: torch.Tensor,
    attn_weights: torch.Tensor,
    graph: BipartiteCSC,
    num_heads: int = 1,
    activation: str = "LeakyReLU",
    negative_slope: float = 0.2,
    concat_heads: bool = True,
    edge_feat: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """
    PyTorch autograd function for a multi-head attention layer (GAT-like)
    without using cudnn (mha_gat) in a node-to-node reduction (n2n).

    Parameters
    ----------
    src_feat : torch.Tensor
        The source node features. Each row consists of concatenated features from
        different heads after the linear transformation.
        Shape: ``(n_in_nodes, dim_in)``, where ``dim_in = dim_head * num_heads``,
        with ``dim_head`` being the feature dimension per head.

    dst_feat : torch.Tensor
        The destination node features. Each row consists of concatenated features from
        different heads after the linear transformation.
        Shape: ``(n_out_nodes, dim_in)``, where ``dim_in = dim_head * num_heads``,
        with ``dim_head`` being the feature dimension per head.

    attn_weights : torch.Tensor
        The attention weights with ``dim_w = 2 * dim_in + dim_in_edges`` where
        ``dim_in_edges`` is assumed to be 0 if ``edge_feat`` is None.
        Shape: ``(dim_w,)``.

    graph : BipartiteCSC
        The graph used in for the operation.

    num_heads : int, default=1
        Number of heads in multi-head attention.

    activation : str, default="LeakyReLU"
        The activation function used in the attention mechanism. Choose from
        ``"ELU"``, ``"LeakyReLU"``, ``"Linear"``, ``"ReLU"``, ``"Scalar"``,
        ``"Sigmoid"`` and ``"Tanh"``.

    negative_slope : float, default=0.2
        LeakyReLU angle of negative slope. Only effective when ``activation`` is
        ``"LeakyReLU"``.

    concat_heads : bool, default=True
        Aggregated embeddings from each head are concatenated if ``True`` or
        averaged if ``False``.

    edge_feat : Optional[torch.Tensor], default=None
        Optional input edge features. Each row consists of concatenated features from
        different heads after the linear transformation.
        Shape: ``(n_edges, dim_in_edge)`` where
        ``dim_in_edge = dim_head_edge * num_heads``, with ``dim_head_edge``
        being the feature dimension per head.

    Returns
    -------
    output : torch.Tensor
        The aggregation output.
        Shape for ``concat_heads=True``: ``(n_out_nodes, dim_in)``;
        Shape for ``concat_heads=False``: ``(n_out_nodes, dim_head)``.
    """
    if activation not in _activation_ops:
        raise ValueError(
            f"Supported activation functions: {_activation_ops}, "
            f"but got '{activation}'."
        )
    act_params = activation_params(negative_slope, getattr(ActivationOp, activation))
    params = mha_params(act_params, num_heads, concat_heads)

    if isinstance(graph, BipartiteCSC):
        return _mha_gat_bipartite_n2n_autograd.apply(
            src_feat, dst_feat, edge_feat, attn_weights, graph, params
        )

    else:
        raise UnsupportedGraphError(BipartiteCSC, graph)


class _mha_gat_bipartite_n2n_autograd(torch.autograd.Function):
    """
    Custom autograd function for a multi-head attention layer (GAT-like)
    without using cudnn (mha_gat) operating on bipartite graphs in a node-to-node
    reduction (n2n).
    """

    @staticmethod
    def forward(ctx, src_feat, dst_feat, edge_feat, attn_weights, graph, params):
        fwd_graph = graph._fwd_graph
        dim = src_feat.size(-1)
        src_feat = src_feat.detach().contiguous()
        dst_feat = dst_feat.detach().contiguous()
        attn_weights = attn_weights.detach().contiguous()
        edge_feat = maybe_detach(edge_feat)
        dim_out = dim if params.concat_heads else (dim // params.num_heads)
        output = torch.empty(
            fwd_graph.n_out_nodes, dim_out, dtype=src_feat.dtype, device=src_feat.device
        )
        sm_scores = torch.empty(
            2,
            params.num_heads,
            fwd_graph.n_indices,
            dtype=src_feat.dtype,
            device=src_feat.device,
        )

        stream = torch.cuda.current_stream().cuda_stream

        if edge_feat is None:
            bipartite_n2n_fwd(
                output,
                sm_scores,
                src_feat,
                dst_feat,
                attn_weights,
                fwd_graph,
                params,
                stream_id=stream,
            )

        else:
            bipartite_n2n_efeat_fwd(
                output,
                sm_scores,
                src_feat,
                dst_feat,
                edge_feat,
                attn_weights,
                fwd_graph,
                params,
                stream_id=stream,
            )

        ctx.bwd_graph = graph._bwd_graph
        ctx.params = params
        ctx.save_for_backward(src_feat, dst_feat, edge_feat, attn_weights, sm_scores)

        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        src_feat, dst_feat, edge_feat, attn_weights, sm_scores = ctx.saved_tensors
        grad_output = grad_output.detach().contiguous()
        (
            needs_grad_src_feat,
            needs_grad_dst_feat,
            needs_grad_efeat,
            needs_grad_weights,
            _,
            _,
        ) = ctx.needs_input_grad
        if not (
            needs_grad_src_feat
            or needs_grad_dst_feat
            or needs_grad_weights
            or needs_grad_efeat
        ):
            return None, None, None, None, None, None

        grad_src_feat = maybe_empty_like(src_feat, needs_grad_src_feat)
        grad_dst_feat = maybe_empty_like(dst_feat, needs_grad_dst_feat)
        grad_edge_feat = maybe_empty_like(edge_feat, needs_grad_efeat)
        grad_attn_weights = maybe_empty_like(attn_weights, needs_grad_weights)
        grad_sm_scores = torch.empty_like(sm_scores)

        stream = torch.cuda.current_stream().cuda_stream

        if edge_feat is None:
            bipartite_n2n_bwd(
                grad_src_feat,
                grad_dst_feat,
                grad_attn_weights,
                grad_sm_scores,
                grad_output,
                src_feat,
                dst_feat,
                attn_weights,
                sm_scores,
                ctx.bwd_graph,
                ctx.params,
                stream_id=stream,
            )

        else:
            bipartite_n2n_efeat_bwd(
                grad_src_feat,
                grad_dst_feat,
                grad_edge_feat,
                grad_attn_weights,
                grad_sm_scores,
                grad_output,
                src_feat,
                dst_feat,
                edge_feat,
                attn_weights,
                sm_scores,
                ctx.bwd_graph,
                ctx.params,
                stream_id=stream,
            )

        return (
            grad_src_feat,
            grad_dst_feat,
            grad_edge_feat,
            grad_attn_weights,
            None,
            None,
        )
