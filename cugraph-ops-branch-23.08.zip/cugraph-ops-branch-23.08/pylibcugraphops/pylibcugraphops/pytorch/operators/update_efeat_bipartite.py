# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

import torch
from torch.autograd.function import once_differentiable

from ..utils import maybe_size, maybe_empty, maybe_detach, get_tensor_meta_data
from ..graph import BipartiteCSC, UnsupportedGraphError
from pylibcugraphops.operators import (
    update_efeat_bipartite_e2e_sum_fwd,
    update_efeat_bipartite_e2e_sum_bwd,
    update_efeat_bipartite_e2e_concat_fwd,
    update_efeat_bipartite_e2e_concat_bwd,
)


def update_efeat_bipartite_e2e(
    edge_feat: Optional[torch.Tensor],
    src_node_feat: Optional[torch.Tensor],
    dst_node_feat: Optional[torch.Tensor],
    graph: BipartiteCSC,
    mode: str = "concat",
) -> torch.Tensor:
    """
    PyTorch autograd function for creating new edge features (update_efeat)
    based on either concatenating or summing edge features and the features of
    the corresponding source and destination node of each edge in an edge-to-edge
    fashion (e2e).

    Parameters
    ----------
    edge_feat : torch.Tensor | None
        The input edge features - ignored if passed as ``None``.
        Shape: ``(n_edges, dim_edge)``.

    src_node_feat : torch.Tensor | None
        The input source node features - ignored if passed as ``None``.
        Shape: ``(n_in_nodes, dim_src)``.

    dst_node_feat : torch.Tensor | None
        The input destination node features - ignored if passed as ``None``.
        Shape: ``(n_out_nodes, dim_dst)``.

    graph : BipartiteCSC
        The graph used for the operation.

    mode : str, default="concat"
        Mode of update, either ``"concat"`` or ``"sum"``.

    Returns
    -------
    output : torch.Tensor
        The output after either concatenation or summation.
        Shape for ``mode=concat``: ``(n_edges, dim_edge + dim_src + dim_dst)``.
        Shape for ``mode=sum``: ``(n_edges, dim_edge)``.
    """
    modes = ["sum", "concat"]

    if mode.lower() not in modes:
        raise ValueError(f"Supported operations: {modes}, " f"but got '{mode}'.")

    if isinstance(graph, BipartiteCSC):
        return _bipartite_e2e_autograd.apply(
            edge_feat, src_node_feat, dst_node_feat, (graph, mode)
        )
    else:
        raise UnsupportedGraphError(BipartiteCSC, graph)


class _bipartite_e2e_autograd(torch.autograd.Function):
    """
    Custom autograd function for an update of the edge features based on
    concatenating or summing edge features, and source node and destination
    node features
    """

    @staticmethod
    def forward(ctx, edge_feat, src_node_feat, dst_node_feat, args):
        graph, mode = args
        # store bwd_graph for backward pass (can be identical to fwd_graph)
        # use graph as name for forward pass after storing graph._bwd_graph
        ctx.bwd_graph = graph._bwd_graph
        fwd_graph = graph._fwd_graph
        ctx.mode = mode

        edge_feat = maybe_detach(edge_feat)
        src_node_feat = maybe_detach(src_node_feat)
        dst_node_feat = maybe_detach(dst_node_feat)

        dim_edge = maybe_size(edge_feat)
        dim_src = maybe_size(src_node_feat)
        dim_dst = maybe_size(dst_node_feat)

        ctx.dim_edge = dim_edge
        ctx.dim_src = dim_src
        ctx.dim_dst = dim_dst

        if dim_edge > 0:
            dtype = edge_feat.dtype
            device = edge_feat.device

        elif dim_src > 0:
            dtype = src_node_feat.dtype
            device = src_node_feat.device

        elif dim_dst > 0:
            dtype = dst_node_feat.dtype
            device = dst_node_feat.device
        else:
            raise ValueError("forward called with all the inputs being None")

        stream = torch.cuda.current_stream().cuda_stream

        if mode.lower() == "concat":
            output = torch.empty(
                fwd_graph.n_indices,
                dim_edge + dim_dst + dim_src,
                dtype=dtype,
                device=device,
            )
            update_efeat_bipartite_e2e_concat_fwd(
                output,
                edge_feat,
                src_node_feat,
                dst_node_feat,
                fwd_graph,
                stream,
            )

        else:
            # all should be equal, so find the one which is not 0
            # check for equality is done in binding
            dim_edge = max(dim_edge, dim_src, dim_dst)
            output = torch.empty(
                fwd_graph.n_indices, dim_edge, dtype=dtype, device=device
            )
            update_efeat_bipartite_e2e_sum_fwd(
                output,
                edge_feat,
                src_node_feat,
                dst_node_feat,
                fwd_graph,
                stream,
            )

        ctx.src_node_feat_meta_data = get_tensor_meta_data(src_node_feat)
        ctx.dst_node_feat_meta_data = get_tensor_meta_data(dst_node_feat)
        ctx.edge_feat_meta_data = get_tensor_meta_data(edge_feat)

        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        grad_output = grad_output.detach().contiguous()
        needs_grad_edge, needs_grad_src, needs_grad_dst, _ = ctx.needs_input_grad

        grad_edge_feat = maybe_empty(
            **ctx.edge_feat_meta_data,
            create_tensor=needs_grad_edge,
        )
        grad_src_feat = maybe_empty(
            **ctx.src_node_feat_meta_data,
            create_tensor=needs_grad_src,
        )
        grad_dst_feat = maybe_empty(
            **ctx.dst_node_feat_meta_data,
            create_tensor=needs_grad_dst,
        )

        stream = torch.cuda.current_stream().cuda_stream
        grad_output = grad_output.detach().contiguous()

        if ctx.mode.lower() == "concat":
            update_efeat_bipartite_e2e_concat_bwd(
                grad_edge_feat,
                grad_src_feat,
                grad_dst_feat,
                grad_output,
                ctx.bwd_graph,
                ctx.dim_edge,
                ctx.dim_src,
                ctx.dim_dst,
                stream,
            )

        else:
            update_efeat_bipartite_e2e_sum_bwd(
                grad_edge_feat,
                grad_src_feat,
                grad_dst_feat,
                grad_output,
                ctx.bwd_graph,
                stream,
            )

        return grad_edge_feat, grad_src_feat, grad_dst_feat, None
