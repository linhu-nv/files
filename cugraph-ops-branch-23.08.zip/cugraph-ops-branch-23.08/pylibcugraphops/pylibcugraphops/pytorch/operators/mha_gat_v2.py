# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
from typing import Optional
from torch.autograd.function import once_differentiable

from ..utils import maybe_empty_like, maybe_detach
from ..graph import StaticCSC, UnsupportedGraphError
from pylibcugraphops import ActivationOp, mha_params
from pylibcugraphops.operators import (
    activation_params,
    mha_gat_v2_fg_n2n_fwd as fg_n2n_fwd,
    mha_gat_v2_fg_n2n_bwd as fg_n2n_bwd,
    mha_gat_v2_fg_n2n_efeat_fwd as fg_n2n_efeat_fwd,
    mha_gat_v2_fg_n2n_efeat_bwd as fg_n2n_efeat_bwd,
)

_activation_ops = [x for x in dir(ActivationOp) if not x.startswith("__")]


def mha_gat_v2_n2n(
    feat: torch.Tensor,
    attn_weights: torch.Tensor,
    graph: StaticCSC,
    num_heads: int = 1,
    activation: str = "LeakyReLU",
    negative_slope: float = 0.2,
    concat_heads: bool = True,
    edge_feat: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """
    PyTorch autograd function for a multi-head attention layer (GAT-like)
    without using cudnn (mha_gat_v2) with an activation prior to the dot
    product but none afterwards in a node-to-node reduction (n2n).

    Parameters
    ----------
    feat : torch.Tensor
        The input node features. Each row consists of concatenated features from
        different heads after the linear transformation.
        Shape: ``(n_in_nodes, dim_in)``, where ``dim_in = dim_head * num_heads``,
        with ``dim_head`` being the feature dimension per head.

    attn_weights : torch.Tensor
        The attention weight.
        Shape: ``(dim_in,)``.

    graph : StaticCSC
        The graph used in for the operation.

    num_heads : int, default=1
        Number of heads in multi-head attention.

    activation : str, default="LeakyReLU"
        The activation function used in the attention mechanism. Choose from
        ``"ELU"``, ``"LeakyReLU"``, ``"Linear"``, ``"ReLU"``, ``"Scalar"``,
        ``"Sigmoid"`` and ``"Tanh"``.

    negative_slope : float, default=0.2
        LeakyReLU angle of negative slope. Only effective when ``activation`` is
        ``"LeakyReLU"``.

    concat_heads : bool, default=True
        Aggregated embeddings from each head are concatenated if ``True`` or
        averaged if ``False``.

    edge_feat : Optional[torch.Tensor], default=None
        Optional input edge features. Each row consists of concatenated features
        from different heads after the linear transformation.
        Shape: ``(n_edges, dim_in)``.

    Returns
    -------
    output : torch.Tensor
        The aggregation output.
        Shape for ``concat_heads=True``: ``(n_out_nodes, dim_in)``;
        Shape for ``concat_heads=False``: ``(n_out_nodes, dim_head)``.
    """
    if activation not in _activation_ops:
        raise ValueError(
            f"Supported activation functions: {_activation_ops}, "
            f"but got '{activation}'."
        )
    act_params = activation_params(negative_slope, getattr(ActivationOp, activation))
    params = mha_params(act_params, num_heads, concat_heads)

    if isinstance(graph, StaticCSC):
        return _mha_gat_v2_fg_n2n_autograd.apply(
            feat, edge_feat, attn_weights, graph, params
        )
    else:
        raise UnsupportedGraphError(StaticCSC, graph)


class _mha_gat_v2_fg_n2n_autograd(torch.autograd.Function):
    """
    Custom autograd function for a multi-head attention layer (GAT-like)
    without using cudnn (mha_gat_v2) with an activation prior to the dot
    product but none afterwards operating on full graphs (fg) in a node-to-node
    reduction (n2n).
    """

    @staticmethod
    def forward(ctx, feat, edge_feat, attn_weights, graph, params):
        fwd_graph = graph._fwd_graph
        dim = feat.size(-1)
        feat = feat.detach().contiguous()
        attn_weights = attn_weights.detach().contiguous()
        edge_feat = maybe_detach(edge_feat)
        dim_out = dim if params.concat_heads else (dim // params.num_heads)
        output = torch.empty(
            fwd_graph.n_nodes, dim_out, dtype=feat.dtype, device=feat.device
        )
        sm_scores = torch.empty(
            2,
            params.num_heads,
            fwd_graph.n_indices,
            dtype=feat.dtype,
            device=feat.device,
        )
        act_scores = torch.empty(
            fwd_graph.n_indices, dim, dtype=feat.dtype, device=feat.device
        )

        stream = torch.cuda.current_stream().cuda_stream

        if edge_feat is None:
            fg_n2n_fwd(
                output,
                sm_scores,
                act_scores,
                feat,
                attn_weights,
                fwd_graph,
                params,
                stream_id=stream,
            )
        else:
            fg_n2n_efeat_fwd(
                output,
                sm_scores,
                act_scores,
                feat,
                edge_feat,
                attn_weights,
                fwd_graph,
                params,
                stream_id=stream,
            )

        ctx.bwd_graph = graph._bwd_graph
        ctx.params = params
        ctx.save_for_backward(feat, edge_feat, attn_weights, sm_scores, act_scores)

        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        feat, edge_feat, attn_weights, sm_scores, act_scores = ctx.saved_tensors
        (
            needs_grad_feat,
            needs_grad_efeat,
            needs_grad_weights,
            _,
            _,
        ) = ctx.needs_input_grad
        if not (needs_grad_feat or needs_grad_weights or needs_grad_efeat):
            return None, None, None, None, None

        grad_feat = maybe_empty_like(feat, needs_grad_feat)
        # needs_grad_efeat is also False if edge_feat is None
        # thus capturing all possible cases
        grad_edge_feat = maybe_empty_like(edge_feat, needs_grad_efeat)
        grad_attn_weights = maybe_empty_like(attn_weights, needs_grad_weights)
        # grad_sm_scores is basically a workspace, thus always required
        grad_sm_scores = torch.empty_like(sm_scores)

        stream = torch.cuda.current_stream().cuda_stream

        if edge_feat is None:
            fg_n2n_bwd(
                grad_feat,
                grad_attn_weights,
                grad_sm_scores,
                grad_output,
                feat,
                attn_weights,
                sm_scores,
                act_scores,
                ctx.bwd_graph,
                ctx.params,
                stream_id=stream,
            )

        else:
            fg_n2n_efeat_bwd(
                grad_feat,
                grad_edge_feat,
                grad_attn_weights,
                grad_sm_scores,
                grad_output,
                feat,
                attn_weights,
                sm_scores,
                act_scores,
                ctx.bwd_graph,
                ctx.params,
                stream_id=stream,
            )

        return grad_feat, grad_edge_feat, grad_attn_weights, None, None
