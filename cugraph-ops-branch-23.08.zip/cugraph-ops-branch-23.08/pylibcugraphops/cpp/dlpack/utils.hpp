/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

#include "dlpack.h"

#include <nanobind/nanobind.h>

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <Python.h>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>

namespace nb = nanobind;

#if __GNUC__ >= 4
#define CUGRAPH_OPS_DLL_LOCAL __attribute__((visibility("hidden")))
#else
#define CUGRAPH_OPS_DLL_LOCAL
#endif

#if defined(__GNUC__) || defined(__ICL) || defined(__clang__)
#define CUGRAPH_OPS_LIKELY(expr)   (__builtin_expect(static_cast<bool>(expr), 1))
#define CUGRAPH_OPS_UNLIKELY(expr) (__builtin_expect(static_cast<bool>(expr), 0))
#else
#define CUGRAPH_OPS_LIKELY(expr)   static_cast<bool>(expr)
#define CUGRAPH_OPS_UNLIKELY(expr) static_cast<bool>(expr)
#endif

namespace cugraph::ops::binding {

// some useful data type constants
static constexpr DLDataType DL_BF16{
  .code = static_cast<uint8_t>(kDLBfloat), .bits = 16, .lanes = 1};
static constexpr DLDataType DL_FP16{.code = static_cast<uint8_t>(kDLFloat), .bits = 16, .lanes = 1};
static constexpr DLDataType DL_FP32{.code = static_cast<uint8_t>(kDLFloat), .bits = 32, .lanes = 1};
static constexpr DLDataType DL_FP64{.code = static_cast<uint8_t>(kDLFloat), .bits = 64, .lanes = 1};
static constexpr DLDataType DL_S8{.code = static_cast<uint8_t>(kDLInt), .bits = 8, .lanes = 1};
static constexpr DLDataType DL_S16{.code = static_cast<uint8_t>(kDLInt), .bits = 16, .lanes = 1};
static constexpr DLDataType DL_S32{.code = static_cast<uint8_t>(kDLInt), .bits = 32, .lanes = 1};
static constexpr DLDataType DL_S64{.code = static_cast<uint8_t>(kDLInt), .bits = 64, .lanes = 1};
// this must be used with the "restricted" data type variant !
static constexpr DLDataType DL_BF16_FP16{
  .code  = uint8_t{1} << static_cast<int>(kDLFloat) | uint8_t{1} << static_cast<int>(kDLBfloat),
  .bits  = uint8_t{16},
  .lanes = uint16_t{1} << 0};
// this must be used with the "restricted" data type variant !
static constexpr DLDataType DL_FP32_64{.code  = uint8_t{1} << static_cast<int>(kDLFloat),
                                       .bits  = uint8_t{32} | uint8_t{64},
                                       .lanes = uint16_t{1} << 0};
// this must be used with the "restricted" data type variant !
static constexpr DLDataType DL_BF16_FP16_32_64{
  .code  = uint8_t{1} << static_cast<int>(kDLFloat) | uint8_t{1} << static_cast<uint8_t>(kDLBfloat),
  .bits  = uint8_t{16} | uint8_t{32} | uint8_t{64},
  .lanes = uint16_t{1} << 0};
// this must be used with the "restricted" data type variant !
static constexpr DLDataType DL_S32_64{.code  = uint8_t{1} << static_cast<int>(kDLInt),
                                      .bits  = uint8_t{32} | uint8_t{64},
                                      .lanes = uint16_t{1} << 0};
// this must be used with the "restricted" data type variant !
static constexpr auto MAX_U8  = uint8_t{255};
static constexpr auto MAX_U16 = uint16_t{65535};
static constexpr DLDataType DL_ANY_DTYPE{.code = MAX_U8, .bits = MAX_U8, .lanes = MAX_U16};

template <typename DataT>
constexpr DLDataType get_dl_data_type();
template <>
constexpr DLDataType get_dl_data_type<__half>()
{
  return DL_FP16;
};
template <>
constexpr DLDataType get_dl_data_type<__nv_bfloat16>()
{
  return DL_BF16;
};
template <>
constexpr DLDataType get_dl_data_type<float>()
{
  return DL_FP32;
};
template <>
constexpr DLDataType get_dl_data_type<double>()
{
  return DL_FP64;
};
template <>
constexpr DLDataType get_dl_data_type<int32_t>()
{
  return DL_S32;
};
template <>
constexpr DLDataType get_dl_data_type<int64_t>()
{
  return DL_S64;
};

// this struct is necessary for handling the life-time of the managed tensor
// but we also add a few convenience functions to be able to work more easily
// with the wrapped tensor
///@note: all convenience functions are unchecked except `maybe_ptr` !
// You have to check with dl_wrapper::has_ptr() yourself before using them.
// However, if you got an instance from the `assert_*` function(s) with
// `allow_none=false` then you can assume that the pointer is valid.
class CUGRAPH_OPS_DLL_LOCAL dl_wrapper {
 public:
  dl_wrapper() noexcept = default;
  explicit dl_wrapper(DLManagedTensor* _dlm_tensor) noexcept
    : dlm_tensor_(_dlm_tensor), dl_tensor_(&(dlm_tensor_->dl_tensor))
  {
  }
  ~dl_wrapper() noexcept
  {
    if (dlm_tensor_ != nullptr && dlm_tensor_->deleter != nullptr)
      dlm_tensor_->deleter(dlm_tensor_);
  }
  // delete copy constructor and assignment
  dl_wrapper(const dl_wrapper&)            = delete;
  dl_wrapper& operator=(const dl_wrapper&) = delete;
  // allow move constructor and assignment
  dl_wrapper(dl_wrapper&& other) noexcept
    : dlm_tensor_(other.dlm_tensor_), dl_tensor_(other.dl_tensor_)
  {
    other.dlm_tensor_ = nullptr;
    other.dl_tensor_  = nullptr;
  }
  dl_wrapper& operator=(dl_wrapper&& other) noexcept
  {
    // check for assignment to self
    if (this != &other) {
      // free our resource as in destructor
      if (dlm_tensor_ != nullptr && dlm_tensor_->deleter != nullptr)
        dlm_tensor_->deleter(dlm_tensor_);

      // get resource from other as in move constructor
      dlm_tensor_ = other.dlm_tensor_;
      dl_tensor_  = other.dl_tensor_;

      // reset other's resource as in move constructor
      other.dlm_tensor_ = nullptr;
      other.dl_tensor_  = nullptr;
    }
    return *this;
  }

  [[nodiscard]] inline int32_t ndim() const { return dl_tensor_->ndim; }
  [[nodiscard]] inline const int64_t* shape() const { return dl_tensor_->shape; }
  [[nodiscard]] inline int64_t dim(int32_t idx) const { return dl_tensor_->shape[idx]; }
  [[nodiscard]] inline const DLDataType& type() const { return dl_tensor_->dtype; }
  [[nodiscard]] inline DLDeviceType device_type() const { return dl_tensor_->device.device_type; }
  // allow access to the entire DLTensor, if necessary
  inline const DLTensor* operator()() const { return dl_tensor_; }

  [[nodiscard]] inline bool has_ptr() const { return dlm_tensor_ != nullptr; }

  template <typename DataT>
  [[nodiscard]] inline DataT* get_ptr() const
  {
    // using dlm_tensor_ since we need a non-const pointer
    char* d = reinterpret_cast<char*>(dlm_tensor_->dl_tensor.data);
    return reinterpret_cast<DataT*>(d + dl_tensor_->byte_offset);
  }

  template <typename DataT>
  [[nodiscard]] inline DataT* maybe_ptr() const
  {
    if (CUGRAPH_OPS_LIKELY(!has_ptr())) return nullptr;
    return get_ptr<DataT>();
  }

 private:
  DLManagedTensor* dlm_tensor_{nullptr};
  const DLTensor* dl_tensor_{nullptr};
};

inline void deleter(DLManagedTensor* tensor)
{
  if (CUGRAPH_OPS_UNLIKELY(tensor->manager_ctx == nullptr)) return;
  delete[] tensor->dl_tensor.shape;
  Py_DECREF(reinterpret_cast<PyObject*>(tensor->manager_ctx));
  tensor->manager_ctx = nullptr;
  delete tensor;
}

// small helper to allow transferring ownership of the shape/strides array
// but also clear it correctly in case an exception occurs
template <typename DataT>
class CUGRAPH_OPS_DLL_LOCAL array_ptr {
 public:
  explicit array_ptr(size_t size) { ptr_ = new DataT[size]; }
  ~array_ptr()
  {
    if (CUGRAPH_OPS_UNLIKELY(ptr_ != nullptr)) delete[] ptr_;
  }
  [[nodiscard]] DataT* get() const { return ptr_; }
  [[nodiscard]] DataT* transfer()
  {
    DataT* p = ptr_;
    ptr_     = nullptr;
    return p;
  }
  DataT& operator[](int idx) { return ptr_[idx]; }

 private:
  DataT* ptr_{nullptr};
};

inline DLManagedTensor* get_dltensor_from_cai(nb::object& obj,
                                              const nb::dict& cai,
                                              const std::string& name)
{
  auto shape           = nb::cast<nb::tuple>(cai["shape"]);
  const auto* type_str = nb::cast<const char*>(cai["typestr"]);
  auto ndim            = shape.size();
  auto data            = nb::cast<nb::tuple>(cai["data"]);
  auto ptr_v           = nb::cast<uintptr_t>(data[0]);
  // we cannot avoid the integer-to-pointer cast here
  // NOLINTNEXTLINE(performance-no-int-to-ptr)
  auto* ptr = reinterpret_cast<void*>(ptr_v);
  // we're using the Python C API directly here because it allows to easily
  // check whether we have the item in the dictionary at all and whether it
  // is None without additional overheads. Note that this does not set
  // any exception and that we get a borrowed reference, so we can ignore
  // anything related to exception/reference handling
  auto* strides_obj = PyDict_GetItemString(cai.ptr(), "strides");
  nb::tuple strides;
  bool has_strides = false;
  if (CUGRAPH_OPS_UNLIKELY(strides_obj != nullptr && strides_obj != Py_None)) {
    // strides_obj is a borrowed reference so we don't care about reference ownership here
    auto strides_h = nb::handle(strides_obj);
    strides        = nb::cast<nb::tuple>(strides_h);
    has_strides    = true;
  }

  // we first check the shapes/strides since the casts here still involve
  // checking the "format" before we check the "content" below
  size_t factor = has_strides ? 2 : 1;
  array_ptr<int64_t> shape_strides(ndim * sizeof(int64_t) * factor);
  auto ndimi = static_cast<int32_t>(ndim);

  // these copies must be done with a for-loop anyway : no way to access all
  // python tuple elements at once
  for (int n = 0; n < ndimi; ++n) {
    shape_strides[n] = nb::cast<int64_t>(shape[n]);
    if (CUGRAPH_OPS_UNLIKELY(has_strides)) shape_strides[n + ndimi] = nb::cast<int64_t>(strides[n]);
  }
  // at this point, we have casted everything, so the "format" is correct
  // now we check the "content" only

  // make sure that ndim can be represented as int32_t
  if (CUGRAPH_OPS_UNLIKELY(ndim > static_cast<size_t>(std::numeric_limits<int32_t>::max()))) {
    const auto& e = name + " __cuda_array_interface__: #dimensions too large";
    throw nb::value_error(e.c_str());
  }

  // we use this call to get both device type and ID from the pointer
  cudaPointerAttributes attr;
  if (CUGRAPH_OPS_UNLIKELY(cudaPointerGetAttributes(&attr, ptr) != cudaSuccess)) {
    const auto& e = name + " invalid CUDA data pointer";
    throw nb::value_error(e.c_str());
  }

  DLTensor dl_tensor;
  dl_tensor.data = ptr;
  if (CUGRAPH_OPS_LIKELY(attr.type == cudaMemoryTypeHost)) {
    dl_tensor.device.device_type = DLDeviceType::kDLCUDAHost;
  } else if (CUGRAPH_OPS_LIKELY(attr.type == cudaMemoryTypeDevice)) {
    dl_tensor.device.device_type = DLDeviceType::kDLCUDA;
  } else if (CUGRAPH_OPS_LIKELY(attr.type == cudaMemoryTypeManaged)) {
    dl_tensor.device.device_type = DLDeviceType::kDLCUDAManaged;
  } else {
    const auto& e = name + " invalid CUDA pointer type";
    throw nb::value_error(e.c_str());
  }
  dl_tensor.device.device_id = attr.device;

  dl_tensor.ndim = ndimi;

  auto type_len = std::strlen(type_str);
  // TODO(@stadlmax): IIUC, CAI does not support BF16
  if (CUGRAPH_OPS_UNLIKELY(type_len < 3 || type_len > 4)) {
    const auto& e = name + " Type '" + type_str + "' unsupported";
    throw nb::value_error(e.c_str());
  }
  if (type_str[1] == 'u' or type_str[1] == 'b') {
    dl_tensor.dtype.code = static_cast<uint8_t>(kDLUInt);
  } else if (type_str[1] == 'i') {
    dl_tensor.dtype.code = static_cast<uint8_t>(kDLInt);
  } else if (type_str[1] == 'f') {
    dl_tensor.dtype.code = static_cast<uint8_t>(kDLFloat);
  } else if (type_str[1] == 'c') {
    dl_tensor.dtype.code = static_cast<uint8_t>(kDLComplex);
  } else {
    const auto& e = name + " Type '" + type_str + "' unsupported";
    throw nb::value_error(e.c_str());
  }
  dl_tensor.dtype.lanes = uint16_t{1};
  if (CUGRAPH_OPS_UNLIKELY(!isdigit(type_str[2]) || (type_len == 4 && !isdigit(type_str[3])))) {
    const auto& e = name + " Type '" + type_str + "' unsupported";
    throw nb::value_error(e.c_str());
  }

  auto n_bytes = static_cast<uint8_t>(type_str[2] - '0');
  if (type_len == 4) n_bytes = n_bytes * 10 + (type_str[3] - '0');
  if (CUGRAPH_OPS_UNLIKELY(n_bytes > 16)) {
    const auto& e = name + " Type '" + type_str + "' unsupported";
    throw nb::value_error(e.c_str());
  }
  dl_tensor.dtype.bits = n_bytes * uint8_t{8};

  // check strides
  if (CUGRAPH_OPS_UNLIKELY(has_strides && strides.size() != ndim)) {
    const auto& e = name + " __cuda_array_interface__: #strides != #dimensions";
    throw nb::value_error(e.c_str());
  }

  // at this point, we have checked the "content": no more exceptions should happen
  // so we create the managed tensor object and transfer ownership of the shape/strides pointer
  dl_tensor.shape = shape_strides.transfer();
  if (CUGRAPH_OPS_UNLIKELY(has_strides))
    dl_tensor.strides = dl_tensor.shape + ndim;
  else
    dl_tensor.strides = nullptr;
  dl_tensor.byte_offset = 0;

  auto* dlm_tensor        = new DLManagedTensor();
  dlm_tensor->dl_tensor   = dl_tensor;
  dlm_tensor->manager_ctx = reinterpret_cast<void*>(obj.ptr());
  Py_INCREF(obj.ptr());
  dlm_tensor->deleter = deleter;

  return dlm_tensor;
}

// RAII construct which ensures that a capsule is correctly set to used
// and manages the ownership of the reference to the capsule python object
class CUGRAPH_OPS_DLL_LOCAL capsule_wrapper {
 public:
  inline DLManagedTensor* get_dlm_tensor(nb::object& obj)
  {
    auto* o = obj.ptr();
    // in both cases, we will now "own" the reference to the capsule object
    if (CUGRAPH_OPS_UNLIKELY(PyCapsule_CheckExact(o))) {
      capsule_ = o;
      Py_INCREF(capsule_);
    } else {
      capsule_ = PyObject_CallMethod(o, "__dlpack__", nullptr);
    }
    // here the error state may be set, but capsule_ will be NULL in that case,
    // so we end up throwing a python_error as expected

    if (CUGRAPH_OPS_LIKELY(capsule_)) {
      auto* p = reinterpret_cast<DLManagedTensor*>(PyCapsule_GetPointer(capsule_, "dltensor"));
      if (CUGRAPH_OPS_LIKELY(p)) return p;
      // here, the error state is set, which is OK since we throw a python_error
      // release ownership of the capsule object again
      Py_DECREF(capsule_);
    }
    capsule_ = nullptr;
    throw nb::python_error();
  }

  inline void explicit_delete() noexcept
  {
    if (CUGRAPH_OPS_LIKELY(capsule_)) {
      // check whether we have a "legal" capsule: this avoids setting the exception state
      if (CUGRAPH_OPS_LIKELY(PyCapsule_IsValid(capsule_, "dltensor")))
        PyCapsule_SetName(capsule_, "used_dltensor");
      // decrease the reference count to release ownership of the capsule ref
      Py_DECREF(capsule_);
    }
    capsule_ = nullptr;
  }

  ~capsule_wrapper() noexcept { explicit_delete(); }

 private:
  PyObject* capsule_{nullptr};
};

// if `RESTRICTED_DTYPE` is set, we restrict dlpack.h further as such:
// - DLDataType::code must not contain more than 8 options. This is the case at time of writing.
// - DLDataType::bits must be a power of two. Other values not accepted.
// - DLDataType::lanes must be at most 16. Other values not accepted.
// This allows checking for multiple codes, bit values and lanes by specifying
// the possible values as bit positions in `exp_data_type`.
// It also allows for allowing any data type by setting all bits to 1
// At time of writing, kDLBfloat is also directly associated with having 16 bits,
// which makes it possible to check for BFloat16 and FP16, FP32, FP64 at once as there
// is no kDLBfloat type with more than 16 bits.
template <bool RESTRICTED_DTYPE = false>
inline dl_wrapper assert_type_shape_strides(nb::object& obj,
                                            const std::string& name,
                                            const DLDataType& exp_data_type,
                                            int32_t exp_n_dim        = -1,
                                            const int64_t* exp_shape = nullptr,
                                            bool allow_none          = false)
{
  dl_wrapper dl;
  if (allow_none && obj.is_none()) return dl;
  if (obj.is_none()) {
    const auto& e = name + " must not be none but got None value";
    throw nb::value_error(e.c_str());
  }

  capsule_wrapper capsule;

  try {
    // this checks for validity of the capsule and raises otherwise
    dl                      = dl_wrapper(capsule.get_dlm_tensor(obj));
    const auto& device_type = dl.device_type();
    if (CUGRAPH_OPS_UNLIKELY(device_type != kDLCUDA && device_type != kDLCUDAHost &&
                             device_type != kDLCUDAManaged)) {
      const auto& e = name + " must be accessible from CUDA, got DLPack device type " +
                      std::to_string(device_type);
      throw nb::value_error(e.c_str());
    }
  } catch (const nb::python_error& /* e */) {
    try {
      auto cai         = nb::cast<nb::dict>(obj.attr("__cuda_array_interface__"));
      auto* dlm_tensor = get_dltensor_from_cai(obj, cai, name);
      dl               = dl_wrapper(dlm_tensor);
    } catch (const nb::builtin_exception& /* e */) {
      throw;
    } catch (const nb::cast_error& /* e */) {
      const auto& e = name + " __cuda_array_interface__: invalid format";
      throw nb::type_error(e.c_str());
    } catch (const nb::python_error& /* e */) {
      // no __cuda_array_interface__ attribute at all or it threw a Python exception
      const auto& e = name + " supports neither __dlpack__ nor __cuda_array_interface__";
      throw nb::type_error(e.c_str());
    }
  }

  if constexpr (RESTRICTED_DTYPE) {
    if (CUGRAPH_OPS_UNLIKELY(((uint8_t{1} << dl.type().code) & exp_data_type.code) == 0)) {
      const auto& e = name + " expected restricted type code " +
                      std::to_string(exp_data_type.code) + " but got " +
                      std::to_string(dl.type().code);
      throw nb::value_error(e.c_str());
    }
    if (CUGRAPH_OPS_UNLIKELY((dl.type().bits & exp_data_type.bits) == 0)) {
      const auto& e = name + " expected restricted type bits " +
                      std::to_string(exp_data_type.bits) + " but got " +
                      std::to_string(dl.type().bits);
      throw nb::value_error(e.c_str());
    }
    if (CUGRAPH_OPS_UNLIKELY(((uint8_t{1} << (dl.type().lanes - 1)) & exp_data_type.lanes) == 0)) {
      const auto& e = name + " expected restricted type lanes " +
                      std::to_string(exp_data_type.lanes) + " but got " +
                      std::to_string(dl.type().lanes);
      throw nb::value_error(e.c_str());
    }
  } else {
    if (CUGRAPH_OPS_UNLIKELY(dl.type().code != exp_data_type.code)) {
      const auto& e = name + " expected type code " + std::to_string(exp_data_type.code) +
                      " but got " + std::to_string(dl.type().code);
      throw nb::value_error(e.c_str());
    }
    if (CUGRAPH_OPS_UNLIKELY(dl.type().bits != exp_data_type.bits)) {
      const auto& e = name + " expected type bits " + std::to_string(exp_data_type.bits) +
                      " but got " + std::to_string(dl.type().bits);
      throw nb::value_error(e.c_str());
    }
    if (CUGRAPH_OPS_UNLIKELY(dl.type().lanes != exp_data_type.lanes)) {
      const auto& e = name + " expected type lanes " + std::to_string(exp_data_type.lanes) +
                      " but got " + std::to_string(dl.type().lanes);
      throw nb::value_error(e.c_str());
    }
  }

  if (CUGRAPH_OPS_UNLIKELY(exp_n_dim >= 0 && dl.ndim() != exp_n_dim)) {
    const auto& e = name + " expected " + std::to_string(exp_n_dim) + " dimensions but got " +
                    std::to_string(dl.ndim());
    throw nb::value_error(e.c_str());
  }

  if (CUGRAPH_OPS_UNLIKELY(exp_shape == nullptr)) return dl;

  for (int32_t i = 0; i < exp_n_dim; ++i) {
    auto exp_s = exp_shape[i];
    if (exp_s < 0) continue;
    auto s = dl.dim(i);
    if (CUGRAPH_OPS_UNLIKELY(exp_s != s)) {
      const auto& e = name + " expected size " + std::to_string(exp_s) + " at dimension " +
                      std::to_string(i) + " but got " + std::to_string(s);
      throw nb::value_error(e.c_str());
    }
  }

  if (CUGRAPH_OPS_LIKELY(dl()->strides == nullptr)) return dl;

  int64_t exp_st = 1;
  for (int32_t i = exp_n_dim - 1; i >= 0; --i) {
    auto st = dl()->strides[i];
    // clamp non-positive dims to 1, since we interpret those as non-existing
    auto d = std::max(int64_t{1}, dl.dim(i));
    // a dimension of 1 can have any stride, so we omit the check in that case
    if (CUGRAPH_OPS_UNLIKELY(d > 1 && st != exp_st)) {
      const auto& e = name + " expected stride " + std::to_string(exp_st) + " at dimension " +
                      std::to_string(i) + " but got " + std::to_string(st);
      throw nb::value_error(e.c_str());
    }
    exp_st *= d;
  }

  return dl;
}

}  // namespace cugraph::ops::binding
