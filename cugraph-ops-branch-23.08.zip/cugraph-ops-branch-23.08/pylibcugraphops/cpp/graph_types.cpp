/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "dlpack/dlpack.h"
#include "dlpack/utils.hpp"
#include "graph_types_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/graph/reverse_graph.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT, typename GraphT>
inline int64_t reverse_graph_helper(GraphT& graph,
                                    const dl_wrapper& dl_node_counts,
                                    const dl_wrapper& dl_cub_workspace,
                                    int64_t cub_workspace_size,
                                    const uintptr_t& stream_id)
{
  IdxT* node_counts   = dl_node_counts.get_ptr<IdxT>();
  void* cub_workspace = dl_cub_workspace.maybe_ptr<void>();
  auto stream         = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));
  size_t cub_ws_size_actual;

  if (cub_workspace == nullptr) {
    void* null_ws = nullptr;
    get_reverse_graph(graph, node_counts, null_ws, cub_ws_size_actual, stream);
    return static_cast<int64_t>(cub_ws_size_actual);
  }

  cub_ws_size_actual = static_cast<size_t>(cub_workspace_size);
  get_reverse_graph(graph, node_counts, cub_workspace, cub_ws_size_actual, stream);
  return cub_workspace_size;
}

template <typename IdxT>
inline graph::mfg_csr<IdxT> make_mfg_csr_helper(const dl_wrapper& dl_out_nodes,
                                                const dl_wrapper& dl_offsets,
                                                const dl_wrapper& dl_indices,
                                                int64_t n_out_nodes,
                                                size_t sample_size,
                                                int64_t n_in_nodes,
                                                int64_t n_indices)
{
  graph::mfg_csr<IdxT> g;
  g.offsets     = dl_offsets.get_ptr<IdxT>();
  g.indices     = dl_indices.get_ptr<IdxT>();
  g.n_in_nodes  = static_cast<IdxT>(n_in_nodes);
  g.n_out_nodes = static_cast<IdxT>(n_out_nodes);
  g.n_indices   = static_cast<IdxT>(n_indices);
  g.out_nodes   = dl_out_nodes.get_ptr<IdxT>();
  g.sample_size = static_cast<IdxT>(sample_size);
  return g;
}

template <typename IdxT>
inline graph::mfg_csr_hg<IdxT> make_mfg_csr_hg_helper(const dl_wrapper& dl_out_nodes,
                                                      const dl_wrapper& dl_offsets,
                                                      const dl_wrapper& dl_indices,
                                                      int64_t n_out_nodes,
                                                      size_t sample_size,
                                                      int64_t n_in_nodes,
                                                      int64_t n_indices,
                                                      const dl_wrapper& dl_out_node_types,
                                                      const dl_wrapper& dl_in_node_types,
                                                      const dl_wrapper& dl_edge_types,
                                                      int32_t n_node_types,
                                                      int32_t n_edge_types)
{
  graph::mfg_csr_hg<IdxT> g;
  g.offsets        = dl_offsets.get_ptr<IdxT>();
  g.indices        = dl_indices.get_ptr<IdxT>();
  g.n_in_nodes     = static_cast<IdxT>(n_in_nodes);
  g.n_out_nodes    = static_cast<IdxT>(n_out_nodes);
  g.n_indices      = static_cast<IdxT>(n_indices);
  g.out_nodes      = dl_out_nodes.get_ptr<IdxT>();
  g.sample_size    = static_cast<IdxT>(sample_size);
  g.out_node_types = dl_out_node_types.maybe_ptr<int32_t>();
  g.in_node_types  = dl_in_node_types.maybe_ptr<int32_t>();
  g.edge_types     = dl_edge_types.get_ptr<int32_t>();
  g.n_node_types   = n_node_types;
  g.n_edge_types   = n_edge_types;
  return g;
}

template <typename IdxT>
inline graph::bipartite_csc<IdxT> make_bipartite_csc_helper(const dl_wrapper& dl_offsets,
                                                            const dl_wrapper& dl_indices,
                                                            const dl_wrapper& dl_ef_indices,
                                                            int64_t n_in_nodes,
                                                            int64_t n_out_nodes,
                                                            int64_t n_indices)
{
  graph::bipartite_csc<IdxT> g;
  g.offsets     = dl_offsets.get_ptr<IdxT>();
  g.indices     = dl_indices.get_ptr<IdxT>();
  g.ef_indices  = dl_ef_indices.maybe_ptr<IdxT>();
  g.n_in_nodes  = static_cast<IdxT>(n_in_nodes);
  g.n_out_nodes = static_cast<IdxT>(n_out_nodes);
  g.n_indices   = static_cast<IdxT>(n_indices);
  return g;
}

template <typename IdxT>
inline graph::bipartite_csc_csr<IdxT> make_bipartite_csc_csr_helper(
  const dl_wrapper& dl_offsets,
  const dl_wrapper& dl_indices,
  const dl_wrapper& dl_rev_offsets,
  const dl_wrapper& dl_rev_indices,
  const dl_wrapper& dl_ef_indices,
  const dl_wrapper& dl_rev_edge_ids,
  int64_t n_in_nodes,
  int64_t n_out_nodes,
  int64_t n_indices)
{
  graph::bipartite_csc_csr<IdxT> g;
  g.offsets      = dl_offsets.get_ptr<IdxT>();
  g.indices      = dl_indices.get_ptr<IdxT>();
  g.ef_indices   = dl_ef_indices.maybe_ptr<IdxT>();
  g.n_in_nodes   = static_cast<IdxT>(n_in_nodes);
  g.n_out_nodes  = static_cast<IdxT>(n_out_nodes);
  g.n_indices    = static_cast<IdxT>(n_indices);
  g.rev_offsets  = dl_rev_offsets.get_ptr<IdxT>();
  g.rev_indices  = dl_rev_indices.get_ptr<IdxT>();
  g.rev_edge_ids = dl_rev_edge_ids.maybe_ptr<IdxT>();
  return g;
}

template <typename IdxT>
inline graph::bipartite_csc_hg<IdxT> make_bipartite_csc_hg_helper(
  const dl_wrapper& dl_offsets,
  const dl_wrapper& dl_indices,
  const dl_wrapper& dl_ef_indices,
  int64_t n_in_nodes,
  int64_t n_out_nodes,
  int64_t n_indices,
  const dl_wrapper& dl_in_node_types,
  const dl_wrapper& dl_out_node_types,
  const dl_wrapper& dl_edge_types,
  int32_t n_node_types,
  int32_t n_edge_types)
{
  graph::bipartite_csc_hg<IdxT> g;
  g.offsets        = dl_offsets.get_ptr<IdxT>();
  g.indices        = dl_indices.get_ptr<IdxT>();
  g.ef_indices     = dl_ef_indices.maybe_ptr<IdxT>();
  g.n_in_nodes     = static_cast<IdxT>(n_in_nodes);
  g.n_out_nodes    = static_cast<IdxT>(n_out_nodes);
  g.n_indices      = static_cast<IdxT>(n_indices);
  g.in_node_types  = dl_in_node_types.maybe_ptr<int32_t>();
  g.out_node_types = dl_out_node_types.maybe_ptr<int32_t>();
  g.edge_types     = dl_edge_types.get_ptr<int32_t>();
  g.n_node_types   = n_node_types;
  g.n_edge_types   = n_edge_types;
  return g;
}

template <typename IdxT>
inline graph::fg_csr<IdxT> make_fg_csr_helper(const dl_wrapper& dl_offsets,
                                              const dl_wrapper& dl_indices,
                                              const dl_wrapper& dl_ef_indices,
                                              const dl_wrapper& dl_rev_edge_ids,
                                              int64_t n_nodes,
                                              int64_t n_indices)
{
  graph::fg_csr<IdxT> g;
  g.offsets      = dl_offsets.get_ptr<IdxT>();
  g.indices      = dl_indices.get_ptr<IdxT>();
  g.ef_indices   = dl_ef_indices.maybe_ptr<IdxT>();
  g.rev_edge_ids = dl_rev_edge_ids.maybe_ptr<IdxT>();
  g.n_nodes      = static_cast<IdxT>(n_nodes);
  g.n_indices    = static_cast<IdxT>(n_indices);
  return g;
}

template <typename IdxT>
inline graph::fg_csr_rev<IdxT> make_fg_csr_rev_helper(const dl_wrapper& dl_offsets,
                                                      const dl_wrapper& dl_indices,
                                                      const dl_wrapper& dl_rev_offsets,
                                                      const dl_wrapper& dl_rev_indices,
                                                      const dl_wrapper& dl_ef_indices,
                                                      const dl_wrapper& dl_rev_edge_ids,
                                                      int64_t n_nodes,
                                                      int64_t n_indices)
{
  graph::fg_csr_rev<IdxT> g;
  g.n_nodes      = static_cast<IdxT>(n_nodes);
  g.n_indices    = static_cast<IdxT>(n_indices);
  g.offsets      = dl_offsets.get_ptr<IdxT>();
  g.indices      = dl_indices.get_ptr<IdxT>();
  g.rev_offsets  = dl_rev_offsets.get_ptr<IdxT>();
  g.rev_indices  = dl_rev_indices.get_ptr<IdxT>();
  g.ef_indices   = dl_ef_indices.maybe_ptr<IdxT>();
  g.rev_edge_ids = dl_rev_edge_ids.maybe_ptr<IdxT>();
  return g;
}

template <typename IdxT>
inline graph::fg_csr_hg<IdxT> make_fg_csr_hg_helper(const dl_wrapper& dl_offsets,
                                                    const dl_wrapper& dl_indices,
                                                    const dl_wrapper& dl_ef_indices,
                                                    const dl_wrapper& dl_rev_edge_ids,
                                                    int64_t n_nodes,
                                                    int64_t n_indices,
                                                    const dl_wrapper& dl_node_types,
                                                    const dl_wrapper& dl_edge_types,
                                                    int32_t n_node_types,
                                                    int32_t n_edge_types)
{
  graph::fg_csr_hg<IdxT> g;
  g.offsets      = dl_offsets.get_ptr<IdxT>();
  g.indices      = dl_indices.get_ptr<IdxT>();
  g.ef_indices   = dl_ef_indices.maybe_ptr<IdxT>();
  g.rev_edge_ids = dl_rev_edge_ids.maybe_ptr<IdxT>();
  g.n_nodes      = static_cast<IdxT>(n_nodes);
  g.n_indices    = static_cast<IdxT>(n_indices);
  g.node_types   = dl_node_types.maybe_ptr<int32_t>();
  g.edge_types   = dl_edge_types.get_ptr<int32_t>();
  g.n_node_types = n_node_types;
  g.n_edge_types = n_edge_types;
  return g;
}

nb::object make_mfg_csr(nb::object& out_nodes,
                        nb::object& offsets,
                        nb::object& indices,
                        size_t sample_size,
                        size_t n_in_nodes)
{
  // use restricted data type to get all possible values
  auto dl_out_nodes =
    assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(out_nodes, "out_nodes", DL_S32_64, 1);
  auto n_out_nodes         = dl_out_nodes.dim(0);
  const auto& exp_idx_type = dl_out_nodes.type();

  int64_t dl_offsets_shape[] = {n_out_nodes + 1};
  auto dl_offsets =
    assert_type_shape_strides(offsets, "offsets", exp_idx_type, 1, dl_offsets_shape);

  auto dl_indices = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto n_indices  = dl_indices.dim(0);

  if (exp_idx_type.bits == 32) {
    auto g = make_mfg_csr_helper<int32_t>(
      dl_out_nodes, dl_offsets, dl_indices, n_out_nodes, sample_size, n_in_nodes, n_indices);
    return nb::cast(g);
  }

  auto g = make_mfg_csr_helper<int64_t>(
    dl_out_nodes, dl_offsets, dl_indices, n_out_nodes, sample_size, n_in_nodes, n_indices);
  return nb::cast(g);
}

nb::object make_mfg_csr_hg(nb::object& out_nodes,
                           nb::object& offsets,
                           nb::object& indices,
                           size_t sample_size,
                           size_t n_in_nodes,
                           int32_t n_node_types,
                           int32_t n_edge_types,
                           nb::object& out_node_types,
                           nb::object& in_node_types,
                           nb::object& edge_types)
{
  // use restricted data type to get all possible values
  auto dl_out_nodes =
    assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(out_nodes, "out_nodes", DL_S32_64, 1);
  auto n_out_nodes          = dl_out_nodes.dim(0);
  const auto& exp_idx_type  = dl_out_nodes.type();
  const auto& exp_type_type = DL_S32;

  int64_t dl_offsets_shape[] = {n_out_nodes + 1};
  auto dl_offsets =
    assert_type_shape_strides(offsets, "offsets", exp_idx_type, 1, dl_offsets_shape);

  auto dl_indices = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto n_indices  = dl_indices.dim(0);

  int64_t dl_out_node_types_shape[] = {n_out_nodes};
  auto dl_out_node_types            = assert_type_shape_strides(
    out_node_types, "out_node_types", exp_type_type, 1, dl_out_node_types_shape, true);

  int64_t dl_in_node_types_shape[] = {static_cast<int64_t>(n_in_nodes)};
  auto dl_in_node_types            = assert_type_shape_strides(
    in_node_types, "in_node_types", exp_type_type, 1, dl_in_node_types_shape, true);

  int64_t dl_edge_types_shape[] = {n_indices};
  auto dl_edge_types =
    assert_type_shape_strides(edge_types, "edge_types", exp_type_type, 1, dl_edge_types_shape);

  if (exp_idx_type.bits == 32) {
    auto g = make_mfg_csr_hg_helper<int32_t>(dl_out_nodes,
                                             dl_offsets,
                                             dl_indices,
                                             n_out_nodes,
                                             sample_size,
                                             n_in_nodes,
                                             n_indices,
                                             dl_out_node_types,
                                             dl_in_node_types,
                                             dl_edge_types,
                                             n_node_types,
                                             n_edge_types);
    return nb::cast(g);
  }
  auto g = make_mfg_csr_hg_helper<int64_t>(dl_out_nodes,
                                           dl_offsets,
                                           dl_indices,
                                           n_out_nodes,
                                           sample_size,
                                           n_in_nodes,
                                           n_indices,
                                           dl_out_node_types,
                                           dl_in_node_types,
                                           dl_edge_types,
                                           n_node_types,
                                           n_edge_types);
  return nb::cast(g);
}

nb::object make_bipartite_csc(nb::object& offsets,
                              nb::object& indices,
                              size_t n_in_nodes,
                              nb::object& ef_indices)
{
  // use restricted data type to get all possible values
  auto dl_offsets =
    assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(offsets, "offsets", DL_S32_64, 1);
  const auto& exp_idx_type = dl_offsets.type();
  auto dl_indices          = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto dl_ef_indices =
    assert_type_shape_strides(ef_indices, "ef_indices", exp_idx_type, 1, dl_indices.shape(), true);
  auto n_out_nodes = dl_offsets.dim(0) - 1;
  auto n_indices   = dl_indices.dim(0);

  if (exp_idx_type.bits == 32) {
    auto g = make_bipartite_csc_helper<int32_t>(
      dl_offsets, dl_indices, dl_ef_indices, n_in_nodes, n_out_nodes, n_indices);

    return nb::cast(g);
  }

  auto g = make_bipartite_csc_helper<int64_t>(
    dl_offsets, dl_indices, dl_ef_indices, n_in_nodes, n_out_nodes, n_indices);

  return nb::cast(g);
}

nb::object make_bipartite_csc_csr(nb::object& offsets,
                                  nb::object& indices,
                                  nb::object& rev_offsets,
                                  nb::object& rev_indices,
                                  size_t n_in_nodes,
                                  nb::object& ef_indices,
                                  nb::object& rev_edge_ids)
{
  // use restricted data type to get all possible values
  auto dl_offsets =
    assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(offsets, "offsets", DL_S32_64, 1);
  const auto& exp_idx_type = dl_offsets.type();
  int64_t rev_off_shape[]  = {static_cast<int64_t>(n_in_nodes + 1)};
  auto dl_rev_offsets =
    assert_type_shape_strides(rev_offsets, "rev_offsets", exp_idx_type, 1, rev_off_shape);
  auto dl_indices     = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto dl_rev_indices = assert_type_shape_strides(rev_indices, "rev_indices", exp_idx_type, 1);
  auto dl_ef_indices =
    assert_type_shape_strides(ef_indices, "ef_indices", exp_idx_type, 1, dl_indices.shape(), true);
  auto dl_rev_edge_ids = assert_type_shape_strides(
    rev_edge_ids, "rev_edge_ids", exp_idx_type, 1, dl_indices.shape(), true);
  auto n_indices   = dl_indices.dim(0);
  auto n_out_nodes = dl_offsets.dim(0) - 1;

  if (exp_idx_type.bits == 32) {
    auto g = make_bipartite_csc_csr_helper<int32_t>(dl_offsets,
                                                    dl_indices,
                                                    dl_rev_offsets,
                                                    dl_rev_indices,
                                                    dl_ef_indices,
                                                    dl_rev_edge_ids,
                                                    n_in_nodes,
                                                    n_out_nodes,
                                                    n_indices);

    return nb::cast(g);
  }

  auto g = make_bipartite_csc_csr_helper<int64_t>(dl_offsets,
                                                  dl_indices,
                                                  dl_rev_offsets,
                                                  dl_rev_indices,
                                                  dl_ef_indices,
                                                  dl_rev_edge_ids,
                                                  n_in_nodes,
                                                  n_out_nodes,
                                                  n_indices);

  return nb::cast(g);
}

nb::object make_bipartite_csc_hg(nb::object& offsets,
                                 nb::object& indices,
                                 size_t n_in_nodes,
                                 int32_t n_node_types,
                                 int32_t n_edge_types,
                                 nb::object& in_node_types,
                                 nb::object& out_node_types,
                                 nb::object& edge_types,
                                 nb::object& ef_indices)
{
  // use restricted data type to get all possible values
  auto dl_offsets =
    assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(offsets, "offsets", DL_S32_64, 1);
  const auto& exp_idx_type = dl_offsets.type();
  auto dl_indices          = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto dl_ef_indices =
    assert_type_shape_strides(ef_indices, "ef_indices", exp_idx_type, 1, dl_indices.shape(), true);
  auto n_out_nodes = dl_offsets.dim(0) - 1;
  auto n_indices   = dl_indices.dim(0);

  const auto& exp_type_type        = DL_S32;
  int64_t dl_in_node_types_shape[] = {static_cast<int64_t>(n_in_nodes)};
  auto dl_in_node_types            = assert_type_shape_strides(
    in_node_types, "in_node_types", exp_type_type, 1, dl_in_node_types_shape, true);
  int64_t dl_out_node_types_shape[] = {n_out_nodes};
  auto dl_out_node_types            = assert_type_shape_strides(
    out_node_types, "out_node_types", exp_type_type, 1, dl_out_node_types_shape, true);
  int64_t dl_edge_types_shape[] = {n_indices};
  auto dl_edge_types =
    assert_type_shape_strides(edge_types, "edge_types", exp_type_type, 1, dl_edge_types_shape);

  if (exp_idx_type.bits == 32) {
    auto g = make_bipartite_csc_hg_helper<int32_t>(dl_offsets,
                                                   dl_indices,
                                                   dl_ef_indices,
                                                   n_in_nodes,
                                                   n_out_nodes,
                                                   n_indices,
                                                   dl_in_node_types,
                                                   dl_out_node_types,
                                                   dl_edge_types,
                                                   n_node_types,
                                                   n_edge_types);

    return nb::cast(g);
  }

  auto g = make_bipartite_csc_hg_helper<int64_t>(dl_offsets,
                                                 dl_indices,
                                                 dl_ef_indices,
                                                 n_in_nodes,
                                                 n_out_nodes,
                                                 n_indices,
                                                 dl_in_node_types,
                                                 dl_out_node_types,
                                                 dl_edge_types,
                                                 n_node_types,
                                                 n_edge_types);

  return nb::cast(g);
}

nb::object make_fg_csr(nb::object& offsets,
                       nb::object& indices,
                       nb::object& ef_indices,
                       nb::object& rev_edge_ids)
{
  // use restricted data type to get all possible values
  auto dl_offsets =
    assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(offsets, "offsets", DL_S32_64, 1);
  const auto& exp_idx_type = dl_offsets.type();
  auto dl_indices          = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto dl_ef_indices =
    assert_type_shape_strides(ef_indices, "ef_indices", exp_idx_type, 1, dl_indices.shape(), true);
  auto dl_rev_edge_ids = assert_type_shape_strides(
    rev_edge_ids, "rev_edge_ids", exp_idx_type, 1, dl_indices.shape(), true);
  auto n_nodes   = dl_offsets.dim(0) - 1;
  auto n_indices = dl_indices.dim(0);

  if (exp_idx_type.bits == 32) {
    auto g = make_fg_csr_helper<int32_t>(
      dl_offsets, dl_indices, dl_ef_indices, dl_rev_edge_ids, n_nodes, n_indices);

    return nb::cast(g);
  }

  auto g = make_fg_csr_helper<int64_t>(
    dl_offsets, dl_indices, dl_ef_indices, dl_rev_edge_ids, n_nodes, n_indices);

  return nb::cast(g);
}

nb::object make_fg_csr_rev(nb::object& offsets,
                           nb::object& indices,
                           nb::object& rev_offsets,
                           nb::object& rev_indices,
                           nb::object& ef_indices,
                           nb::object& rev_edge_ids)
{
  // use restricted data type to get all possible values
  auto dl_offsets =
    assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(offsets, "offsets", DL_S32_64, 1);
  const auto& exp_idx_type = dl_offsets.type();
  auto dl_rev_offsets =
    assert_type_shape_strides(rev_offsets, "rev_offsets", exp_idx_type, 1, dl_offsets.shape());
  auto dl_indices = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto dl_rev_indices =
    assert_type_shape_strides(rev_indices, "rev_indices", exp_idx_type, 1, dl_indices.shape());
  auto dl_ef_indices =
    assert_type_shape_strides(ef_indices, "ef_indices", exp_idx_type, 1, dl_indices.shape(), true);
  auto dl_rev_edge_ids = assert_type_shape_strides(
    rev_edge_ids, "rev_edge_ids", exp_idx_type, 1, dl_indices.shape(), true);
  auto n_nodes   = dl_offsets.dim(0) - 1;
  auto n_indices = dl_indices.dim(0);

  if (exp_idx_type.bits == 32) {
    auto g = make_fg_csr_rev_helper<int32_t>(dl_offsets,
                                             dl_indices,
                                             dl_rev_offsets,
                                             dl_rev_indices,
                                             dl_ef_indices,
                                             dl_rev_edge_ids,
                                             n_nodes,
                                             n_indices);

    return nb::cast(g);
  }

  auto g = make_fg_csr_rev_helper<int64_t>(dl_offsets,
                                           dl_indices,
                                           dl_rev_offsets,
                                           dl_rev_indices,
                                           dl_ef_indices,
                                           dl_rev_edge_ids,
                                           n_nodes,
                                           n_indices);

  return nb::cast(g);
}

nb::object make_fg_csr_hg(nb::object& offsets,
                          nb::object& indices,
                          int32_t n_node_types,
                          int32_t n_edge_types,
                          nb::object& node_types,
                          nb::object& edge_types,
                          nb::object& ef_indices,
                          nb::object& rev_edge_ids)
{
  // use restricted data type to get all possible values
  auto dl_offsets =
    assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(offsets, "offsets", DL_S32_64, 1);
  const auto& exp_idx_type = dl_offsets.type();
  auto dl_indices          = assert_type_shape_strides(indices, "indices", exp_idx_type, 1);
  auto dl_ef_indices =
    assert_type_shape_strides(ef_indices, "ef_indices", exp_idx_type, 1, dl_indices.shape(), true);
  auto dl_rev_edge_ids = assert_type_shape_strides(
    rev_edge_ids, "rev_edge_ids", exp_idx_type, 1, dl_indices.shape(), true);
  auto n_nodes   = dl_offsets.dim(0) - 1;
  auto n_indices = dl_indices.dim(0);

  const auto& exp_type_type     = DL_S32;
  int64_t dl_node_types_shape[] = {n_nodes};
  auto dl_node_types            = assert_type_shape_strides(
    node_types, "node_types", exp_type_type, 1, dl_node_types_shape, true);

  int64_t dl_edge_types_shape[] = {n_indices};
  auto dl_edge_types =
    assert_type_shape_strides(edge_types, "edge_types", exp_type_type, 1, dl_edge_types_shape);

  if (exp_idx_type.bits == 32) {
    auto g = make_fg_csr_hg_helper<int32_t>(dl_offsets,
                                            dl_indices,
                                            dl_ef_indices,
                                            dl_rev_edge_ids,
                                            n_nodes,
                                            n_indices,
                                            dl_node_types,
                                            dl_edge_types,
                                            n_node_types,
                                            n_edge_types);
    return nb::cast(g);
  }

  auto g = make_fg_csr_hg_helper<int64_t>(dl_offsets,
                                          dl_indices,
                                          dl_ef_indices,
                                          dl_rev_edge_ids,
                                          n_nodes,
                                          n_indices,
                                          dl_node_types,
                                          dl_edge_types,
                                          n_node_types,
                                          n_edge_types);
  return nb::cast(g);
}

template <typename IdxT>
int64_t reverse_graph_impl(cugraph::ops::graph::bipartite_csc_csr<IdxT>& graph,
                           nb::object node_counts,
                           nb::object cub_workspace,
                           int64_t cub_workspace_size,
                           const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();
  int64_t node_counts_shape[]          = {int64_t{graph.n_in_nodes + 1}};
  int64_t cub_workspace_shape[]        = {cub_workspace_size};
  auto dl_node_counts =
    assert_type_shape_strides(node_counts, "node_counts", IDX_TYPE, 1, node_counts_shape);
  auto dl_cub_workspace =
    assert_type_shape_strides(cub_workspace, "cub_workspace", DL_S8, 1, cub_workspace_shape, true);
  return reverse_graph_helper<IdxT, cugraph::ops::graph::bipartite_csc_csr<IdxT>>(
    graph, dl_node_counts, dl_cub_workspace, cub_workspace_size, stream_id);
}

template <typename IdxT>
int64_t reverse_graph_impl(cugraph::ops::graph::fg_csr_rev<IdxT>& graph,
                           nb::object node_counts,
                           nb::object cub_workspace,
                           int64_t cub_workspace_size,
                           const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();
  int64_t node_counts_shape[]          = {int64_t{graph.n_nodes + 1}};
  int64_t cub_workspace_shape[]        = {cub_workspace_size};
  auto dl_node_counts =
    assert_type_shape_strides(node_counts, "node_counts", IDX_TYPE, 1, node_counts_shape);
  auto dl_cub_workspace =
    assert_type_shape_strides(cub_workspace, "cub_workspace", DL_S8, 1, cub_workspace_shape, true);
  return reverse_graph_helper<IdxT, cugraph::ops::graph::fg_csr_rev<IdxT>>(
    graph, dl_node_counts, dl_cub_workspace, cub_workspace_size, stream_id);
}

template <typename IdxT, typename GraphT>
int64_t reverse_graph(GraphT& graph,
                      nb::object node_counts,
                      nb::object cub_workspace,
                      int64_t cub_workspace_size,
                      const uintptr_t& stream_id)
{
  return reverse_graph_impl<IdxT>(graph, node_counts, cub_workspace, cub_workspace_size, stream_id);
}

}  // namespace cugraph::ops::binding

template <typename ClassT>
void init_graph_bipartite_csc(nb::module_& m, const char* name)
{
  nb::class_<ClassT>(m, name)
    .def(nb::init<>())
    .def_ro("n_in_nodes", &ClassT::n_in_nodes)
    .def_ro("n_out_nodes", &ClassT::n_out_nodes)
    .def_ro("n_indices", &ClassT::n_indices)
    .def_ro("n_edges", &ClassT::n_indices);
}

template <typename ClassT>
void init_graph_fg_csr(nb::module_& m, const char* name)
{
  nb::class_<ClassT>(m, name)
    .def(nb::init<>())
    .def_ro("n_nodes", &ClassT::n_nodes)
    .def_ro("n_indices", &ClassT::n_indices)
    .def_ro("n_edges", &ClassT::n_indices);
}

template <typename ClassT, typename ParentT, typename IdxT>
void init_graph_fg_csr_seq(nb::module_& m, const char* name)
{
  nb::class_<ClassT, ParentT>(m, name).def(nb::init<>()).def_ro("n_graphs", &ClassT::n_graphs);
}

template <typename ClassT, typename IdxT>
void init_graph_fg_csr_batch(nb::module_& m, const char* name)
{
  nb::class_<ClassT>(m, name)
    .def(nb::init<const cugraph::ops::graph::fg_csr_seq<IdxT>&>())
    .def_ro("batch_size", &ClassT::batch_size)
    .def_ro("n_nodes", &ClassT::n_nodes)
    .def_ro("n_edges", &ClassT::n_edges);
}

template <typename ClassT, bool HAS_NNZ>
void init_graph_mfg(nb::module_& m, const char* name)
{
  auto c = nb::class_<ClassT>(m, name)
             .def(nb::init<>())
             .def_ro("n_out_nodes", &ClassT::n_out_nodes)
             .def_ro("sample_size", &ClassT::sample_size)
             .def_ro("n_in_nodes", &ClassT::n_in_nodes);
  if constexpr (HAS_NNZ) c.def_ro("n_indices", &ClassT::n_indices);
}

template <typename ClassT, typename ParentT>
void init_graph_bipartite_csc_hg(nb::module_& m, const char* name)
{
  nb::class_<ClassT, ParentT>(m, name)
    .def_ro("n_node_types", &ClassT::n_node_types)
    .def_ro("n_edge_types", &ClassT::n_edge_types);
}

template <typename ClassT, typename ParentT>
void init_graph_fg_csr_hg(nb::module_& m, const char* name)
{
  nb::class_<ClassT, ParentT>(m, name)
    .def_ro("n_node_types", &ClassT::n_node_types)
    .def_ro("n_edge_types", &ClassT::n_edge_types);
}

template <typename ClassT, typename ParentT>
void init_graph_mfg_hg(nb::module_& m, const char* name)
{
  nb::class_<ClassT, ParentT>(m, name)
    .def_ro("n_node_types", &ClassT::n_node_types)
    .def_ro("n_edge_types", &ClassT::n_edge_types);
}

template <typename IdxT, typename GraphT>
void init_reverse_graph(nb::module_& m)
{
  m.def("reverse_graph",
        &cugraph::ops::binding::reverse_graph<IdxT, GraphT>,
        nb::arg("graph"),
        nb::arg("workspace"),
        nb::arg("cub_workspace").none() = nb::none(),
        nb::arg("cub_workspace_size"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(REVERSE_GRAPH_DOC));
}

void init_graph_types(nb::module_& m)
{
  m.attr("invalid_id_int32") = cugraph::ops::graph::INVALID_ID<int32_t>;
  m.attr("invalid_id_int64") = cugraph::ops::graph::INVALID_ID<int64_t>;
  init_graph_bipartite_csc<cugraph::ops::bipartite_csc_s32_t>(m, "bipartite_csc_int32");
  init_graph_bipartite_csc<cugraph::ops::bipartite_csc_s64_t>(m, "bipartite_csc_int64");
  init_graph_bipartite_csc<cugraph::ops::bipartite_csc_csr_s32_t>(m, "bipartite_csc_csr_int32");
  init_graph_bipartite_csc<cugraph::ops::bipartite_csc_csr_s64_t>(m, "bipartite_csc_csr_int64");
  init_graph_fg_csr<cugraph::ops::fg_csr_s32_t>(m, "fg_csr_int32");
  init_graph_fg_csr<cugraph::ops::fg_csr_s64_t>(m, "fg_csr_int64");
  init_graph_fg_csr<cugraph::ops::fg_csr_rev_s32_t>(m, "fg_csr_rev_int32");
  init_graph_fg_csr<cugraph::ops::fg_csr_rev_s64_t>(m, "fg_csr_rev_int64");
  init_graph_fg_csr_seq<cugraph::ops::fg_csr_seq_s32_t, cugraph::ops::fg_csr_s32_t, int32_t>(
    m, "fg_csr_seq_int32");
  init_graph_fg_csr_seq<cugraph::ops::fg_csr_seq_s64_t, cugraph::ops::fg_csr_s64_t, int64_t>(
    m, "fg_csr_seq_int64");
  init_graph_fg_csr_batch<cugraph::ops::fg_csr_batch_s32_t, int32_t>(m, "fg_csr_batch_int32");
  init_graph_fg_csr_batch<cugraph::ops::fg_csr_batch_s64_t, int64_t>(m, "fg_csr_batch_int64");
  init_graph_mfg<cugraph::ops::mfg_csr_s32_t, true>(m, "mfg_csr_int32");
  init_graph_mfg<cugraph::ops::mfg_csr_s64_t, true>(m, "mfg_csr_int64");
  init_graph_mfg<cugraph::ops::mfg_ellpack_s32_t, false>(m, "mfg_ellpack_int32");
  init_graph_mfg<cugraph::ops::mfg_ellpack_s64_t, false>(m, "mfg_ellpack_int64");
  init_graph_mfg<cugraph::ops::mfg_csr_rev_s32_t, true>(m, "mfg_csr_rev_int32");
  init_graph_mfg<cugraph::ops::mfg_csr_rev_s64_t, true>(m, "mfg_csr_rev_int64");

  init_graph_bipartite_csc_hg<cugraph::ops::bipartite_csc_hg_s32_t,
                              cugraph::ops::bipartite_csc_s32_t>(m, "bipartite_csc_hg_int32");
  init_graph_bipartite_csc_hg<cugraph::ops::bipartite_csc_hg_s64_t,
                              cugraph::ops::bipartite_csc_s64_t>(m, "bipartite_csc_hg_int64");
  init_graph_fg_csr_hg<cugraph::ops::fg_csr_hg_s32_t, cugraph::ops::fg_csr_s32_t>(
    m, "fg_csr_hg_int32");
  init_graph_fg_csr_hg<cugraph::ops::fg_csr_hg_s64_t, cugraph::ops::fg_csr_s64_t>(
    m, "fg_csr_hg_int64");
  init_graph_mfg_hg<cugraph::ops::mfg_ellpack_hg_s32_t, cugraph::ops::mfg_ellpack_s32_t>(
    m, "mfg_ellpack_hg_int32");
  init_graph_mfg_hg<cugraph::ops::mfg_ellpack_hg_s64_t, cugraph::ops::mfg_ellpack_s64_t>(
    m, "mfg_ellpack_hg_int64");
  init_graph_mfg_hg<cugraph::ops::mfg_csr_hg_s32_t, cugraph::ops::mfg_csr_s32_t>(
    m, "mfg_csr_hg_int32");
  init_graph_mfg_hg<cugraph::ops::mfg_csr_hg_s64_t, cugraph::ops::mfg_csr_s64_t>(
    m, "mfg_csr_hg_int64");
  init_graph_mfg_hg<cugraph::ops::mfg_csr_rev_hg_s32_t, cugraph::ops::mfg_csr_rev_s32_t>(
    m, "mfg_csr_rev_hg_int32");
  init_graph_mfg_hg<cugraph::ops::mfg_csr_rev_hg_s64_t, cugraph::ops::mfg_csr_rev_s64_t>(
    m, "mfg_csr_rev_hg_int64");

  init_reverse_graph<int32_t, cugraph::ops::bipartite_csc_csr_s32_t>(m);
  init_reverse_graph<int64_t, cugraph::ops::bipartite_csc_csr_s64_t>(m);
  init_reverse_graph<int32_t, cugraph::ops::fg_csr_rev_s32_t>(m);
  init_reverse_graph<int64_t, cugraph::ops::fg_csr_rev_s64_t>(m);

  // we don't allow None as inputs here, which is the default.
  // we still use nb::arg to specify the names of arguments
  m.def("make_mfg_csr",
        &cugraph::ops::binding::make_mfg_csr,
        nb::arg("out_nodes"),
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("sample_size"),
        nb::arg("n_in_nodes"),
        nb::raw_doc(MAKE_MFG_CSR_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 3>());

  m.def("make_mfg_csr_hg",
        &cugraph::ops::binding::make_mfg_csr_hg,
        nb::arg("out_nodes"),
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("sample_size"),
        nb::arg("n_in_nodes"),
        nb::arg("n_node_types"),
        nb::arg("n_edge_types"),
        nb::arg("out_node_types").none(),
        nb::arg("in_node_types").none(),
        nb::arg("edge_types"),
        nb::raw_doc(MAKE_MFG_CSR_HG_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 3>(),
        nb::keep_alive<0, 8>(),
        nb::keep_alive<0, 9>(),
        nb::keep_alive<0, 10>());

  m.def("make_bipartite_csc",
        &cugraph::ops::binding::make_bipartite_csc,
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("n_in_nodes"),
        nb::arg("ef_indices").none() = nb::none(),
        nb::raw_doc(MAKE_BIPART_CSC_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 4>());

  m.def("make_bipartite_csc_csr",
        &cugraph::ops::binding::make_bipartite_csc_csr,
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("rev_offsets"),
        nb::arg("rev_indices"),
        nb::arg("n_in_nodes"),
        nb::arg("ef_indices").none()   = nb::none(),
        nb::arg("rev_edge_ids").none() = nb::none(),
        nb::raw_doc(MAKE_BIPART_CSC_CSR_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 3>(),
        nb::keep_alive<0, 4>(),
        nb::keep_alive<0, 6>(),
        nb::keep_alive<0, 7>());

  m.def("make_bipartite_csc_hg",
        &cugraph::ops::binding::make_bipartite_csc_hg,
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("n_in_nodes"),
        nb::arg("n_node_types"),
        nb::arg("n_edge_types"),
        nb::arg("in_node_types").none(),
        nb::arg("out_node_types").none(),
        nb::arg("edge_types"),
        nb::arg("ef_indices").none() = nb::none(),
        nb::raw_doc(MAKE_BIPART_CSC_HG_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 6>(),
        nb::keep_alive<0, 7>(),
        nb::keep_alive<0, 8>(),
        nb::keep_alive<0, 9>());

  m.def("make_fg_csr",
        &cugraph::ops::binding::make_fg_csr,
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("ef_indices").none()   = nb::none(),
        nb::arg("rev_edge_ids").none() = nb::none(),
        nb::raw_doc(MAKE_FG_CSR_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 3>(),
        nb::keep_alive<0, 4>());

  m.def("make_fg_csr_rev",
        &cugraph::ops::binding::make_fg_csr_rev,
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("rev_offsets"),
        nb::arg("rev_indices"),
        nb::arg("ef_indices").none()   = nb::none(),
        nb::arg("rev_edge_ids").none() = nb::none(),
        nb::raw_doc(MAKE_FG_CSR_REV_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 3>(),
        nb::keep_alive<0, 4>());

  m.def("make_fg_csr_hg",
        &cugraph::ops::binding::make_fg_csr_hg,
        nb::arg("offsets"),
        nb::arg("indices"),
        nb::arg("n_node_types"),
        nb::arg("n_edge_types"),
        nb::arg("node_types").none(),
        nb::arg("edge_types"),
        nb::arg("ef_indices").none()   = nb::none(),
        nb::arg("rev_edge_ids").none() = nb::none(),
        nb::raw_doc(MAKE_FG_CSR_HG_DOC),
        nb::keep_alive<0, 1>(),
        nb::keep_alive<0, 2>(),
        nb::keep_alive<0, 5>(),
        nb::keep_alive<0, 6>(),
        nb::keep_alive<0, 7>(),
        nb::keep_alive<0, 8>());
}
