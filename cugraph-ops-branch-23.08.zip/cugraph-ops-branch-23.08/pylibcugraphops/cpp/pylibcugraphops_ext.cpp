/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_dimenet(nb::module_&);
void init_global_types(nb::module_&);
void init_graph_types(nb::module_&);
void init_operators(nb::module_&);

NB_MODULE(pylibcugraphops_ext, m)
{
  // suppress leak warnings if desired
#if defined(NB_NO_LEAK_WARNINGS)
  nb::set_leak_warnings(false);
#endif

  // we want to first initialize global types and the graph classes so that
  // docstrings in later bindings can use the named types rather than the name
  // of the C++ type
  init_global_types(m);
  init_graph_types(m);

  init_operators(m);

  init_dimenet(m);
}
