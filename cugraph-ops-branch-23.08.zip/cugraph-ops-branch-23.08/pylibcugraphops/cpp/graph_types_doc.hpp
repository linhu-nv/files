/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const MAKE_MFG_CSR_DOC =
  R"(Creates a Message-Flow-Graph using CSR from the graph structure tensors.

.. code-block:: python

    make_mfg_csr(
        out_nodes: device array, offsets: device array,
        indices: device array, sample_size: int, n_in_nodes: int
    ) -> pylibcugraphops.mfg_csr_int[32|64]

Parameters
----------
out_nodes : device array type
    Device array containing the output nodes of the graph.
    Shape: ``(n_out_nodes, )``.

offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices.
    Shape: ``(n_out_nodes + 1, )``.

indices : device array type
    Contains the adjacency lists of all the out nodes.
    Shape: ``(n_indices, )``.

sample_size : int
    Maximum degree of nodes. Must be smaller than :math:`2^{31}`.

n_in_nodes : int
    The number of input nodes of the bipartite graph / the indexing range of
    ``indices``.

Returns
-------
MFG
    An opaque python object representing the MFG to be used in aggregators.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_mfg_csr
...
>>> cupy.random.seed(0)
>>> n_out_nodes = 5
>>> n_in_nodes = n_out_nodes + 10
>>> sample_size = 4
>>> mfg_dtype = cupy.int32
>>> # use any distribution to generate n_edges (with non-negative values)
>>> n_edges = cupy.random.randint(0, 2 * sample_size, n_out_nodes, dtype=mfg_dtype)
>>> offsets = cupy.zeros(n_out_nodes+1, dtype=mfg_dtype)
>>> offsets[1:] = cupy.cumsum(n_edges)
>>> indices = cupy.random.randint(0, n_in_nodes, offsets[-1].item(), dtype=mfg_dtype)
>>> out_nodes = cupy.arange(0, n_out_nodes, dtype=mfg_dtype)
...
>>> m = make_mfg_csr(out_nodes, offsets, indices, sample_size, n_in_nodes)
>>> # call aggregator with `m` here
)";

static constexpr const char* const MAKE_MFG_CSR_HG_DOC =
  R"(Creates a heterogeneous Message-Flow-Graph using CSR from the graph structure tensors.

.. code-block:: python

    make_mfg_csr_hg(
        out_nodes: device array, offsets: device array, indices: device array,
        sample_size: int, n_in_nodes: int, n_node_types: int, n_edge_types: int,
        out_node_types: Optional[device array], in_node_types: Optional[device array],
        edge_types: device array
    ) -> pylibcugraphops.mfg_csr_hg_int[32|64]

Parameters
----------
out_nodes : device array type
    Device array containing the output nodes of the graph.
    Shape: ``(n_out_nodes, )``.

offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices.
    Shape: ``(n_out_nodes + 1, )``.

indices : device array type
    Contains the adjacency lists of all the out nodes.
    Shape: ``(n_indices, )``.

sample_size : int
    Maximum degree of nodes. Must be smaller than :math:`2^{31}`.

n_in_nodes : int
    The number of input nodes of the bipartite graph / the indexing range of
    ``indices``.

n_node_types : int
    Number of node types in the graph.

n_edge_types : int
    Number of edge types in the graph.

out_node_types : device array type | None
    For each output node, contains their node type. Follows the same
    indexing as ``out_nodes``.
    Shape: ``(n_out_nodes, )`` if set.

in_node_types : device array type | None
    For each input node, contains their node type. Indexing is over ``n_in_nodes``.
    Shape: ``(n_in_nodes, )`` if set.

edge_types : device array type
    For each edge, contains their edge type. Follows the same indexing
    as ``indices``.
    Shape: ``(n_indices, )``.

Returns
-------
MFG
    An opaque python object representing the MFG to be used in aggregators.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_mfg_csr_hg
...
>>> cupy.random.seed(0)
>>> n_out_nodes = 5
>>> n_in_nodes = n_out_nodes + 10
>>> sample_size = 4
>>> mfg_dtype = cupy.int32
>>> # use any distribution to generate n_edges (with non-negative values)
>>> n_edges = cupy.random.randint(0, 2 * sample_size, n_out_nodes, dtype=mfg_dtype)
>>> offsets = cupy.zeros(n_out_nodes+1, dtype=mfg_dtype)
>>> offsets[1:] = cupy.cumsum(n_edges)
>>> indices = cupy.random.randint(0, n_in_nodes, offsets[-1].item(), dtype=mfg_dtype)
>>> out_nodes = cupy.arange(0, n_out_nodes, dtype=mfg_dtype)
...
>>> n_node_types = 3
>>> n_edge_types = 7
>>> out_node_types = cupy.random.randint(0, n_node_types, n_out_nodes, dtype=cupy.int32)
>>> in_node_types = cupy.random.randint(0, n_node_types, n_in_nodes, dtype=cupy.int32)
>>> edge_types = cupy.random.randint(0, n_edge_types, indices.shape[0], dtype=cupy.int32)
...
>>> m = make_mfg_csr_hg(out_nodes, offsets, indices, sample_size, n_in_nodes,
...     n_node_types, n_edge_types, out_node_types, in_node_types, edge_types)
>>> # call aggregator with `m` here
)";

static constexpr const char* const MAKE_FG_CSR_DOC =
  R"(Creates a Full-Graph representation using CSR from the graph structure tensors.

.. code-block:: python

    make_fg_csr(
        offsets: device array, indices: device array,
        ef_indices: Optional[device array], rev_edge_ids: Optional[device array]
    ) -> pylibcugraphops.fg_csr_int[32|64]

Parameters
----------
offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices.
    Shape: ``(n_nodes + 1, )``.

indices : device array type
    Contains the adjacency lists of all the out nodes.
    Shape: ``(n_indices, )``.

ef_indices : device array type | None
    Contains edge feature indices for each of the above edge, pointing to that row in the
    edge embedding table. This can be used to avoid having to reorder edge features
    when we sort edges while creating CSR, or apply other transformations on the graph structure.
    Shape: ``(n_indices, )`` if set.

rev_edge_ids : device array type | None
    For every edge, this provides the indices of the reverse edges.
    Shape: ``(n_indices, )`` if set.

Returns
-------
FG
    An opaque python object representing the FG to be used in aggregators.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_fg_csr
...
>>> cupy.random.seed(0)
>>> n_nodes = 15
>>> avg_degree = 5
>>> fg_dtype = cupy.int32
>>> # use any distribution to generate n_edges (with non-negative values)
>>> n_edges = cupy.random.randint(0, 2 * avg_degree, n_nodes, dtype=fg_dtype)
>>> offsets = cupy.zeros(n_nodes+1, dtype=fg_dtype)
>>> offsets[1:] = cupy.cumsum(n_edges)
>>> indices = cupy.random.randint(0, n_nodes, offsets[-1].item(), dtype=fg_dtype)
...
>>> m = make_fg_csr(offsets, indices)
>>> # call aggregator with `m` here
)";

static constexpr const char* const MAKE_FG_CSR_REV_DOC =
  R"(Creates a Full-Graph representation using CSR from the graph structure tensors
     which also contains structures for the reverse direction.

.. code-block:: python

    make_fg_csr_rev(
        offsets: device array, indices: device array,
        rev_offsets: device array, rev_indices: device array,
        ef_indices: Optional[device array], rev_edge_ids: Optional[device array]
    ) -> pylibcugraphops.fg_csr_int[32|64]

Parameters
----------
offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that out-node in the indices.
    Shape: ``(n_nodes + 1, )``.

indices : device array type
    Contains the adjacency lists of all the out nodes.
    Shape: ``(n_indices, )``.

rev_offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that in-node in the indices.
    Shape: ``(n_nodes + 1, )``.

rev_indices : device array type
    Contains the adjacency lists of all the in nodes.
    Shape: ``(n_indices, )``.

ef_indices : device array type | None
    Contains edge feature indices for each of the above edge, pointing to that row in the
    edge embedding table. This can be used to avoid having to reorder edge features
    when we sort edges while creating CSR, or apply other transformations on the graph structure.
    Shape: ``(n_indices, )`` if set.

rev_edge_ids : device array type | None
    For every edge, this provides the index mapping from `rev_indices` into `indices`.
    Shape: ``(n_indices, )`` if set.

Returns
-------
FG
    An opaque python object representing the FG to be used in aggregators.
)";

static constexpr const char* const MAKE_FG_CSR_HG_DOC =
  R"(Creates a heterogenous Full-Graph representation using CSR from the graph structure tensors.

.. code-block:: python

    make_fg_csr_hg(
        offsets: device array, indices: device array, n_node_types: int,
        n_edge_types: int, node_types: device array, edge_types: device array,
        ef_indices: Optional[device array], rev_edge_ids: Optional[device array]
    ) -> pylibcugraphops.fg_csr_hg_int[32|64]

Parameters
----------
offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices.
    Shape: ``(n_nodes + 1, )``.

indices : device array type
    Contains the adjacency lists of all the out nodes.
    Shape: ``(n_indices, )``.

n_node_types : int
    Number of node types in the graph.

n_edge_types : int
    Number of edge types in the graph.

node_types : device array type
    Node types of each node in the graph.
    Shape: ``(n_nodes, )``.

edge_types : device array type
    Edge types of each edge in the graph. Follows the same indexing
    as ``indices``.
    Shape: ``(n_indices, )``.

ef_indices : device array type | None
    Contains edge feature indices for each of the above edge, pointing to that row in the
    edge embedding table. This can be used to avoid having to reorder edge features
    when we sort edges while creating CSR, or apply other transformations on the graph structure.
    Shape: ``(n_indices, )`` if set.

rev_edge_ids : device array type | None
    For every edge, this provides the indices of the reverse edges.
    Shape: ``(n_indices, )`` if set.

Returns
-------
FG
    An opaque python object representing the FG to be used in aggregators.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_fg_csr_hg
...
>>> cupy.random.seed(0)
>>> n_nodes = 15
>>> avg_deg = 5
>>> fg_dtype = cupy.int32
>>> # use any distribution to generate n_edges (with non-negative values)
>>> n_edges = cupy.random.randint(0, 2 * avg_degree, n_nodes, dtype=fg_dtype)
>>> offsets = cupy.zeros(n_nodes+1, dtype=fg_dtype)
>>> offsets[1:] = cupy.cumsum(n_edges)
>>> indices = cupy.random.randint(0, n_nodes, offsets[-1].item(), dtype=fg_dtype)
...
>>> n_node_types = 3
>>> n_edge_types = 7
>>> node_types = cupy.random.randint(0, n_node_types, n_nodes, dtype=cupy.int32)
>>> edge_types = cupy.random.randint(0, n_edge_types, indices.shape[0], dtype=cupy.int32)
>>>
>>> graph = make_fg_csr_hg(offsets, indices, n_node_types, n_edge_types, node_types, edge_types)
>>> # call aggregator with `graph` here
)";

static constexpr const char* const MAKE_BIPART_CSC_DOC =
  R"(Creates a basic CSC graph representation for a bipartite graph
     from the tensors defining it.

.. code-block:: python

    make_bipartite_csc(
        offsets: device array, indices: device array, n_in_nodes: int,
        ef_indices: Optional[device array]
    ) -> pylibcugraphops.bipartite_csc_int[32|64]

Parameters
----------
offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices. It's length is
    one more than the length of out_nodes.

indices : device array type
    Contains the adjacency lists of all the out nodes.

n_in_nodes : int
    number of input nodes (equals ``max(indices) + 1``)

ef_indices : device array type | None
    Contains edge feature indices for each of the above edge, pointing to that row in the
    edge embedding table. This can be used to avoid having to reorder edge features
    when we sort edges while creating a compressed sparse representation,
    or apply other transformations on the graph structure.

Returns
-------
graph_csc
    An opaque python object representing the bipartite graph to be used in aggregators.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_bipartite_csc
>>>
>>> cupy.random.seed(0)
>>> n_out_nodes = 15
>>> n_in_nodes = 25
>>> avg_degree = 5
>>> fg_dtype = cupy.int32
>>> # use any distribution to generate n_edges (with non-negative values)
>>> n_edges = cupy.random.randint(0, 2 * avg_degree, n_in_nodes, dtype=fg_dtype)
>>> offsets = cupy.zeros(n_out_nodes+1, dtype=fg_dtype)
>>> offsets[1:] = cupy.cumsum(n_edges)
>>> indices = cupy.random.randint(0, n_in_nodes, offsets[-1].item(), dtype=fg_dtype)
>>>
>>> graph = make_bipartite_csc(offsets, indices, n_in_nodes)
>>> # call aggregator with `graph` here
)";

static constexpr const char* const MAKE_BIPART_CSC_CSR_DOC =
  R"(Creates a basic CSC graph representation for a bipartite graph
     from the tensors defining it including the reverse direction in CSR.

.. code-block:: python

    make_bipartite_csc_csr(
        offsets: device array, indices: device array,
        rev_offsets: device array, rev_indices: device array, n_in_nodes: int,
        ef_indices: Optional[device array], rev_edge_ids: Optional[device array],
    ) -> pylibcugraphops.bipartite_csc_int[32|64]

Parameters
----------
offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices. It's length is
    one more than the length of out_nodes.

indices : device array type
    Contains the adjacency lists of all the out nodes.

rev_offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices. It's length is
    one more than the length of in_nodes.

rev_indices : device array type
    Contains the adjacency lists of all the in nodes.

n_in_nodes : int
    number of input nodes (equals ``max(indices) + 1``)

ef_indices : device array type | None
    Contains edge feature indices for each of the above edge, pointing to that row in the
    edge embedding table. This can be used to avoid having to reorder edge features
    when we sort edges while creating a compressed sparse representation,
    or apply other transformations on the graph structure.

rev_edge_ids : device array type | None
    For every edge, this provides the mapping from each index into `rev_indices` to
    the corresponding edge-id in `indices`.

Returns
-------
graph_csc_csc
    An opaque python object representing the bipartite graph to be used in aggregators.
)";

static constexpr const char* const MAKE_BIPART_CSC_HG_DOC =
  R"(Creates a basic CSC graph representation for a heterogenous, bipartite graph
     from the tensors defining it.

.. code-block:: python

    make_bipartite_csc_hg(
        offsets: device array, indices: device array, n_node_types: int,
        n_edge_types: int, node_types: device array, edge_types: device array,
        ef_indices: Optional[device array]
    ) -> pylibcugraphops.bipartite_csc_hg_int[32|64]

offsets : device array type
    Monotonically increasing array with each location pointing to the start
    offset of the neighborhood of that node in the indices. It's length is
    one more than the length of out_nodes.

indices : device array type
    Contains the adjacency lists of all the out nodes.

n_node_types : int
    Number of node types in the graph.

n_edge_types : int
    Number of edge types in the graph.

node_types : device array type
    Node types of each node in the graph.

edge_types : device array type
    Edge types of each edge in the graph. Follows the same indexing
    as 'indices'.

ef_indices : device array type | None
    Contains edge feature indices for each of the above edge, pointing to that row in the
    edge embedding table. This can be used to avoid having to reorder edge features
    when we sort edges while creating CSR, or apply other transformations on the graph structure.

Returns
-------
graph_csc
    An opaque python object representing the bipartite graph to be used in aggregators.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_bipartite_csc_hg
>>>
>>> cupy.random.seed(0)
>>> n_in_nodes = 25
>>> n_out_nodes = 15
>>> avg_deg = 5
>>> fg_dtype = cupy.int32
>>> # use any distribution to generate n_edges (with non-negative values)
>>> n_edges = cupy.random.randint(0, 2 * avg_degree, n_in_nodes, dtype=fg_dtype)
>>> offsets = cupy.zeros(n_out_nodes+1, dtype=fg_dtype)
>>> offsets[1:] = cupy.cumsum(n_edges)
>>> indices = cupy.random.randint(0, n_in_nodes, offsets[-1].item(), dtype=fg_dtype)
>>>
>>> n_node_types = 3
>>> n_edge_types = 7
>>> in_node_types = cupy.random.randint(0, n_node_types, n_in_nodes, dtype=cupy.int32)
>>> out_node_types = cupy.random.randint(0, n_node_types, n_out_nodes, dtype=cupy.int32)
>>> edge_types = cupy.random.randint(0, n_edge_types, indices.shape[0], dtype=cupy.int32)
>>>
>>> graph = make_bipartite_csc_hg(offsets, indices, n_in_nodes,
...     n_node_types, n_edge_types, in_node_types, out_node_types, edge_types)
>>> # call aggregator with `graph` here
)";

static constexpr const char* const REVERSE_GRAPH_DOC =
  R"(Given a structure containing the original graph and empty
     fields for the reverse graph, populate `rev_offsets`, `rev_indcies`,
     and `rev_edge_ids` to form the reverse graph.

.. code-block:: python

    reverse_graph(
        graph: pylibcugraphops.fg_csr_rev_int[32|64] | pylibcugraphops.bipartite_csc_csr_int[32|64]
        workspace: device array, cub_workspace: device array | None,
        cub_workspace_size: int, stream_id: int = 0,
    ) -> int

graph : pylibcugraphops.fg_csr_rev_int[32|64] | pylibcugraphops.bipartite_csc_csr_int[32|64]
    The graph structure containing the original graph which will be populated with its reverse.

workspace : device array type
    workspace buffer used as scratch buffer:
    Shape: `graph.n_indices`

cub_workspace : device array type
    workspace buffer used as scratch buffer, initially of unknown size, pass as `nullptr`
    and the functionw will return the requires workspace size, allocate accordingly.

cub_workspace_size : int
    size of workspace buffer, if cub_workspace is passed as `nullptr` may be 0.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
