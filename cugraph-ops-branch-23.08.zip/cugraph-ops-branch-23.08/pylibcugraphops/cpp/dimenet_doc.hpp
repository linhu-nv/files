/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const RADIAL_BASIS_FWD_DOC =
  R"(Computes the forward pass for Dimenet++ radial basis features.

.. code-block:: python

    radial_basis_fwd(
        output_rbf: device array, output_sbf_rad: device array,
        input_vector: device array, input_w: device array
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_dist: number of distance dimensions. Must be 1.

Parameters
----------
output_rbf : device array type
    Device array containing the output radial basis features.
    Dimension is assumed to be [#edges, n_radial].

output_sbf_rad : device array type
    Device array containing the output radial basis part of
    spherical basis features.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_vector : device array type
    Device array containing the vector values (position of input node -
    position of output node + edge offsets) for each edge.
    Dimension is assumed to be [#edges, n_dist].

input_w : device array type
    Device array containing the input frequencies.
    Dimension is assumed to be [n_radial].
)";

static constexpr const char* const RADIAL_BASIS_BWD_DOC =
  R"(Computes the backward pass for Dimenet++ radial basis features.

.. code-block:: python

    radial_basis_bwd(
        output_grad_vector: device array, output_grad_w: device array,
        input_grad_rbf: device array, input_grad_sbf_rad: device array,
        input_vector: device array, input_w: device array
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_dist: number of distance dimensions. Must be 1.

Parameters
----------
output_grad_vector : device array type
    Device array containing the output gradients for input vector (of forward).
    Dimension is assumed to be [#edges, n_dist].

output_grad_w : device array type
    Device array containing the output gradients of input frequencies (of forward).
    Dimension is assumed to be [n_radial].

input_grad_rbf : device array type
    Device array containing the gradients on radial basis features from forward.
    Dimension is assumed to be [#edges, n_radial].

input_grad_sbf_rad : device array type
    Device array containing the gradients on radial part of spherical basis
    features from forward.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_vector : device array type
    Device array containing the vector values from forward.
    Dimension is assumed to be [#edges, n_dist].

input_w : device array type
    Device array containing the input frequencies from forward.
    Dimension is assumed to be [n_radial].
)";

static constexpr const char* const RADIAL_BASIS_BWD_BWD_DOC =
  R"(Computes the second-order backward pass for Dimenet++ radial basis features.

.. code-block:: python

    radial_basis_bwd_bwd(
        output_grad_grad_rbf: device array,
        output_grad_grad_sbf_rad: device array, output_grad_w: device array,
        input_grad_grad_vector: device array, input_grad_grad_w: device array,
        input_grad_rbf: device array, input_grad_sbf_rad: device array,
        input_vector: device array, input_w: device array
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_dist: number of distance dimensions. Must be 1.

Parameters
----------
output_grad_grad_rbf : device array type
    Device array containing the output gradients for gradients of
    radial basis features (of backward).
    Dimension is assumed to be [#edges, n_radial].

output_grad_grad_sbf_rad : device array type
    Device array containing the output gradients for gradients of
    radial part of spherical basis features (of backward).
    Dimension is assumed to be [#edges, n_spherical * n_radial].

output_grad_w : device array type
    Device array containing the output gradients of input frequencies (of backward).
    Dimension is assumed to be [n_radial].

input_grad_grad_vector : device array type
    Device array containing the gradients on gradients of vector values
    (from backward).
    Dimension is assumed to be [#edges, n_dist].

input_grad_grad_w : device array type
    Device array containing the gradients on gradients of frequencies
    (from backward).
    Dimension is assumed to be [n_radial].

input_grad_rbf : device array type
    Device array containing the gradients on radial basis features from forward.
    Dimension is assumed to be [#edges, n_radial].

input_grad_sbf_rad : device array type
    Device array containing the gradients on radial part of spherical basis
    features from forward.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_vector : device array type
    Device array containing the vector values from forward.
    Dimension is assumed to be [#edges, n_dist].

input_w : device array type
    Device array containing the input frequencies from forward.
    Dimension is assumed to be [n_radial].
)";

static constexpr const char* const AGG_EDGE_TO_EDGE_FWD_DOC =
  R"(Computes the forward pass for Dimenet++ interaction block aggregation layer.

.. code-block:: python

    agg_edge_to_edge_fwd(
        output_embedding: device array,
        input_vector: device array, input_rbf: device array,
        input_embedding: device array, input_weights: device array,
        coo_idx: device array, dst_offsets: device array,
        dst_edge_index: device array, mma_operation: pylibcugraphops.MMAOp,
        cuda_stream: int = 0
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_vec: number of vector/position dimensions. Must be 3.
    - n_emb: input/output embedding dimension. Assumed to be at most 64.
    - n_mid: we project the spherical basis features twice: once to feature
        dimension `n_mid`, and then to feature dimension `n_emb`.
        Assumed to be at most 8.

Parameters
----------
output_embedding : device array type
    Device array containing the output embeddings values.
    Dimension is assumed to be [#edges, n_emb].

input_vector : device array type
    Device array containing the vector values (position of input node -
    position of output node + edge offsets) for each edge.
    Dimension is assumed to be [#edges, n_vec].

input_rbf : device array type
    Device array containing the radial basis features used for calculating
    the spherical basis features.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_embedding : device array type
    Device array containing the input embeddings values.
    Dimension is assumed to be [#edges, n_emb].

input_weights : device array type
    Device array containing the weights used to project
    spherical basis features twice: first to "middle" dimension `n_mid`,
    then to embedding dimension `n_emb`. The weights are represented in a
    combined form with the second projection weights being transposed.
    Dimension is assumed to be [(n_spherical * n_radial) + n_emb, n_mid].

coo_idx : device array type
    Device array containing the COO index of the graph.
    Dimension is assumed to be [2, #edges].

dst_offsets : device array type
    Device array containing the CSR-like offsets of the destination nodes.
    Dimension is assumed to be [#nodes + 1].

dst_edge_index : device array type
    Device array containing the CSR-like indices of mapping the neighbors of
    destination nodes to edge IDs.
    Dimension is assumed to be [#edges].

mma_operation : pylibcugraphops.MMAOp
    MMA precision: pylibcugraphops.MMAOp.HighPrecision performs 3x TF32 operations
    while pylibcugraphops.MMAOp.LowPrecision performs 1x TF32 MMA operation

cuda_stream : int, default=0
    CUDA stream as an integer representing the raw pointer
)";

static constexpr const char* const AGG_EDGE_TO_EDGE_BWD_DOC =
  R"(Computes the backward pass for Dimenet++ interaction block aggregation layer.

.. code-block:: python

    agg_edge_to_edge_bwd(
        output_grad_rbf: device array,
        output_grad_embedding: device array, output_grad_weights: device array,
        input_vector: device array, input_rbf: device array,
        input_embedding: device array, input_grad_embedding: device array,
        input_weights: device array, coo_idx: device array, src_offsets: device array,
        mma_operation: pylibcugraphops.MMAOp, cuda_stream: int = 0
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_vec: number of vector/position dimensions. Must be 3.
    - n_emb: input/output embedding dimension. Assumed to be at most 64.
    - n_mid: we project the spherical basis features twice: once to feature
        dimension `n_mid`, and then to feature dimension `n_emb`.
        Assumed to be at most 8.

Parameters
----------
output_grad_rbf : device array type
    Device array containing the output gradients for radial basis features.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

output_grad_embedding : device array type
    Device array containing the output gradients for input embeddings
    (of forward).
    Dimension is assumed to be [#edges, n_emb].

output_grad_weights : device array type
    Device array containing the output gradients for weights.
    Dimension is assumed to be [(n_spherical * n_radial + n_emb), n_mid].

input_vector : device array type
    Device array containing the vector values from forward.
    Dimension is assumed to be [#edges, n_vec].

input_rbf : device array type
    Device array containing the radial basis features from forward.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_embedding : device array type
    Device array containing the input embeddings values from forward.
    Dimension is assumed to be [#edges, n_emb].

input_grad_embedding : device array type
    Device array containing the input gradients for output embeddings
    (of forward).
    Dimension is assumed to be [#edges, n_emb].

input_weights : device array type
    Device array containing the weights used in forward.
    Dimension is assumed to be [(n_spherical * n_radial + n_emb), n_mid].

coo_idx : device array type
    Device array containing the COO index of the graph.
    Dimension is assumed to be [2, #edges].

src_offsets : device array type
    Device array containing the CSR-like offsets of the source nodes.
    Dimension is assumed to be [#nodes + 1].

mma_operation : pylibcugraphops.MMAOp
    MMA precision: pylibcugraphops.MMAOp.HighPrecision performs 3x TF32 operations
    while pylibcugraphops.MMAOp.LowPrecision performs 1x TF32 MMA operation

cuda_stream : int, default=0
    CUDA stream as an integer representing the raw pointer
)";

static constexpr const char* const AGG_EDGE_TO_EDGE_BWD2_GRAD_DOC =
  R"(Computes the second-order backward pass for Dimenet++ interaction block
     aggregation layer with respect to the gradient of output embeddings.

.. code-block:: python

    agg_edge_to_edge_bwd2_grad(
        output_grad_grad_embedding: device array,
        input_vector: device array, input_rbf: device array,
        input_grad_grad_rbf: device array, input_embedding: device array,
        input_grad_grad_embedding: device array, input_weights: device array,
        coo_idx: device array, dst_offsets: device array, dst_edge_index: device array,
        mma_operation: pylibcugraphops.MMAOp, cuda_stream: int = 0
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_vec: number of vector/position dimensions. Must be 3.
    - n_emb: input/output embedding dimension. Assumed to be at most 64.
    - n_mid: we project the spherical basis features twice: once to feature
        dimension `n_mid`, and then to feature dimension `n_emb`.
        Assumed to be at most 8.

Parameters
----------
output_grad_grad_embedding : device array type
    Device array containing the output gradients for input gradients
    (from backward) of output embeddings (from forward).
    Dimension is assumed to be [#edges, n_emb].

input_vector : device array type
    Device array containing the vector values from forward.
    Dimension is assumed to be [#edges, n_vec].

input_rbf : device array type
    Device array containing the radial basis features from forward.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_grad_grad_rbf : device array type
    Device array containing the gradients for output gradients
    (from backward) of radial basis features (from forward).
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_embedding : device array type
    Device array containing the input embeddings values from forward.
    Dimension is assumed to be [#edges, n_emb].

input_grad_grad_embedding : device array type
    Device array containing the gradients for output gradients
    (from backward) of input embeddings (from forward).
    Dimension is assumed to be [#edges, n_emb].

input_weights : device array type
    Device array containing the weights used in forward.
    Dimension is assumed to be [(n_spherical * n_radial + n_emb), n_mid].

coo_idx : device array type
    Device array containing the COO index of the graph.
    Dimension is assumed to be [2, #edges].

dst_offsets : device array type
    Device array containing the CSR-like offsets of the destination nodes.
    Dimension is assumed to be [#nodes + 1].

dst_edge_index : device array type
    Device array containing the CSR-like indices of mapping the neighbors of
    destination nodes to edge IDs.
    Dimension is assumed to be [#edges].

mma_operation : pylibcugraphops.MMAOp
    MMA precision: pylibcugraphops.MMAOp.HighPrecision performs 3x TF32 operations
    while pylibcugraphops.MMAOp.LowPrecision performs 1x TF32 MMA operation

cuda_stream : int, default=0
    CUDA stream as an integer representing the raw pointer
)";

static constexpr const char* const AGG_EDGE_TO_EDGE_BWD2_MAIN_DOC =
  R"(Computes the second-order backward pass for Dimenet++ interaction block
     aggregation layer with respect to radial basis features, embeddings and
     weights as used in first backward pass.

.. code-block:: python

    agg_edge_to_edge_bwd2_main(
        output_grad_rbf_grad_embedding: device array,
        output_grad_embedding_grad_rbf: device array, output_grad_weights: device array,
        input_vector: device array, input_rbf: device array,
        input_grad_grad_rbf: device array, input_embedding: device array,
        input_grad_grad_embedding: device array, input_grad_embedding: device array,
        input_weights: device array, coo_idx: device array, src_offsets: device array,
        mma_operation: pylibcugraphops.MMAOp, cuda_stream: int = 0
    )

We define the following dimensions:
    - n_spherical: number of spherical basis functions. Must be 7.
    - n_radial: number of radial basis functions. Must be 6.
    - n_vec: number of vector/position dimensions. Must be 3.
    - n_emb: input/output embedding dimension. Assumed to be at most 64.
    - n_mid: we project the spherical basis features twice: once to feature
        dimension `n_mid`, and then to feature dimension `n_emb`.
        Assumed to be at most 8.

Parameters
----------
output_grad_rbf_grad_embedding : device array type
    Device array containing the output gradients for radial basis features
    (from backward).
    Dimension is assumed to be [#edges, n_spherical * n_radial].

output_grad_embedding_grad_rbf : device array type
    Device array containing the output gradients for input embeddings
    (from backward).
    Dimension is assumed to be [#edges, n_emb].

output_grad_weights : device array type
    Device array containing the output gradients for weights
    (from backward).
    Dimension is assumed to be [(n_spherical * n_radial + n_emb), n_mid].

input_vector : device array type
    Device array containing the vector values from forward.
    Dimension is assumed to be [#edges, n_vec].

input_rbf : device array type
    Device array containing the radial basis features from forward.
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_grad_grad_rbf : device array type
    Device array containing the gradients for output gradients
    (from backward) of radial basis features (from forward).
    Dimension is assumed to be [#edges, n_spherical * n_radial].

input_embedding : device array type
    Device array containing the input embeddings values from forward.
    Dimension is assumed to be [#edges, n_emb].

input_grad_grad_embedding : device array type
    Device array containing the gradients for output gradients
    (from backward) of input embeddings (from forward).
    Dimension is assumed to be [#edges, n_emb].

input_grad_embedding : device array type
    Device array containing the gradients for output embeddings
    (from backward).
    Dimension is assumed to be [#edges, n_emb].

input_weights : device array type
    Device array containing the weights used in forward.
    Dimension is assumed to be [(n_spherical * n_radial + n_emb), n_mid].

coo_idx : device array type
    Device array containing the COO index of the graph.
    Dimension is assumed to be [2, #edges].

src_offsets : device array type
    Device array containing the CSR-like offsets of the source nodes.
    Dimension is assumed to be [#nodes + 1].

mma_operation : pylibcugraphops.MMAOp
    MMA precision: pylibcugraphops.MMAOp.HighPrecision performs 3x TF32 operations
    while pylibcugraphops.MMAOp.LowPrecision performs 1x TF32 MMA operation

cuda_stream : int, default=0
    CUDA stream as an integer representing the raw pointer
)";
