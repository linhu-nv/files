/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "pool_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/pool.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
int64_t pool_fg_n2s_fwd(nb::object& output_embedding,
                        nb::object& input_embedding,
                        const graph::fg_csr<IdxT>& fg,
                        bool use_atomics,
                        nb::object& workspace,
                        int64_t workspace_size,
                        AggOpT aggregation_operation,
                        nb::object& output_extrema_location,
                        const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_out_shape[] = {1, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_in_shape[] = {fg.n_nodes, -1};
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);

  auto dim_out = dl_out.dim(1);
  auto dim_in  = dl_in.dim(1);

  if (dim_out != dim_in) {
    const auto& e = "Leading dimension of input and output embeddings do not match, got " +
                    std::to_string(dim_in) + " and " + std::to_string(dim_out) + " respectively.";
    throw nb::value_error(e.c_str());
  }

  // allow_none, i.e. if aggregation op is sum or mean
  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  // allow no workspace if we only call function to compute workspace size or if not needed
  auto allow_none_workspace  = (use_atomics && allow_none) || (workspace_size < 0);
  int64_t dl_out_pos_shape[] = {1, dim_in};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  int64_t dl_w_size[] = {-1};
  auto dl_w_space =
    assert_type_shape_strides(workspace, "workspace", DL_S64, 1, dl_w_size, allow_none_workspace);

  // if we need workspace, assert its size w.r.t. passed workspace array
  if (workspace_size >= 0) {
    auto allocated_workspace = dl_w_space.dim(0);
    if (allocated_workspace != workspace_size) {
      const auto& e = "size of passed 'workspace' array (" + std::to_string(allocated_workspace) +
                      ") does not match passed 'workspace_size' (" +
                      std::to_string(workspace_size) + ").";
      throw nb::value_error(e.c_str());
    }
  }

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::pool_fg_n2s_fwd(dl_out.template get_ptr<float>(),
                                  dl_out_pos.template maybe_ptr<IdxT>(),
                                  dl_in.template get_ptr<const float>(),
                                  static_cast<size_t>(dim_in),
                                  fg,
                                  aggregation_operation,
                                  use_atomics,
                                  dl_w_space.template maybe_ptr<int64_t>(),
                                  workspace_size,
                                  stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
  return workspace_size;
}

template <typename IdxT>
void pool_fg_n2s_bwd(nb::object& grad_input_embedding,
                     nb::object& grad_output_embedding,
                     const graph::fg_csr<IdxT>& fg,
                     AggOpT aggregation_operation,
                     nb::object& output_extrema_location,
                     const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_out_shape[] = {1, -1};
  auto dl_g_out          = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_embedding, "grad_output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_g_out.type();

  int64_t dl_in_shape[] = {fg.n_nodes, -1};
  auto dl_g_in          = assert_type_shape_strides(
    grad_input_embedding, "grad_input_embedding", exp_data_type, 2, dl_in_shape);

  auto dim_out = dl_g_out.dim(1);
  auto dim_in  = dl_g_in.dim(1);

  if (dim_out != dim_in) {
    const auto& e = "Leading dimension of input and output embeddings do not match, got " +
                    std::to_string(dim_in) + " and " + std::to_string(dim_out) + " respectively.";
    throw nb::value_error(e.c_str());
  }

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {1, dim_in};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::pool_fg_n2s_bwd(dl_g_in.template get_ptr<float>(),
                                  dl_g_out.template get_ptr<const float>(),
                                  dl_out_pos.template maybe_ptr<const IdxT>(),
                                  static_cast<size_t>(dim_in),
                                  fg,
                                  aggregation_operation,
                                  stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_pool_fg_n2s_fwd_bwd(nb::module_& m)
{
  m.def("pool_fg_n2s_fwd",
        &cugraph::ops::binding::pool_fg_n2s_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("input_embedding"),
        nb::arg("fg"),
        nb::arg("use_atomics"),
        nb::arg("workspace").none(),
        nb::arg("workspace_size"),
        nb::arg("aggregation_operation")          = cugraph::ops::AggOpT::kSum,
        nb::arg("output_extrema_location").none() = nb::none(),
        nb::arg("stream_id")                      = 0,
        nb::raw_doc(POOL_FG_N2S_FWD_DOC));

  m.def("pool_fg_n2s_bwd",
        &cugraph::ops::binding::pool_fg_n2s_bwd<IdxT>,
        nb::arg("grad_input_embedding"),
        nb::arg("grad_output_embedding"),
        nb::arg("fg"),
        nb::arg("aggregation_operation")          = cugraph::ops::AggOpT::kSum,
        nb::arg("output_extrema_location").none() = nb::none(),
        nb::arg("stream_id")                      = 0,
        nb::raw_doc(POOL_FG_N2S_BWD_DOC));
}

void init_pool_fg(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_pool_fg_n2s_fwd_bwd<int64_t>(m);
  init_pool_fg_n2s_fwd_bwd<int32_t>(m);
}
