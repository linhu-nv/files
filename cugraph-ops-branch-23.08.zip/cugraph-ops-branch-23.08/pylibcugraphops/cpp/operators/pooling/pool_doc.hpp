/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const POOL_FG_N2S_FWD_DOC =
  R"(Computes the forward pass for a pooling operation (pool_fg) aggregating
     node features from an entire graph of batch of graphs in a node-to-scalar
     reduction (n2s)

.. code-block:: python

    pool_fg_n2s_fwd(
        output_embedding: device array, input_embedding: device array,
        fg: pylibcugraphops.fg_csr_int[32|64], use_atomics: bool,
        workspace: Optional[device array], workspace_size: int64,
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> int

Parameters
----------
output_embedding : device array type
    Device array containing the output embeddings.
    Shape: ``(fg.n_nodes, dim)``.

input_embedding : device array type
    Device array containing the input embeddings.
    Shape: ``(fg.n_nodes, dim)``.

fg : opaque FG type
    FG used for the operation.

use_atomics : bool
    if true and ``aggregation_operation`` is ``AggOp.Sum`` or ``AggOp.Mean`` then
    operation uses (potentially) nondeterministic atomics but does not require
    a workspace.

workspace : device array type
    workspace required for intermediate computation steps.

workspace_size : int64
    required workspace size, if negative, then compute the workspace
    size and return this value.

aggregation_operation : AggOp
    The kind of aggregation operation, default is ``AggOp.Sum``.

output_extrema_location : optional device array type
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)``.

stream_id : int, default=0
    CUDA stream pointer as a python int.

Returns
-------
W_SIZE : int64
    the workspace size needed for this operation.
)";

static constexpr const char* const POOL_FG_N2S_BWD_DOC =
  R"(Computes the backward pass for a pooling operation (pool_fg) aggregating
     node features from an entire graph of batch of graphs in a node-to-scalar
     reduction (n2s)

.. code-block:: python

    pool_fg_n2s_bwd(
        grad_input_embedding: device array,
        grad_output_embedding: device array, fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type
    Device array containing the gradient on the input embeddings.
    Shape: ``(fg.n_nodes, dim)``.

grad_output : device array type
    Device array containing the gradient on the output embeddings.
    Shape: ``(fg.n_nodes, dim)``.

fg : opaque FG type
    FG used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : optional device array type
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)``.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
