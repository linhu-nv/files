/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const AGG_DMPNN_FG_E2E_FWD_DOC =
  R"(Computes the forward pass for D-MPNN-like full graph aggregation
     (agg_dmpnn_fg) using edge features in an edge-to-edge reduction scheme (e2e)

.. code-block:: python

    agg_dmpnn_fg_e2n_fwd(
        output_edge_embedding: device array, input_edge_embedding: device array,
        fg: pylibcugraphops.fg_csr_int[32|64], concat_own: bool, stream_id: int = 0
    )

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.

input_embedding : device array type
    Device array containing the input node embeddings.

fg : opaque CSR graph type
    graph used for the operation.

concat_own : bool
    concat an edge's input features to the aggregated output features

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const AGG_DMPNN_FG_E2E_BWD_DOC =
  R"(Computes the backward pass for D-MPNN-like full graph aggregation
     (agg_dmpnn_fg) using edge features in an edge-to-edge reduction scheme (e2e)

.. code-block:: python

    agg_dmpnn_fg_e2n_fwd(
        grad_input_edge_embedding: device array,
        grad_output_edge_embedding: device array,
        fg: pylibcugraphops.fg_csr_int[32|64], concat_own: bool, stream_id: int = 0
    )

Parameters
----------
grad_input_edge_embedding : device array type
    Device array containing the output gradient on input edge embeddings of forward.

grad_output_edge_embedding : device array type
    Device array containing the input gradient on output edge embeddings of forward.

fg : opaque CSR graph type
    graph used for the operation.

concat_own : bool
    concat an edge's input features to the aggregated output features

stream_id : int, default=0
    CUDA stream pointer as a python int
)";
