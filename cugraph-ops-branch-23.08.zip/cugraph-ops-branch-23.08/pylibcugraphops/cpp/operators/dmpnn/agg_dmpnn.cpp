/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "agg_dmpnn_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/agg_dmpnn.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
void agg_dmpnn_fg_e2e_fwd(nb::object& output_edge_embedding,
                          nb::object& input_edge_embedding,
                          const graph::fg_csr<IdxT>& fg,
                          bool concat_own,
                          const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_indices, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_edge_embedding, "output_edge_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_in_shape[] = {fg.n_indices, -1};
  auto dl_in            = assert_type_shape_strides(
    input_edge_embedding, "input_edge_embedding", exp_data_type, 2, dl_in_shape);

  auto dim_out = dl_out.dim(1);
  auto dim_in  = dl_in.dim(1);
  auto dim_exp = concat_own ? dim_in * 2 : dim_in;
  if (dim_out != dim_exp) {
    const auto& e = "Leading dimensions of input and output edge embeddings do not match, got " +
                    std::to_string(dim_in) + " as input and " + std::to_string(dim_out) +
                    " as output, but expected output of dimension " + std::to_string(dim_exp);
    throw nb::value_error(e.c_str());
  }

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_dmpnn_fg_e2e_fwd(dl_out.template get_ptr<float>(),
                                       dl_in.template get_ptr<const float>(),
                                       static_cast<size_t>(dim_in),
                                       fg,
                                       concat_own,
                                       stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void agg_dmpnn_fg_e2e_bwd(nb::object& grad_input_edge_embedding,
                          nb::object& grad_output_edge_embedding,
                          const graph::fg_csr<IdxT>& fg,
                          bool concat_own,
                          const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_indices, -1};
  auto dl_g_out          = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_edge_embedding, "grad_output_edge_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_g_out.type();

  int64_t dl_in_shape[] = {fg.n_indices, -1};
  auto dl_g_in          = assert_type_shape_strides(
    grad_input_edge_embedding, "grad_input_edge_embedding", exp_data_type, 2, dl_in_shape);

  auto dim_out = dl_g_out.dim(1);
  auto dim_in  = dl_g_in.dim(1);
  auto dim_exp = concat_own ? dim_in * 2 : dim_in;
  if (dim_out != dim_exp) {
    const auto& e = "Leading dimensions of input and output gradients do not match, got " +
                    std::to_string(dim_in) + " as input and " + std::to_string(dim_out) +
                    " as output, but expected output of dimension " + std::to_string(dim_exp);
    throw nb::value_error(e.c_str());
  }

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_dmpnn_fg_e2e_bwd(dl_g_in.template get_ptr<float>(),
                                       dl_g_out.template get_ptr<const float>(),
                                       static_cast<size_t>(dim_in),
                                       fg,
                                       concat_own,
                                       stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_agg_dmpnn_fg_e2e_fwd_bwd(nb::module_& m)
{
  m.def("agg_dmpnn_fg_e2e_fwd",
        &cugraph::ops::binding::agg_dmpnn_fg_e2e_fwd<IdxT>,
        nb::arg("output_edge_embedding"),
        nb::arg("input_edge_embedding"),
        nb::arg("fg"),
        nb::arg("concat_own"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(AGG_DMPNN_FG_E2E_FWD_DOC));

  m.def("agg_dmpnn_fg_e2e_bwd",
        &cugraph::ops::binding::agg_dmpnn_fg_e2e_bwd<IdxT>,
        nb::arg("grad_input_edge_embedding"),
        nb::arg("grad_output_edge_embedding"),
        nb::arg("fg"),
        nb::arg("concat_own"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(AGG_DMPNN_FG_E2E_BWD_DOC));
}

void init_agg_dmpnn_fg(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_agg_dmpnn_fg_e2e_fwd_bwd<int64_t>(m);
  init_agg_dmpnn_fg_e2e_fwd_bwd<int32_t>(m);
}
