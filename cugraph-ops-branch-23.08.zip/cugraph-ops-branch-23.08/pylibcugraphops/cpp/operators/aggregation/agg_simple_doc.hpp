/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const AGG_SIMPLE_FG_N2N_FWD_DOC =
  R"(Computes the forward pass for simple aggregation (agg_simple) using node features in an
     node-to-node reduction (n2n) on a full graph (fg).

.. code-block:: python

    agg_simple_fg_n2n_fwd(
        output_embedding: device array, input_embedding: device array,
        fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(fg.n_nodes, dim)``.

input_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(fg.n_nodes, dim)``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_SIMPLE_FG_N2N_BWD_DOC =
  R"(Computes the backward pass for a simple aggregation (agg_simple) using node features in an
     node-to-node reduction (n2n) on a full graph (fg).

.. code-block:: python

    agg_simple_fg_n2n_bwd(
        grad_input: device array,
        grad_output: device array, fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type
    Device array containing the output gradient on input embeddings of forward.
    Shape: ``(fg.n_nodes, dim)``.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape: ``(fg.n_nodes, dim)``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_SIMPLE_FG_E2N_FWD_DOC =
  R"(Computes the forward pass for simple aggregation (agg_simple) using edge features in an
     edge-to-node reduction (e2n) on a full graph (fg).

.. code-block:: python

    agg_simple_fg_e2n_fwd(
        output_embedding: device array, input_embedding: device array,
        fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(fg.n_nodes, dim)``.

input_embedding : device array type
    Device array containing the input edge embeddings.
    Shape: ``(n_edges, dim)``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_SIMPLE_FG_E2N_BWD_DOC =
  R"(Computes the backward pass for a simple aggregation (agg_simple) using edge features in an
     edge-to-node reduction (e2n) on a full graph (fg).

.. code-block:: python

    agg_simple_fg_e2n_bwd(
        grad_input: device array,
        grad_output: device array, fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type
    Device array containing the output gradient on input embeddings of forward.
    Shape: ``(n_edges, dim)``.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape: ``(fg.n_nodes, dim)``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_SIMPLE_FG_N2N_E2N_FWD_DOC =
  R"(Computes the forward pass for both a simple aggregation (agg_simple) using node features in an
     node-to-node reduction (n2n) and a simple aggregation using edge features in an
     edge-to-node reduction (e2n) on a full graph (fg) where the results are concatenated.

.. code-block:: python

    agg_simple_fg_n2n_e2n_fwd(
        output_embedding: device array, input_node_embedding: device array,
        input_edge_embedding: device array, fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(fg.n_nodes, dim_in_node + dim_in_edge)``.

input_node_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(fg.n_nodes, dim_in_node)``.

input_edge_embedding : device array type
    Device array containing the input edge embeddings.
    Shape: ``(n_edges, dim_in_edge)``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim_in_node + dim_in_edge)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_SIMPLE_FG_N2N_E2N_BWD_DOC =
  R"(Computes the backward pass for both a simple aggregation (agg_simple) using node features in an
     node-to-node reduction (n2n) and a simple aggregation using edge features in an
     edge-to-node reduction (e2n) on a full graph (fg) where the results are concatenated.

.. code-block:: python

    agg_simple_fg_n2n_e2n_bwd(
        grad_input_node: device array, grad_input_edge: device array,
        grad_output: device array, fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input_node : device array type
    Device array containing the output gradient on input node embeddings of forward.
    Shape: ``(fg.n_nodes, dim_in_node)``.

grad_input_edge : device array type
    Device array containing the output gradient on input edge embeddings of forward.
    Shape: ``(n_edges, dim_in_edge)``.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape: ``(fg.n_nodes, dim_in_node + dim_in_edge)``.

fg : The opaque CSR graph type
    graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim_in_node + dim_in_edge)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
