/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const AGG_CONCAT_MFG_N2N_FWD_DOC =
  R"(Computes the forward pass for simple aggregation using node features in an
     node-to-node reduction (n2n) on a message-flow graph (mfg) while concatenating the original
     features of output at the end (agg_concat).

.. code-block:: python

    agg_concat_mfg_n2n_fwd(
        output_embedding: device array, input_embedding: device array,
        mfg: pylibcugraphops.mfg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(mfg.n_out_nodes, 2 * dim_in)``.

input_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

mfg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(mfg.n_out_nodes, dim_in)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_CONCAT_MFG_N2N_BWD_DOC =
  R"(Computes the backward pass for a simple aggregation using node features in an
     node-to-node reduction (n2n) on a message-flow graph (mfg) while concatenating the original features of
     output nodes at the end (agg_concat).

.. code-block:: python

    agg_concat_mfg_n2n_bwd(
        grad_input: device array, grad_output: device array,
        mfg: pylibcugraphops.mfg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type
    Device array containing the output gradient on input embeddings of forward.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape: ``(mfg.n_out_nodes, 2 * dim_in)``.

mfg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(mfg.n_out_nodes, dim_in)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
