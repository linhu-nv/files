/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const AGG_WEIGHTED_FG_N2N_FWD_DOC =
  R"(Computes the forward pass for a weighted aggregation (agg_weighted) using node features in an
     node-to-node reduction (n2n). The reduction operates on a full graph (fg) and each incoming
     message is weighted according to its edge weight.

.. code-block:: python

    agg_weighted_fg_n2n_fwd(
        output_embedding: device array, input_embedding: device array,
        edge_weight: device array, fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, node_degree: Optional[device array],
        stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(fg.n_nodes, dim)``.

input_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(fg.n_nodes, dim)``.

edge_weight: device array type
    Device array containing the edge weights.
    Shape: ``(n_edges, )``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : optional device array type
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

node_degree : optional device array type
    Device array containing the in-node degree, i.e. the sum of incoming weights.
    This is required for mean aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, )`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_WEIGHTED_FG_N2N_BWD_DOC =
  R"(Computes the backward pass for a weighted aggregation (agg_weighted) using node features in an
     node-to-node reduction (n2n). The reduction operates on a full graph (fg) and each incoming
     message is weighted according to its edge weight.

.. code-block:: python

    agg_weighted_fg_n2n_bwd(
        grad_input: device array, grad_edge_weight: Optional[device array],
        grad_output: device array, edge_weight: device array, input_embedding: device array,
        fg: pylibcugraphops.fg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_embedding: Optional[device array] = None, output_extrema_location: Optional[device array] = None,
        node_degree: Optional[device array], stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type
    Device array containing the output gradient on input embeddings of forward.
    Shape: ``(fg.n_nodes, dim)``.

grad_edge_weight : device array type | None
    Device array containing the output gradient on edge weights. If ``None``, this is
    not calculated. If both this and ``grad_input`` are ``None``, no calculation is performed.
    Shape: ``(n_edges, )`` if set.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape: ``(fg.n_nodes, dim)``.

edge_weight: device array type
    Device array containing the edge weights.
    Shape: ``(n_edges, )``.

input_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(fg.n_nodes, dim)``.

fg : opaque CSR graph type
    The graph used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_embedding : device array type | None
    Device array containing the output node embeddings, only required for ``AggOp.Mean``,
    can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

output_extrema_location : optional device array type
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, dim)`` if set.

node_degree : optional device array type
    Device array containing the in-node degree, i.e. the sum of incoming weights.
    This is required for mean aggregation only, and can be ``None`` otherwise.
    Shape: ``(fg.n_nodes, )`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
