/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const AGG_SIMPLE_MFG_N2N_FWD_DOC =
  R"(Computes the forward pass for node-to-node MFG-based aggregation.

.. code-block:: python

    agg_simple_mfg_n2n_fwd(
        output_embedding: device array, input_embedding: device array,
        mfg: pylibcugraphops.mfg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output embeddings.
    Shape: ``(mfg.n_out_nodes, dim_in)``.

input_embedding : device array type
    Device array containing the input embeddings.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

mfg : opaque MFG type
    MFG used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(mfg.n_out_nodes, dim_in)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.

Examples
--------
>>> import cupy
>>> from pylibcugraphops.operators import agg_simple_mfg_n2n_fwd
>>> from pylibcugraphops import make_mfg_csr
...
>>> cupy.random.seed(0)
>>> n_out_nodes = 5
>>> n_in_nodes = n_out_nodes + 10
>>> sample_size = 4
>>> mfg_dtype = cupy.int32
>>> offsets = cupy.arange(0, sample_size*(1+n_out_nodes), sample_size, dtype=mfg_dtype)
>>> indices = cupy.random.randint(0, n_in_nodes, sample_size*n_out_nodes, dtype=mfg_dtype)
>>> out_nodes = cupy.arange(0, n_out_nodes, dtype=mfg_dtype)
>>> mfg = make_mfg_csr(out_nodes, offsets, indices, sample_size, n_in_nodes)
...
>>> dim = 2
>>> input_embedding = cupy.random.ranf((n_in_nodes, dim), dtype=cupy.float32)
>>> output_embedding = cupy.empty((n_out_nodes, dim), dtype=cupy.float32)
>>> agg_simple_mfg_n2n_fwd(output_embedding=output_embedding,
...                        input_embedding=input_embedding,
...                        mfg=mfg)
>>> output_embedding
array([[1.7227178, 2.1672485],
       [1.0122863, 2.1379762],
       [0.9409931, 2.387764 ],
       [1.0015422, 1.6581956],
       [1.2444825, 2.4060926]], dtype=float32)
)";

static constexpr const char* const AGG_SIMPLE_MFG_N2N_BWD_DOC =
  R"(Computes the backward pass for node-to-node MFG-based aggregation.

.. code-block:: python

    agg_simple_mfg_n2n_bwd(
        grad_input: device array, grad_output: device array,
        mfg: pylibcugraphops.mfg_csr_int[32|64],
        aggregation_operation: pylibcugraphops.operators.AggOp = pylibcugraphops.operators.AggOp.Sum,
        output_extrema_location: Optional[device array] = None, stream_id: int = 0
    )

Parameters
----------
grad_input : device array type
    Device array containing the gradient on the input embeddings.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

grad_output : device array type
    Device array containing the gradient on the output embeddings.
    Shape: ``(mfg.n_out_nodes, dim_in)``.

mfg : opaque MFG type
    MFG used for the operation.

aggregation_operation : AggOp, default=AggOp.Sum
    The kind of aggregation operation.

output_extrema_location : device array type | None
    Device array containing the location of the min/max embeddings.
    This is required for min/max aggregation only, and can be ``None`` otherwise.
    Shape: ``(mfg.n_out_nodes, dim_in)`` if set.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
