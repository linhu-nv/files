/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "agg_concat_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/agg_concat.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>
#include <limits>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
void agg_concat_fg_n2n_fwd(nb::object& output_embedding,
                           nb::object& input_embedding,
                           const graph::fg_csr<IdxT>& fg,
                           AggOpT aggregation_operation,
                           nb::object& output_extrema_location,
                           const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_in_shape[] = {fg.n_nodes, -1};
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);

  auto dim_out = dl_out.dim(1);
  auto dim_in  = dl_in.dim(1);
  if (dim_out != 2 * dim_in) {
    const auto& e = "Leading dimensions of input and output embeddings do not match, got " +
                    std::to_string(dim_in) + " (which would imply " + std::to_string(2 * dim_in) +
                    " as dim_out)" + " and " + std::to_string(dim_out) + " respectively.";
    throw nb::value_error(e.c_str());
  }

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {fg.n_nodes, dim_in};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_concat_fg_n2n_fwd(dl_out.template get_ptr<float>(),
                                        dl_out_pos.template maybe_ptr<IdxT>(),
                                        dl_in.template get_ptr<const float>(),
                                        dl_in.template get_ptr<const float>(),
                                        dim_in,
                                        dim_in,
                                        fg,
                                        aggregation_operation,
                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::agg_concat_fg_n2n_fwd(dl_out.template get_ptr<__nv_bfloat16>(),
                                          dl_out_pos.template maybe_ptr<IdxT>(),
                                          dl_in.template get_ptr<const __nv_bfloat16>(),
                                          dl_in.template get_ptr<const __nv_bfloat16>(),
                                          dim_in,
                                          dim_in,
                                          fg,
                                          aggregation_operation,
                                          stream);
    } else {
      cugraph::ops::agg_concat_fg_n2n_fwd(dl_out.template get_ptr<__half>(),
                                          dl_out_pos.template maybe_ptr<IdxT>(),
                                          dl_in.template get_ptr<const __half>(),
                                          dl_in.template get_ptr<const __half>(),
                                          dim_in,
                                          dim_in,
                                          fg,
                                          aggregation_operation,
                                          stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void agg_concat_fg_n2n_bwd(nb::object& grad_input,
                           nb::object& grad_output,
                           const graph::fg_csr<IdxT>& fg,
                           AggOpT aggregation_operation,
                           nb::object& output_extrema_location,
                           const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_g_out_shape[] = {fg.n_nodes, -1};
  auto dl_g_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output, "grad_output", DL_BF16_FP16_32_64, 2, dl_g_out_shape);
  const auto& exp_data_type = dl_g_out.type();

  int64_t dl_g_in_shape[] = {fg.n_nodes, -1};
  auto dl_g_in =
    assert_type_shape_strides(grad_input, "grad_input", exp_data_type, 2, dl_g_in_shape, true);

  if (!dl_g_in.has_ptr()) {
    // nothing to compute
    return;
  }

  auto dim_out = dl_g_out.dim(1);
  auto dim_in  = dl_g_in.dim(1);
  if (dim_out != 2 * dim_in) {
    const auto& e =
      "Leading dimensions for gradients of input and output embeddings do not match, got " +
      std::to_string(dim_in) + " (which would imply " + std::to_string(2 * dim_in) +
      " as dim_out)" + " and " + std::to_string(dim_out) + " respectively.";
    throw nb::value_error(e.c_str());
  }

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {fg.n_nodes, dim_in};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_concat_fg_n2n_bwd(dl_g_in.template get_ptr<float>(),
                                        dl_g_in.template get_ptr<float>(),
                                        dl_g_out.template get_ptr<float>(),
                                        dl_out_pos.template maybe_ptr<const IdxT>(),
                                        dim_in,
                                        dim_in,
                                        fg,
                                        aggregation_operation,
                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::agg_concat_fg_n2n_bwd(dl_g_in.template get_ptr<__nv_bfloat16>(),
                                          dl_g_in.template get_ptr<__nv_bfloat16>(),
                                          dl_g_out.template get_ptr<__nv_bfloat16>(),
                                          dl_out_pos.template maybe_ptr<const IdxT>(),
                                          dim_in,
                                          dim_in,
                                          fg,
                                          aggregation_operation,
                                          stream);
    } else {
      cugraph::ops::agg_concat_fg_n2n_bwd(dl_g_in.template get_ptr<__half>(),
                                          dl_g_in.template get_ptr<__half>(),
                                          dl_g_out.template get_ptr<__half>(),
                                          dl_out_pos.template maybe_ptr<const IdxT>(),
                                          dim_in,
                                          dim_in,
                                          fg,
                                          aggregation_operation,
                                          stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void agg_concat_fg_e2n_fwd(nb::object& output_embedding,
                           nb::object& input_edge_embedding,
                           nb::object& input_node_embedding,
                           const graph::fg_csr<IdxT>& fg,
                           AggOpT aggregation_operation,
                           nb::object& output_extrema_location,
                           const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE*/ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_in_edge_shape[] = {fg.n_indices, -1};
  auto dl_in_edge            = assert_type_shape_strides(
    input_edge_embedding, "input_edge_embedding", exp_data_type, 2, dl_in_edge_shape, true);

  int64_t dl_in_node_shape[] = {fg.n_nodes, -1};
  auto dl_in_node            = assert_type_shape_strides(
    input_node_embedding, "input_node_embedding", exp_data_type, 2, dl_in_node_shape, true);

  auto dim_out     = dl_out.dim(1);
  auto dim_in_edge = dl_in_edge.dim(1);
  auto dim_in_node = dl_in_node.dim(1);
  auto dim_sum     = dim_in_edge + dim_in_node;

  if (dim_out != dim_sum) {
    const auto& e =
      "Leading dimensions of gradients on input and output embeddings do not match, got " +
      std::to_string(dim_sum) + "[" + std::to_string(dim_in_node) + " + " +
      std::to_string(dim_in_edge) + "]" + " and " + std::to_string(dim_out) + " respectively.";
    throw nb::value_error(e.c_str());
  }

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {fg.n_nodes, dim_in_edge};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_concat_fg_e2n_fwd(dl_out.template get_ptr<float>(),
                                        dl_out_pos.template maybe_ptr<IdxT>(),
                                        dl_in_edge.template get_ptr<float>(),
                                        dl_in_node.template get_ptr<float>(),
                                        dim_in_edge,
                                        dim_in_node,
                                        fg,
                                        aggregation_operation,
                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::agg_concat_fg_e2n_fwd(dl_out.template get_ptr<__nv_bfloat16>(),
                                          dl_out_pos.template maybe_ptr<IdxT>(),
                                          dl_in_edge.template get_ptr<__nv_bfloat16>(),
                                          dl_in_node.template get_ptr<__nv_bfloat16>(),
                                          dim_in_edge,
                                          dim_in_node,
                                          fg,
                                          aggregation_operation,
                                          stream);
    } else {
      cugraph::ops::agg_concat_fg_e2n_fwd(dl_out.template get_ptr<__half>(),
                                          dl_out_pos.template maybe_ptr<IdxT>(),
                                          dl_in_edge.template get_ptr<__half>(),
                                          dl_in_node.template get_ptr<__half>(),
                                          dim_in_edge,
                                          dim_in_node,
                                          fg,
                                          aggregation_operation,
                                          stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void agg_concat_fg_e2n_bwd(nb::object& grad_edge_embedding,
                           nb::object& grad_node_embedding,
                           nb::object& grad_output_embedding,
                           const graph::fg_csr<IdxT>& fg,
                           size_t dim_edge,
                           size_t dim_node,
                           AggOpT aggregation_operation,
                           nb::object& output_extrema_location,
                           const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_g_out_shape[] = {fg.n_nodes, static_cast<int64_t>(dim_edge + dim_node)};
  auto dl_g_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_embedding, "grad_output_embedding", DL_BF16_FP16_32_64, 2, dl_g_out_shape);
  const auto& exp_data_type = dl_g_out.type();

  int64_t dl_g_in_edge_shape[] = {fg.n_indices, static_cast<int64_t>(dim_edge)};
  auto dl_g_in_edge            = assert_type_shape_strides(
    grad_edge_embedding, "grad_edge_embedding", exp_data_type, 2, dl_g_in_edge_shape);

  int64_t dl_g_in_node_shape[] = {fg.n_nodes, static_cast<int64_t>(dim_node)};
  auto dl_g_in_node            = assert_type_shape_strides(
    grad_node_embedding, "grad_node_embedding", exp_data_type, 2, dl_g_in_node_shape);

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {fg.n_nodes, static_cast<int64_t>(dim_edge)};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_concat_fg_e2n_bwd(dl_g_in_edge.template maybe_ptr<float>(),
                                        dl_g_in_node.template maybe_ptr<float>(),
                                        dl_g_out.template get_ptr<const float>(),
                                        dl_out_pos.template maybe_ptr<const IdxT>(),
                                        dim_edge,
                                        dim_node,
                                        fg,
                                        aggregation_operation,
                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::agg_concat_fg_e2n_bwd(dl_g_in_edge.template maybe_ptr<__nv_bfloat16>(),
                                          dl_g_in_node.template maybe_ptr<__nv_bfloat16>(),
                                          dl_g_out.template get_ptr<const __nv_bfloat16>(),
                                          dl_out_pos.template maybe_ptr<const IdxT>(),
                                          dim_edge,
                                          dim_node,
                                          fg,
                                          aggregation_operation,
                                          stream);
    } else {
      cugraph::ops::agg_concat_fg_e2n_bwd(dl_g_in_edge.template maybe_ptr<__half>(),
                                          dl_g_in_node.template maybe_ptr<__half>(),
                                          dl_g_out.template get_ptr<const __half>(),
                                          dl_out_pos.template maybe_ptr<const IdxT>(),
                                          dim_edge,
                                          dim_node,
                                          fg,
                                          aggregation_operation,
                                          stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void agg_concat_fg_n2n_e2n_fwd(nb::object& output_embedding,
                               nb::object& input_node_embedding,
                               nb::object& input_edge_embedding,
                               const graph::fg_csr<IdxT>& fg,
                               AggOpT aggregation_operation,
                               nb::object& output_extrema_location,
                               const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPe*/ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_in_node_shape[] = {fg.n_nodes, -1};
  auto dl_in_node            = assert_type_shape_strides(
    input_node_embedding, "input_node_embedding", exp_data_type, 2, dl_in_node_shape);

  int64_t dl_in_edge_shape[] = {fg.n_indices, -1};
  auto dl_in_edge            = assert_type_shape_strides(
    input_edge_embedding, "input_edge_embedding", exp_data_type, 2, dl_in_edge_shape);

  auto dim_out     = dl_out.dim(1);
  auto dim_in_node = dl_in_node.dim(1);
  auto dim_in_edge = dl_in_edge.dim(1);
  auto dim_sum     = 2 * dim_in_node + dim_in_edge;
  if (dim_out != dim_sum) {
    const auto& e =
      "Leading dimensions for gradients of input nodes and input edges and "
      "output embeddings do not match, got " +
      std::to_string(dim_sum) + " [" + std::to_string(dim_in_node) + " + " +
      std::to_string(dim_in_edge) + std::to_string(dim_in_node) + " ]" + " and " +
      std::to_string(dim_out) + " respectively ";
    throw nb::value_error(e.c_str());
  }

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {fg.n_nodes, dim_in_node + dim_in_edge};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_concat_fg_n2n_e2n_fwd(dl_out.template get_ptr<float>(),
                                            dl_out_pos.template maybe_ptr<IdxT>(),
                                            dl_in_node.template get_ptr<const float>(),
                                            dl_in_edge.template get_ptr<const float>(),
                                            dl_in_node.template get_ptr<const float>(),
                                            dim_in_node,
                                            dim_in_edge,
                                            dim_in_node,
                                            fg,
                                            aggregation_operation,
                                            stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::agg_concat_fg_n2n_e2n_fwd(dl_out.template get_ptr<__nv_bfloat16>(),
                                              dl_out_pos.template maybe_ptr<IdxT>(),
                                              dl_in_node.template get_ptr<const __nv_bfloat16>(),
                                              dl_in_edge.template get_ptr<const __nv_bfloat16>(),
                                              dl_in_node.template get_ptr<const __nv_bfloat16>(),
                                              dim_in_node,
                                              dim_in_edge,
                                              dim_in_node,
                                              fg,
                                              aggregation_operation,
                                              stream);
    } else {
      cugraph::ops::agg_concat_fg_n2n_e2n_fwd(dl_out.template get_ptr<__half>(),
                                              dl_out_pos.template maybe_ptr<IdxT>(),
                                              dl_in_node.template get_ptr<const __half>(),
                                              dl_in_edge.template get_ptr<const __half>(),
                                              dl_in_node.template get_ptr<const __half>(),
                                              dim_in_node,
                                              dim_in_edge,
                                              dim_in_node,
                                              fg,
                                              aggregation_operation,
                                              stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void agg_concat_fg_n2n_e2n_bwd(nb::object& grad_input_node,
                               nb::object& grad_input_edge,
                               nb::object& grad_output,
                               const graph::fg_csr<IdxT>& fg,
                               size_t dim_node,
                               size_t dim_edge,
                               AggOpT aggregation_operation,
                               nb::object& output_extrema_location,
                               const uintptr_t& stream_id)
{
  static constexpr DLDataType IDX_TYPE = get_dl_data_type<IdxT>();

  int64_t dl_g_out_shape[] = {fg.n_nodes, static_cast<int64_t>(dim_node + dim_edge + dim_node)};
  auto dl_g_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output, "grad_output", DL_BF16_FP16_32_64, 2, dl_g_out_shape);
  const auto& exp_data_type = dl_g_out.type();

  int64_t dl_g_in_node_shape[] = {fg.n_nodes, static_cast<int64_t>(dim_node)};
  auto dl_g_in_node            = assert_type_shape_strides(
    grad_input_node, "grad_input_node", exp_data_type, 2, dl_g_in_node_shape, true);

  int64_t dl_g_in_edge_shape[] = {fg.n_indices, static_cast<int64_t>(dim_edge)};
  auto dl_g_in_edge            = assert_type_shape_strides(
    grad_input_edge, "grad_input_edge", exp_data_type, 2, dl_g_in_edge_shape, true);

  auto allow_none = aggregation_operation == AggOpT::kSum || aggregation_operation == AggOpT::kMean;
  int64_t dl_out_pos_shape[] = {fg.n_nodes, static_cast<int64_t>(dim_node + dim_edge)};
  auto dl_out_pos            = assert_type_shape_strides(
    output_extrema_location, "output_extrema_location", IDX_TYPE, 2, dl_out_pos_shape, allow_none);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_concat_fg_n2n_e2n_bwd(dl_g_in_node.template maybe_ptr<float>(),
                                            dl_g_in_edge.template maybe_ptr<float>(),
                                            dl_g_in_node.template maybe_ptr<float>(),
                                            dl_g_out.template get_ptr<const float>(),
                                            dl_out_pos.template maybe_ptr<const IdxT>(),
                                            dim_node,
                                            dim_edge,
                                            dim_node,
                                            fg,
                                            aggregation_operation,
                                            stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::agg_concat_fg_n2n_e2n_bwd(dl_g_in_node.template maybe_ptr<__nv_bfloat16>(),
                                              dl_g_in_edge.template maybe_ptr<__nv_bfloat16>(),
                                              dl_g_in_node.template maybe_ptr<__nv_bfloat16>(),
                                              dl_g_out.template get_ptr<const __nv_bfloat16>(),
                                              dl_out_pos.template maybe_ptr<const IdxT>(),
                                              dim_node,
                                              dim_edge,
                                              dim_node,
                                              fg,
                                              aggregation_operation,
                                              stream);
    } else {
      cugraph::ops::agg_concat_fg_n2n_e2n_bwd(dl_g_in_node.template maybe_ptr<__half>(),
                                              dl_g_in_edge.template maybe_ptr<__half>(),
                                              dl_g_in_node.template maybe_ptr<__half>(),
                                              dl_g_out.template get_ptr<const __half>(),
                                              dl_out_pos.template maybe_ptr<const IdxT>(),
                                              dim_node,
                                              dim_edge,
                                              dim_node,
                                              fg,
                                              aggregation_operation,
                                              stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_agg_concat_fg_n2n_fwd_bwd(nb::module_& m)
{
  m.def("agg_concat_fg_n2n_fwd",
        &cugraph::ops::binding::agg_concat_fg_n2n_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("input_embedding"),
        nb::arg("fg"),
        nb::arg("aggregation_operation") = cugraph::ops::AggOpT::kSum,
        nb::arg("out_pos").none()        = nb::none(),
        nb::arg("stream_id")             = 0,
        nb::raw_doc(AGG_CONCAT_FG_N2N_FWD_DOC));

  m.def("agg_concat_fg_n2n_bwd",
        &cugraph::ops::binding::agg_concat_fg_n2n_bwd<IdxT>,
        nb::arg("grad_input"),
        nb::arg("grad_output"),
        nb::arg("fg"),
        nb::arg("aggregation_operation") = cugraph::ops::AggOpT::kSum,
        nb::arg("out_pos").none()        = nb::none(),
        nb::arg("stream_id")             = 0,
        nb::raw_doc(AGG_CONCAT_FG_N2N_BWD_DOC));
}

template <typename IdxT>
void init_agg_concat_fg_e2n_fwd_bwd(nb::module_& m)
{
  m.def("agg_concat_fg_e2n_fwd",
        &cugraph::ops::binding::agg_concat_fg_e2n_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("input_edge_embedding"),
        nb::arg("input_node_embedding"),
        nb::arg("fg"),
        nb::arg("aggregation_operation") = cugraph::ops::AggOpT::kSum,
        nb::arg("out_pos").none()        = nb::none(),
        nb::arg("stream_id")             = 0,
        nb::raw_doc(AGG_CONCAT_FG_E2N_FWD_DOC));

  m.def("agg_concat_fg_e2n_bwd",
        &cugraph::ops::binding::agg_concat_fg_e2n_bwd<IdxT>,
        nb::arg("grad_input_edge"),
        nb::arg("grad_input_node"),
        nb::arg("grad_output"),
        nb::arg("fg"),
        nb::arg("dim_edge"),
        nb::arg("dim_node"),
        nb::arg("aggregation_operation") = cugraph::ops::AggOpT::kSum,
        nb::arg("out_pos").none()        = nb::none(),
        nb::arg("stream_id")             = 0,
        nb::raw_doc(AGG_CONCAT_FG_E2N_BWD_DOC));
}

template <typename IdxT>
void init_agg_concat_fg_n2n_e2n_fwd_bwd(nb::module_& m)
{
  m.def("agg_concat_fg_n2n_e2n_fwd",
        &cugraph::ops::binding::agg_concat_fg_n2n_e2n_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("input_node_embedding"),
        nb::arg("input_edge_embedding"),
        nb::arg("fg"),
        nb::arg("aggregation_operation") = cugraph::ops::AggOpT::kSum,
        nb::arg("out_pos").none()        = nb::none(),
        nb::arg("stream_id")             = 0,
        nb::raw_doc(AGG_CONCAT_FG_N2N_E2N_FWD_DOC));

  m.def("agg_concat_fg_n2n_e2n_bwd",
        &cugraph::ops::binding::agg_concat_fg_n2n_e2n_bwd<IdxT>,
        nb::arg("grad_input_node"),
        nb::arg("grad_input_edge"),
        nb::arg("grad_output"),
        nb::arg("fg"),
        nb::arg("dim_node"),
        nb::arg("dim_edge"),
        nb::arg("aggregation_operation") = cugraph::ops::AggOpT::kSum,
        nb::arg("out_pos").none()        = nb::none(),
        nb::arg("stream_id")             = 0,
        nb::raw_doc(AGG_CONCAT_FG_N2N_E2N_BWD_DOC));
}

void init_agg_concat_fg(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_agg_concat_fg_n2n_fwd_bwd<int64_t>(m);
  init_agg_concat_fg_n2n_fwd_bwd<int32_t>(m);

  init_agg_concat_fg_e2n_fwd_bwd<int64_t>(m);
  init_agg_concat_fg_e2n_fwd_bwd<int32_t>(m);

  init_agg_concat_fg_n2n_e2n_fwd_bwd<int64_t>(m);
  init_agg_concat_fg_n2n_e2n_fwd_bwd<int32_t>(m);
}
