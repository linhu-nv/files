/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const UPDATE_EFEAT_E2E_CONCAT_FWD_DOC =
  R"(Computes the forward pass for an operation which concatenates
     edge features, and the node features of the source and destination
     nodes of each each in an edge-to-edge operation.

.. code-block:: python

    update_efeat_static_e2e_concat_fwd(
        output_edge_embedding: device array,
        input_edge_embedding: Optional[device array],
        input_node_embedding: Optional[device array],
        graph: pylibcugraphops.fg_csr_int[32|64],
        use_source_emb: bool, use_target_emb: bool,
        stream_id: int = 0
    )

Parameters
----------
output_edge_embedding : device array type
    Device array containing the output edge embeddings.

input_edge_embedding : device array type | None
    Device array containing the input edge embeddings, ignored if passed as None

input_node_embedding : device array type | None
    Device array containing the input source node embeddings.

graph : opaque CSC graph type
    graph used for the operation.

use_source_emb : bool
    whether to use node embeddings indexed by indices of source nodes

use_target_emb : bool
    whether to use node embeddings indexed by indices of source nodes

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const UPDATE_EFEAT_E2E_SUM_FWD_DOC =
  R"(Computes the forward pass for an operation which sums
     edge features, and the node features of the source and destination
     nodes of each each in an edge-to-edge operation.

.. code-block:: python

    update_efeat_static_e2e_concat_fwd(
        output_edge_embedding: device array,
        input_edge_embedding: Optional[device array],
        input_node_embedding: Optional[device array],
        graph: pylibcugraphops.fg_csr_int[32|64],
        use_source_emb: bool, use_target_emb: bool, stream_id: int = 0
    )

Parameters
----------
output_edge_embedding : device array type
    Device array containing the output edge embeddings.

input_edge_embedding : device array type | None
    Device array containing the input edge embeddings, ignored if passed as None

input_node_embedding : device array type | None
    Device array containing the input node embeddings.

graph : opaque CSC graph type
    graph used for the operation.

use_source_emb : bool
    whether to use node embeddings indexed by indices of source nodes

use_target_emb : bool
    whether to use node embeddings indexed by indices of source nodes

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const UPDATE_EFEAT_E2E_CONCAT_BWD_DOC =
  R"(Computes the backward pass for an operation which concatenates
     edge features, and the node features of the source and destination
     nodes of each each in an edge-to-edge operation.

.. code-block:: python

    update_efeat_static_e2e_concat_bwd(
        grad_input_edge_embedding: Optional[device array],
        grad_input_src_node_embedding: Optional[device array],
        grad_input_dst_node_embedding: Optional[device array],
        grad_output_edge_embedding: device array, graph: pylibcugraphops.fg_csr_int[32|64],
        dim_edge: int, dim_node: int, use_source_emb: bool, use_target_emb: bool,
        stream_id: int = 0
    )

Parameters
----------
grad_input_edge_embedding : device array type | None
    Device array containing the gradient on the input edge embeddings which
    is not computed if array is passed as None.

grad_input_node_embedding : device array type | None
    Device array containing the gradient on the input source node embeddings which
    is not computed if array is passed as None.

grad_output_edge_embedding : device array type
    Device array containing the gradient on the output edge embeddings.

graph : opaque CSC graph type
    graph used for the operation.

dim_edge : int
    Dimension of input edge embeddings from the forward pass which can be 0 if the
    corresponding array has been passed as None during the forward pass.

dim_node : int
    Dimension of input source node embeddings from the forward pass.

use_source_emb : bool
    whether to use node embeddings indexed by indices of source nodes

use_target_emb : bool
    whether to use node embeddings indexed by indices of source nodes

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const UPDATE_EFEAT_E2E_SUM_BWD_DOC =
  R"(Computes the backward pass for an operation which sums
     edge features, and the node features of the source and destination
     nodes of each each in an edge-to-edge operation.

.. code-block:: python

    update_efeat_static_e2e_sum_bwd(
        grad_input_edge_embedding: Optional[device array],
        grad_input_node_embedding: Optional[device array],
        grad_output_edge_embedding: device array, graph: pylibcugraphops.fg_csr_int[32|64],
        dim_edge: int, use_source_emb: bool, use_target_emb: bool, stream_id: int = 0
    )

Parameters
----------
grad_input_edge_embedding : device array type | None
    Device array containing the gradient on the input edge embeddings which is
    not computed if passed as None

grad_input_node_embedding : device array type | None
    Device array containing the gradient on the input node embeddings which
    is not computed if passed as None

grad_output_edge_embedding : device array type
    Device array containing the gradient on the output edge embeddings.

graph : opaque CSC graph type
    graph used for the operation.

dim_edge : int
    Dimension of output edge embeddings from the forward pass.

use_source_emb : bool
    whether to use node embeddings indexed by indices of source nodes

use_target_emb : bool
    whether to use node embeddings indexed by indices of source nodes

stream_id : int, default=0
    CUDA stream pointer as a python int
)";
