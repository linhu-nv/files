/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "update_efeat_bipartite_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/update_efeat_bipartite.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
void update_efeat_bipartite_e2e_concat_fwd(nb::object& output_edge_embedding,
                                           nb::object& input_edge_embedding,
                                           nb::object& input_src_node_embedding,
                                           nb::object& input_dst_node_embedding,
                                           const graph::bipartite_csc<IdxT>& graph,
                                           const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {graph.n_indices, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_edge_embedding, "output_edge_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto& exp_data_type = dl_out.type();

  int64_t dl_in_shape[] = {graph.n_indices, -1};
  auto dl_in_edge       = assert_type_shape_strides(
    input_edge_embedding, "input_edge_embedding", exp_data_type, 2, dl_in_shape, true);

  int64_t dl_in_src_shape[] = {graph.n_in_nodes, -1};
  auto dl_in_src            = assert_type_shape_strides(
    input_src_node_embedding, "input_src_node_embedding", exp_data_type, 2, dl_in_src_shape, true);

  int64_t dl_in_dst_shape[] = {graph.n_out_nodes, -1};
  auto dl_in_dst            = assert_type_shape_strides(
    input_dst_node_embedding, "input_dst_node_embedding", exp_data_type, 2, dl_in_dst_shape, true);

  auto dim_out          = dl_out.dim(1);
  auto dim_out_expected = dl_in_edge.dim(1) + dl_in_src.dim(1) + dl_in_dst.dim(1);
  if (dim_out != dim_out_expected) {
    const auto& e =
      "Leading dimensions of input and output edge embeddings do not match, "
      "expected output with dimension " +
      std::to_string(dim_out_expected) + " but got " + std::to_string(dim_out);
    throw nb::value_error(e.c_str());
  }

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::update_efeat_bipartite_e2e_concat_fwd(
      dl_out.template get_ptr<float>(),
      dl_in_edge.template maybe_ptr<const float>(),
      dl_in_src.template maybe_ptr<const float>(),
      dl_in_dst.template maybe_ptr<const float>(),
      graph,
      static_cast<size_t>(dl_in_edge.dim(1)),
      static_cast<size_t>(dl_in_src.dim(1)),
      static_cast<size_t>(dl_in_dst.dim(1)),
      stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::update_efeat_bipartite_e2e_concat_fwd(
        dl_out.template get_ptr<__nv_bfloat16>(),
        dl_in_edge.template maybe_ptr<const __nv_bfloat16>(),
        dl_in_src.template maybe_ptr<const __nv_bfloat16>(),
        dl_in_dst.template maybe_ptr<const __nv_bfloat16>(),
        graph,
        static_cast<size_t>(dl_in_edge.dim(1)),
        static_cast<size_t>(dl_in_src.dim(1)),
        static_cast<size_t>(dl_in_dst.dim(1)),
        stream);
    } else {
      cugraph::ops::update_efeat_bipartite_e2e_concat_fwd(
        dl_out.template get_ptr<__half>(),
        dl_in_edge.template maybe_ptr<const __half>(),
        dl_in_src.template maybe_ptr<const __half>(),
        dl_in_dst.template maybe_ptr<const __half>(),
        graph,
        static_cast<size_t>(dl_in_edge.dim(1)),
        static_cast<size_t>(dl_in_src.dim(1)),
        static_cast<size_t>(dl_in_dst.dim(1)),
        stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename GraphT>
void update_efeat_bipartite_e2e_concat_bwd(nb::object& grad_input_edge_embedding,
                                           nb::object& grad_input_src_node_embedding,
                                           nb::object& grad_input_dst_node_embedding,
                                           nb::object& grad_output_edge_embedding,
                                           const GraphT& graph,
                                           int dim_edge,
                                           int dim_src,
                                           int dim_dst,
                                           const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {graph.n_indices, dim_edge + dim_src + dim_dst};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_edge_embedding, "grad_output_edge_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto& exp_data_type = dl_out.type();

  int64_t dl_in_shape[] = {graph.n_indices, dim_edge};
  auto dl_in_edge       = assert_type_shape_strides(
    grad_input_edge_embedding, "grad_input_edge_embedding", exp_data_type, 2, dl_in_shape, true);

  int64_t dl_in_src_shape[] = {graph.n_in_nodes, dim_src};
  auto dl_in_src            = assert_type_shape_strides(grad_input_src_node_embedding,
                                             "grad_input_src_node_embedding",
                                             exp_data_type,
                                             2,
                                             dl_in_src_shape,
                                             true);

  int64_t dl_in_dst_shape[] = {graph.n_out_nodes, dim_dst};
  auto dl_in_dst            = assert_type_shape_strides(grad_input_dst_node_embedding,
                                             "grad_input_dst_node_embedding",
                                             exp_data_type,
                                             2,
                                             dl_in_dst_shape,
                                             true);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::update_efeat_bipartite_e2e_concat_bwd(dl_in_edge.template maybe_ptr<float>(),
                                                        dl_in_src.template maybe_ptr<float>(),
                                                        dl_in_dst.template maybe_ptr<float>(),
                                                        dl_out.template get_ptr<const float>(),
                                                        graph,
                                                        static_cast<size_t>(dim_edge),
                                                        static_cast<size_t>(dim_src),
                                                        static_cast<size_t>(dim_dst),
                                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::update_efeat_bipartite_e2e_concat_bwd(
        dl_in_edge.template maybe_ptr<__nv_bfloat16>(),
        dl_in_src.template maybe_ptr<__nv_bfloat16>(),
        dl_in_dst.template maybe_ptr<__nv_bfloat16>(),
        dl_out.template get_ptr<const __nv_bfloat16>(),
        graph,
        static_cast<size_t>(dim_edge),
        static_cast<size_t>(dim_src),
        static_cast<size_t>(dim_dst),
        stream);
    } else {
      cugraph::ops::update_efeat_bipartite_e2e_concat_bwd(dl_in_edge.template maybe_ptr<__half>(),
                                                          dl_in_src.template maybe_ptr<__half>(),
                                                          dl_in_dst.template maybe_ptr<__half>(),
                                                          dl_out.template get_ptr<const __half>(),
                                                          graph,
                                                          static_cast<size_t>(dim_edge),
                                                          static_cast<size_t>(dim_src),
                                                          static_cast<size_t>(dim_dst),
                                                          stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void update_efeat_bipartite_e2e_sum_fwd(nb::object& output_edge_embedding,
                                        nb::object& input_edge_embedding,
                                        nb::object& input_src_node_embedding,
                                        nb::object& input_dst_node_embedding,
                                        const graph::bipartite_csc<IdxT>& graph,
                                        const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {graph.n_indices, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_edge_embedding, "output_edge_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto& exp_data_type = dl_out.type();
  auto dim_edge       = dl_out.dim(1);

  int64_t dl_in_shape[] = {graph.n_indices, dim_edge};
  auto dl_in_edge       = assert_type_shape_strides(
    input_edge_embedding, "input_edge_embedding", exp_data_type, 2, dl_in_shape, true);

  int64_t dl_in_src_shape[] = {graph.n_in_nodes, dim_edge};
  auto dl_in_src            = assert_type_shape_strides(
    input_src_node_embedding, "input_src_node_embedding", exp_data_type, 2, dl_in_src_shape, true);

  int64_t dl_in_dst_shape[] = {graph.n_out_nodes, dim_edge};
  auto dl_in_dst            = assert_type_shape_strides(
    input_dst_node_embedding, "input_dst_node_embedding", exp_data_type, 2, dl_in_dst_shape, true);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::update_efeat_bipartite_e2e_sum_fwd(dl_out.template get_ptr<float>(),
                                                     dl_in_edge.template maybe_ptr<const float>(),
                                                     dl_in_src.template maybe_ptr<const float>(),
                                                     dl_in_dst.template maybe_ptr<const float>(),
                                                     graph,
                                                     static_cast<size_t>(dim_edge),
                                                     stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::update_efeat_bipartite_e2e_sum_fwd(
        dl_out.template get_ptr<__nv_bfloat16>(),
        dl_in_edge.template maybe_ptr<const __nv_bfloat16>(),
        dl_in_src.template maybe_ptr<const __nv_bfloat16>(),
        dl_in_dst.template maybe_ptr<const __nv_bfloat16>(),
        graph,
        static_cast<size_t>(dim_edge),
        stream);
    } else {
      cugraph::ops::update_efeat_bipartite_e2e_sum_fwd(
        dl_out.template get_ptr<__half>(),
        dl_in_edge.template maybe_ptr<const __half>(),
        dl_in_src.template maybe_ptr<const __half>(),
        dl_in_dst.template maybe_ptr<const __half>(),
        graph,
        static_cast<size_t>(dim_edge),
        stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename GraphT>
void update_efeat_bipartite_e2e_sum_bwd(nb::object& grad_input_edge_embedding,
                                        nb::object& grad_input_src_node_embedding,
                                        nb::object& grad_input_dst_node_embedding,
                                        nb::object& grad_output_edge_embedding,
                                        const GraphT& graph,
                                        const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {graph.n_indices, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_edge_embedding, "grad_output_edge_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_edge       = dl_out.dim(1);
  auto& exp_data_type = dl_out.type();

  int64_t dl_in_shape[] = {graph.n_indices, dim_edge};
  auto dl_in_edge       = assert_type_shape_strides(
    grad_input_edge_embedding, "grad_input_edge_embedding", exp_data_type, 2, dl_in_shape, true);

  int64_t dl_in_src_shape[] = {graph.n_in_nodes, dim_edge};
  auto dl_in_src            = assert_type_shape_strides(grad_input_src_node_embedding,
                                             "grad_input_src_node_embedding",
                                             exp_data_type,
                                             2,
                                             dl_in_src_shape,
                                             true);

  int64_t dl_in_dst_shape[] = {graph.n_out_nodes, dim_edge};
  auto dl_in_dst            = assert_type_shape_strides(grad_input_dst_node_embedding,
                                             "grad_input_dst_node_embedding",
                                             exp_data_type,
                                             2,
                                             dl_in_dst_shape,
                                             true);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::update_efeat_bipartite_e2e_sum_bwd(dl_in_edge.template maybe_ptr<float>(),
                                                     dl_in_src.template maybe_ptr<float>(),
                                                     dl_in_dst.template maybe_ptr<float>(),
                                                     dl_out.template get_ptr<const float>(),
                                                     graph,
                                                     static_cast<size_t>(dim_edge),
                                                     stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      cugraph::ops::update_efeat_bipartite_e2e_sum_bwd(
        dl_in_edge.template maybe_ptr<__nv_bfloat16>(),
        dl_in_src.template maybe_ptr<__nv_bfloat16>(),
        dl_in_dst.template maybe_ptr<__nv_bfloat16>(),
        dl_out.template get_ptr<const __nv_bfloat16>(),
        graph,
        static_cast<size_t>(dim_edge),
        stream);
    } else {
      cugraph::ops::update_efeat_bipartite_e2e_sum_bwd(dl_in_edge.template maybe_ptr<__half>(),
                                                       dl_in_src.template maybe_ptr<__half>(),
                                                       dl_in_dst.template maybe_ptr<__half>(),
                                                       dl_out.template get_ptr<const __half>(),
                                                       graph,
                                                       static_cast<size_t>(dim_edge),
                                                       stream);
    }
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_update_efeat_bipartite_e2e_fwd_bwd(nb::module_& m)
{
  m.def("update_efeat_bipartite_e2e_concat_fwd",
        &cugraph::ops::binding::update_efeat_bipartite_e2e_concat_fwd<IdxT>,
        nb::arg("output_edge_embedding"),
        nb::arg("input_edge_embedding").none(),
        nb::arg("input_src_node_embedding").none(),
        nb::arg("input_dst_node_embedding").none(),
        nb::arg("graph"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(UPDATE_EFEAT_E2E_CONCAT_FWD_DOC));

  m.def("update_efeat_bipartite_e2e_concat_bwd",
        &cugraph::ops::binding::update_efeat_bipartite_e2e_concat_bwd<
          cugraph::ops::graph::bipartite_csc<IdxT>>,
        nb::arg("grad_input_edge_embedding").none(),
        nb::arg("grad_input_src_node_embedding").none(),
        nb::arg("grad_input_dst_node_embedding").none(),
        nb::arg("grad_output_edge_embedding"),
        nb::arg("graph"),
        nb::arg("dim_edge"),
        nb::arg("dim_src"),
        nb::arg("dim_dst"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(UPDATE_EFEAT_E2E_CONCAT_BWD_DOC));

  m.def("update_efeat_bipartite_e2e_concat_bwd",
        &cugraph::ops::binding::update_efeat_bipartite_e2e_concat_bwd<
          cugraph::ops::graph::bipartite_csc_csr<IdxT>>,
        nb::arg("grad_input_edge_embedding").none(),
        nb::arg("grad_input_src_node_embedding").none(),
        nb::arg("grad_input_dst_node_embedding").none(),
        nb::arg("grad_output_edge_embedding"),
        nb::arg("graph"),
        nb::arg("dim_edge"),
        nb::arg("dim_src"),
        nb::arg("dim_dst"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(UPDATE_EFEAT_E2E_CONCAT_BWD_DOC));

  m.def("update_efeat_bipartite_e2e_sum_fwd",
        &cugraph::ops::binding::update_efeat_bipartite_e2e_sum_fwd<IdxT>,
        nb::arg("output_edge_embedding"),
        nb::arg("input_edge_node_embedding").none(),
        nb::arg("input_src_node_embedding").none(),
        nb::arg("input_dst_node_embedding").none(),
        nb::arg("graph"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(UPDATE_EFEAT_E2E_SUM_FWD_DOC));

  m.def("update_efeat_bipartite_e2e_sum_bwd",
        &cugraph::ops::binding::update_efeat_bipartite_e2e_sum_bwd<
          cugraph::ops::graph::bipartite_csc<IdxT>>,
        nb::arg("grad_input_edge_embedding").none(),
        nb::arg("grad_input_src_node_embedding").none(),
        nb::arg("grad_input_dst_node_embedding").none(),
        nb::arg("grad_output_edge_embedding"),
        nb::arg("graph"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(UPDATE_EFEAT_E2E_SUM_BWD_DOC));

  m.def("update_efeat_bipartite_e2e_sum_bwd",
        &cugraph::ops::binding::update_efeat_bipartite_e2e_sum_bwd<
          cugraph::ops::graph::bipartite_csc_csr<IdxT>>,
        nb::arg("grad_input_edge_embedding").none(),
        nb::arg("grad_input_src_node_embedding").none(),
        nb::arg("grad_input_dst_node_embedding").none(),
        nb::arg("grad_output_edge_embedding"),
        nb::arg("graph"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(UPDATE_EFEAT_E2E_SUM_BWD_DOC));
}

void init_update_efeat_bipartite(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_update_efeat_bipartite_e2e_fwd_bwd<int64_t>(m);
  init_update_efeat_bipartite_e2e_fwd_bwd<int32_t>(m);
}
