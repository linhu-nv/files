/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "agg_hg_basis_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/agg_hg_basis.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>
#include <limits>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
void hg_basis_fg_n2n_pre_fwd(nb::object& output_embedding,
                             nb::object& input_embedding,
                             nb::object& weights_combination,
                             const graph::fg_csr_hg<IdxT>& fg,
                             bool concat_own,
                             bool norm_by_out_degree,
                             const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_out.dim(1);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_w_shape[] = {fg.n_edge_types, -1};
  auto dl_w            = assert_type_shape_strides(
    weights_combination, "weights_combination", exp_data_type, 2, dl_w_shape, true);
  auto n_bases = dl_w.has_ptr() ? dl_w.dim(1) : fg.n_edge_types;

  if (n_bases > int64_t{std::numeric_limits<int>::max()}) {
    const auto& e = "#bases must be smaller than INT_MAX, got " + std::to_string(n_bases);
    throw nb::value_error(e.c_str());
  }

  auto dim_in           = dl_out.dim(1) * (n_bases + (concat_own ? 1 : 0));
  int64_t dl_in_shape[] = {fg.n_nodes, dim_in};
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_hg_basis_fg_n2n_pre_fwd(dl_out.template get_ptr<float>(),
                                              dl_in.template get_ptr<const float>(),
                                              dl_w.template maybe_ptr<const float>(),
                                              static_cast<size_t>(dim_in),
                                              static_cast<int>(n_bases),
                                              fg,
                                              concat_own,
                                              norm_by_out_degree,
                                              stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void hg_basis_fg_n2n_pre_bwd(nb::object& grad_input,
                             nb::object& grad_weights,
                             nb::object& grad_output,
                             nb::object& input_embedding,
                             nb::object& weights_combination,
                             const graph::fg_csr_hg<IdxT>& fg,
                             bool concat_own,
                             bool norm_by_out_degree,
                             const uintptr_t& stream_id)
{
  int64_t dl_grad_out_shape[] = {fg.n_nodes, -1};
  auto dl_grad_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output, "grad_output", DL_BF16_FP16_32_64, 2, dl_grad_out_shape);
  auto dim_out              = dl_grad_out.dim(1);
  const auto& exp_data_type = dl_grad_out.type();

  int64_t dl_w_shape[] = {fg.n_edge_types, -1};
  auto dl_w            = assert_type_shape_strides(
    weights_combination, "weights_combination", exp_data_type, 2, dl_w_shape, true);

  auto n_bases = dl_w.has_ptr() ? dl_w.dim(1) : fg.n_edge_types;
  if (n_bases > int64_t{std::numeric_limits<int>::max()}) {
    const auto& e = "#bases must be smaller than INT_MAX, got " + std::to_string(n_bases);
    throw nb::value_error(e.c_str());
  }

  int64_t dl_grad_w_shape[] = {fg.n_edge_types, n_bases};
  auto dl_grad_w            = assert_type_shape_strides(
    grad_weights, "grad_weights", exp_data_type, 2, dl_grad_w_shape, true);

  auto dim_in           = dim_out * (n_bases + (concat_own ? 1 : 0));
  int64_t dl_in_shape[] = {fg.n_nodes, dim_in};
  auto dl_grad_in =
    assert_type_shape_strides(grad_input, "grad_input", exp_data_type, 2, dl_in_shape, true);
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    agg_hg_basis_fg_n2n_pre_bwd(dl_grad_in.template maybe_ptr<float>(),
                                dl_grad_w.template maybe_ptr<float>(),
                                dl_grad_out.template get_ptr<float>(),
                                dl_in.template get_ptr<float>(),
                                dl_w.template maybe_ptr<float>(),
                                static_cast<size_t>(dim_in),
                                static_cast<int>(n_bases),
                                fg,
                                concat_own,
                                norm_by_out_degree,
                                stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void hg_basis_fg_n2n_post_fwd(nb::object& output_embedding,
                              nb::object& input_embedding,
                              nb::object& weights_combination,
                              const graph::fg_csr_hg<IdxT>& fg,
                              bool concat_own,
                              bool norm_by_out_degree,
                              const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  const auto& exp_data_type = dl_out.type();

  int64_t dl_w_shape[] = {fg.n_edge_types, -1};
  auto dl_w            = assert_type_shape_strides(
    weights_combination, "weights_combination", exp_data_type, 2, dl_w_shape, true);
  auto n_bases = dl_w.has_ptr() ? dl_w.dim(1) : fg.n_edge_types;

  if (n_bases > int64_t{std::numeric_limits<int>::max()}) {
    const auto& e = "#bases must be smaller than INT_MAX, got " + std::to_string(n_bases);
    throw nb::value_error(e.c_str());
  }
  int64_t dl_in_shape[] = {fg.n_nodes, -1};
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);
  auto dim_in = dl_in.dim(1);

  auto dim_out_exp = dl_in.dim(1) * (n_bases + (concat_own ? 1 : 0));
  if (dl_out.dim(1) != dim_out_exp) {
    const auto& e = "Expected output dimension " + std::to_string(dl_out.dim(1)) +
                    "= #bases x feature dimension " + std::to_string(dim_out_exp);
    throw nb::value_error(e.c_str());
  }

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_hg_basis_fg_n2n_post_fwd(dl_out.template get_ptr<float>(),
                                               dl_in.template get_ptr<const float>(),
                                               dl_w.template maybe_ptr<const float>(),
                                               static_cast<size_t>(dim_in),
                                               static_cast<int>(n_bases),
                                               fg,
                                               concat_own,
                                               norm_by_out_degree,
                                               stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void hg_basis_fg_n2n_post_bwd(nb::object& grad_input,
                              nb::object& grad_weights,
                              nb::object& grad_output,
                              nb::object& input_embedding,
                              nb::object& weights_combination,
                              const graph::fg_csr_hg<IdxT>& fg,
                              bool concat_own,
                              bool norm_by_out_degree,
                              const uintptr_t& stream_id)
{
  int64_t dl_g_out_shape[] = {fg.n_nodes, -1};
  auto dl_g_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output, "grad_output", DL_BF16_FP16_32_64, 2, dl_g_out_shape);
  auto dim_out              = dl_g_out.dim(1);
  const auto& exp_data_type = dl_g_out.type();

  int64_t dl_w_shape[] = {fg.n_edge_types, -1};
  auto dl_w            = assert_type_shape_strides(
    weights_combination, "weights_combination", exp_data_type, 2, dl_w_shape, true);
  auto n_bases = dl_w.has_ptr() ? dl_w.dim(1) : fg.n_edge_types;

  int64_t dl_g_w_shape[] = {fg.n_edge_types, n_bases};
  auto dl_g_w =
    assert_type_shape_strides(grad_weights, "grad_weights", exp_data_type, 2, dl_g_w_shape, true);

  int64_t dl_in_shape[] = {fg.n_nodes, -1};
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);
  auto dim_in      = dl_in.dim(1);
  auto dim_out_exp = dim_in * (n_bases + (concat_own ? 1 : 0));
  if (dim_out != dim_out_exp) {
    const auto& e = "Expected output dimension " + std::to_string(dim_out) +
                    "= #bases x feature dimension " + std::to_string(dim_out_exp);
    throw nb::value_error(e.c_str());
  }

  int64_t dl_grad_in_shape[] = {fg.n_nodes, dim_in};
  auto dl_g_in =
    assert_type_shape_strides(grad_input, "grad_input", exp_data_type, 2, dl_grad_in_shape, true);

  if (n_bases > int64_t{std::numeric_limits<int>::max()}) {
    const auto& e = "#bases must be smaller than INT_MAX, got " + std::to_string(n_bases);
    throw nb::value_error(e.c_str());
  }

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::agg_hg_basis_fg_n2n_post_bwd(dl_g_in.template maybe_ptr<float>(),
                                               dl_g_w.template maybe_ptr<float>(),
                                               dl_g_out.template get_ptr<const float>(),
                                               dl_in.template get_ptr<const float>(),
                                               dl_w.template maybe_ptr<const float>(),
                                               static_cast<size_t>(dim_in),
                                               static_cast<int>(n_bases),
                                               fg,
                                               concat_own,
                                               norm_by_out_degree,
                                               stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_agg_hg_basis_fg_n2n_pre_fwd_bwd(nb::module_& m)
{
  // weights_combination allows None as input
  m.def("agg_hg_basis_fg_n2n_pre_fwd",
        &cugraph::ops::binding::hg_basis_fg_n2n_pre_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("input_embedding"),
        nb::arg("weights_combination").none(),
        nb::arg("fg"),
        nb::arg("concat_own")         = false,
        nb::arg("norm_by_out_degree") = false,
        nb::arg("stream_id")          = 0,
        nb::raw_doc(AGG_HG_BASIS_FG_N2N_PRE_FWD_DOC));
  m.def("agg_hg_basis_fg_n2n_pre_bwd",
        &cugraph::ops::binding::hg_basis_fg_n2n_pre_bwd<IdxT>,
        nb::arg("grad_input"),
        nb::arg("grad_weights").none(),
        nb::arg("grad_output"),
        nb::arg("input_embedding"),
        nb::arg("weights_combination").none(),
        nb::arg("fg"),
        nb::arg("concat_own")         = false,
        nb::arg("norm_by_out_degree") = false,
        nb::arg("stream_id")          = 0,
        nb::raw_doc(AGG_HG_BASIS_FG_N2N_PRE_BWD_DOC));
}

template <typename IdxT>
void init_agg_hg_basis_fg_n2n_post_fwd_bwd(nb::module_& m)
{
  // weights_combination allows None as input
  m.def("agg_hg_basis_fg_n2n_post_fwd",
        &cugraph::ops::binding::hg_basis_fg_n2n_post_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("input_embedding"),
        nb::arg("weights_combination").none(),
        nb::arg("fg"),
        nb::arg("concat_own")         = false,
        nb::arg("norm_by_out_degree") = false,
        nb::arg("stream_id")          = 0,
        nb::raw_doc(AGG_HG_BASIS_FG_N2N_POST_FWD_DOC));

  m.def("agg_hg_basis_fg_n2n_post_bwd",
        &cugraph::ops::binding::hg_basis_fg_n2n_post_bwd<IdxT>,
        nb::arg("grad_input").none(),
        nb::arg("grad_weights").none(),
        nb::arg("grad_output"),
        nb::arg("input_embedding"),
        nb::arg("weights_combination").none(),
        nb::arg("fg"),
        nb::arg("concat_own")         = false,
        nb::arg("norm_by_out_degree") = false,
        nb::arg("stream_id")          = 0,
        nb::raw_doc(AGG_HG_BASIS_FG_N2N_POST_BWD_DOC));
}

void init_agg_hg_basis_fg(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_agg_hg_basis_fg_n2n_pre_fwd_bwd<int64_t>(m);
  init_agg_hg_basis_fg_n2n_pre_fwd_bwd<int32_t>(m);

  init_agg_hg_basis_fg_n2n_post_fwd_bwd<int64_t>(m);
  init_agg_hg_basis_fg_n2n_post_fwd_bwd<int32_t>(m);
}
