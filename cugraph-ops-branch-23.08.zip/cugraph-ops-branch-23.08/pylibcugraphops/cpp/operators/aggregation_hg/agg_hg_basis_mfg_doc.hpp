/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const AGG_HG_BASIS_MFG_N2N_POST_FWD_DOC =
  R"(Computes the forward pass for node-to-node message-flow-graph RGCN-like basis regularized
     aggregation, with features being transformed after (post) this aggregation.

.. code-block:: python

    agg_hg_basis_mfg_n2n_post_fwd(
        output_embedding: device array, input_embedding: device array,
        weights_combination: Optional[device array], mfg: pylibcugraphops.mfg_csr_hg_int[32|64],
        concat_own: bool = False, norm_by_out_degree: bool = False, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output embeddings.
    Shape for ``concat_own=False``: ``(mfg.n_out_nodes, dim_out)``;
    Shape for ``concat_own=True``: ``(mfg.n_out_nodes, dim_out + dim_in)``, with
    ``dim_out = dim_in * n_bases`` if ``weights_combination`` is set,
    ``dim_out = dim_in * n_edge_types`` otherwise.

input_embedding : device array type
    Device array containing the input embeddings.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

weights_combination : device array type | None
    Device array containing the combination weights. If ``None``, no weights are
    used and features of different edge types are aggregated into separate
    output dimensions.
    Shape: ``(n_edge_types, n_bases)`` if set.

mfg : opaque CSR graph type
    The graph used for the operation.

concat_own : bool, default=False
    Concatenate output node embeddings in the aggregation.

norm_by_out_degree : bool, default=False
    If set, output embeddings are normed by the degree of the output node.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_HG_BASIS_MFG_N2N_POST_BWD_DOC =
  R"(Computes the backward pass for node-to-node message-flow-graph RGCN-like basis regularized
     aggregation, with features being transformed after (post) this aggregation
     (in forward).

.. code-block:: python

    agg_hg_basis_mfg_n2n_post_bwd(
        grad_input: Optional[device array],
        grad_weights: Optional[device array], grad_output: device array,
        input_embedding: device array, weights_combination: Optional[device array],
        mfg: pylibcugraphops.mfg_csr_hg_int[32|64], concat_own: bool = False,
        norm_by_out_degree: bool = False, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type | None
    Device array containing the output gradient on input embeddings of forward.
    If ``None``, this is not calculated.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

grad_weights : device array type | None
    Device array containing the output gradient on combination weights of forward.
    If ``None``, this is not calculated.
    If both this and ``grad_input`` are ``None``, no calculation is performed.
    Shape: ``(n_edge_types, n_bases)`` if set.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape for ``concat_own=False``: ``(mfg.n_out_nodes, dim_out)``;
    Shape for ``concat_own=True``: ``(mfg.n_out_nodes, dim_out + dim_in)``, with
    ``dim_out = dim_in * n_bases`` if ``weights_combination`` is set,
    ``dim_out = dim_in * n_edge_types`` otherwise.

input_embedding : device array type
    Device array containing the input embeddings from forward.
    Shape: same as ``grad_input``.

weights_combination : device array type
    Device array containing the combination weights from forward.
    Shape: same as ``grad_weights``.

mfg : opaque CSR graph type
    The graph used for the operation (must be same as in forward).

concat_own : bool, default=False
    Concatenate output node embeddings in the aggregation.

norm_by_out_degree : bool, default=False
    If set, output embeddings are normed by the degree of the output node.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_HG_BASIS_MFG_N2N_PRE_FWD_DOC =
  R"(Computes the forward pass for node-to-node message-flow-graph RGCN-like basis regularized
     aggregation, with features being transformed before (pre) this aggregation.

.. code-block:: python

    agg_hg_basis_mfg_n2n_pre_fwd(
        output_embedding: device array, input_embedding: device array,
        weights_combination: Optional[device array], mfg: pylibcugraphops.mfg_csr_hg_int[32|64],
        concat_own: bool = False, norm_by_out_degree: bool = False, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output embeddings.
    Shape for ``concat_own=False``: ``(mfg.n_out_nodes, dim_out)``;
    Shape for ``concat_own=True``: ``(mfg.n_out_nodes, dim_out + dim_in)``, with
    ``dim_out = dim_in * n_bases`` if ``weights_combination`` is set,
    ``dim_out = dim_in * n_edge_types`` otherwise.

input_embedding : device array type
    Device array containing the input embeddings.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

weights_combination : device array type | None
    Device array containing the combination weights. If ``None``, no weights are
    used and features of different edge types are aggregated into separate
    output dimensions.
    Shape: ``(n_edge_types, n_bases)`` if set.

mfg : opaque CSR graph type
    The graph used for the operation.

concat_own : bool, default=False
    Concatenate output node embeddings in the aggregation.

norm_by_out_degree : bool, default=False
    If set, output embeddings are normed by the degree of the output node.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const AGG_HG_BASIS_MFG_N2N_PRE_BWD_DOC =
  R"(Computes the backward pass for node-to-node message-flow-graph RGCN-like basis regularized
     aggregation, with features being transformed before (pre) this aggregation
     (in forward).

.. code-block:: python

    agg_hg_basis_mfg_n2n_pre_bwd(
        grad_input: Optional[device array],
        grad_weights: Optional[device array], grad_output: device array,
        input_embedding: device array, weights_combination: Optional[device array],
        mfg: pylibcugraphops.mfg_csr_hg_int[32|64], concat_own: bool = False,
        norm_by_out_degree: bool = False, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input : device array type | None
    Device array containing the output gradient on input embeddings of forward.
    If ``None``, this is not calculated.
    Shape: ``(mfg.n_in_nodes, dim_in)``.

grad_weights : device array type | None
    Device array containing the output gradient on combination weights of forward.
    If ``None``, this is not calculated.
    If both this and ``grad_input`` are ``None``, no calculation is performed.
    Shape: ``(n_edge_types, n_bases)`` if set.

grad_output : device array type
    Device array containing the input gradient on output embeddings of forward.
    Shape for ``concat_own=False``: ``(mfg.n_out_nodes, dim_out)``;
    Shape for ``concat_own=True``: ``(mfg.n_out_nodes, dim_out + dim_in)``, with
    ``dim_out = dim_in * n_bases`` if ``weights_combination`` is set,
    ``dim_out = dim_in * n_edge_types`` otherwise.

input_embedding : device array type
    Device array containing the input embeddings from forward.
    Shape: same as ``grad_input``.

weights_combination : device array type
    Device array containing the combination weights from forward.
    Shape: same as ``grad_weights``.

mfg : opaque CSR graph type
    The graph used for the operation (must be same as in forward).

concat_own : bool, default=False
    Concatenate output node embeddings in the aggregation.

norm_by_out_degree : bool, default=False
    If set, output embeddings are normed by the degree of the output node.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
