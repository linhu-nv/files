/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const MHA_SIMPLE_BIPARTITE_N2N_FWD_DOC =
  R"(Computes the forward pass for a simple multi-head attention layer
     without using cudnn (mha_simple) operating on bipartite graphs in a node-to-node reduction (n2n)

.. code-block:: python

    mha_simple_bipartite_n2n_fwd(
        output_embedding: device array, softmax_scores: device array,
        key_embedding: device array, query_embedding: device array, value_embedding: device array,
        graph: pylibcugraphops.bipartite_csc_int[64|32], params: pylibcugraphops.operators.mha_params,
        norm_by_dim: bool = true, stream_id: int = 0
    )

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (for backward)

key_embedding : device array type
    Device array containing the input key embeddings.

query_embedding : device array type
    Device array containing the input query embeddings.

value_embedding : device array type
    Device array containing the input value embeddings.

graph : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    structure summarizing hyperparameters of the primitive like num_heads, concat_heads
    or the used activation function

norm_by_dim : bool, default=True
    if set, dot-product is scaled by sqrt(dim_head)

score_bias : optional device array type
    Optional device array containing the bias added to the un-normalized softmax scores
    (when not passed as None)

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const MHA_SIMPLE_BIPARTITE_N2N_EFEAT_FWD_DOC =
  R"(Computes the forward pass for a simple multi-head attention layer
     without using cudnn (mha_simple) operating on bipartite graphs in a node-to-node reduction (n2n)

.. code-block:: python

    mha_simple_bipartite_n2n_efeat_fwd(
        output_embedding: device array, softmax_scores: device array,
        key_embedding: device array, query_embedding: device array,
        value_embedding: device array, edge_embedding: device array,
        graph: pylibcugraphops.bipartite_csc_int[64|32],
        params: pylibcugraphops.operators.mha_params,
        norm_by_dim: bool = true, stream_id: int = 0
    )

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (for backward)

key_embedding : device array type
    Device array containing the input key embeddings.

query_embedding : device array type
    Device array containing the input query embeddings.

value_embedding : device array type
    Device array containing the input value embeddings.

edge_embedding : device array type
    Device array containing the input edge embeddings.

graph : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    structure summarizing hyperparameters of the primitive like num_heads, concat_heads
    or the used activation function

norm_by_dim : bool, default=True
    if set, dot-product is scaled by sqrt(dim_head)

score_bias : optional device array type
    Optional device array containing the bias added to the un-normalized softmax scores
    (when not passed as None)

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const MHA_SIMPLE_BIPARTITE_N2N_BWD_DOC =
  R"(Computes the backward pass for a simple multi-head attention layer
     without using cudnn (mha_simple) operating on bipartite graphs in a node-to-node reduction (n2n)

.. code-block:: python

    mha_simple_bipartite_n2n_bwd(
        grad_key_embedding: device array, grad_query_embedding: device array,
        grad_value_embedding: device array, grad_softmax_scores: device array,
        grad_output_embedding: device array, key_embedding: device array,
        query_embedding: device array, value_embedding: device array,
        softmax_scores: device array, graph: pylibcugraphops.bipartite_csc_int[64|32],
        params: pylibcugraphops.operators.mha_params, norm_by_dim: bool = true,
        grad_score_bias: Optional[device array] = none, stream_id: int = 0
    )

Parameters
----------
grad_key_embedding : device array type
    Device array containing the output gradient on the key embeddings.

grad_query_embedding : device array type
    Device array containing the output gradient on the query embeddings.

grad_value_embedding : device array type
    Device array containing the output gradient on the value embeddings.

grad_softmax_scores : device array type
    Device array containing the gradient of softmax scores (workspace device array)

grad_output_embedding : device array type
    Device array containing the

key_embedding : device array type
    Device array containing the input key embeddings.

query_embedding : device array type
    Device array containing the input query embeddings.

value_embedding : device array type
    Device array containing the input value embeddings.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (from forward pass)

graph : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    structure summarizing hyperparameters of the primitive like num_heads, concat_heads
    or the used activation function

norm_by_dim : bool, default=True
    if set, dot-product is scaled by `sqrt(dim_head)`

grad_score_bias : optional device array type
    Optional device array containing the gradient on the bias added to the un-normalized softmax scores
    (when not passed as None)

stream_id : int, default=0
    CUDA stream pointer as a python int
)";

static constexpr const char* const MHA_SIMPLE_BIPARTITE_N2N_EFEAT_BWD_DOC =
  R"(Computes the backward pass for a simple multi-head attention layer
     without using cudnn (mha_simple) operating on bipartite graphs in a node-to-node reduction (n2n)

.. code-block:: python

    mha_simple_bipartite_n2n_efeat_bwd(
        grad_key_embedding: device array, grad_query_embedding: device array,
        grad_value_embedding: device array, grad_edge_embedding: device array,
        grad_softmax_scores: device array, grad_output_embedding: device array,
        key_embedding: device array, query_embedding: device array, value_embedding: device array,
        edge_embedding: device array, softmax_scores: device array, graph: pylibcugraphops.bipartite_csc_int[64|32],
        params: pylibcugraphops.operators.mha_params, norm_by_dim: bool = true,
        grad_score_bias: Optional[device array] = none, stream_id: int = 0
    )

Parameters
----------
grad_key_embedding : device array type
    Device array containing the output gradient on the key embeddings.

grad_query_embedding : device array type
    Device array containing the output gradient on the query embeddings.

grad_value_embedding : device array type
    Device array containing the output gradient on the value embeddings.

grad_edge_embedding : device array type
    Device array containing the output gradient on the edge embeddings.

grad_softmax_scores : device array type
    Device array containing the gradient of softmax scores (workspace device array)

grad_output_embedding : device array type
    Device array containing the

key_embedding : device array type
    Device array containing the input key embeddings.

query_embedding : device array type
    Device array containing the input query embeddings.

value_embedding : device array type
    Device array containing the input value embeddings.

value_embedding : device array type
    Device array containing the input edge embeddings.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (from forward pass)

graph : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    structure summarizing hyperparameters of the primitive like num_heads, concat_heads
    or the used activation function

norm_by_dim : bool, default=True
    if set, dot-product is scaled by `sqrt(dim_head)`

grad_score_bias : optional device array type
    Optional device array containing the gradient on the bias added to the un-normalized softmax scores
    (when not passed as None)

stream_id : int, default=0
    CUDA stream pointer as a python int
)";
