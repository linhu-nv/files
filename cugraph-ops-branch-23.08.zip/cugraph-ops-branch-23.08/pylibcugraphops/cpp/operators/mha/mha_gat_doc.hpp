/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const MHA_GAT_FG_N2N_FWD_DOC =
  R"(Computes the forward pass for a multi-head attention layer (GAT-like)
     without using cudnn (mha_gat) operating on full graphs (fg) in a node-to-node reduction (n2n).

.. code-block:: python

    mha_gat_fg_n2n_fwd(
        output_embedding: device array, softmax_scores: device array,
        node_embedding: device array, attention_weights: device array, fg: pylibcugraphops.fg_csr_int[64|32],
        params: pylibcugraphops.operators.mha_params, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(fg.n_nodes, dim_out)``, with ``dim_out = dim_node`` when ``params.concat_heads`` is ``True``;
    ``dim_out = dim_node / params.num_heads`` otherwise.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (for backward).
    Shape: ``(2, params.num_heads, fg.n_indices)``.

node_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(fg.n_nodes, dim_node)``.

attention_weights: device array type
    Device array containing the (learnable) attention weights.
    Shape: ``(2 * dim_node, )``.

fg : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    Structure summarizing hyperparameters of the primitive like ``num_heads``, ``concat_heads``
    or the used activation function.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const MHA_GAT_FG_N2N_EFEAT_FWD_DOC =
  R"(Computes the forward pass for a multi-head attention layer (GAT-like)
     without using cudnn (mha_gat) operating on full graphs (fg) in a node-to-node reduction (n2n)
     but using edge features, too, for computing the dot product (efeat).

.. code-block:: python

    mha_gat_fg_n2n_efeat_fwd(
        output_embedding: device array, softmax_scores: device array,
        node_embedding: device array, edge_embedding: device array,
        attention_weights: device array, fg: pylibcugraphops.fg_csr_int[64|32],
        params: pylibcugraphops.operators.mha_params, stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output node embeddings.
    Shape: ``(fg.n_nodes, dim_out)``, with ``dim_out = dim_node`` when ``params.concat_heads`` is ``True``;
    ``dim_out = dim_node / params.num_heads`` otherwise.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (for backward).
    Shape: ``(2, params.num_heads, fg.n_indices)``.

node_embedding : device array type
    Device array containing the input node embeddings.
    Shape: ``(fg.n_nodes, dim_node)``.

edge_embedding : device array type
    Device array containing the input edge embeddings.
    Shape: ``(fg.n_indices, dim_edge)``.

attention_weights : device array type
    Device array containing the (learnable) attention weights.
    Shape: ``(2 * dim_node + dim_edge, )``.

fg : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    Structure summarizing hyperparameters of the primitive like ``num_heads``, ``concat_heads``
    or the used activation function.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const MHA_GAT_FG_N2N_BWD_DOC =
  R"(Computes the backward pass for a multi-head attention layer (GAT-like)
     without using cudnn (mha_gat) operating on full graphs (fg) in a node-to-node reduction (n2n).

.. code-block:: python

    mha_gat_fg_n2n_bwd(
        grad_node_embedding: device array, grad_attention_weights: device array,
        grad_softmax_scores: device array, grad_output_embedding: device array,
        node_embedding: device array, attention_weights: device array,
        softmax_scores: device array, fg: pylibcugraphops.fg_csr_int[64|32],
        params: pylibcugraphops.operators.mha_params, stream_id: int = 0
    ) -> None

Parameters
----------
grad_node_embedding : device array type
    Device array containing the output gradient on the node embeddings.
    May be `None` if not needed.
    Shape: ``(fg.n_nodes, dim_node)``.

grad_attention_weights : device array type
    Device array containing the output gradient on the attention weights.
    May be `None` if not needed.
    Shape: ``(2 * dim_node, )``.

grad_softmax_scores : device array type
    Device array containing the gradient of softmax scores (workspace device array).
    Shape: ``(2, params.num_heads, fg.n_indices)``.

grad_output_embedding : device array type
    Device array containing the input gradients on the output node embeddings.
    Shape: ``(fg.n_nodes, dim_out)``, with ``dim_out = dim_node`` when ``params.concat_heads`` is ``True``;
    ``dim_out = dim_node / params.num_heads`` otherwise.

node_embedding : device array type
    Device array containing the input node embeddings.
    Shape: same as ``grad_node_embedding``.

attention_weights: device array type
    Device array containing the (learnable) attention weights.
    Shape: same as ``grad_attention_weights``.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (from forward pass).
    Shape: same as ``grad_softmax_scores``.

fg : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    Structure summarizing hyperparameters of the primitive like ``num_heads``, ``concat_heads``
    or the used activation function.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";

static constexpr const char* const MHA_GAT_FG_N2N_EFEAT_BWD_DOC =
  R"(Computes the backward pass for a multi-head attention layer (GAT-like)
     without using cudnn (mha_gat) operating on full graphs (fg) in a node-to-node reduction (n2n)
     but using edge features, too, for computing the dot product (efeat).

.. code-block:: python

    mha_gat_fg_n2n_efeat_bwd(
        grad_node_embedding : device array, grad_edge_embedding : device array,
        grad_attention_weights : device array, grad_softmax_scores : device array,
        grad_output_embedding: device array, node_embedding: device array,
        edge_embedding: device array, attention_weights: device array,
        softmax_scores: device array, fg: pylibcugraphops.fg_csr_int[64|32],
        params: pylibcugraphops.operators.mha_params, stream_id: int = 0
    ) -> None

Parameters
----------
grad_node_embedding : device array type
    Device array containing the gradients on node embeddings.
    May be `None` if not needed.
    Shape: ``(fg.n_nodes, dim_node)``.

grad_edge_embedding : device array type
    Device array containing the gradients on edge embeddings.
    May be `None` if not needed.
    Shape: ``(fg.n_indices, dim_edge)``.

grad_attention_weights : device array type
    Device array containing the output gradient on the attention weights.
    May be `None` if not needed.
    Shape: ``(2 * dim_node + dim_edge, )``.

grad_softmax_scores : device array type
    Device array containing the gradient of softmax scores (workspace device array).
    Shape: ``(2, params.num_heads, fg.n_indices)``.

grad_output_embedding : device array type
    Device array containing the input gradients on the output node embeddings.
    Shape: ``(fg.n_nodes, dim_out)``, with ``dim_out = dim_node`` when ``params.concat_heads`` is ``True``;
    ``dim_out = dim_node / params.num_heads`` otherwise.

node_embedding : device array type
    Device array containing the input node embeddings.
    Shape: same as ``grad_node_embedding``.

edge_embedding : device array type
    Device array containing the input edge embeddings.
    Shape: same as ``grad_edge_embedding``.

attention_weights : device array type
    Device array containing the (learnable) attention weights.
    Shape: same as ``grad_attention_weights``.

softmax_scores : device array type
    Device array containing the pre- and post-softmax-scores (from forward pass).
    Shape: same as ``grad_softmax_scores``.

fg : opaque FG type
    FG used for the operation.

params : opaque mha_params type
    Structure summarizing hyperparameters of the primitive like ``num_heads``, ``concat_heads``
    or the used activation function.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
