/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "mha_gat_mfg_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/mha_gat_mfg.hpp>

#include <nanobind/nanobind.h>

#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
void mha_gat_mfg_n2n_fwd(nb::object& output_embedding,
                         nb::object& softmax_scores,
                         nb::object& input_embedding,
                         nb::object& attention_weights,
                         const graph::mfg_csr<IdxT>& mfg,
                         const mha_params& params,
                         const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {mfg.n_out_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_out.dim(1);
  auto dim_node             = params.concat_heads ? dim_out : dim_out * params.num_heads;
  const auto& exp_data_type = dl_out.type();

  int64_t dl_sm_scores_shape[] = {2, mfg.n_out_nodes, params.num_heads, mfg.sample_size + 1};
  auto dl_sm_scores            = assert_type_shape_strides(
    softmax_scores, "softmax_scores", exp_data_type, 4, dl_sm_scores_shape);

  int64_t dl_in_shape[] = {mfg.n_in_nodes, dim_node};
  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);

  int64_t dl_w_shape[] = {2 * dim_node};
  auto dl_w =
    assert_type_shape_strides(attention_weights, "attention_weights", exp_data_type, 1, dl_w_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::mha_gat_mfg_n2n_fwd(dl_out.template get_ptr<float>(),
                                      dl_sm_scores.template get_ptr<float>(),
                                      dl_in.template get_ptr<const float>(),
                                      dl_w.template get_ptr<const float>(),
                                      mfg,
                                      params,
                                      static_cast<size_t>(dim_node),
                                      stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    cugraph::ops::mha_gat_mfg_n2n_fwd(dl_out.template get_ptr<double>(),
                                      dl_sm_scores.template get_ptr<double>(),
                                      dl_in.template get_ptr<const double>(),
                                      dl_w.template get_ptr<const double>(),
                                      mfg,
                                      params,
                                      static_cast<size_t>(dim_node),
                                      stream);
  }
}

template <typename IdxT>
void mha_gat_mfg_n2n_bwd(nb::object& grad_input_embedding,
                         nb::object& grad_attention_weights,
                         nb::object& grad_output_embedding,
                         nb::object& input_embedding,
                         nb::object& attention_weights,
                         nb::object& softmax_scores,
                         const graph::mfg_csr<IdxT>& mfg,
                         const mha_params& params,
                         const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {mfg.n_out_nodes, -1};
  auto dl_grad_out       = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_embedding, "grad_output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_grad_out.dim(1);
  auto dim_node             = params.concat_heads ? dim_out : dim_out * params.num_heads;
  const auto& exp_data_type = dl_grad_out.type();

  int64_t dl_in_shape[] = {mfg.n_in_nodes, dim_node};
  auto dl_grad_in       = assert_type_shape_strides(
    grad_input_embedding, "grad_input_embedding", exp_data_type, 2, dl_in_shape);

  int64_t dl_w_shape[] = {2 * dim_node};
  auto dl_grad_w       = assert_type_shape_strides(
    grad_attention_weights, "grad_attention_weights", exp_data_type, 1, dl_w_shape);

  auto dl_in =
    assert_type_shape_strides(input_embedding, "input_embedding", exp_data_type, 2, dl_in_shape);
  auto dl_w =
    assert_type_shape_strides(attention_weights, "attention_weights", exp_data_type, 1, dl_w_shape);

  int64_t dl_sm_scores_shape[] = {2, mfg.n_out_nodes, params.num_heads, mfg.sample_size + 1};
  auto dl_sm_scores            = assert_type_shape_strides(
    softmax_scores, "softmax_scores", exp_data_type, 4, dl_sm_scores_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::mha_gat_mfg_n2n_bwd(dl_grad_in.template get_ptr<float>(),
                                      dl_grad_w.template get_ptr<float>(),
                                      dl_grad_out.template get_ptr<const float>(),
                                      dl_in.template get_ptr<const float>(),
                                      dl_w.template get_ptr<const float>(),
                                      dl_sm_scores.template get_ptr<const float>(),
                                      mfg,
                                      params,
                                      static_cast<size_t>(dim_node),
                                      stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    cugraph::ops::mha_gat_mfg_n2n_bwd(dl_grad_in.template get_ptr<double>(),
                                      dl_grad_w.template get_ptr<double>(),
                                      dl_grad_out.template get_ptr<const double>(),
                                      dl_in.template get_ptr<const double>(),
                                      dl_w.template get_ptr<const double>(),
                                      dl_sm_scores.template get_ptr<const double>(),
                                      mfg,
                                      params,
                                      static_cast<size_t>(dim_node),
                                      stream);
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_mha_gat_mfg_n2n_fwd_bwd(nb::module_& m)
{
  m.def("mha_gat_mfg_n2n_fwd",
        &cugraph::ops::binding::mha_gat_mfg_n2n_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("softmax_scores"),
        nb::arg("input_embedding"),
        nb::arg("attention_weights"),
        nb::arg("mfg"),
        nb::arg("params"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(MHA_GAT_MFG_N2N_FWD_DOC));

  m.def("mha_gat_mfg_n2n_bwd",
        &cugraph::ops::binding::mha_gat_mfg_n2n_bwd<IdxT>,
        nb::arg("grad_input_embedding"),
        nb::arg("grad_attention_weights"),
        nb::arg("grad_output_embedding"),
        nb::arg("input_embedding"),
        nb::arg("attention_weights"),
        nb::arg("softmax_scores"),
        nb::arg("mfg"),
        nb::arg("params"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(MHA_GAT_MFG_N2N_BWD_DOC));
}

void init_mha_gat_mfg(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_mha_gat_mfg_n2n_fwd_bwd<int64_t>(m);
  init_mha_gat_mfg_n2n_fwd_bwd<int32_t>(m);
}
