/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "../../dlpack/dlpack.h"
#include "../../dlpack/utils.hpp"
#include "mha_gat_v2_doc.hpp"

#include <cugraph-ops/graph/format.hpp>
#include <cugraph-ops/operators/mha_gat_v2.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>
#include <string>

namespace nb = nanobind;

namespace cugraph::ops::binding {

template <typename IdxT>
void mha_gat_v2_fg_n2n_fwd(nb::object& output_embedding,
                           nb::object& softmax_scores,
                           nb::object& activation_scores,
                           nb::object& node_embedding,
                           nb::object& attention_weights,
                           const graph::fg_csr<IdxT>& fg,
                           mha_params& params,
                           const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_out.dim(1);
  const auto& exp_data_type = dl_out.type();

  auto dim_node = (params.concat_heads) ? dim_out : dim_out * params.num_heads;

  int64_t dl_node_shape[] = {fg.n_nodes, dim_node};
  auto dl_node =
    assert_type_shape_strides(node_embedding, "node_embedding", exp_data_type, 2, dl_node_shape);

  int64_t dl_sm_shape[] = {2, params.num_heads, fg.n_indices};
  auto dl_sm =
    assert_type_shape_strides(softmax_scores, "softmax_scores", exp_data_type, 3, dl_sm_shape);

  int64_t dl_act_shape[] = {fg.n_indices, dim_node};
  auto dl_act            = assert_type_shape_strides(
    activation_scores, "activation_scores", exp_data_type, 2, dl_act_shape);

  int64_t dl_attn_shape[] = {dim_node};
  auto dl_attn_w          = assert_type_shape_strides(
    attention_weights, "attention_weights", exp_data_type, 1, dl_attn_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::mha_gat_v2_fg_n2n_fwd(dl_out.template get_ptr<float>(),
                                        dl_sm.template get_ptr<float>(),
                                        dl_act.template get_ptr<float>(),
                                        dl_node.template get_ptr<float>(),
                                        dl_attn_w.template get_ptr<float>(),
                                        fg,
                                        params,
                                        dim_node,
                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void mha_gat_v2_fg_n2n_bwd(nb::object& grad_node_embedding,
                           nb::object& grad_attention_weights,
                           nb::object& grad_softmax_scores,
                           nb::object& grad_output_embedding,
                           nb::object& node_embedding,
                           nb::object& attention_weights,
                           nb::object& softmax_scores,
                           nb::object& activation_scores,
                           const graph::fg_csr<IdxT>& fg,
                           mha_params& params,
                           const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_grad_out       = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_embedding, "grad_output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_grad_out.dim(1);
  const auto& exp_data_type = dl_grad_out.type();

  auto dim_node = (params.concat_heads) ? dim_out : dim_out * params.num_heads;

  int64_t dl_node_shape[] = {fg.n_nodes, dim_node};
  auto dl_node =
    assert_type_shape_strides(node_embedding, "node_embedding", exp_data_type, 2, dl_node_shape);

  auto dl_grad_node = assert_type_shape_strides(
    grad_node_embedding, "grad_node_embedding", exp_data_type, 2, dl_node_shape, true);

  int64_t dl_sm_shape[] = {2, params.num_heads, fg.n_indices};
  auto dl_sm =
    assert_type_shape_strides(softmax_scores, "softmax_scores", exp_data_type, 3, dl_sm_shape);
  auto dl_grad_sm = assert_type_shape_strides(
    grad_softmax_scores, "grad_softmax_scores", exp_data_type, 3, dl_sm_shape);

  int64_t dl_act_shape[] = {fg.n_indices, dim_node};
  auto dl_act            = assert_type_shape_strides(
    activation_scores, "activation_scores", exp_data_type, 2, dl_act_shape);

  int64_t dl_attn_shape[] = {dim_node};
  auto dl_attn_w          = assert_type_shape_strides(
    attention_weights, "attention_weights", exp_data_type, 1, dl_attn_shape);
  auto dl_grad_attn_w = assert_type_shape_strides(
    grad_attention_weights, "grad_attention_weights", exp_data_type, 1, dl_attn_shape, true);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::mha_gat_v2_fg_n2n_bwd(dl_grad_node.template get_ptr<float>(),
                                        dl_grad_attn_w.template get_ptr<float>(),
                                        dl_grad_sm.template get_ptr<float>(),
                                        dl_grad_out.template get_ptr<float>(),
                                        dl_node.template get_ptr<float>(),
                                        dl_attn_w.template get_ptr<float>(),
                                        dl_sm.template get_ptr<float>(),
                                        dl_act.template get_ptr<float>(),
                                        fg,
                                        params,
                                        dim_node,
                                        stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void mha_gat_v2_fg_n2n_efeat_fwd(nb::object& output_embedding,
                                 nb::object& softmax_scores,
                                 nb::object& activation_scores,
                                 nb::object& node_embedding,
                                 nb::object& edge_embedding,
                                 nb::object& attention_weights,
                                 const graph::fg_csr<IdxT>& fg,
                                 mha_params& params,
                                 const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_out            = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    output_embedding, "output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_out.dim(1);
  const auto& exp_data_type = dl_out.type();

  auto dim_node = (params.concat_heads) ? dim_out : dim_out * params.num_heads;

  int64_t dl_node_shape[] = {fg.n_nodes, dim_node};
  auto dl_node =
    assert_type_shape_strides(node_embedding, "node_embedding", exp_data_type, 2, dl_node_shape);

  int64_t dl_edge_shape[] = {fg.n_indices, dim_node};
  auto dl_edge =
    assert_type_shape_strides(edge_embedding, "edge_embedding", exp_data_type, 2, dl_edge_shape);

  int64_t dl_sm_shape[] = {2, params.num_heads, fg.n_indices};
  auto dl_sm =
    assert_type_shape_strides(softmax_scores, "softmax_scores", exp_data_type, 3, dl_sm_shape);

  int64_t dl_act_shape[] = {fg.n_indices, dim_node};
  auto dl_act            = assert_type_shape_strides(
    activation_scores, "activation_scores", exp_data_type, 2, dl_act_shape);

  int64_t dl_attn_shape[] = {dim_node};
  auto dl_attn_w          = assert_type_shape_strides(
    attention_weights, "attention_weights", exp_data_type, 1, dl_attn_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::mha_gat_v2_fg_n2n_efeat_fwd(dl_out.template get_ptr<float>(),
                                              dl_sm.template get_ptr<float>(),
                                              dl_act.template get_ptr<float>(),
                                              dl_node.template get_ptr<float>(),
                                              dl_edge.template get_ptr<float>(),
                                              dl_attn_w.template get_ptr<float>(),
                                              fg,
                                              params,
                                              dim_node,
                                              stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

template <typename IdxT>
void mha_gat_v2_fg_n2n_efeat_bwd(nb::object& grad_node_embedding,
                                 nb::object& grad_edge_embedding,
                                 nb::object& grad_attention_weights,
                                 nb::object& grad_softmax_scores,
                                 nb::object& grad_output_embedding,
                                 nb::object& node_embedding,
                                 nb::object& attention_weights,
                                 nb::object& softmax_scores,
                                 nb::object& activation_scores,
                                 const graph::fg_csr<IdxT>& fg,
                                 mha_params& params,
                                 const uintptr_t& stream_id)
{
  int64_t dl_out_shape[] = {fg.n_nodes, -1};
  auto dl_grad_out       = assert_type_shape_strides</* RESTRICTED_DTYPE */ true>(
    grad_output_embedding, "grad_output_embedding", DL_BF16_FP16_32_64, 2, dl_out_shape);
  auto dim_out              = dl_grad_out.dim(1);
  const auto& exp_data_type = dl_grad_out.type();

  auto dim_node = (params.concat_heads) ? dim_out : dim_out * params.num_heads;

  int64_t dl_node_shape[] = {fg.n_nodes, dim_node};
  auto dl_node =
    assert_type_shape_strides(node_embedding, "node_embedding", exp_data_type, 2, dl_node_shape);

  auto dl_grad_node = assert_type_shape_strides(
    grad_node_embedding, "grad_node_embedding", exp_data_type, 2, dl_node_shape, true);

  int64_t dl_edge_shape[] = {fg.n_indices, dim_node};
  auto dl_grad_edge       = assert_type_shape_strides(
    grad_edge_embedding, "grad_edge_embedding", exp_data_type, 2, dl_edge_shape, true);

  int64_t dl_sm_shape[] = {2, params.num_heads, fg.n_indices};
  auto dl_sm            = assert_type_shape_strides(
    softmax_scores, "softmax_scores", exp_data_type, 3, dl_sm_shape, true);
  auto dl_grad_sm = assert_type_shape_strides(
    grad_softmax_scores, "grad_softmax_scores", exp_data_type, 3, dl_sm_shape);

  int64_t dl_act_shape[] = {fg.n_indices, dim_node};
  auto dl_act            = assert_type_shape_strides(
    activation_scores, "activation_scores", exp_data_type, 2, dl_act_shape);

  int64_t dl_attn_shape[] = {dim_node};
  auto dl_attn_w          = assert_type_shape_strides(
    attention_weights, "attention_weights", exp_data_type, 1, dl_attn_shape);
  auto dl_grad_attn_w = assert_type_shape_strides(
    grad_attention_weights, "grad_attention_weights", exp_data_type, 1, dl_attn_shape);

  auto stream = cuda::stream(reinterpret_cast<const cudaStream_t&>(stream_id));

  if (exp_data_type.bits == 32) {
    cugraph::ops::mha_gat_v2_fg_n2n_efeat_bwd(dl_grad_node.template get_ptr<float>(),
                                              dl_grad_edge.template get_ptr<float>(),
                                              dl_grad_attn_w.template get_ptr<float>(),
                                              dl_grad_sm.template get_ptr<float>(),
                                              dl_grad_out.template get_ptr<float>(),
                                              dl_node.template get_ptr<float>(),
                                              dl_attn_w.template get_ptr<float>(),
                                              dl_sm.template get_ptr<float>(),
                                              dl_act.template get_ptr<float>(),
                                              fg,
                                              params,
                                              dim_node,
                                              stream);
  } else if (exp_data_type.bits == 16) {
    if (exp_data_type.code == kDLBfloat) {
      throw nb::import_error("Operator for DataType 'BFloat16' not implemented!");
    }
    throw nb::import_error("Operator for DataType 'Float16' not implemented!");
  } else {
    throw nb::import_error("Operator for DataType 'Double' not implemented!");
  }
}

}  // namespace cugraph::ops::binding

template <typename IdxT>
void init_mha_gat_v2_fg_n2n_fwd_bwd(nb::module_& m)
{
  m.def("mha_gat_v2_fg_n2n_fwd",
        &cugraph::ops::binding::mha_gat_v2_fg_n2n_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("softmax_scores"),
        nb::arg("activation_scores"),
        nb::arg("node_embedding"),
        nb::arg("attention_weights"),
        nb::arg("fg"),
        nb::arg("params"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(MHA_GAT_V2_FG_N2N_FWD_DOC));

  m.def("mha_gat_v2_fg_n2n_efeat_fwd",
        &cugraph::ops::binding::mha_gat_v2_fg_n2n_efeat_fwd<IdxT>,
        nb::arg("output_embedding"),
        nb::arg("softmax_scores"),
        nb::arg("activation_scores"),
        nb::arg("node_embedding"),
        nb::arg("edge_embedding"),
        nb::arg("attention_weights"),
        nb::arg("fg"),
        nb::arg("params"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(MHA_GAT_V2_FG_N2N_EFEAT_FWD_DOC));

  m.def("mha_gat_v2_fg_n2n_bwd",
        &cugraph::ops::binding::mha_gat_v2_fg_n2n_bwd<IdxT>,
        nb::arg("grad_node_embedding").none(),
        nb::arg("grad_attention_weights").none(),
        nb::arg("grad_softmax_scores"),
        nb::arg("grad_output_embedding"),
        nb::arg("node_embedding"),
        nb::arg("attention_weights"),
        nb::arg("softmax_scores"),
        nb::arg("activation_scores"),
        nb::arg("fg"),
        nb::arg("params"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(MHA_GAT_V2_FG_N2N_BWD_DOC));

  m.def("mha_gat_v2_fg_n2n_efeat_bwd",
        &cugraph::ops::binding::mha_gat_v2_fg_n2n_efeat_bwd<IdxT>,
        nb::arg("grad_node_embedding").none(),
        nb::arg("grad_edge_embedding").none(),
        nb::arg("grad_attention_weights").none(),
        nb::arg("grad_softmax_scores"),
        nb::arg("grad_output_embedding"),
        nb::arg("node_embedding"),
        nb::arg("attention_weights"),
        nb::arg("softmax_scores"),
        nb::arg("activation_scorees"),
        nb::arg("fg"),
        nb::arg("params"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(MHA_GAT_V2_FG_N2N_EFEAT_BWD_DOC));
}

void init_mha_gat_v2_fg(nb::module_& m)
{
  // the order of adding overloads matters (slightly) for performance
  // we add the 64-bit variant first since by default, PyTorch integer tensors
  // are 64-bit
  init_mha_gat_v2_fg_n2n_fwd_bwd<int64_t>(m);
  init_mha_gat_v2_fg_n2n_fwd_bwd<int32_t>(m);
}
