/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#pragma once

static constexpr const char* const MHA_GAT_MFG_N2N_FWD_DOC =
  R"(Computes the forward pass for a multi-head attention layer (GAT-like) without
     using cudnn (mha_gat) operating on message flow graphs (mfg) in a node-to-node
     reduction (n2n).

.. code-block:: python

    mha_gat_mfg_n2n_fwd(
        output_embedding: device array, softmax_scores: device array,
        input_embedding: device array, attention_weights: device array,
        mfg: pylibcugraphops.mfg_csr_int[32|64], params: pylibcugraphops.operators.mha_params,
        stream_id: int = 0
    ) -> None

Parameters
----------
output_embedding : device array type
    Device array containing the output embeddings of output nodes after attention.
    Shape: ``(mfg.n_out_nodes, dim)``.

softmax_scores : device array type
    Device array of softmax scores (needed for backward pass).
    Shape: ``(2, mfg.n_out_nodes, params.num_heads, mfg.sample_size+1)``.

input_embedding : device array type
    Device array containing the input embeddings of input nodes. For each
    node, the embedding associated with different heads are expected to be
    concatenated, with the total size being ``dim``.
    Shape: ``(mfg.n_in_nodes, dim)``.

attention_weights : device array type
    Device array of the attention weights.
    Shape: ``(2, dim)``.

mfg : opaque CSR graph type
    The graph used for the operation.

params : opaque mha_params type
    Structure summarizing hyperparameters of the primitive like ``num_heads``, ``concat_heads``
    or the used activation function.

stream_id : int, default=0
    CUDA stream pointer as a python int.

Examples
--------
>>> import cupy
>>> from pylibcugraphops import make_mfg_csr, mha_params, ActivationOp
>>> from pylibcugraphops.operators import mha_gat_mfg_n2n_fwd, mha_gat_mfg_n2n_bwd, activation_params
...
>>> cupy.random.seed(0)
>>> n_in_nodes, n_out_nodes, sample_size = 5, 2, 3
>>> out_nodes = cupy.arange(0, n_out_nodes)
>>> offsets = cupy.arange(0, sample_size*(1+n_out_nodes), sample_size)
>>> indices = cupy.random.randint(0, n_in_nodes, sample_size*n_out_nodes)
...
>>> mfg = make_mfg_csr(out_nodes, offsets, indices, sample_size, n_in_nodes)
...
>>> dim, num_heads, concat_heads = 4, 2, True
>>> activation = activation_params(0.2, ActivationOp.LeakyReLU)
>>> params = mha_params(activation, num_heads, concat_heads)
...
>>> dtype = cupy.float32
>>> output_emb = cupy.empty((n_out_nodes, dim), dtype=dtype)
>>> sm_scores = cupy.empty((2, n_out_nodes, num_heads, sample_size+1), dtype=dtype)
>>> input_emb = cupy.random.ranf((n_in_nodes, dim), dtype=dtype)
>>> attn_weights = cupy.random.ranf((2, dim), dtype=dtype)
...
>>> mha_gat_mfg_n2n_fwd(output_emb, sm_scores, input_emb, attn_weights, mfg, params)
...
>>> output_emb
[[0.639116   0.33007827 0.5529313  0.53337693]
 [0.60389125 0.329934   0.4211161  0.6845765 ]]
>>> sm_scores
[[[[0.35385016 0.2922997  0.35385016 0. ]
   [0.33211976 0.33576044 0.33211976 0. ]]
  [[0.3394063  0.29883364 0.36176    0. ]
   [0.3370772  0.33326823 0.32965457 0. ]]]
 [[[1.0915143  0.9004204  1.0915143  0. ]
   [1.060275   1.0711772  1.060275   0. ]]
  [[1.2000732  1.0727624  1.2638563  0. ]
   [1.0546062  1.0432419  1.0323396  0. ]]]]
...
>>> grad_input_emb = cupy.empty_like(input_emb, dtype=dtype)
>>> grad_attn_weights = cupy.empty_like(attn_weights, dtype=dtype)
>>> grad_output_emb = cupy.random.ranf(output_emb.shape, dtype=dtype)
...
>>> mha_gat_mfg_n2n_bwd(grad_input_emb, grad_attn_weights, grad_output_emb,
...                     input_emb, attn_weights, sm_scores, mfg, params)
...
>>> grad_input_emb
[[4.59992000e-09 7.19341076e-09 3.39992878e-09 7.70423014e-09]
 [4.79056239e-01 5.36319137e-01 2.08132595e-01 4.88811702e-01]
 [2.81328056e-02 2.09434196e-01 1.09593146e-01 2.75661707e-01]
 [0.00000000e+00 0.00000000e+00 0.00000000e+00 0.00000000e+00]
 [1.74064189e-01 2.61839688e-01 2.07691148e-01 4.29601669e-01]]
>>> grad_attn_weights
[[ 1.9169597e-02 -4.7847675e-03 -3.5764787e-02  3.9390489e-02]
 [ 1.9590921e-08  6.2790222e-09 -3.8959023e-09  4.2223469e-10]]
)";

static constexpr const char* const MHA_GAT_MFG_N2N_BWD_DOC =
  R"(Computes the backward pass of a multi-head attention layer (GAT-like) without
     using cudnn (mha_gat) operating on message flow graphs (mfg) in a node-to-node
     reduction (n2n).

.. code-block:: python

    mha_gat_mfg_n2n_bwd(
        grad_input_embedding: device array, grad_attention_weights: device array,
        grad_output_embedding: device array, input_embedding: device array, attention_weights: device array,
        softmax_scores: device array, mfg: pylibcugraphops.mfg_csr_int[32|64],
        params: pylibcugraphops.operators.mha_params, stream_id: int = 0
    ) -> None

Parameters
----------
grad_input_embedding : device array type
    Device array of the gradient w.r.t input embedding of input nodes.
    Shape: ``(mfg.n_in_nodes, dim)``.

grad_attention_weights : device array type
    Device array of the gradient w.r.t the attention weights.
    Shape: ``(2, dim)``.

grad_output_embedding : device array type
    Device array of the gradient w.r.t the output embeddings of output nodes.
    Shape: ``(mfg.n_out_nodes, dim)``.

input_embedding : device array type
    Device array containing the input embeddings of input nodes. For each
    node, the embedding associated with different heads are expected to be
    concatenated.
    Shape: same as ``grad_input_embedding``.

attention_weights : device array type
    Device array of the attention weights.
    Shape: same as ``grad_attention_weights``.

softmax_scores : device array type
    Device array of softmax scores (computed during forward pass).
    Shape: ``(2, mfg.n_out_nodes, params.num_heads, mfg.sample_size+1)``.

mfg : opaque CSR graph type
    The graph used for the operation.

params : opaque mha_params type
    Structure summarizing hyperparameters of the primitive like ``num_heads``, ``concat_heads``
    or the used activation function.

stream_id : int, default=0
    CUDA stream pointer as a python int.
)";
