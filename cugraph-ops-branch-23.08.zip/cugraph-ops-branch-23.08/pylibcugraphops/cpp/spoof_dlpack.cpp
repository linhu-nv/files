/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "dlpack/dlpack.h"
#include "dlpack/utils.hpp"

#include <nanobind/nanobind.h>

#include <cuda_runtime.h>

#include <Python.h>

#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

namespace nb = nanobind;

// this is a simple extension module with a few helpers to spoof DLPack tensors

// this first class is useful for testing cuda array interface bindings since
// the pointer actually needs to come from CUDA as we check the device based
// on the pointer value. This could be done in python using cuda-python, but
// since it is the only place we require cuda-python for tests, it makes sense
// to work around this in order to keep dependencies easier to manage
class cuda_ptr {
 private:
  int type_;
  void* ptr_;

 public:
  explicit cuda_ptr(int type) : type_(type)
  {
    cudaError_t status = cudaSuccess;
    ptr_               = nullptr;
    if (type == 0)
      status = cudaMalloc(&ptr_, 1);
    else if (type == 1)
      status = cudaMallocHost(&ptr_, 1);
    else if (type == 2)
      status = cudaMallocManaged(&ptr_, 1);
    if (status != cudaSuccess)
      throw std::domain_error("Cannot allocate 1 byte of type " + std::to_string(type) +
                              " from CUDA");
  }
  ~cuda_ptr() noexcept
  {
    cudaError_t status = cudaSuccess;
    if (type_ == 0 || type_ == 2)
      status = cudaFree(ptr_);
    else if (type_ == 1)
      status = cudaFreeHost(ptr_);
    if (status != cudaSuccess)
      std::cout << "FATAL: unable to deallocate pointer at " << ptr_ << " of type " << type_
                << std::endl;
  }
  uintptr_t get() { return reinterpret_cast<uintptr_t>(ptr_); }
};

class spoof_dl_pack {
 public:
  spoof_dl_pack(int64_t d1,
                int64_t d2,
                uint8_t dtype_code,
                uint8_t dtype_bits,
                uint16_t dtype_lanes,
                uint16_t device_code,
                bool _spoof_deleter = false,
                int64_t st1         = 0,
                int64_t st2         = 0) noexcept
  {
    shape_[0]      = d1;
    shape_[1]      = d2;
    shape_[2]      = st1;
    shape_[3]      = st2;
    tensor_.data   = reinterpret_cast<void*>(shape_);
    tensor_.device = {static_cast<DLDeviceType>(device_code), 0};
    tensor_.ndim   = 2;
    tensor_.dtype  = {dtype_code, dtype_bits, dtype_lanes};
    tensor_.shape  = shape_;
    if (st1 != 0 || st2 != 0)
      tensor_.strides = &shape_[2];
    else
      tensor_.strides = nullptr;
    tensor_.byte_offset = 0;
    spoof_deleter_      = _spoof_deleter;
  }

  static void capsule_deleter(PyObject* capsule)
  {
    if (PyCapsule_IsValid(capsule, "dltensor") != 0) {
      throw nb::type_error("Capsule should have been renamed before deleting");
    }
    std::cout << "Deleting spoofed DLPack capsule" << std::endl;
  }

  static void tensor_deleter(struct DLManagedTensor* dlm_tensor) { delete dlm_tensor; }

  nb::object get_dlpack()
  {
    std::cout << "Getting spoofed DLPack capsule ";
    if (spoof_deleter_)
      std::cout << "with";
    else
      std::cout << "without";
    std::cout << " deleter" << std::endl;
    DLManagedTensor* dlm_ptr;
    if (spoof_deleter_) {
      // we don't use a manager context, but we'll add the deleter
      dlm_ptr = new DLManagedTensor{tensor_, nullptr, spoof_dl_pack::tensor_deleter};
    } else {
      // we simply tie the life-time of the managed tensor to this instance
      // thus no need for a manager context or deleter.
      // also tests the case without manager/deleter
      dlm_tensor_ = {tensor_, nullptr, nullptr};
      dlm_ptr     = &dlm_tensor_;
    }
    auto* capsule = PyCapsule_New(dlm_ptr, "dltensor", spoof_dl_pack::capsule_deleter);
    if (PyErr_Occurred() != nullptr) throw nb::python_error();
    return nb::steal(capsule);
  }

 private:
  bool spoof_deleter_;
  DLTensor tensor_;
  DLManagedTensor dlm_tensor_;
  int64_t shape_[4];
};

bool test_single_object(nb::object& obj,
                        int32_t exp_n_dim,
                        int64_t exp_d1,
                        int64_t exp_d2,
                        uint8_t exp_dtype_code,
                        uint8_t exp_dtype_bits,
                        uint16_t exp_dtype_lanes,
                        bool allow_none)
{
  int64_t exp_shape[2] = {exp_d1, exp_d2};
  if (exp_dtype_lanes == 0) {
    cugraph::ops::binding::assert_type_shape_strides<true>(
      obj, "object", cugraph::ops::binding::DL_ANY_DTYPE, exp_n_dim, exp_shape, allow_none);
  } else {
    DLDataType exp_dtype{exp_dtype_code, exp_dtype_bits, exp_dtype_lanes};
    cugraph::ops::binding::assert_type_shape_strides(
      obj, "object", exp_dtype, exp_n_dim, exp_shape, allow_none);
  }
  return true;
}

void init_spoof_dlpack(nb::module_& m)
{
  nb::class_<cuda_ptr>(m, "CudaPtr")
    .def(nb::init<int>(), nb::arg("type"))
    .def("get", &cuda_ptr::get);

  nb::class_<spoof_dl_pack>(m, "SpoofDLPack")
    .def(nb::init<int64_t, int64_t, uint8_t, uint8_t, uint16_t, uint16_t, bool, int64_t, int64_t>(),
         nb::arg("d1"),
         nb::arg("d2"),
         nb::arg("dtype_code"),
         nb::arg("dtype_bits"),
         nb::arg("dtype_lanes"),
         nb::arg("device_code"),
         nb::arg("spoof_deleter") = false,
         nb::arg("st1")           = 0,
         nb::arg("st2")           = 0)
    .def("__dlpack__", &spoof_dl_pack::get_dlpack);

  m.def("test_single_object",
        &test_single_object,
        nb::arg("obj").none(),
        nb::arg("exp_n_dim"),
        nb::arg("exp_d1"),
        nb::arg("exp_d2"),
        nb::arg("exp_dtype_code"),
        nb::arg("exp_dtype_bits"),
        nb::arg("exp_dtype_lanes"),
        nb::arg("allow_none") = false);
}
