/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

#include <cugraph-ops/mma.hpp>

namespace nb = nanobind;

void init_global_types(nb::module_& m)
{
  nb::enum_<cugraph::ops::MMAOpT>(m, "MMAOp")
    .value("HighPrecision", cugraph::ops::MMAOpT::kHighPrecision)
    .value("LowPrecision", cugraph::ops::MMAOpT::kLowPrecision)
    .value("SIMT", cugraph::ops::MMAOpT::kSimt);
}
