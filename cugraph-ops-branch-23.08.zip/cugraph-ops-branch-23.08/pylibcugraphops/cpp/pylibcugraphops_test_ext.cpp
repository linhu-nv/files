/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

namespace nb = nanobind;

void init_spoof_dlpack(nb::module_&);

NB_MODULE(pylibcugraphops_test_ext, m)
{
  // test utils
  init_spoof_dlpack(m);
}
