/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include <nanobind/nanobind.h>

#include <cugraph-ops/operators/common.hpp>

namespace nb = nanobind;

void init_agg_concat_mfg(nb::module_&);
void init_agg_hg_basis_mfg(nb::module_&);
void init_agg_simple_mfg(nb::module_&);
void init_mha_gat_mfg(nb::module_&);

void init_agg_hg_basis_fg(nb::module_&);
void init_agg_concat_fg(nb::module_&);
void init_agg_dmpnn_fg(nb::module_&);
void init_agg_simple_fg(nb::module_&);
void init_agg_weighted_fg(nb::module_&);
void init_agg_concat_weighted_fg(nb::module_&);

void init_mha_gat_bipartite(nb::module_&);
void init_mha_gat_fg(nb::module_&);
void init_mha_gat_v2_bipartite(nb::module_&);
void init_mha_gat_v2_fg(nb::module_&);
void init_mha_simple_bipartite(nb::module_&);
void init_mha_simple_fg(nb::module_&);
void init_pool_fg(nb::module_&);

void init_update_efeat_bipartite(nb::module_&);
void init_update_efeat_static(nb::module_&);

void init_operators(nb::module_& m)
{
  auto ops = m.def_submodule("operators", "cugraph_ops graph operators");

  nb::enum_<cugraph::ops::AggOpT>(ops, "AggOp")
    .value("Mean", cugraph::ops::AggOpT::kMean)
    .value("Sum", cugraph::ops::AggOpT::kSum)
    .value("Max", cugraph::ops::AggOpT::kMax)
    .value("Min", cugraph::ops::AggOpT::kMin);

  nb::enum_<cugraph::ops::ActivationOpT>(m, "ActivationOp")
    .value("Linear", cugraph::ops::ActivationOpT::kLinear)
    .value("ReLU", cugraph::ops::ActivationOpT::kRelu)
    .value("Sigmoid", cugraph::ops::ActivationOpT::kSigmoid)
    .value("Tanh", cugraph::ops::ActivationOpT::kTanh)
    .value("ELU", cugraph::ops::ActivationOpT::kELU)
    .value("Scalar", cugraph::ops::ActivationOpT::kScalar)
    .value("LeakyReLU", cugraph::ops::ActivationOpT::kLeakyRelu);

  nb::class_<cugraph::ops::activation_params>(ops, "activation_params")
    .def(nb::init<float, cugraph::ops::ActivationOpT>(),
         nb::arg("alpha") = 0.0,
         nb::arg("type")  = cugraph::ops::ActivationOpT::kLinear)
    .def_rw("alpha", &cugraph::ops::activation_params::alpha)
    .def_rw("type", &cugraph::ops::activation_params::type);

  nb::class_<cugraph::ops::mha_params>(m, "mha_params")
    .def(nb::init<>())
    .def(nb::init<cugraph::ops::activation_params, int, bool>(),
         nb::arg("activation"),
         nb::arg("num_heads"),
         nb::arg("concat_heads") = true)
    .def_rw("activation", &cugraph::ops::mha_params::activation)
    .def_rw("num_heads", &cugraph::ops::mha_params::num_heads)
    .def_rw("concat_heads", &cugraph::ops::mha_params::concat_heads);

  init_agg_hg_basis_fg(ops);
  init_agg_concat_fg(ops);
  init_agg_dmpnn_fg(ops);
  init_agg_simple_fg(ops);
  init_agg_weighted_fg(ops);
  init_agg_concat_weighted_fg(ops);
  init_mha_gat_bipartite(ops);
  init_mha_gat_fg(ops);
  init_mha_gat_v2_bipartite(ops);
  init_mha_gat_v2_fg(ops);
  init_mha_simple_bipartite(ops);
  init_mha_simple_fg(ops);
  init_pool_fg(ops);

  init_agg_concat_mfg(ops);
  init_agg_simple_mfg(ops);
  init_mha_gat_mfg(ops);
  init_agg_hg_basis_mfg(ops);

  init_update_efeat_bipartite(ops);
  init_update_efeat_static(ops);
}
