/*
 * Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.
 *
 * This source code and/or documentation ("Licensed Deliverables") are
 * subject to NVIDIA intellectual property rights under U.S. and
 * international Copyright laws.
 */

#include "dimenet_doc.hpp"
#include "dlpack/dlpack.h"
#include "dlpack/utils.hpp"

#include <cugraph-ops/dimenet/agg_edge_to_edge.hpp>
#include <cugraph-ops/dimenet/radial_basis.hpp>
#include <cugraph-ops/graph/format.hpp>

#include <nanobind/nanobind.h>

#include <cstdint>

namespace nb = nanobind;

namespace cugraph::ops::binding {

static constexpr int N_DIST = 1, N_SPHERICAL = 7, N_RADIAL = 6, N_VEC = 3;
static constexpr int N_SBF = N_SPHERICAL * N_RADIAL;

void radial_basis_fwd(nb::object& output_rbf,
                      nb::object& output_sbf_rad,
                      nb::object& input_vector,
                      nb::object& input_w)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  int64_t dl_output_rbf_shape[] = {-1, N_RADIAL};
  auto dl_output_rbf            = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_rbf, "output_rbf", DL_FP32_64, 2, dl_output_rbf_shape);
  auto n_edges              = dl_output_rbf.dim(0);
  const auto& exp_data_type = dl_output_rbf.type();

  int64_t dl_output_sbf_rad_shape[] = {n_edges, N_SBF};
  auto dl_output_sbf_rad            = assert_type_shape_strides(
    output_sbf_rad, "output_sbf_rad", exp_data_type, 2, dl_output_sbf_rad_shape);

  int64_t dl_input_vector_shape[] = {n_edges, N_DIST};
  auto dl_input_vector            = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_input_vector_shape);

  int64_t dl_input_w_shape[] = {N_RADIAL};
  auto dl_input_w =
    assert_type_shape_strides(input_w, "input_w", exp_data_type, 1, dl_input_w_shape);

  if (exp_data_type.bits == 32) {
    dimenet::radial_basis_fwd(dl_output_rbf.get_ptr<float>(),
                              dl_output_sbf_rad.get_ptr<float>(),
                              dl_input_vector.get_ptr<float>(),
                              dl_input_w.get_ptr<float>(),
                              static_cast<int32_t>(n_edges),
                              nullptr);
  } else {
    dimenet::radial_basis_fwd(dl_output_rbf.get_ptr<double>(),
                              dl_output_sbf_rad.get_ptr<double>(),
                              dl_input_vector.get_ptr<double>(),
                              dl_input_w.get_ptr<double>(),
                              static_cast<int32_t>(n_edges),
                              nullptr);
  }
}

void radial_basis_bwd(nb::object& output_grad_vector,
                      nb::object& output_grad_w,
                      nb::object& input_grad_rbf,
                      nb::object& input_grad_sbf_rad,
                      nb::object& input_vector,
                      nb::object& input_w)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  int64_t dl_output_grad_vector_shape[] = {-1, N_DIST};
  auto dl_output_grad_vector            = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_grad_vector, "output_grad_vector", DL_FP32_64, 2, dl_output_grad_vector_shape);
  auto n_edges              = dl_output_grad_vector.dim(0);
  const auto& exp_data_type = dl_output_grad_vector.type();

  int64_t dl_output_grad_w_shape[] = {N_RADIAL};
  auto dl_output_grad_w            = assert_type_shape_strides(
    output_grad_w, "output_grad_w", exp_data_type, 1, dl_output_grad_w_shape);

  int64_t dl_input_grad_rbf_shape[] = {n_edges, N_RADIAL};
  auto dl_input_grad_rbf            = assert_type_shape_strides(
    input_grad_rbf, "input_grad_rbf", exp_data_type, 2, dl_input_grad_rbf_shape);

  int64_t dl_input_grad_sbf_rad_shape[] = {n_edges, N_SBF};
  auto dl_input_grad_sbf_rad            = assert_type_shape_strides(
    input_grad_sbf_rad, "input_grad_sbf_rad", exp_data_type, 2, dl_input_grad_sbf_rad_shape);

  auto dl_input_vector = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_output_grad_vector.shape());

  auto dl_input_w =
    assert_type_shape_strides(input_w, "input_w", exp_data_type, 1, dl_output_grad_w.shape());

  if (exp_data_type.bits == 32) {
    dimenet::radial_basis_bwd(dl_output_grad_vector.get_ptr<float>(),
                              dl_output_grad_w.get_ptr<float>(),
                              dl_input_grad_rbf.get_ptr<float>(),
                              dl_input_grad_sbf_rad.get_ptr<float>(),
                              dl_input_vector.get_ptr<float>(),
                              dl_input_w.get_ptr<float>(),
                              static_cast<int32_t>(n_edges),
                              nullptr);
  } else {
    dimenet::radial_basis_bwd(dl_output_grad_vector.get_ptr<double>(),
                              dl_output_grad_w.get_ptr<double>(),
                              dl_input_grad_rbf.get_ptr<double>(),
                              dl_input_grad_sbf_rad.get_ptr<double>(),
                              dl_input_vector.get_ptr<double>(),
                              dl_input_w.get_ptr<double>(),
                              static_cast<int32_t>(n_edges),
                              nullptr);
  }
}

void radial_basis_bwd_bwd(nb::object& output_grad_grad_rbf,
                          nb::object& output_grad_grad_sbf_rad,
                          nb::object& output_grad_w,
                          nb::object& input_grad_grad_vector,
                          nb::object& input_grad_grad_w,
                          nb::object& input_grad_rbf,
                          nb::object& input_grad_sbf_rad,
                          nb::object& input_vector,
                          nb::object& input_w)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  int64_t dl_output_grad_grad_rbf_shape[] = {-1, N_RADIAL};
  auto dl_output_grad_grad_rbf            = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_grad_grad_rbf, "output_grad_grad_rbf", DL_FP32_64, 2, dl_output_grad_grad_rbf_shape);
  auto n_edges              = dl_output_grad_grad_rbf.dim(0);
  const auto& exp_data_type = dl_output_grad_grad_rbf.type();

  int64_t dl_output_grad_grad_sbf_rad_shape[] = {n_edges, N_SBF};
  auto dl_output_grad_grad_sbf_rad            = assert_type_shape_strides(output_grad_grad_sbf_rad,
                                                               "output_grad_grad_sbf_rad",
                                                               exp_data_type,
                                                               2,
                                                               dl_output_grad_grad_sbf_rad_shape);

  int64_t dl_output_grad_w_shape[] = {N_RADIAL};
  auto dl_output_grad_w            = assert_type_shape_strides(
    output_grad_w, "output_grad_w", exp_data_type, 1, dl_output_grad_w_shape);

  int64_t dl_input_grad_grad_vector_shape[] = {n_edges, N_DIST};
  auto dl_input_grad_grad_vector            = assert_type_shape_strides(input_grad_grad_vector,
                                                             "input_grad_grad_vector",
                                                             exp_data_type,
                                                             2,
                                                             dl_input_grad_grad_vector_shape);

  auto dl_input_grad_grad_w = assert_type_shape_strides(
    input_grad_grad_w, "input_grad_grad_w", exp_data_type, 1, dl_output_grad_w.shape());

  auto dl_input_grad_rbf = assert_type_shape_strides(
    input_grad_rbf, "input_grad_rbf", exp_data_type, 2, dl_output_grad_grad_rbf.shape());

  auto dl_input_grad_sbf_rad = assert_type_shape_strides(input_grad_sbf_rad,
                                                         "input_grad_sbf_rad",
                                                         exp_data_type,
                                                         2,
                                                         dl_output_grad_grad_sbf_rad.shape());

  auto dl_input_vector = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_input_grad_grad_vector.shape());

  auto dl_input_w =
    assert_type_shape_strides(input_w, "input_w", exp_data_type, 1, dl_output_grad_w.shape());

  if (exp_data_type.bits == 32) {
    dimenet::radial_basis_bwd_bwd(dl_output_grad_grad_rbf.get_ptr<float>(),
                                  dl_output_grad_grad_sbf_rad.get_ptr<float>(),
                                  dl_output_grad_w.get_ptr<float>(),
                                  dl_input_grad_grad_vector.get_ptr<float>(),
                                  dl_input_grad_grad_w.get_ptr<float>(),
                                  dl_input_grad_rbf.get_ptr<float>(),
                                  dl_input_grad_sbf_rad.get_ptr<float>(),
                                  dl_input_vector.get_ptr<float>(),
                                  dl_input_w.get_ptr<float>(),
                                  static_cast<int32_t>(n_edges),
                                  nullptr);
  } else {
    dimenet::radial_basis_bwd_bwd(dl_output_grad_grad_rbf.get_ptr<double>(),
                                  dl_output_grad_grad_sbf_rad.get_ptr<double>(),
                                  dl_output_grad_w.get_ptr<double>(),
                                  dl_input_grad_grad_vector.get_ptr<double>(),
                                  dl_input_grad_grad_w.get_ptr<double>(),
                                  dl_input_grad_rbf.get_ptr<double>(),
                                  dl_input_grad_sbf_rad.get_ptr<double>(),
                                  dl_input_vector.get_ptr<double>(),
                                  dl_input_w.get_ptr<double>(),
                                  static_cast<int32_t>(n_edges),
                                  nullptr);
  }
}

void agg_edge_to_edge_fwd(nb::object& output_embedding,
                          nb::object& input_vector,
                          nb::object& input_rbf,
                          nb::object& input_embedding,
                          nb::object& input_weights,
                          nb::object& coo_idx,
                          nb::object& dst_offsets,
                          nb::object& dst_edge_index,
                          MMAOpT mma_op,
                          const uintptr_t& stream_id)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  auto dl_output_embedding = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_embedding, "output_embedding", DL_FP32_64, 2);
  auto n_edges              = dl_output_embedding.dim(0);
  auto n_emb                = dl_output_embedding.dim(1);
  const auto& exp_data_type = dl_output_embedding.type();

  int64_t dl_input_vector_shape[] = {n_edges, N_VEC};
  auto dl_input_vector            = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_input_vector_shape);

  int64_t dl_input_rbf_shape[] = {n_edges, N_SBF};
  auto dl_input_rbf =
    assert_type_shape_strides(input_rbf, "input_rbf", exp_data_type, 2, dl_input_rbf_shape);

  auto dl_input_embedding = assert_type_shape_strides(
    input_embedding, "input_embedding", exp_data_type, 2, dl_output_embedding.shape());

  int64_t dl_input_weights_shape[] = {N_SBF + n_emb, -1};
  auto dl_input_weights            = assert_type_shape_strides(
    input_weights, "input_weights", exp_data_type, 2, dl_input_weights_shape);
  auto n_mid = dl_input_weights.dim(1);

  int64_t dl_coo_idx_shape[] = {2, n_edges};
  auto dl_coo_idx = assert_type_shape_strides(coo_idx, "coo_idx", DL_S64, 2, dl_coo_idx_shape);

  // cannot determine number of nodes, so no check for shape here
  auto dl_dst_offsets = assert_type_shape_strides(dst_offsets, "dst_offsets", DL_S64, 1);

  int64_t dl_dst_edge_index_shape[] = {n_edges};
  auto dl_dst_edge_index =
    assert_type_shape_strides(dst_edge_index, "dst_edge_index", DL_S64, 1, dl_dst_edge_index_shape);

  auto* stream = reinterpret_cast<const cudaStream_t&>(stream_id);

  if (exp_data_type.bits == 32) {
    dimenet::agg_edge_to_edge_fwd(dl_output_embedding.get_ptr<float>(),
                                  n_edges,
                                  dl_input_vector.get_ptr<float>(),
                                  dl_input_rbf.get_ptr<float>(),
                                  dl_input_embedding.get_ptr<float>(),
                                  n_emb,
                                  dl_input_weights.get_ptr<float>(),
                                  n_mid,
                                  dl_coo_idx.get_ptr<int64_t>(),
                                  dl_dst_offsets.get_ptr<int64_t>(),
                                  dl_dst_edge_index.get_ptr<int64_t>(),
                                  mma_op,
                                  stream);
  } else {
    dimenet::agg_edge_to_edge_fwd(dl_output_embedding.get_ptr<double>(),
                                  n_edges,
                                  dl_input_vector.get_ptr<double>(),
                                  dl_input_rbf.get_ptr<double>(),
                                  dl_input_embedding.get_ptr<double>(),
                                  n_emb,
                                  dl_input_weights.get_ptr<double>(),
                                  n_mid,
                                  dl_coo_idx.get_ptr<int64_t>(),
                                  dl_dst_offsets.get_ptr<int64_t>(),
                                  dl_dst_edge_index.get_ptr<int64_t>(),
                                  mma_op,
                                  stream);
  }
}

void agg_edge_to_edge_bwd(nb::object& output_grad_rbf,
                          nb::object& output_grad_embedding,
                          nb::object& output_grad_weights,
                          nb::object& input_vector,
                          nb::object& input_rbf,
                          nb::object& input_embedding,
                          nb::object& input_grad_embedding,
                          nb::object& input_weights,
                          nb::object& coo_idx,
                          nb::object& src_offsets,
                          MMAOpT mma_op,
                          const uintptr_t& stream_id)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  int64_t dl_output_grad_rbf_shape[] = {-1, N_SBF};
  auto dl_output_grad_rbf            = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_grad_rbf, "output_grad_rbf", DL_FP32_64, 2, dl_output_grad_rbf_shape);
  auto n_edges              = dl_output_grad_rbf.dim(0);
  const auto& exp_data_type = dl_output_grad_rbf.type();

  int64_t dl_output_grad_embedding_shape[] = {n_edges, -1};
  auto dl_output_grad_embedding            = assert_type_shape_strides(output_grad_embedding,
                                                            "output_grad_embedding",
                                                            exp_data_type,
                                                            2,
                                                            dl_output_grad_embedding_shape);
  auto n_emb                               = dl_output_grad_embedding.dim(1);

  int64_t dl_output_grad_weights_shape[] = {N_SBF + n_emb, -1};
  auto dl_output_grad_weights            = assert_type_shape_strides(
    output_grad_weights, "output_grad_weights", exp_data_type, 2, dl_output_grad_weights_shape);
  auto n_mid = dl_output_grad_weights.dim(1);

  int64_t dl_input_vector_shape[] = {n_edges, N_VEC};
  auto dl_input_vector            = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_input_vector_shape);

  auto dl_input_rbf =
    assert_type_shape_strides(input_rbf, "input_rbf", exp_data_type, 2, dl_output_grad_rbf.shape());

  auto dl_input_embedding = assert_type_shape_strides(
    input_embedding, "input_embedding", exp_data_type, 2, dl_output_grad_embedding.shape());

  auto dl_input_grad_embedding = assert_type_shape_strides(input_grad_embedding,
                                                           "input_grad_embedding",
                                                           exp_data_type,
                                                           2,
                                                           dl_output_grad_embedding.shape());

  auto dl_input_weights = assert_type_shape_strides(
    input_weights, "input_weights", exp_data_type, 2, dl_output_grad_weights.shape());

  int64_t dl_coo_idx_shape[] = {2, n_edges};
  auto dl_coo_idx = assert_type_shape_strides(coo_idx, "coo_idx", DL_S64, 2, dl_coo_idx_shape);

  // cannot determine number of nodes, so no check for shape here
  auto dl_src_offsets = assert_type_shape_strides(src_offsets, "src_offsets", DL_S64, 1);

  auto* stream = reinterpret_cast<const cudaStream_t&>(stream_id);

  if (exp_data_type.bits == 32) {
    dimenet::agg_edge_to_edge_bwd(dl_output_grad_rbf.get_ptr<float>(),
                                  dl_output_grad_embedding.get_ptr<float>(),
                                  dl_output_grad_weights.get_ptr<float>(),
                                  n_edges,
                                  dl_input_vector.get_ptr<float>(),
                                  dl_input_rbf.get_ptr<float>(),
                                  dl_input_embedding.get_ptr<float>(),
                                  dl_input_grad_embedding.get_ptr<float>(),
                                  n_emb,
                                  dl_input_weights.get_ptr<float>(),
                                  n_mid,
                                  dl_coo_idx.get_ptr<int64_t>(),
                                  dl_src_offsets.get_ptr<int64_t>(),
                                  mma_op,
                                  stream);
  } else {
    dimenet::agg_edge_to_edge_bwd(dl_output_grad_rbf.get_ptr<double>(),
                                  dl_output_grad_embedding.get_ptr<double>(),
                                  dl_output_grad_weights.get_ptr<double>(),
                                  n_edges,
                                  dl_input_vector.get_ptr<double>(),
                                  dl_input_rbf.get_ptr<double>(),
                                  dl_input_embedding.get_ptr<double>(),
                                  dl_input_grad_embedding.get_ptr<double>(),
                                  n_emb,
                                  dl_input_weights.get_ptr<double>(),
                                  n_mid,
                                  dl_coo_idx.get_ptr<int64_t>(),
                                  dl_src_offsets.get_ptr<int64_t>(),
                                  mma_op,
                                  stream);
  }
}

void agg_edge_to_edge_bwd2_grad(nb::object& output_grad_grad_embedding,
                                nb::object& input_vector,
                                nb::object& input_rbf,
                                nb::object& input_grad_grad_rbf,
                                nb::object& input_embedding,
                                nb::object& input_grad_grad_embedding,
                                nb::object& input_weights,
                                nb::object& coo_idx,
                                nb::object& dst_offsets,
                                nb::object& dst_edge_index,
                                MMAOpT mma_op,
                                const uintptr_t& stream_id)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  auto dl_output_grad_grad_embedding = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_grad_grad_embedding, "output_grad_grad_embedding", DL_FP32_64, 2);
  auto n_edges              = dl_output_grad_grad_embedding.dim(0);
  auto n_emb                = dl_output_grad_grad_embedding.dim(1);
  const auto& exp_data_type = dl_output_grad_grad_embedding.type();

  int64_t dl_input_vector_shape[] = {n_edges, N_VEC};
  auto dl_input_vector            = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_input_vector_shape);

  int64_t dl_input_rbf_shape[] = {n_edges, N_SBF};
  auto dl_input_rbf =
    assert_type_shape_strides(input_rbf, "input_rbf", exp_data_type, 2, dl_input_rbf_shape);

  auto dl_input_grad_grad_rbf = assert_type_shape_strides(
    input_grad_grad_rbf, "input_grad_grad_rbf", exp_data_type, 2, dl_input_rbf.shape());

  auto dl_input_embedding = assert_type_shape_strides(
    input_embedding, "input_embedding", exp_data_type, 2, dl_output_grad_grad_embedding.shape());

  auto dl_input_grad_grad_embedding =
    assert_type_shape_strides(input_grad_grad_embedding,
                              "input_grad_grad_embedding",
                              exp_data_type,
                              2,
                              dl_output_grad_grad_embedding.shape());

  int64_t input_weights_shape[] = {N_SBF + n_emb, -1};
  auto dl_input_weights         = assert_type_shape_strides(
    input_weights, "input_weights", exp_data_type, 2, input_weights_shape);
  auto n_mid = dl_input_weights.dim(1);

  int64_t dl_coo_idx_shape[] = {2, n_edges};
  auto dl_coo_idx = assert_type_shape_strides(coo_idx, "coo_idx", DL_S64, 2, dl_coo_idx_shape);

  // cannot determine number of nodes, so no check for shape here
  auto dl_dst_offsets = assert_type_shape_strides(dst_offsets, "dst_offsets", DL_S64, 1);

  int64_t dl_dst_edge_index_shape[] = {n_edges};
  auto dl_dst_edge_index =
    assert_type_shape_strides(dst_edge_index, "dst_edge_index", DL_S64, 1, dl_dst_edge_index_shape);

  auto* stream = reinterpret_cast<const cudaStream_t&>(stream_id);

  if (exp_data_type.bits == 32) {
    dimenet::agg_edge_to_edge_bwd2_grad(dl_output_grad_grad_embedding.get_ptr<float>(),
                                        n_edges,
                                        dl_input_vector.get_ptr<float>(),
                                        dl_input_rbf.get_ptr<float>(),
                                        dl_input_grad_grad_rbf.get_ptr<float>(),
                                        dl_input_embedding.get_ptr<float>(),
                                        dl_input_grad_grad_embedding.get_ptr<float>(),
                                        n_emb,
                                        dl_input_weights.get_ptr<float>(),
                                        n_mid,
                                        dl_coo_idx.get_ptr<int64_t>(),
                                        dl_dst_offsets.get_ptr<int64_t>(),
                                        dl_dst_edge_index.get_ptr<int64_t>(),
                                        mma_op,
                                        stream);
  } else {
    dimenet::agg_edge_to_edge_bwd2_grad(dl_output_grad_grad_embedding.get_ptr<double>(),
                                        n_edges,
                                        dl_input_vector.get_ptr<double>(),
                                        dl_input_rbf.get_ptr<double>(),
                                        dl_input_grad_grad_rbf.get_ptr<double>(),
                                        dl_input_embedding.get_ptr<double>(),
                                        dl_input_grad_grad_embedding.get_ptr<double>(),
                                        n_emb,
                                        dl_input_weights.get_ptr<double>(),
                                        n_mid,
                                        dl_coo_idx.get_ptr<int64_t>(),
                                        dl_dst_offsets.get_ptr<int64_t>(),
                                        dl_dst_edge_index.get_ptr<int64_t>(),
                                        mma_op,
                                        stream);
  }
}

void agg_edge_to_edge_bwd2_main(nb::object& output_grad_rbf_grad_embedding,
                                nb::object& output_grad_embedding_grad_rbf,
                                nb::object& output_grad_weights,
                                nb::object& input_vector,
                                nb::object& input_rbf,
                                nb::object& input_grad_grad_rbf,
                                nb::object& input_embedding,
                                nb::object& input_grad_grad_embedding,
                                nb::object& input_grad_embedding,
                                nb::object& input_weights,
                                nb::object& coo_idx,
                                nb::object& src_offsets,
                                MMAOpT mma_op,
                                const uintptr_t& stream_id)
{
  // use restricted data type for first tensor to check for either 32 or 64 bits
  int64_t dl_output_grad_rbf_grad_embedding_shape[] = {-1, N_SBF};
  auto dl_output_grad_rbf_grad_embedding = assert_type_shape_strides</* RESTRICTED_DTYPE= */ true>(
    output_grad_rbf_grad_embedding,
    "output_grad_rbf_grad_embedding",
    DL_FP32_64,
    2,
    dl_output_grad_rbf_grad_embedding_shape);
  auto n_edges              = dl_output_grad_rbf_grad_embedding.dim(0);
  const auto& exp_data_type = dl_output_grad_rbf_grad_embedding.type();

  int64_t dl_output_grad_embedding_grad_rbf_shape[] = {n_edges, -1};
  auto dl_output_grad_embedding_grad_rbf =
    assert_type_shape_strides(output_grad_embedding_grad_rbf,
                              "output_grad_embedding_grad_rbf",
                              exp_data_type,
                              2,
                              dl_output_grad_embedding_grad_rbf_shape);
  auto n_emb = dl_output_grad_embedding_grad_rbf.dim(1);

  int64_t dl_output_grad_weights_shape[] = {N_SBF + n_emb, -1};
  auto dl_output_grad_weights            = assert_type_shape_strides(
    output_grad_weights, "output_grad_weights", exp_data_type, 2, dl_output_grad_weights_shape);

  int64_t dl_input_vector_shape[] = {n_edges, N_VEC};
  auto dl_input_vector            = assert_type_shape_strides(
    input_vector, "input_vector", exp_data_type, 2, dl_input_vector_shape);

  auto dl_input_rbf = assert_type_shape_strides(
    input_rbf, "input_rbf", exp_data_type, 2, dl_output_grad_rbf_grad_embedding.shape());

  auto dl_input_grad_grad_rbf =
    assert_type_shape_strides(input_grad_grad_rbf,
                              "input_grad_grad_rbf",
                              exp_data_type,
                              2,
                              dl_output_grad_rbf_grad_embedding.shape());

  auto dl_input_embedding = assert_type_shape_strides(input_embedding,
                                                      "input_embedding",
                                                      exp_data_type,
                                                      2,
                                                      dl_output_grad_embedding_grad_rbf.shape());

  auto dl_input_grad_grad_embedding =
    assert_type_shape_strides(input_grad_grad_embedding,
                              "input_grad_grad_embedding",
                              exp_data_type,
                              2,
                              dl_output_grad_embedding_grad_rbf.shape());

  auto dl_input_grad_embedding =
    assert_type_shape_strides(input_grad_embedding,
                              "input_grad_embedding",
                              exp_data_type,
                              2,
                              dl_output_grad_embedding_grad_rbf.shape());

  auto dl_input_weights = assert_type_shape_strides(
    input_weights, "input_weights", exp_data_type, 2, dl_output_grad_weights.shape());
  auto n_mid = dl_input_weights.dim(1);

  int64_t dl_coo_idx_shape[] = {2, n_edges};
  auto dl_coo_idx = assert_type_shape_strides(coo_idx, "coo_idx", DL_S64, 2, dl_coo_idx_shape);

  // cannot determine number of nodes, so no check for shape here
  auto dl_src_offsets = assert_type_shape_strides(src_offsets, "src_offsets", DL_S64, 1);

  auto* stream = reinterpret_cast<const cudaStream_t&>(stream_id);

  if (exp_data_type.bits == 32) {
    dimenet::agg_edge_to_edge_bwd2_main(dl_output_grad_rbf_grad_embedding.get_ptr<float>(),
                                        dl_output_grad_embedding_grad_rbf.get_ptr<float>(),
                                        dl_output_grad_weights.get_ptr<float>(),
                                        n_edges,
                                        dl_input_vector.get_ptr<float>(),
                                        dl_input_rbf.get_ptr<float>(),
                                        dl_input_grad_grad_rbf.get_ptr<float>(),
                                        dl_input_embedding.get_ptr<float>(),
                                        dl_input_grad_grad_embedding.get_ptr<float>(),
                                        dl_input_grad_embedding.get_ptr<float>(),
                                        n_emb,
                                        dl_input_weights.get_ptr<float>(),
                                        n_mid,
                                        dl_coo_idx.get_ptr<int64_t>(),
                                        dl_src_offsets.get_ptr<int64_t>(),
                                        mma_op,
                                        stream);
  } else {
    dimenet::agg_edge_to_edge_bwd2_main(dl_output_grad_rbf_grad_embedding.get_ptr<double>(),
                                        dl_output_grad_embedding_grad_rbf.get_ptr<double>(),
                                        dl_output_grad_weights.get_ptr<double>(),
                                        n_edges,
                                        dl_input_vector.get_ptr<double>(),
                                        dl_input_rbf.get_ptr<double>(),
                                        dl_input_grad_grad_rbf.get_ptr<double>(),
                                        dl_input_embedding.get_ptr<double>(),
                                        dl_input_grad_grad_embedding.get_ptr<double>(),
                                        dl_input_grad_embedding.get_ptr<double>(),
                                        n_emb,
                                        dl_input_weights.get_ptr<double>(),
                                        n_mid,
                                        dl_coo_idx.get_ptr<int64_t>(),
                                        dl_src_offsets.get_ptr<int64_t>(),
                                        mma_op,
                                        stream);
  }
}

}  // namespace cugraph::ops::binding

void init_dimenet(nb::module_& main_module)
{
  auto m = main_module.def_submodule("dimenet");
  // output_extrema_location allows None as input
  m.def("radial_basis_fwd",
        &cugraph::ops::binding::radial_basis_fwd,
        nb::arg("output_rbf"),
        nb::arg("output_sbf_rad"),
        nb::arg("input_vector"),
        nb::arg("input_w"),
        nb::raw_doc(RADIAL_BASIS_FWD_DOC));
  m.def("radial_basis_bwd",
        &cugraph::ops::binding::radial_basis_bwd,
        nb::arg("output_grad_vector"),
        nb::arg("output_grad_w"),
        nb::arg("input_grad_rbf"),
        nb::arg("input_grad_sbf_rad"),
        nb::arg("input_vector"),
        nb::arg("input_w"),
        nb::raw_doc(RADIAL_BASIS_BWD_DOC));
  m.def("radial_basis_bwd_bwd",
        &cugraph::ops::binding::radial_basis_bwd_bwd,
        nb::arg("output_grad_grad_rbf"),
        nb::arg("output_grad_grad_sbf_rad"),
        nb::arg("output_grad_w"),
        nb::arg("input_grad_grad_vector"),
        nb::arg("input_grad_grad_w"),
        nb::arg("input_grad_rbf"),
        nb::arg("input_grad_sbf_rad"),
        nb::arg("input_vector"),
        nb::arg("input_w"),
        nb::raw_doc(RADIAL_BASIS_BWD_BWD_DOC));

  m.def("agg_edge_to_edge_fwd",
        &cugraph::ops::binding::agg_edge_to_edge_fwd,
        nb::arg("output_embedding"),
        nb::arg("input_vector"),
        nb::arg("input_rbf"),
        nb::arg("input_embedding"),
        nb::arg("input_weights"),
        nb::arg("coo_idx"),
        nb::arg("dst_offsets"),
        nb::arg("dst_edge_index"),
        nb::arg("mma_op"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(AGG_EDGE_TO_EDGE_FWD_DOC));
  m.def("agg_edge_to_edge_bwd",
        &cugraph::ops::binding::agg_edge_to_edge_bwd,
        nb::arg("output_grad_rbf"),
        nb::arg("output_grad_embedding"),
        nb::arg("output_grad_weights"),
        nb::arg("input_vector"),
        nb::arg("input_rbf"),
        nb::arg("input_embedding"),
        nb::arg("input_grad_embedding"),
        nb::arg("input_weights"),
        nb::arg("coo_idx"),
        nb::arg("src_offsets"),
        nb::arg("mma_op"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(AGG_EDGE_TO_EDGE_BWD_DOC));
  m.def("agg_edge_to_edge_bwd2_grad",
        &cugraph::ops::binding::agg_edge_to_edge_bwd2_grad,
        nb::arg("output_grad_grad_embedding"),
        nb::arg("input_vector"),
        nb::arg("input_rbf"),
        nb::arg("input_grad_grad_rbf"),
        nb::arg("input_embedding"),
        nb::arg("input_grad_grad_embedding"),
        nb::arg("input_weights"),
        nb::arg("coo_idx"),
        nb::arg("dst_offsets"),
        nb::arg("dst_edge_index"),
        nb::arg("mma_op"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(AGG_EDGE_TO_EDGE_BWD2_GRAD_DOC));
  m.def("agg_edge_to_edge_bwd2_main",
        &cugraph::ops::binding::agg_edge_to_edge_bwd2_main,
        nb::arg("output_grad_rbf_grad_embedding"),
        nb::arg("output_grad_embedding_grad_rbf"),
        nb::arg("output_grad_weights"),
        nb::arg("input_vector"),
        nb::arg("input_rbf"),
        nb::arg("input_grad_grad_rbf"),
        nb::arg("input_embedding"),
        nb::arg("input_grad_grad_embedding"),
        nb::arg("input_grad_embedding"),
        nb::arg("input_weights"),
        nb::arg("coo_idx"),
        nb::arg("src_offsets"),
        nb::arg("mma_op"),
        nb::arg("stream_id") = 0,
        nb::raw_doc(AGG_EDGE_TO_EDGE_BWD2_MAIN_DOC));
}
