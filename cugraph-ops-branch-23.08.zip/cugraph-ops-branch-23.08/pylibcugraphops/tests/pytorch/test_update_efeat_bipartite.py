# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import BipartiteCSC
from pylibcugraphops.pytorch.operators import update_efeat_bipartite_e2e

device = torch.device("cuda:0")
graph_data = {
    "num_src_nodes": 10,
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}


@pytest.mark.parametrize("mode", ["concat", "sum"])
@pytest.mark.parametrize("needs_grad_src_feat", [False, True])
@pytest.mark.parametrize("needs_grad_dst_feat", [False, True])
@pytest.mark.parametrize("needs_grad_edge_feat", [False, True])
@pytest.mark.parametrize("reverse_graph_bwd", [False, True])
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
@pytest.mark.filterwarnings("ignore::UserWarning")
def test_update_efeat_bipartite_gradcheck(
    mode,
    needs_grad_src_feat,
    needs_grad_dst_feat,
    needs_grad_edge_feat,
    reverse_graph_bwd,
    idx_type,
):
    if not (needs_grad_src_feat or needs_grad_dst_feat or needs_grad_edge_feat):
        assert True
        return

    graph = BipartiteCSC(
        offsets=graph_data["offsets"].to(idx_type),
        indices=graph_data["indices"].to(idx_type),
        num_src_nodes=graph_data["num_src_nodes"],
        reverse_graph_bwd=reverse_graph_bwd,
    )

    torch.manual_seed(0)
    dim = 32
    src_feat = torch.rand(graph.num_src_nodes, dim, device=device)
    dst_feat = torch.rand(graph.num_dst_nodes, dim, device=device)
    edge_feat = torch.rand(graph.num_edges, dim, device=device)

    src_feat.requires_grad_(needs_grad_src_feat)
    dst_feat.requires_grad_(needs_grad_dst_feat)
    edge_feat.requires_grad_(needs_grad_edge_feat)

    torch.autograd.gradcheck(
        lambda x, y, z: update_efeat_bipartite_e2e(x, y, z, graph, mode),
        (edge_feat, src_feat, dst_feat),
        atol=0.25,
        rtol=0.1,
    )
