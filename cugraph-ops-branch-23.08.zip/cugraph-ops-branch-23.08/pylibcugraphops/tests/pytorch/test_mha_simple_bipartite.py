# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import BipartiteCSC
from pylibcugraphops.pytorch.operators import mha_simple_n2n

from utils import check_zero_degree_outputs

device = torch.device("cuda:0")

graph_data = {
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
    "num_src_nodes": 10,
}


@pytest.mark.parametrize("num_heads", [1, 2, 4, 4, 8])
@pytest.mark.parametrize("concat_heads", [True, False])
@pytest.mark.parametrize("use_bias", [True, False])
@pytest.mark.parametrize("use_edge_emb", [True, False])
@pytest.mark.parametrize("norm_by_dim", [True, False])
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
@pytest.mark.filterwarnings("ignore::UserWarning")
def test_mha_simple_bipartite_gradcheck(
    num_heads, concat_heads, use_bias, use_edge_emb, norm_by_dim, idx_type
):
    graph = BipartiteCSC(
        offsets=graph_data["offsets"].to(idx_type),
        indices=graph_data["indices"].to(idx_type),
        num_src_nodes=graph_data["num_src_nodes"],
    )

    kwargs = {
        "num_heads": num_heads,
        "concat_heads": concat_heads,
        "norm_by_dim": norm_by_dim,
    }

    dim_head = 16
    dim = dim_head * num_heads

    torch.manual_seed(0)
    key_feat = torch.randn(graph.num_src_nodes, dim, device=device)
    value_feat = torch.randn(graph.num_src_nodes, dim, device=device)
    query_feat = torch.randn(graph.num_dst_nodes, dim, device=device)
    key_feat.requires_grad_()
    value_feat.requires_grad_()
    query_feat.requires_grad_()

    if use_bias:
        score_bias = torch.randn(num_heads, graph.num_edges, device=device)
        score_bias.requires_grad_()
    else:
        score_bias = None

    if use_edge_emb:
        edge_embedding = torch.randn(graph.num_edges, dim, device=device)
        edge_embedding.requires_grad_()
    else:
        edge_embedding = None

    output = mha_simple_n2n(
        key_feat,
        query_feat,
        value_feat,
        graph,
        edge_emb=edge_embedding,
        score_bias=score_bias,
        **kwargs
    )
    check_zero_degree_outputs(output, graph.offsets)

    torch.autograd.gradcheck(
        lambda k, q, v, e, b: mha_simple_n2n(
            k, q, v, graph, edge_emb=e, score_bias=b, **kwargs
        ),
        (key_feat, query_feat, value_feat, edge_embedding, score_bias),
        atol=1.0,
        rtol=0.1,
    )
