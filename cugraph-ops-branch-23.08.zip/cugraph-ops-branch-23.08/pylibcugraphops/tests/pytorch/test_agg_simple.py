# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import SampledCSC, StaticCSC
from pylibcugraphops.pytorch.operators import agg_simple_n2n

from utils import check_zero_degree_outputs

device = torch.device("cuda:0")

aggr_options = ["max", "mean", "min", "sum"]

sampled_data = {
    "num_src_nodes": 10,
    "num_dst_nodes": 8,
    "max_num_neighbors": 8,
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}

static_data = {
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15, 15, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}


@pytest.mark.parametrize("aggr", aggr_options)
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
def test_agg_simple_n2n_equality(idx_type, aggr):
    offsets = static_data["offsets"].to(dtype=idx_type)
    indices = static_data["indices"].to(dtype=idx_type)
    static_graph = StaticCSC(offsets=offsets, indices=indices)

    sampled_graph = SampledCSC(
        sampled_data["offsets"].to(idx_type),
        sampled_data["indices"].to(idx_type),
        sampled_data["max_num_neighbors"],
        sampled_data["num_src_nodes"],
    )

    num_src_nodes = sampled_data["num_src_nodes"]
    num_dst_nodes = sampled_data["offsets"].size(0) - 1

    dim = 32
    torch.manual_seed(0)
    feat_static = torch.rand(num_src_nodes, dim, device=device)
    feat_static.requires_grad_()
    feat_sampled = feat_static.detach().clone()
    feat_sampled.requires_grad_()

    output_static = agg_simple_n2n(feat_static, static_graph, aggr)
    output_sampled = agg_simple_n2n(feat_sampled, sampled_graph, aggr)

    check_zero_degree_outputs(output_static, static_graph.offsets)
    assert torch.allclose(output_static[:num_dst_nodes], output_sampled)

    grad_output_static = torch.rand_like(output_static)
    grad_output_static[num_dst_nodes:] = 0
    grad_output_sampled = grad_output_static[:num_dst_nodes]

    output_sampled.backward(grad_output_sampled)
    output_static.backward(grad_output_static)
    assert torch.allclose(feat_static.grad, feat_sampled.grad)
