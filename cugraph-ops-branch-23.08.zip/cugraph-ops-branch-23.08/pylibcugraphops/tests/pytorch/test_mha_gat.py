# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import StaticCSC, SampledCSC
from pylibcugraphops.pytorch.operators import mha_gat_n2n

from utils import check_zero_degree_outputs

device = torch.device("cuda:0")

activations = ["ELU", "LeakyReLU", "Linear", "ReLU", "Scalar", "Sigmoid", "Tanh"]

sampled_data = {
    "num_src_nodes": 10,
    "num_dst_nodes": 8,
    "max_num_neighbors": 8,
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}

static_data = {
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15, 15, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}


@pytest.mark.parametrize("num_heads", [1, 2, 3, 5])
@pytest.mark.parametrize("concat_heads", [True, False])
@pytest.mark.parametrize("activation", activations)
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
def test_mha_gat_n2n_equality(idx_type, activation, concat_heads, num_heads):
    offsets = static_data["offsets"].to(dtype=idx_type)
    indices = static_data["indices"].to(dtype=idx_type)
    static_graph = StaticCSC(offsets=offsets, indices=indices)

    sampled_graph = SampledCSC(
        offsets=sampled_data["offsets"].to(idx_type),
        indices=sampled_data["indices"].to(idx_type),
        max_num_neighbors=sampled_data["max_num_neighbors"],
        num_src_nodes=sampled_data["num_src_nodes"],
    )

    kwargs = {
        "num_heads": num_heads,
        "activation": activation,
        "concat_heads": concat_heads,
    }

    num_src_nodes = sampled_data["num_src_nodes"]
    num_dst_nodes = sampled_data["offsets"].size(0) - 1
    dim_head = 16
    dim = dim_head * num_heads

    torch.manual_seed(0)
    feat_static = torch.rand(num_src_nodes, dim, device=device)
    feat_static.requires_grad_()
    feat_sampled = feat_static.detach().clone()
    feat_sampled.requires_grad_()

    attn_weights_static = torch.rand(2 * dim, device=device)
    attn_weights_static.requires_grad_()
    attn_weights_sampled = attn_weights_static.detach().clone()
    attn_weights_sampled.requires_grad_()

    output_static = mha_gat_n2n(
        feat_static, attn_weights_static, static_graph, **kwargs
    )
    output_sampled = mha_gat_n2n(
        feat_sampled, attn_weights_sampled, sampled_graph, **kwargs
    )

    assert torch.allclose(output_static[:num_dst_nodes], output_sampled)

    check_zero_degree_outputs(output_static, static_graph.offsets)

    grad_output_static = torch.rand_like(output_static)
    grad_output_static[num_dst_nodes:] = 0
    grad_output_sampled = grad_output_static[:num_dst_nodes]

    output_sampled.backward(grad_output_sampled)
    output_static.backward(grad_output_static)
    assert torch.allclose(feat_static.grad, feat_sampled.grad, atol=1e-06)
    assert torch.allclose(
        attn_weights_static.grad, attn_weights_sampled.grad, atol=1e-06
    )
