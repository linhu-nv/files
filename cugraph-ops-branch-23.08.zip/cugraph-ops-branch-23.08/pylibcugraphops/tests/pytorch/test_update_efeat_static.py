# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import StaticCSC
from pylibcugraphops.pytorch.operators import update_efeat_static_e2e

device = torch.device("cuda:0")
graph_data = {
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15, 15, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}


@pytest.mark.parametrize("mode", ["concat", "sum"])
@pytest.mark.parametrize("needs_grad_node_feat", [False, True])
@pytest.mark.parametrize("needs_grad_edge_feat", [False, True])
@pytest.mark.parametrize("use_src_dst", [(True, True), (False, True), (True, False)])
@pytest.mark.parametrize("reverse_graph_bwd", [False, True])
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
@pytest.mark.filterwarnings("ignore::UserWarning")
def test_update_efeat_static_gradcheck(
    mode,
    needs_grad_edge_feat,
    needs_grad_node_feat,
    use_src_dst,
    reverse_graph_bwd,
    idx_type,
):
    if not (needs_grad_node_feat or needs_grad_node_feat):
        assert True
        return

    graph = StaticCSC(
        offsets=graph_data["offsets"].to(idx_type),
        indices=graph_data["indices"].to(idx_type),
        reverse_graph_bwd=reverse_graph_bwd,
    )

    torch.manual_seed(0)
    dim = 32
    node_feat = torch.rand(graph.num_nodes, dim, device=device)
    edge_feat = torch.rand(graph.num_edges, dim, device=device)

    node_feat.requires_grad_(needs_grad_node_feat)
    edge_feat.requires_grad_(needs_grad_edge_feat)

    use_source_emb, use_target_emb = use_src_dst

    torch.autograd.gradcheck(
        lambda x, y: update_efeat_static_e2e(
            x, y, graph, use_source_emb, use_target_emb, mode
        ),
        (edge_feat, node_feat),
        atol=0.25,
        rtol=0.1,
    )
