# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import StaticCSC
from pylibcugraphops.pytorch.operators import agg_simple_n2n_e2n

from utils import check_zero_degree_outputs

device = torch.device("cuda:0")

aggr_options = ["max", "mean", "min", "sum"]

graph_data = {
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15, 15, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}


@pytest.mark.parametrize("aggr", aggr_options)
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
@pytest.mark.filterwarnings("ignore::UserWarning")
def test_agg_simple_n2n_e2n_gradcheck(idx_type, aggr):
    offsets = graph_data["offsets"].to(dtype=idx_type)
    indices = graph_data["indices"].to(dtype=idx_type)
    graph = StaticCSC(offsets=offsets, indices=indices)

    dim_edge = 32
    dim_node = 16
    torch.manual_seed(0)
    node_feat = torch.rand(graph.num_nodes, dim_node, device=device)
    edge_feat = torch.rand(graph.num_edges, dim_edge, device=device)
    node_feat.requires_grad_()
    edge_feat.requires_grad_()

    output = agg_simple_n2n_e2n(node_feat, edge_feat, graph, aggr=aggr)
    check_zero_degree_outputs(output, graph.offsets)

    torch.autograd.gradcheck(
        lambda x, y: agg_simple_n2n_e2n(x, y, graph, aggr=aggr),
        (node_feat, edge_feat),
        atol=0.25,
        rtol=0.1,
    )
