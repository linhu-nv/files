# Copyright (c) 2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch
from pylibcugraphops.pytorch import BipartiteCSC
from pylibcugraphops.pytorch.operators import mha_gat_v2_n2n_bipartite

from utils import check_zero_degree_outputs

device = torch.device("cuda:0")

activations = ["ELU", "LeakyReLU", "Linear", "ReLU", "Scalar", "Sigmoid", "Tanh"]

graph_data = {
    "num_src_nodes": 10,
    "offsets": torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 15], device=device),
    "indices": torch.tensor(
        [9, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8], device=device
    ),
}


@pytest.mark.parametrize("num_heads", [1, 2, 3, 5])
@pytest.mark.parametrize("concat_heads", [True, False])
@pytest.mark.parametrize("activation", activations)
@pytest.mark.parametrize("use_edge_feat", [True, False])
@pytest.mark.parametrize("idx_type", [torch.int64, torch.int32])
@pytest.mark.filterwarnings("ignore::UserWarning")
def test_mha_gat_v2_bipartite_gradcheck(
    idx_type, use_edge_feat, activation, concat_heads, num_heads
):
    offsets = graph_data["offsets"].to(dtype=idx_type)
    indices = graph_data["indices"].to(dtype=idx_type)

    graph = BipartiteCSC(
        offsets=offsets, indices=indices, num_src_nodes=graph_data["num_src_nodes"]
    )

    kwargs = {
        "num_heads": num_heads,
        "activation": activation,
        "concat_heads": concat_heads,
    }

    dim_head = 16
    dim = dim_head * num_heads

    torch.manual_seed(0)
    src_feat = torch.rand(graph.num_src_nodes, dim, device=device)
    dst_feat = torch.rand(graph.num_dst_nodes, dim, device=device)
    src_feat.requires_grad_()
    dst_feat.requires_grad_()

    if use_edge_feat:
        edge_feat = torch.rand(graph.num_edges, dim, device=device)
        edge_feat.requires_grad_()
    else:
        edge_feat = None

    attn_weights = torch.rand(dim, device=device)
    attn_weights.requires_grad_()

    output = mha_gat_v2_n2n_bipartite(
        src_feat, dst_feat, attn_weights, graph, edge_feat=edge_feat, **kwargs
    )
    check_zero_degree_outputs(output, graph.offsets)

    torch.autograd.gradcheck(
        lambda x, y, w, e: mha_gat_v2_n2n_bipartite(
            x, y, w, graph, edge_feat=e, **kwargs
        ),
        (src_feat, dst_feat, attn_weights, edge_feat),
        atol=0.25,
        rtol=0.1,
    )
