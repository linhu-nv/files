# Copyright (c) 2022-2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pylibcugraphops.binding.pylibcugraphops_test_ext as test_ext

import pytest


class SpoofCAI(object):
    always_error = False

    def __init__(self, cai):
        self.cai = cai

    @property
    def __cuda_array_interface__(self):
        return self.cai


class SpoofCAIWrong(object):
    always_error = True
    test = 0

    def __init__(self, cai):
        super().__init__()
        self.ptr = cai["data"][0]
        self.test_v = SpoofCAIWrong.test % 6
        SpoofCAIWrong.test += 1

    @property
    def __cuda_array_interface__(self):
        if self.test_v == 0:
            return None
        if self.test_v == 1:
            return ["shape", "typestr", "data"]
        if self.test_v == 2:
            return {"shape": (2, 3), "typestr": None, "data": None}
        if self.test_v == 3:
            return {"shape": (2, 3), "typestr": "abcd", "data": None}
        if self.test_v == 4:
            return {"shape": ("hello",), "typestr": "<u1", "data": (self.ptr, False)}
        return {"shape": [2, 3], "typestr": "abcd", "data": ("hello", False)}


class SpoofWrongDLPack(object):
    always_error = True
    test = 0

    def __init__(self, cai):
        self.cai = cai
        self.test_v = SpoofWrongDLPack.test % 4
        SpoofWrongDLPack.test += 1

    def __dlpack__(self):
        if self.test_v == 0:
            return None
        if self.test_v == 1:
            return 2
        if self.test_v == 2:
            return object()
        return self


class SpoofWrongDLPackAddCAI(SpoofWrongDLPack):
    always_error = False

    def __init__(self, cai, correct_CAI=True):
        super().__init__(cai)
        self.correct_CAI = correct_CAI
        SpoofWrongDLPackAddCAI.always_error = not correct_CAI

    @property
    def __cuda_array_interface__(self):
        if self.correct_CAI:
            return self.cai
        return None


class SpoofWrongDLPackAddWrongCAI(SpoofWrongDLPackAddCAI):
    def __init__(self, cai):
        super().__init__(cai, correct_CAI=False)


def _helper_test(obj, **kwargs):
    if obj.always_error:
        with pytest.raises(TypeError):
            test_ext.test_single_object(obj, **kwargs)
    else:
        assert test_ext.test_single_object(obj, **kwargs)


def _helper_test_value_error(obj, **kwargs):
    if obj.always_error:
        with pytest.raises(TypeError):
            test_ext.test_single_object(obj, **kwargs)
    else:
        with pytest.raises(ValueError):
            test_ext.test_single_object(obj, **kwargs)


def _to_typestr(code, bits, lanes):
    if code == 0:
        cai_code = "i"
    elif code == 1:
        cai_code = "u"
    elif code == 2:
        cai_code = "f"
    elif code == 5:
        cai_code = "c"
    else:
        cai_code = "V"

    return "<{}{}".format(cai_code, lanes * bits // 8)


def test_none():
    # test some additional wrong formats here first
    ptr = test_ext.CudaPtr(0)
    d1 = SpoofCAI(
        {
            "shape": [1, 2],
            "typestr": 2,
            "data": [0, "test"],
            "version": 3,
            "strides": "hello",
        }
    )
    d2 = SpoofCAI(
        {
            "shape": (1, 2),
            "typestr": 2,
            "data": [0, "test"],
            "version": 3,
            "strides": "hello",
        }
    )
    d3 = SpoofCAI(
        {
            "shape": (1, 2),
            "typestr": "<u1",
            "data": [0, "test"],
            "version": 3,
            "strides": "hello",
        }
    )
    d4 = SpoofCAI(
        {
            "shape": (1, 2),
            "typestr": "<u1",
            "data": (0, "test"),
            "version": 3,
            "strides": "hello",
        }
    )
    d5 = SpoofCAI(
        {
            "shape": (1, 2),
            "typestr": "<u1",
            "data": (0, False),
            "version": 3,
            "strides": "hello",
        }
    )
    for d in [d1, d2, d3, d4, d5]:
        with pytest.raises(TypeError):
            test_ext.test_single_object(
                d,
                exp_n_dim=0,
                exp_d1=0,
                exp_d2=0,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
            )
    for c_type in [
        SpoofCAI,
        SpoofCAIWrong,
        SpoofWrongDLPack,
        SpoofWrongDLPackAddCAI,
        SpoofWrongDLPackAddWrongCAI,
    ]:
        cai = {
            "shape": (1, 1),
            "typestr": "<i1",
            "data": (ptr.get(), False),
            "version": 3,
            "strides": None,
        }
        d = c_type(cai)
        # tests with None values are already in test_dlpack

        # not None and allow_none, values as expected
        _helper_test(
            d,
            exp_n_dim=2,
            exp_d1=1,
            exp_d2=1,
            exp_dtype_code=0,
            exp_dtype_bits=8,
            exp_dtype_lanes=1,
            allow_none=True,
        )
        # not None and allow_none, values not as expected
        _helper_test_value_error(
            d,
            exp_n_dim=0,
            exp_d1=0,
            exp_d2=0,
            exp_dtype_code=0,
            exp_dtype_bits=0,
            exp_dtype_lanes=0,
            allow_none=True,
        )
        # not None and not allow_none, values as expected
        _helper_test(
            d,
            exp_n_dim=2,
            exp_d1=1,
            exp_d2=1,
            exp_dtype_code=0,
            exp_dtype_bits=8,
            exp_dtype_lanes=1,
            allow_none=False,
        )
        # not None and not allow_none, values not as expected
        _helper_test_value_error(
            d,
            exp_n_dim=0,
            exp_d1=0,
            exp_d2=0,
            exp_dtype_code=0,
            exp_dtype_bits=0,
            exp_dtype_lanes=0,
            allow_none=False,
        )


def test_devices():
    for code in range(4):
        ptr = test_ext.CudaPtr(code)
        for c_type in [
            SpoofCAI,
            SpoofCAIWrong,
            SpoofWrongDLPack,
            SpoofWrongDLPackAddCAI,
            SpoofWrongDLPackAddWrongCAI,
        ]:
            cai = {
                "shape": (1, 1),
                "typestr": "<i1",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
            d = c_type(cai)
            if cai["data"][0] == 0:
                _helper_test_value_error(
                    d,
                    exp_n_dim=2,
                    exp_d1=1,
                    exp_d2=1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            else:
                _helper_test(
                    d,
                    exp_n_dim=2,
                    exp_d1=1,
                    exp_d2=1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )


def test_dtype():
    ptr = test_ext.CudaPtr(0)
    for c_type in [
        SpoofCAI,
        SpoofCAIWrong,
        SpoofWrongDLPack,
        SpoofWrongDLPackAddCAI,
        SpoofWrongDLPackAddWrongCAI,
    ]:
        d1 = c_type(
            {
                "shape": (1, 1),
                "typestr": "<x256",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
        )
        d2 = c_type(
            {
                "shape": (1, 1),
                "typestr": "<x2",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
        )
        d3 = c_type(
            {
                "shape": (1, 1),
                "typestr": "<u5x",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
        )
        d4 = c_type(
            {
                "shape": (1, 1),
                "typestr": "<u64",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
        )
        for d in [d1, d2, d3, d4]:
            _helper_test_value_error(
                d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
            )
        # CAI does not support lanes > 1 or bits % 8 != 0
        for code, bits, lanes in [(0, 8, 1), (1, 64, 1), (2, 32, 1)]:
            cai = {
                "shape": (1, 1),
                "typestr": _to_typestr(code, bits, lanes),
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
            d = c_type(cai)
            # code/bits/lanes 0 should accept any data type
            _helper_test(
                d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
            )
            _helper_test(
                d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=code,
                exp_dtype_bits=bits,
                exp_dtype_lanes=lanes,
            )
            _helper_test_value_error(
                d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=4,
                exp_dtype_bits=1,
                exp_dtype_lanes=5,
            )
            _helper_test_value_error(
                d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=code,
                exp_dtype_bits=1,
                exp_dtype_lanes=5,
            )
            _helper_test_value_error(
                d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=code,
                exp_dtype_bits=bits,
                exp_dtype_lanes=5,
            )


def test_dim():
    ptr = test_ext.CudaPtr(0)
    for c_type in [
        SpoofCAI,
        SpoofCAIWrong,
        SpoofWrongDLPack,
        SpoofWrongDLPackAddCAI,
        SpoofWrongDLPackAddWrongCAI,
    ]:
        for d1, d2 in [(0, 8), (1, 4), (2, 32)]:
            cai = {
                "shape": (d1, d2),
                "typestr": "<i1",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": None,
            }
            d = c_type(cai)
            # n_dim negative should accept any dimension and shape
            _helper_test(
                d,
                exp_n_dim=-1,
                exp_d1=-1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            _helper_test(
                d,
                exp_n_dim=-1,
                exp_d1=15,
                exp_d2=15,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # dim < 0 should accept any size
            _helper_test(
                d,
                exp_n_dim=2,
                exp_d1=-1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            _helper_test(
                d,
                exp_n_dim=2,
                exp_d1=-1,
                exp_d2=d2,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            _helper_test(
                d,
                exp_n_dim=2,
                exp_d1=d1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # correct dimensions
            _helper_test(
                d,
                exp_n_dim=2,
                exp_d1=d1,
                exp_d2=d2,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # incorrect number of dimensions
            _helper_test_value_error(
                d,
                exp_n_dim=1,
                exp_d1=d1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            _helper_test_value_error(
                d,
                exp_n_dim=0,
                exp_d1=d1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # incorrect dimension 1
            _helper_test_value_error(
                d,
                exp_n_dim=2,
                exp_d1=d1 + 1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # incorrect dimension 2
            _helper_test_value_error(
                d,
                exp_n_dim=2,
                exp_d1=d1,
                exp_d2=d2 + 1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )


def test_strides():
    ptr = test_ext.CudaPtr(0)
    for c_type in [
        SpoofCAI,
        SpoofCAIWrong,
        SpoofWrongDLPack,
        SpoofWrongDLPackAddCAI,
        SpoofWrongDLPackAddWrongCAI,
    ]:
        for st1, st2 in [(3, 1), (5, 3), (5, 1), (1, 1)]:
            cai = {
                "shape": (5, 3),
                "typestr": "<i1",
                "data": (ptr.get(), False),
                "version": 3,
                "strides": (st1, st2),
            }
            d = c_type(cai)
            # strides (3, 1) are OK, all others should fail
            if st1 == 3 and st2 == 1:
                _helper_test(
                    d,
                    exp_n_dim=2,
                    exp_d1=5,
                    exp_d2=3,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            else:
                _helper_test_value_error(
                    d,
                    exp_n_dim=2,
                    exp_d1=5,
                    exp_d2=3,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
