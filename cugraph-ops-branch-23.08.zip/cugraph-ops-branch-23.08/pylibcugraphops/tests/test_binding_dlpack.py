# Copyright (c) 2022-2023, NVIDIA CORPORATION.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# we use spoofed DLPack classes
import pylibcugraphops.binding.pylibcugraphops_test_ext as test_ext

import pytest


class AddCAI(test_ext.SpoofDLPack):
    def __init__(self, d1, d2, dtype_code, dtype_bits, dtype_lanes,
                 device_code, st1=0, st2=0, correct_CAI=True):
        super().__init__(
            d1, d2, dtype_code, dtype_bits, dtype_lanes, device_code,
            st1=st1, st2=st2
        )
        self.correct_CAI = correct_CAI
        self.d1 = d1
        self.d2 = d2

    @property
    def __cuda_array_interface__(self):
        if self.correct_CAI:
            return {'shape': [self.d1, self.d2], 'typestr': '|u1', 'data': (0, True)}
        return ['shape', 'typestr', 'data']


class AddWrongCAI(AddCAI):
    def __init__(self, d1, d2, dtype_code, dtype_bits, dtype_lanes, device_code,
                 st1=0, st2=0):
        super().__init__(
            d1, d2, dtype_code, dtype_bits, dtype_lanes, device_code,
            st1=st1, st2=st2, correct_CAI=False
        )


def test_none():
    for c_type in [test_ext.SpoofDLPack, AddCAI, AddWrongCAI]:
        # DLPack object on CUDA device
        d = c_type(
            d1=1,
            d2=1,
            dtype_code=0,
            dtype_bits=8,
            dtype_lanes=1,
            device_code=2
        )
        # None and all values as expected
        assert test_ext.test_single_object(
            obj=None,
            exp_n_dim=2,
            exp_d1=1,
            exp_d2=1,
            exp_dtype_code=0,
            exp_dtype_bits=8,
            exp_dtype_lanes=1,
            allow_none=True
        )
        # None and values not as expected
        assert test_ext.test_single_object(
            obj=None,
            exp_n_dim=0,
            exp_d1=0,
            exp_d2=0,
            exp_dtype_code=0,
            exp_dtype_bits=0,
            exp_dtype_lanes=0,
            allow_none=True
        )
        # None and not allow_none
        with pytest.raises(ValueError):
            test_ext.test_single_object(
                obj=None,
                exp_n_dim=0,
                exp_d1=0,
                exp_d2=0,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
                allow_none=False
            )
        # not None and allow_none, values as expected
        assert test_ext.test_single_object(
            obj=d,
            exp_n_dim=2,
            exp_d1=1,
            exp_d2=1,
            exp_dtype_code=0,
            exp_dtype_bits=8,
            exp_dtype_lanes=1,
            allow_none=True
        )
        # not None and allow_none, values not as expected
        with pytest.raises(ValueError):
            test_ext.test_single_object(
                obj=d,
                exp_n_dim=0,
                exp_d1=0,
                exp_d2=0,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
                allow_none=True
            )
        # not None and not allow_none, values as expected
        assert test_ext.test_single_object(
            obj=d,
            exp_n_dim=2,
            exp_d1=1,
            exp_d2=1,
            exp_dtype_code=0,
            exp_dtype_bits=8,
            exp_dtype_lanes=1,
            allow_none=False
        )
        # not None and not allow_none, values not as expected
        with pytest.raises(ValueError):
            test_ext.test_single_object(
                obj=d,
                exp_n_dim=0,
                exp_d1=0,
                exp_d2=0,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
                allow_none=False
            )


def test_devices():
    for c_type in [test_ext.SpoofDLPack, AddCAI, AddWrongCAI]:
        # there are 16 DLPack devices for v0.7. 0 is reserved but still tested
        for code in range(17):
            # DLPack object on requested device
            d = c_type(
                d1=1,
                d2=1,
                dtype_code=0,
                dtype_bits=8,
                dtype_lanes=1,
                device_code=code
            )
            if code == 2 or code == 3 or code == 13:
                assert test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=1,
                    exp_d2=1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            else:
                with pytest.raises(ValueError):
                    test_ext.test_single_object(
                        obj=d,
                        exp_n_dim=2,
                        exp_d1=1,
                        exp_d2=1,
                        exp_dtype_code=0,
                        exp_dtype_bits=8,
                        exp_dtype_lanes=1,
                    )


def test_dtype():
    for c_type in [test_ext.SpoofDLPack, AddCAI, AddWrongCAI]:
        # DLPack object on CUDA device
        for code, bits, lanes in [(0, 8, 1), (1, 4, 8), (2, 32, 2)]:
            d = c_type(
                d1=1,
                d2=1,
                dtype_code=code,
                dtype_bits=bits,
                dtype_lanes=lanes,
                device_code=2
            )
            # code/bits/lanes 0 should accept any data type
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=0,
                exp_dtype_bits=0,
                exp_dtype_lanes=0,
            )
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=2,
                exp_d1=1,
                exp_d2=1,
                exp_dtype_code=code,
                exp_dtype_bits=bits,
                exp_dtype_lanes=lanes,
            )
            with pytest.raises(ValueError):
                # code not matching
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=1,
                    exp_d2=1,
                    exp_dtype_code=4,
                    exp_dtype_bits=1,
                    exp_dtype_lanes=5,
                )
            with pytest.raises(ValueError):
                # bits not matching
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=1,
                    exp_d2=1,
                    exp_dtype_code=code,
                    exp_dtype_bits=1,
                    exp_dtype_lanes=5,
                )
            with pytest.raises(ValueError):
                # lanes not matching
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=1,
                    exp_d2=1,
                    exp_dtype_code=code,
                    exp_dtype_bits=bits,
                    exp_dtype_lanes=5,
                )


def test_dim():
    for c_type in [test_ext.SpoofDLPack, AddCAI, AddWrongCAI]:
        # DLPack object on CUDA device
        for d1, d2 in [(0, 8), (1, 4), (2, 32)]:
            d = c_type(
                d1=d1,
                d2=d2,
                dtype_code=0,
                dtype_bits=8,
                dtype_lanes=1,
                device_code=2
            )
            # n_dim negative should accept any dimension and shape
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=-1,
                exp_d1=-1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=-1,
                exp_d1=15,
                exp_d2=15,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # dim < 0 should accept any size
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=2,
                exp_d1=-1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=2,
                exp_d1=-1,
                exp_d2=d2,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=2,
                exp_d1=d1,
                exp_d2=-1,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # correct dimensions
            assert test_ext.test_single_object(
                obj=d,
                exp_n_dim=2,
                exp_d1=d1,
                exp_d2=d2,
                exp_dtype_code=0,
                exp_dtype_bits=8,
                exp_dtype_lanes=1,
            )
            # incorrect number of dimensions
            with pytest.raises(ValueError):
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=1,
                    exp_d1=d1,
                    exp_d2=-1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            with pytest.raises(ValueError):
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=0,
                    exp_d1=d1,
                    exp_d2=-1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            # incorrect dimension 1
            with pytest.raises(ValueError):
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=d1 + 1,
                    exp_d2=-1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            # incorrect dimension 2
            with pytest.raises(ValueError):
                test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=d1,
                    exp_d2=d2 + 1,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )


def test_strides():
    for c_type in [test_ext.SpoofDLPack, AddCAI, AddWrongCAI]:
        # DLPack object on CUDA device
        for st1, st2 in [(1, 1), (4, 1), (1, 4), (4, 4), (5, 1), (0, 0), (-1, -1)]:
            d = c_type(
                d1=4,
                d2=4,
                dtype_code=0,
                dtype_bits=8,
                dtype_lanes=1,
                device_code=2,
                st1=st1,
                st2=st2
            )
            # strides (4, 1) are OK, double 0 means any stride, so they pass as well.
            # all others should fail
            if (st1 == 4 and st2 == 1) or (st1 == 0 and st2 == 0):
                assert test_ext.test_single_object(
                    obj=d,
                    exp_n_dim=2,
                    exp_d1=4,
                    exp_d2=4,
                    exp_dtype_code=0,
                    exp_dtype_bits=8,
                    exp_dtype_lanes=1,
                )
            else:
                with pytest.raises(ValueError):
                    test_ext.test_single_object(
                        obj=d,
                        exp_n_dim=2,
                        exp_d1=4,
                        exp_d2=4,
                        exp_dtype_code=0,
                        exp_dtype_bits=8,
                        exp_dtype_lanes=1,
                    )
